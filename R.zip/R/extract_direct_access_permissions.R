#' Direct Access Berechtigungen extrahieren
#'
#' Extrahiert sämtliche Direct Access Berechtigungen
#' eines D365FO Security Privileges.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit allen Direct Access Berechtigungen.
#'
#' @details
#' Die Funktion extrahiert sämtliche Knoten unterhalb
#' von DirectAccessPermissions.
#'
#' Leere Ergebnisse werden als Tibble mit definierter
#' Struktur zurückgegeben.
#'
#' @seealso
#' parse_privilege()
#' extract_direct_access_fields()
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#'
#' permissions <-
#'   extract_direct_access_permissions(
#'     xml_doc
#'   )
#' }
#'
#' @export
extract_direct_access_permissions <- function(xml_doc) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # =========================================
  # DIRECT ACCESS EXTRAHIEREN
  # =========================================

  direct_access <- xml2::xml_find_all(
    xml_doc,
    "//DirectAccessPermissions/*"
  )

  result <- purrr::map_dfr(direct_access, function(node) {

    grant_node <- xml2::xml_find_first(
      node,
      "./Grant"
    )

    tibble::tibble(
      XmlNode = xml2::xml_name(node),

      ObjectName = xml2::xml_text(
        xml2::xml_find_first(node, "./Name")
      ),

      Read = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Read")
      ),

      Create = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Create")
      ),

      Update = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Update")
      ),

      Delete = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Delete")
      ),

      Correct = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Correct")
      ),

      Invoke = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Invoke")
      )
    )
  })

  # =========================================
  # LEERE STRUKTUR ABSICHERN
  # =========================================

  if (ncol(result) == 0) {
    result <- empty_direct_access_permissions()
  }

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}
