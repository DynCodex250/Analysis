#' Compare form data sources between two D365FO form documentations
#'
#' Compares the data sources of two
#' \code{D365FormDocumentation} objects.
#'
#' The function identifies newly added and
#' removed data sources by comparing the
#' logical form structure.
#'
#' @param old_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the original form documentation.
#'
#' @param new_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the updated form documentation.
#'
#' @return A list containing:
#' \describe{
#'   \item{Added}{
#'     Data sources that exist only in the new documentation.
#'   }
#'   \item{Removed}{
#'     Data sources that exist only in the old documentation.
#'   }
#' }
#'
#' @details
#' The function compares the
#' \code{DataSources} tables of two
#' \code{D365FormDocumentation} objects.
#'
#' Data sources are uniquely identified
#' by their DataSource name.
#'
#' Typical use cases:
#'
#' \itemize{
#'   \item Detect newly introduced data sources.
#'   \item Identify removed data sources after updates.
#'   \item Compare customized forms.
#'   \item Validate structural changes between environments.
#' }
#'
#' @examples
#' \dontrun{
#'
#' comparison <-
#'   compare_form_datasources(
#'     old_documentation,
#'     new_documentation
#'   )
#'
#' comparison$Added
#'
#' comparison$Removed
#'
#' }
#'
#' @export
compare_form_datasources <- function(
    old_documentation,
    new_documentation
) {
  
  #===========================================================
  # VALIDATE INPUT PARAMETERS
  #===========================================================
  
  if (!inherits(
    old_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "old_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  if (!inherits(
    new_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "new_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  #===========================================================
  # LOAD DATA SOURCES
  #===========================================================
  
  old_datasources <-
    old_documentation$DataSources
  
  new_datasources <-
    new_documentation$DataSources
  
  #===========================================================
  # ADDED DATA SOURCES
  #===========================================================
  
  added <-
    
    dplyr::anti_join(
      new_datasources,
      old_datasources,
      by = "DataSource"
    )
  
  #===========================================================
  # REMOVED DATA SOURCES
  #===========================================================
  
  removed <-
    
    dplyr::anti_join(
      old_datasources,
      new_datasources,
      by = "DataSource"
    )
  
  #===========================================================
  # RESULT
  #===========================================================
  
  result <-
    
    list(
      Added = added,
      Removed = removed
    )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  return(result)
  
}