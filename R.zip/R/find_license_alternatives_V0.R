#' Lizenzfreundliche Privilege-Alternativen ermitteln
#'
#' Identifiziert für lizenzkritische Privileges mögliche
#' Alternativen mit geringerem Access Level.
#'
#' Die Funktion untersucht alle Privileges mit
#' `NOTENTITLED > 0` und sucht nach weiteren Privileges,
#' die dasselbe Entry Point bzw. MenuItem (`AOTNAME`)
#' verwenden.
#'
#' Ziel ist die Identifikation vorhandener Microsoft-
#' Standardprivileges, die möglicherweise eine
#' Activity-Lizenz unterstützen und dadurch eine
#' Alternative zu Maintain-Privileges darstellen.
#'
#' Typischerweise werden hierbei Beziehungen wie
#'
#' \preformatted{
#' WHSLOADPLANNINGWORKBENCHMAINTAIN
#'              ↓
#' WHSLOADPLANNINGWORKBENCH
#'              ↓
#' WHSLOADPLANNINGWORKBENCHVIEW
#' }
#'
#' sichtbar.
#'
#' Die Funktion dient als erster Schritt einer
#' Lizenzoptimierungsanalyse und hilft dabei zu
#' entscheiden, ob vorhandene Standardprivileges
#' verwendet werden können oder kundenspezifische
#' Security-Objekte erstellt werden müssen.
#'
#' @param licenses Tibble mit den Ergebnissen von
#'   `get_license_requirements()`.
#'
#'   Die Tabelle muss mindestens folgende Spalten
#'   enthalten:
#'
#'   * IDENTIFIER
#'   * AOTNAME
#'   * NOTENTITLED
#'   * ACCESSLEVEL
#'
#' @return Tibble mit den Spalten:
#'
#' \describe{
#'
#' \item{ProblemPrivilege}{
#' Lizenzkritisches Privilege.
#' }
#'
#' \item{AOTNAME}{
#' Zugehöriges Entry Point oder MenuItem.
#' }
#'
#' \item{AlternativePrivilege}{
#' Mögliches Privilege mit ACCESSLEVEL = 1.
#' }
#'
#' \item{HasAlternative}{
#' TRUE, wenn eine Alternative gefunden wurde.
#' }
#'
#' }
#'
#' @details
#'
#' Die Funktion sucht zunächst alle Privileges mit
#' `NOTENTITLED > 0`.
#'
#' Anschließend werden sämtliche Privileges mit
#' `ACCESSLEVEL = 1` für dieselbe `AOTNAME`
#' ermittelt.
#'
#' Dadurch können häufig vorhandene Microsoft-
#' View-Privileges identifiziert werden, bevor
#' kundenspezifische Privileges entwickelt werden.
#'
#' Typischer Analyseablauf:
#'
#' \preformatted{
#' Lizenzkritisches Privilege
#'            ↓
#' Zugehöriges MenuItem
#'            ↓
#' Alternative Privileges suchen
#'            ↓
#' Activity-kompatible Variante prüfen
#' }
#'
#' @examples
#' \dontrun{
#'
#' licenses <-
#'   get_license_requirements(
#'     con
#'   )
#'
#' alternatives <-
#'   find_license_alternatives(
#'     licenses
#'   )
#'
#' alternatives
#'
#' alternatives |>
#'   dplyr::filter(
#'     HasAlternative
#'   )
#'
#' }
#'
#' @export
find_license_alternatives_V0 <- function(
    licenses
){

  problem_privileges <-
    licenses |>
    dplyr::filter(
      NOTENTITLED > 0
    )

  problem_privileges |>

    dplyr::select(
      ProblemPrivilege = IDENTIFIER,
      AOTNAME
    ) |>

    dplyr::left_join(

      licenses |>
        dplyr::filter(
          ACCESSLEVEL == 1
        ) |>
        dplyr::select(
          AOTNAME,
          AlternativePrivilege = IDENTIFIER
        ),
      by = "AOTNAME"

    ) |>
    dplyr::mutate(
      HasAlternative =
        !is.na(
          AlternativePrivilege
        )

    )
}
