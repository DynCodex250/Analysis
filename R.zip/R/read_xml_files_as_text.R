


read_xml_files_as_text <- function(folder_path){
  # =========================================
  #   XML-DATEIEN ERMITTELN
  # =========================================

  xml_files <- list.files(path = folder_path,pattern = "\\.xml$",full.names = TRUE)

  # =========================================
  #   LEERE LISTE
  # =========================================

  xml_texts <- list()

  # =========================================
  #   DATEIEN EINLESEN
  # =========================================

  for(file in xml_files){

    file_content <- paste(
      readLines(
        file,
        warn = FALSE,
        encoding = "UTF-8"
      ),
      collapse = "\n"
    )

    # =========================================
    # DATEINAME ALS LISTENNAME
    # =========================================

    xml_texts[[basename(file)]] <- file_content

  }

  return(xml_texts)
}


read_xml_file <- function(file_path){

  read_xml(file_path)
}
