#' WIBU Dev-Rollen laden
#'
#' Lädt alle WIBU-Entwicklerrollen aus SECURITYROLE.
#'
#' Eine Rolle gilt als Dev-Rolle, wenn:
#'
#' * der technische Identifier WIBU enthält
#'
#' Dev-Rollen werden in Visual Studio über den AOT erstellt.
#' Ihr AOTNAME ist ein lesbarer technischer Bezeichner.
#'
#' Der Anzeigename enthält häufig ein Klammer-Suffix
#' mit dem technischen Identifier:
#'
#' \preformatted{
#' _WIBU Fibu Finanzbuchhaltung (_WIBU_Fibu_Finanzbuchhaltung)
#' }
#'
#' Dieses Suffix wird in NAME2 entfernt,
#' um den späteren Join mit Config-Rollen zu ermöglichen.
#'
#' @param connection DBI-Verbindung zur D365FO-Datenbank.
#'
#' @return Tibble mit drei Spalten:
#'
#' \describe{
#'   \item{AOTNAME}{Lesbarer technischer Identifier der Dev-Rolle.}
#'   \item{NAME}{Anzeigename der Rolle (mit Klammer-Suffix).}
#'   \item{NAME2}{Bereinigter Anzeigename ohne Klammer-Suffix — Join-Key.}
#' }
#'
#' @details
#' Bereinigungslogik für NAME2:
#'
#' Alles ab der ersten öffnenden Klammer wird entfernt
#' und das Ergebnis wird mit LTRIM/RTRIM von Leerzeichen befreit.
#'
#' @examples
#' \dontrun{
#'
#' dev_roles <- load_dev_roles(connection)
#'
#' dev_roles$NAME2
#'
#' }
#'
#' @seealso
#' \code{\link{load_config_roles}}
#' \code{\link{load_role_mapping}}
#' \code{\link{load_dev_role_mapping}}
#'
#' @export

load_dev_roles <- function(connection) {

  sql <- "
SELECT
    SR.AOTNAME,
    SR.NAME,
    LTRIM(RTRIM(
        CASE
            WHEN CHARINDEX('(', SR.NAME) > 0
            THEN LEFT(SR.NAME, CHARINDEX('(', SR.NAME) - 1)
            ELSE SR.NAME
        END
    )) AS NAME2
FROM SECURITYROLE SR
WHERE SR.AOTNAME LIKE '%WIBU%'
ORDER BY SR.NAME ASC
"

  result <- DBI::dbGetQuery(connection, sql)

  tibble::as_tibble(result)

}
