#' D365FO Privileges auf Berechtigungsänderungen vergleichen
#'
#' Vergleicht zwei D365FO Privilege-Modelle und analysiert
#' Änderungen an Security-Berechtigungen innerhalb bestehender
#' Security-Objekte.
#'
#' Im Gegensatz zu `compare_privileges_existence()`
#' werden keine hinzugefügten oder entfernten Objekte
#' betrachtet.
#'
#' Die Funktion konzentriert sich ausschließlich auf
#' Änderungen von Berechtigungen innerhalb bereits
#' vorhandener Security-Objekte.
#'
#' Verglichene Berechtigungen:
#'
#' - Read
#' - Create
#' - Update
#' - Delete
#' - Correct
#' - Invoke
#'
#' Analysierte Komponenten:
#'
#' - EntryPoints
#' - EntryPointControls
#' - DataEntityPermissions
#' - DataEntityMethods
#' - DirectAccessPermissions
#' - DirectAccessFields
#' - FormControlOverrides
#'
#' Die Funktion dient als Grundlage für:
#' - Security Audits
#' - Berechtigungsreviews
#' - Security-Risikoanalysen
#' - Release-Vergleiche
#' - Compliance-Prüfungen
#'
#' @param privilege_a Erstes D365FO Privilege-Modell.
#'        Typischerweise die Referenzversion.
#'
#' @param privilege_b Zweites D365FO Privilege-Modell.
#'        Typischerweise die Ziel- oder neue Version.
#'
#' @return Tibble mit allen gefundenen
#' Berechtigungsänderungen.
#'
#' Enthaltene Spalten:
#'
#' \describe{
#'   \item{Component}{
#'   Name der Security-Komponente.
#'   }
#'
#'   \item{Object}{
#'   Eindeutige Objektidentifikation.
#'   }
#'
#'   \item{Permission}{
#'   Geänderte Berechtigung.
#'   }
#'
#'   \item{OldValue}{
#'   Ursprünglicher Berechtigungswert.
#'   }
#'
#'   \item{NewValue}{
#'   Neuer Berechtigungswert.
#'   }
#' }
#'
#' Zusätzlich wird ein Metadata-Attribut mit den
#' Metadaten beider Privileges gespeichert.
#'
#' @details
#' Die Funktion betrachtet ausschließlich Objekte,
#' die in beiden Privileges vorhanden sind.
#'
#' Hinzugefügte oder entfernte Objekte werden nicht
#' ausgewertet.
#'
#' Für Existenzvergleiche sollte
#' `compare_privileges_existence()`
#' verwendet werden.
#'
#' Die eigentliche Berechtigungsanalyse erfolgt über
#' `compare_component_security()`.
#'
#' Die Funktion eignet sich insbesondere zur Analyse
#' von Security-Änderungen zwischen Releases,
#' Hotfixes oder kundenspezifischen Anpassungen.
#'
#' @seealso
#' compare_component_security()
#' compare_privileges_existence()
#' compare_privileges_risk_analysis()
#' compare_privileges_release()
#'
#' @examples
#'
#' # Zwei Privileges einlesen
#' privilege_old <- parse_privilege(
#'   "CustTableMaintain.xml"
#' )
#'
#' privilege_new <- parse_privilege(
#'   "CustTableMaintain_v2.xml"
#' )
#'
#' # Berechtigungsänderungen analysieren
#' security_changes <-
#'   compare_privileges_security(
#'     privilege_old,
#'     privilege_new
#'   )
#'
#' # Alle Änderungen anzeigen
#' security_changes
#'
#' # Nur Update-Berechtigungen anzeigen
#' dplyr::filter(
#'   security_changes,
#'   Permission == "Update"
#' )
#'
#' @export
compare_privileges_security <- function(
    privilege_a,
    privilege_b
){

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if(!inherits(privilege_a, "D365Privilege")){
    stop("privilege_a muss ein D365Privilege sein.")
  }

  if(!inherits(privilege_b,"D365Privilege")){
    stop("privilege_b muss ein D365Privilege sein.")
  }

  # ================================
  # KOMPONENTEN DEFINIEREN
  # ================================

  component_config <- list(
    EntryPoints = list(key_columns = c("Name")),
    EntryPointControls = list(key_columns = c("EntryPointName","FormName","ControlName")),
    DataEntityPermissions = list(key_columns = c("DataEntityName")),
    DataEntityMethods = list(key_columns = c("DataEntityName", "MethodName")),
    DirectAccessPermissions = list(key_columns = c("ObjectName")),
    DirectAccessFields = list(key_columns = c("ParentObject","FieldName")),
    FormControlOverrides = list(key_columns = c("ParentForm","ControlName"))
  )

  # ================================
  # VERARBEITUNG DURCHFÜHREN
  # ================================

  result <-
    purrr::imap_dfr(
      component_config,
      function(config, component_name){
        compare_component_security(
          component_a = privilege_a[[component_name]],
          component_b = privilege_b[[component_name]],
          component_name = component_name,
          key_columns = config$key_columns
        )
      }
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  attr(result, "metadata") <-
    list(
      SourcePrivilege = privilege_a$Metadata,
      TargetPrivilege = privilege_b$Metadata
    )

  class(result) <-
    c(
      "D365PrivilegeSecurityComparison",
      "tbl_df",
      "tbl",
      "data.frame"
    )

  return(result)

}
