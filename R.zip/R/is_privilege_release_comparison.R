#' Prüfen ob ein Privilege-Releasevergleich vorliegt#'#' Prüft, ob ein Objekt das Ergebnis eines#' compare_privileges_release()-Aufrufs ist.#'#' Die Funktion wird zukünftig von#' Export- und Reportingfunktionen verwendet.#'#' @param x Zu prüfendes Objekt.#'#' @return TRUE wenn das Objekt ein#' D365PrivilegeReleaseComparison ist,#' ansonsten FALSE.#'#' @details#' Die Prüfung erfolgt über die Objektklasse.#'#' Erwartete Klasse:#'#' D365PrivilegeReleaseComparison#'#' @seealso#' compare_privileges_release()#' export_privilege_release_excel()#'#' @examples#' report <-#'   compare_privileges_release(#'     privilege_a,#'     privilege_b#'   )#'#' is_privilege_release_comparison(#'   report#' )#'#' @export
is_privilege_release_comparison <- function(x){

  # ================================
  #   OBJEKT PRÜFEN
  # ================================

    result <-inherits(x,"D365PrivilegeReleaseComparison")

    # ================================
    #   ERGEBNIS ZURÜCKGEBEN
    # ================================

      return(result)
}
