#' Benutzerberechtigungen vollständig vergleichen
#'
#' Vergleicht die vollständigen Berechtigungen aller
#' Benutzerpaare innerhalb eines Security-Modells.
#'
#' Für jede mögliche Benutzerkombination wird geprüft,
#' ob die vorhandenen Rollen- und Organisationszuweisungen
#' exakt identisch sind.
#'
#' Die Funktion eignet sich insbesondere zur
#' Identifikation von Benutzern mit identischen
#' Berechtigungen sowie zur Validierung von
#' Berechtigungsgruppen.
#'
#' @details
#' Für jeden Benutzer werden sämtliche
#' Berechtigungsdatensätze betrachtet.
#'
#' Der Vergleich erfolgt auf Basis der Kombination aus:
#'
#' * SECURITYROLEIDENTIFIER
#' * ORGANIZATIONID
#'
#' Die Reihenfolge der Datensätze beeinflusst das
#' Ergebnis nicht, da die Daten vor dem Vergleich
#' sortiert werden.
#'
#' Für jedes Benutzerpaar wird geprüft, ob die
#' vollständigen Datensätze identisch sind.
#'
#' Das Ergebnis liefert für jede Kombination
#' zweier Benutzer einen Wahrheitswert:
#'
#' * TRUE
#' * FALSE
#'
#' Dabei werden nur eindeutige Benutzerpaare
#' betrachtet.
#'
#' Beispiel:
#'
#' \preformatted{
#' User1 User2
#' A     B
#' A     C
#' B     C
#' }
#'
#' Die Kombination
#'
#' \preformatted{
#' B - A
#' }
#'
#' wird nicht erneut berechnet.
#'
#' @param security_model Tibble mit den
#' konsolidierten Rollenzuweisungen.
#'
#' Erwartete Spalten:
#'
#' * USERID
#' * SECURITYROLEIDENTIFIER
#' * ORGANIZATIONID
#'
#' weitere Spalten werden ignoriert.
#'
#' @return Tibble.
#'
#' Enthält folgende Spalten:
#'
#' * User1
#' * User2
#' * IsIdentical
#'
#' @examples
#' \dontrun{
#' complete_comparison <-
#'   compare_users_complete(
#'     security_model
#'   )
#' }
#'
#' Beispielausgabe:
#'
#' \preformatted{
#' User1 User2 IsIdentical
#' s.o.  s.t.  FALSE
#' s.o.  b.e.  TRUE
#' s.t.  b.e.  FALSE
#' }
#'
#' @export
compare_users_complete <- function(
  security_model
){
  #=============================================
  # Validierung
  #=============================================
  required_columns <- c(
    "USERID",
    "SECURITYROLEIDENTIFIER",
    "ORGANIZATIONID"
  )
  
  missing_columns <- setdiff(
    required_columns,
    names(security_model)
  )
  
  if(length(missing_columns) > 0){
    stop(
      paste(
        "Folgende Spalten fehlen:",
        paste(
          missing_columns,
          collapse = ", "
        )
      )
    )
  }
  
  #=============================================
  # Alle Benutzer ermitteln
  #=============================================
  users <-
    security_model |>
    dplyr::pull(
      USERID
    ) |>
    unique() |>
    sort()
  
  if(length(users) < 2){
    return(
      tibble::tibble(
        User1 = character(),
        User2 = character(),
        IsIdentical = logical()
      )
    )
  }
  
  #=============================================
  # Fingerprint für jeden Benutzer berechnen
  #=============================================
  user_fingerprints <-
    security_model |>
    dplyr::distinct(
      USERID,
      SECURITYROLEIDENTIFIER,
      ORGANIZATIONID
    ) |>
    dplyr::arrange(
      USERID,
      SECURITYROLEIDENTIFIER,
      ORGANIZATIONID
    ) |>
    dplyr::group_by(
      USERID
    ) |>
    dplyr::summarise(
      Fingerprint = paste(
        paste(
          SECURITYROLEIDENTIFIER,
          ORGANIZATIONID,
          sep = "|"
        ),
        collapse = ";"
      ),
      .groups = "drop"
    )
  
  #=============================================
  # Benutzerpaare vergleichen
  #=============================================
  pairs <- t(combn(users, 2))
  result <- tibble::tibble(
    User1 = pairs[, 1],
    User2 = pairs[, 2]
  ) |>
    dplyr::left_join(
      user_fingerprints,
      by = c("User1" = "USERID")
    ) |>
    dplyr::rename(
      Fingerprint1 = Fingerprint
    ) |>
    dplyr::left_join(
      user_fingerprints,
      by = c("User2" = "USERID")
    ) |>
    dplyr::rename(
      Fingerprint2 = Fingerprint
    ) |>
    dplyr::mutate(
      IsIdentical =
        (Fingerprint1 == Fingerprint2)
    ) |>
    dplyr::select(
      User1,
      User2,
      IsIdentical
    )
  
  return(result)
}

#' @export
sec_compare_users_complete <- compare_users_complete

