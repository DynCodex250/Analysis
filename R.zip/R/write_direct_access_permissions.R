

write_direct_access_permissions <- function(parent_node,df){

  # =========================================
  #   ROOT NODE
  # =========================================

    dap_node <- xml_add_child(parent_node,"DirectAccessPermissions")

  # =========================================
  #   NUR ENTITY ZEILEN
  # =========================================

    entity_rows <- df %>%filter(Ebene == "Entity")

  # =========================================
  #   ENTITIES DURCHLAUFEN
  # =========================================

    for(i in seq_len(nrow(entity_rows))){

      entity <- entity_rows[i, ]

      # =========================================
      # REFERENZTYP
      # =========================================

      entity_node <- xml_add_child(
        dap_node,
        entity$ObjektTyp
      )

      # =========================================
      # GRANT NODE
      # =========================================

      permissions <- c(
        "Correct",
        "Create",
        "Delete",
        "Invoke",
        "Read",
        "Update"
      )

      # =========================================
      # ENTITY GRANTS
      # =========================================

      entity_has_grants <- FALSE

      grant_node <- xml_add_child(
        entity_node,
        "Grant"
      )

      for(permission in permissions){

        permission_value <- entity[[permission]]

        if(!is.na(permission_value) &&
           permission_value != ""){

          entity_has_grants <- TRUE

          xml_add_child(
            grant_node,
            permission,
            permission_value
          )
        }
      }

      # =========================================
      # LEEREN GRANT NODE ENTFERNEN
      # =========================================

      if(!entity_has_grants){
        xml_remove(grant_node)
      }

      # =========================================
      # NAME
      # =========================================

      xml_add_child(
        entity_node,
        "Name",
        entity$Objektname
      )

      # =========================================
      # FIELDS NODE
      # =========================================

      fields_node <- xml_add_child(
        entity_node,
        "Fields"
      )

      # =========================================
      # ZUGEHÖRIGE FELDER
      # =========================================

      field_rows <- df %>%
        filter(
          Ebene == "Field",
          Objektname == entity$Objektname
        )

      # =========================================
      # FELDER SCHREIBEN
      # =========================================

      if(nrow(field_rows) > 0){

        for(j in seq_len(nrow(field_rows))){

          field <- field_rows[j, ]

          field_node <- xml_add_child(
            fields_node,
            field$ObjektTyp
          )

          # =========================================
          # FELDNAME
          # =========================================

          xml_add_child(
            field_node,
            "Name",
            field$Feldname
          )

          # =========================================
          # FIELD GRANTS
          # =========================================

          field_has_grants <- FALSE

          field_grant_node <- xml_add_child(
            field_node,
            "Grant"
          )

          for(permission in permissions){

            permission_value <- field[[permission]]

            if(!is.na(permission_value) &&
               permission_value != ""){

              field_has_grants <- TRUE

              xml_add_child(
                field_grant_node,
                permission,
                permission_value
              )
            }
          }

          # =========================================
          # LEEREN FIELD GRANT ENTFERNEN
          # =========================================

          if(!field_has_grants){
            xml_remove(field_grant_node)
          }
        }
      }

    }
    }
