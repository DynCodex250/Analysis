#' Analyse security information for form menu items
#'
#' Links the menu items used within a D365FO form with the
#' corresponding security information from
#' \code{UserSecGovRelatedObjects}.
#'
#' The function represents the first step of a security analysis
#' by establishing the following relationship:
#'
#' \preformatted{
#' Form
#'   -> MenuItem
#'       -> Privilege
#' }
#'
#' Menu items are matched against security resources using a
#' case-insensitive comparison of the menu item name and the
#' security resource.
#'
#' @param documentation Object of class
#'   \code{D365FormDocumentation}.
#'
#' @param user_sec_gov_related_objects Tibble returned by
#'   \code{load_user_sec_gov_related_objects()}.
#'   The following columns are required:
#'
#' \describe{
#'   \item{PRIVILEGEIDENTIFIER}{Privilege identifier.}
#'   \item{PRIVILEGENAME}{Privilege name.}
#'   \item{RESOURCETYPE}{Resource type.}
#'   \item{RESOURCE_}{Resource name.}
#' }
#'
#' @return
#' A tibble containing one row per menu item together with the
#' matching security information.
#'
#' The resulting dataset contains at least the following columns:
#'
#' \describe{
#'   \item{ControlType}{Control type.}
#'   \item{ControlName}{Control name.}
#'   \item{MenuItemName}{Referenced menu item.}
#'   \item{MenuItemType}{Menu item type.}
#'   \item{Parent}{Parent control.}
#'   \item{Path}{Control hierarchy path.}
#'   \item{PrivilegeIdentifier}{Matching privilege identifier.}
#'   \item{PrivilegeName}{Matching privilege name.}
#'   \item{ResourceType}{Security resource type.}
#'   \item{ResourceName}{Security resource.}
#' }
#'
#' @details
#' The function validates both the documentation object and the
#' required columns of the security dataset.
#'
#' A temporary uppercase key is created for both menu items and
#' security resources to ensure case-insensitive matching.
#'
#' The security information is attached using
#' \code{dplyr::left_join()} before the output columns are
#' renamed and cleaned.
#'
#' This function is intended as the foundation for higher-level
#' security analyses such as privilege, duty and role impact
#' assessments.
#'
#' @examples
#' \dontrun{
#'
#' security_info <-
#'   analyze_form_menu_item_security(
#'     documentation,
#'     user_sec_gov_related_objects
#'   )
#'
#' security_info |>
#'   dplyr::filter(
#'     MenuItemName == "CustInvoiceJournal"
#'   )
#'
#' }
#'
#' @seealso
#' \code{\link{load_user_sec_gov_related_objects}}
#'
#' \code{\link{analyze_form_documentation}}
#'
#' @export
#

analyze_form_menu_item_securityN <- function(
    documentation,
    user_sec_gov_related_objects
){

  # ==========================================================
  # VALIDIERUNG
  # ==========================================================

  if(!inherits(
    documentation,
    "D365FormDocumentation"
  )){
    stop(
      "documentation muss ein D365FormDocumentation sein."
    )
  }

  required_columns <- c(
    "PRIVILEGEIDENTIFIER",
    "PRIVILEGENAME",
    "RESOURCETYPE",
    "RESOURCE_"
  )

  missing_columns <- setdiff(
    required_columns,
    names(user_sec_gov_related_objects)
  )

  if(length(missing_columns) > 0){

    stop(
      paste(
        "Folgende Spalten fehlen:",
        paste(
          missing_columns,
          collapse = ", "
        )
      )
    )

  }

  # ==========================================================
  # MENUITEMS
  # ==========================================================

  menu_items <-

    documentation$MenuItems |>

    dplyr::mutate(

      ResourceKey =
        toupper(
          MenuItemName
        )

    )

  # ==========================================================
  # SECURITY DATEN
  # ==========================================================

  security_objects <-

    user_sec_gov_related_objects |>

    dplyr::mutate(

      ResourceKey =
        toupper(
          RESOURCE_
        )

    )

  # ==========================================================
  # JOIN
  # ==========================================================

  result <-

    menu_items |>

    dplyr::left_join(

      security_objects,

      by = "ResourceKey"

    )

  # ==========================================================
  # SPALTEN AUFRÄUMEN
  # ==========================================================

  result <-

    result |>

    dplyr::rename(

      PrivilegeIdentifier =
        PRIVILEGEIDENTIFIER,

      PrivilegeName =
        PRIVILEGENAME,

      ResourceType =
        RESOURCETYPE,

      ResourceName =
        RESOURCE_

    ) |>

    dplyr::select(

      ControlType,
      ControlName,

      MenuItemName,
      MenuItemType,

      Parent,
      Path,

      PrivilegeIdentifier,
      PrivilegeName,

      ResourceType,
      ResourceName,

      dplyr::everything(),

      -ResourceKey

    )

  # ==========================================================
  # ERGEBNIS
  # ==========================================================

  return(result)

}
