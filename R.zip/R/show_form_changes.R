#' Formularänderungen anzeigen
#'#' Zeigt ausschließlich die
#' Unterschiede eines
#' D365FormComparison Objekts an.
#'#' Unveränderte Bereiche werden
#' ausgeblendet.
#'#' @param comparison Ergebnis von
#' compare_forms_documentation().
#' #'#' @return Unsichtbar das
#' #' Vergleichsobjekt.
#'#' @examples#' comparison <-
#'   compare_forms_documentation(
#'     documentation_old,
#'     documentation_new
#'   )
#'#' show_form_changes(
#'   comparison
#' )
#'#' @export
#'

show_form_changes <- function(comparison){

# ================================
#   VALIDIERUNG
# ================================

  if(!inherits(comparison,"D365FormComparison")){

    stop(
      "comparison muss ein D365FormComparison sein."
    )

  }

# ================================
#   HILFSFUNKTION
# ================================

  print_section <- function(title,changes){

    added <-
      changes$Added

    removed <-
      changes$Removed

    if(
      nrow(added) == 0 &&
      nrow(removed) == 0){

      return(invisible(NULL))

    }

    cat("\n")
    cat(title, "\n")
    cat(
      paste(
        rep(
          "-",
          nchar(title)
        ),
        collapse = ""
      ),
      "\n",
      sep = ""
    )

    # ============================
    # ADDED
    # ============================

    if(nrow(added) > 0){

      cat("\nAdded:\n")

      print(
        added,
        n = Inf
      )

    }

    # ============================
    # REMOVED
    # ============================

    if(nrow(removed) > 0){

      cat("\nRemoved:\n")

      print(
        removed,
        n = Inf
      )

    }

  }

  # ================================
  #   AUSGABE
  # ================================

    print_section("DataSources",comparison$DataSources)

  print_section("Tabs",comparison$Tabs)

  print_section("Groups",comparison$Groups)

  print_section("Fields",comparison$Fields)

  print_section("Buttons",comparison$Buttons)

  print_section("Parts",comparison$Parts)

  invisible(comparison)

  }
