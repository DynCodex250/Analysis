#' Änderungen zwischen zwei Privileges zusammenfassen
#'
#' Vergleicht zwei Privileges und liefert eine Zusammenfassung der hinzugefügten,
#' entfernten und unveränderten Rechte.
#'
#' Die Funktion eignet sich insbesondere zur Validierung von kundenspezifischen
#' View- oder Activity-Varianten bestehender Maintain-Privileges.
#'
#' @param privilege_model_old Ursprüngliches D365PrivilegeModel.
#'
#' @param privilege_model_new Neues D365PrivilegeModel.
#'
#' @return Liste der Klasse D365PrivilegeComparisonSummary.
#'
#' Enthält:
#'
#' * RightsRemoved
#' * RightsAdded
#' * RightsUnchanged
#'
#' @examples
#' summary <-
#'   summarize_privilege_changes(
#'     privilege_model_old,
#'     privilege_model_new
#'   )
#'
#' summary
#'
#' @export
summarize_privilege_changes <- function(
    privilege_model_old,
    privilege_model_new){
  # ==========================
  # DETAILVERGLEICH
  # ==========================
  comparison <-
    compare_privilege_access_levels(
      privilege_model_old,
      privilege_model_new
    )
  # ==========================
  # RECHTE
  # ==========================
  access_types <- c("ReadAccess",
                    "UpdateAccess",
                    "CreateAccess",
                    "DeleteAccess",
                    "CorrectAccess",
                    "InvokeAccess")
  
  # ==========================
  # ZUSAMMENFASSUNG
  # ==========================
  rights_removed <- list()
  rights_added <- list()
  rights_unchanged <- list()
  
  for(access_type in access_types){
    old_col <- paste0(access_type, "_Old")
    new_col <- paste0(access_type, "_New")
    
    removed <- sum(
      comparison[[old_col]] %in% TRUE
      &
        (
          is.na(comparison[[new_col]])
          |
            comparison[[new_col]] %in% FALSE), na.rm = TRUE)
    
    added <- sum(
      comparison[[new_col]] %in% TRUE &
        (is.na(
          comparison[[old_col]]
        ) |
          comparison[[old_col]] %in% FALSE
        ), na.rm = TRUE)
    
    unchanged <- sum(
      comparison[[old_col]] %in% TRUE &
        comparison[[new_col]] %in% TRUE, na.rm = TRUE)
    
    rights_removed[[access_type]] <- removed
    rights_added[[access_type]] <- added
    rights_unchanged[[access_type]] <- unchanged
  }
  
  result <-
    list(
      RightsRemoved =
        tibble::enframe(
          rights_removed,
          name = "AccessType",
          value = "Count"),
      
      RightsAdded =
        tibble::enframe(
          rights_added,
          name = "AccessType",
          value = "Count"),
      
      RightsUnchanged =
        tibble::enframe(
          rights_unchanged,
          name = "AccessType",
          value = "Count")
    )
  
  class(result) <- c("D365PrivilegeComparisonSummary",class(result))
  return(result)
}

#' @export
print.D365PrivilegeComparisonSummary <- function(
    x,
    ...){
  cat("\nPrivilege Comparison Summary\n")
  cat("\nRemoved Rights\n")
  print(x$RightsRemoved, row.names = FALSE)
  cat("\nAdded Rights\n")
  print(x$RightsAdded, row.names = FALSE)
  cat("\nUnchanged Rights\n")
  print(x$RightsUnchanged, row.names = FALSE)
  
  invisible(x)
}