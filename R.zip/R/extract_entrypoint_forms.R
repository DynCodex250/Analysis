#' EntryPoint-Formulare extrahieren
#'
#' Extrahiert alle Formulare, die innerhalb von
#' EntryPoints eines D365FO Security Privileges
#' referenziert werden.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit EntryPointName und FormName.
#'
#' @details
#' Die Funktion liest alle Form-Referenzen unterhalb
#' der EntryPoints aus.
#'
#' Leere Ergebnisse werden als Tibble mit definierter
#' Struktur zurückgegeben.
#'
#' @seealso
#' parse_privilege()
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#'
#' forms <-
#'   extract_entrypoint_forms(
#'     xml_doc
#'   )
#' }
#'
#' @export
extract_entrypoint_forms <- function(xml_doc) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # =========================================
  # FORMULARE EXTRAHIEREN
  # =========================================

  form_nodes <- xml2::xml_find_all(
    xml_doc,
    "//EntryPoints//Forms/*"
  )

  result <- purrr::map_dfr(form_nodes, function(form_node) {

    entrypoint_node <- xml2::xml_parent(
      xml2::xml_parent(form_node)
    )

    tibble::tibble(
      EntryPointName = xml2::xml_text(
        xml2::xml_find_first(entrypoint_node, "./Name")
      ),

      FormName = xml2::xml_text(
        xml2::xml_find_first(form_node, "./Name")
      )
    )
  })

  # =========================================
  # LEERE STRUKTUR ABSICHERN
  # =========================================

  if (ncol(result) == 0) {
    result <- empty_entrypoint_forms()
  }

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}
