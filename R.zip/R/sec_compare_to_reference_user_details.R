#' Referenzvergleich auf Rollenebene (Detailansicht)
#'
#' Vergleicht die Rollenzuweisungen mehrerer Benutzer
#' mit einem Referenzbenutzer und liefert die
#' Unterschiede auf Rollenebene als Detailtabelle.
#'
#' Im Gegensatz zu
#' \code{compare_to_reference_user()}
#' wird nicht nur angezeigt, ob ein Benutzer
#' vom Referenzbenutzer abweicht, sondern auch
#' welche konkreten Rollen fehlen oder zusätzlich
#' vorhanden sind.
#'
#' Die Funktion liefert sowohl den technischen
#' Rollenidentifikator als auch den lesbaren
#' Rollennamen.
#'
#' Dadurch können:
#'
#' * Fachbereiche mit lesbaren Rollennamen arbeiten
#' * technische Dubletten erkannt werden
#' * Rollen mit identischem Namen aber
#'   unterschiedlicher ID identifiziert werden
#'
#' @details
#' Für jeden Benutzer werden die Rollen des
#' Referenzbenutzers mit den eigenen Rollen
#' verglichen.
#'
#' Folgende Differenztypen werden ermittelt:
#'
#' * Missing
#'   Rollen des Referenzbenutzers, die beim
#'   verglichenen Benutzer fehlen.
#'
#' * Additional
#'   Rollen, die beim verglichenen Benutzer
#'   vorhanden sind, aber nicht beim
#'   Referenzbenutzer.
#'
#' Sonderfall:
#'
#' Besitzt ein Benutzer exakt dieselben Rollen
#' wie der Referenzbenutzer, wird ein Datensatz
#' mit dem Differenztyp \code{"Identisch"}
#' erzeugt.
#'
#' Der Referenzbenutzer selbst wird ebenfalls
#' im Ergebnis ausgegeben.
#'
#' @param security_assignments Tibble mit den
#' konsolidierten Rollenzuweisungen.
#'
#' Erwartete Spalten:
#' * USERID
#' * SECURITYROLEIDENTIFIER
#' * SECURITYROLENAME
#'
#' Weitere Spalten werden ignoriert.
#'
#' @param reference_user Benutzerkennung des
#' Referenzbenutzers.
#'
#' @return Tibble.
#'
#' Enthält folgende Spalten:
#'
#' * USERID
#' * Differenztyp
#' * SECURITYROLEIDENTIFIER
#' * SECURITYROLENAME
#'
#' Mögliche Werte für Differenztyp:
#'
#' * Referenz
#' * Identisch
#' * Missing
#' * Additional
#'
#' @examples
#' \dontrun{
#' details <-
#'   compare_to_reference_user_details(
#'     security_assignments = security_model,
#'     reference_user = "s.t"
#'   )
#' }
#'
#' Beispielausgabe:
#'
#' \preformatted{
#' USERID Differenztyp SECURITYROLEIDENTIFIER
#' s.o.   Missing      408D9823-E27F-417A...
#'
#' SECURITYROLENAME
#' _WIBU Verkauf Innendienst Leitung
#' }
#'
#' Typische Verwendung:
#'
#' * Excel-Blatt
#'   03a_Referenzvergleich_Details
#'
#' * Audit-Analysen
#'
#'   Berechtigungsvergleiche
#' * Rollenharmonisierung
#'
#' @export
sec_compare_to_reference_user_details <- function(
  security_assignments,
  reference_user
){
  #=============================================
  # Validierung
  #=============================================
  required_columns <- c(
    "USERID",
    "SECURITYROLEIDENTIFIER",
    "SECURITYROLENAME"
  )
  missing_columns <- setdiff(
    required_columns,
    names(security_assignments)
  )
  if(length(missing_columns) > 0){
    stop(
      paste(
        "Folgende Spalten fehlen:",
        paste(
          missing_columns,
          collapse = ", "
        )
      )
    )
  }
  
  #=============================================
  # Referenzrollen ermitteln
  #=============================================
  reference_roles <-
    security_assignments |>
    dplyr::filter(
      USERID == reference_user
    ) |>
    dplyr::distinct(
      SECURITYROLEIDENTIFIER,
      SECURITYROLENAME
    )
  
  # Referenzbenutzer prüfen
  if(nrow(reference_roles) == 0){
    stop(
      paste(
        "Referenzbenutzer nicht gefunden:",
        reference_user
      )
    )
  }
  
  # Alle Benutzer ermitteln
  users <-
    security_assignments |>
    dplyr::pull(
      USERID
    ) |>
    unique() |>
    sort()
  
  #=============================================
  # Benutzer vergleichen
  #=============================================
  result <-
    purrr::map_dfr(
      users,
      function(user){
        
        # Referenzbenutzer
        if(user == reference_user){
          return(
            tibble::tibble(
              USERID = user,
              Differenztyp = "Referenz",
              SECURITYROLEIDENTIFIER =
                NA_character_,
              SECURITYROLENAME =
                NA_character_
            )
          )
        }
        
        # Rollen des aktuellen Benutzers
        user_roles <-
          security_assignments |>
          dplyr::filter(
            USERID == user
          ) |>
          dplyr::distinct(
            SECURITYROLEIDENTIFIER,
            SECURITYROLENAME
          )
        
        # Fehlende Rollen
        missing_roles <-
          dplyr::anti_join(
            reference_roles,
            user_roles,
            by = c(
              "SECURITYROLEIDENTIFIER",
              "SECURITYROLENAME"
            )
          )
        
        # Zusätzliche Rollen
        additional_roles <-
          dplyr::anti_join(
            user_roles,
            reference_roles,
            by = c(
              "SECURITYROLEIDENTIFIER",
              "SECURITYROLENAME"
            )
          )
        
        # Identischer Benutzer
        if(
          nrow(missing_roles) == 0 &&
          nrow(additional_roles) == 0
        ){
          return(
            tibble::tibble(
              USERID = user,
              Differenztyp = "Identisch",
              SECURITYROLEIDENTIFIER =
                NA_character_,
              SECURITYROLENAME =
                NA_character_
            )
          )
        }
        
        # Missing erzeugen
        missing_df <-
          missing_roles |>
          dplyr::mutate(
            USERID = user,
            Differenztyp = "Missing"
          )
        
        # Additional erzeugen
        additional_df <-
          additional_roles |>
          dplyr::mutate(
            USERID = user,
            Differenztyp = "Additional"
          )
        
        # Ergebnis zurückgeben
        dplyr::bind_rows(
          missing_df,
          additional_df
        )
      }
    )
  
  # Ausgabe formatieren
  result <- result |>
    dplyr::select(
      USERID,
      Differenztyp,
      SECURITYROLEIDENTIFIER,
      SECURITYROLENAME
    )
  
  return(result)
}
