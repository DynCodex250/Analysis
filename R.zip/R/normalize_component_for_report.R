#' Security-Komponente für Release-Report normalisieren#'#' Normalisiert die Daten einer Security-Komponente#' für die Verwendung in D365FO Privilege#' Release-Reports.#'#' Die Funktion verwendet eine externe#' Report-Mapping-Konfiguration, um die#' unterschiedlichen Strukturen der einzelnen#' Security-Komponenten in ein einheitliches#' Berichtsformat zu überführen.#'#' Dadurch können neue Komponenten oder#' Anpassungen der Report-Darstellung ohne#' Änderungen am Programmcode vorgenommen werden.#'#' @param component_name Name der zu#' verarbeitenden Security-Komponente.#'#' @param component_data Tibble mit den Daten#' der Security-Komponente.#'#' @param report_mapping Report-Konfiguration aus#' load_report_mapping().#'#' @return Tibble mit den Spalten:#'#' * Component#' * Object#' * Details#'#' @details#' Die Funktion wird von#' normalize_existence_objects()#' verwendet.#'#' Die Zuordnung zwischen Security-Komponenten#' und Report-Spalten erfolgt vollständig über#' die Report-Mapping-Konfiguration.#'#' Dadurch bleibt die Report-Engine unabhängig#' von konkreten D365FO-Komponentenstrukturen.#'#' Erwartete Mapping-Spalten:#'#' * Component#' * DisplayName#' * ObjectColumn#' * DetailsColumn1#' * DetailsColumn2#'#' @seealso#' load_report_mapping()#'#' @examples#' mapping <-#'   load_report_mapping()#'#' normalize_component_for_report(#'   component_name = "EntryPoints",#'   component_data = component_data,#'   report_mapping = mapping#' )#'#' @export

normalize_component_for_report <- function(component_name,component_data,report_mapping){

  # ================================
  #   EINGABEPARAMETER VALIDIEREN
  # ================================

    if(!is.character(component_name)){stop("component_name muss ein Character sein.")}

  if(length(component_name) != 1){stop("component_name muss genau einen Wert enthalten.")}

  if(!is.data.frame(component_data)){stop("component_data muss ein Data Frame sein.")}

  if(!is.data.frame(report_mapping)){stop("report_mapping muss ein Data Frame sein.")}

  # ================================
  #   REPORT-KONFIGURATION ERMITTELN
  # ================================

    config <-
      report_mapping |>
      dplyr::filter(
        Component == component_name
      )

    if(nrow(config) == 0){

      stop(
        paste0(
          "Keine Report-Konfiguration für Komponente '",
          component_name,
          "' gefunden."
        )
      )
    }

    # ================================
    #   OBJEKTSPALTE ERMITTELN
    # ================================

      object_column <-config$ObjectColumn[[1]]

      if(!object_column %in% names(component_data)){

        stop(
          paste0(
            "Spalte '",
            object_column,
            "' wurde in Komponente '",
            component_name,
            "' nicht gefunden."
          )
        )

      }

      object_values <-component_data[[object_column]]

      # ================================
      #   DETAILSPALTEN ERMITTELN
      # ================================

        detail_columns <-
        c(
          config$DetailsColumn1[[1]],
          config$DetailsColumn2[[1]]
        )

      detail_columns <-
        detail_columns[
          !is.na(detail_columns) &
            detail_columns != ""
        ]

      # ================================
      #   DETAILWERTE ERZEUGEN
      # ================================

        if(length(detail_columns) == 0){

          details_values <-
            rep(
              "",
              nrow(component_data)
            )

        } else {

          missing_columns <-

            setdiff(
              detail_columns,
              names(component_data)
            )

          if(length(missing_columns) > 0){

            stop(

              paste0(
                "Folgende Detailspalten wurden nicht gefunden: ",
                paste(
                  missing_columns,
                  collapse = ", "
                )
              )
            )
          }

          details_values <-

            apply(

              component_data[detail_columns],

              1,

              function(x){

                paste(

                  x[

                    !is.na(x) &
                      x != ""

                  ],

                  collapse = " | "
                )
              }
            )
        }

      # ================================
      #   ERGEBNIS ERSTELLEN
      # ================================

        result <-

        tibble::tibble(

          Component =
            config$DisplayName[[1]],

          Object =
            object_values,

          Details =
            details_values

        )

      # ================================
      #   ERGEBNIS ZURÜCKGEBEN
      # ================================

        return(result)

}
