#' Get licensing requirements for D365FO privileges
#'
#' Retrieves licensing information from the
#' LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW and returns the
#' relationship between security privileges and the corresponding
#' Dynamics 365 Finance & Operations license requirements.
#'
#' The function can be used to determine whether a privilege is entitled
#' or not entitled for a specific license SKU. This is especially useful
#' when analysing security roles, duties and privileges in the context
#' of license optimization or security governance projects.
#'
#' By default, the function returns information for the
#' "Operations - Activity" license SKU. Optionally, a set of privilege
#' identifiers can be provided to limit the result set.
#'
#' @param con A valid database connection object.
#'
#' @param privilege_identifiers Character vector containing one or more
#'        D365FO privilege identifiers.
#'        If empty, all privileges matching the selected SKU are returned.
#'
#' @param sku_name Character value containing the license SKU name.
#'        Defaults to "Operations - Activity".
#'        Set to NULL or "" to disable SKU filtering.
#'
#' @return A data frame containing:
#' \describe{
#'   \item{IDENTIFIER}{Privilege identifier}
#'   \item{AOTNAME}{AOT object name}
#'   \item{SKUNAME}{License SKU name}
#'   \item{ENTITLED}{Indicates whether the privilege is entitled}
#'   \item{NOTENTITLED}{Indicates whether the privilege is not entitled}
#' }
#'
#' @details
#' The function queries the table
#' LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW
#' and joins it with SECURITYPRIVILEGE in order to retrieve
#' privilege identifiers that are meaningful in security analyses.
#'
#' Typical use cases:
#' \itemize{
#'   \item Identify the license impact of specific privileges.
#'   \item Validate whether privileges are covered by an
#'         Operations Activity license.
#'   \item Support role cleanup and license optimization projects.
#'   \item Analyse licensing implications of custom security roles.
#' }
#'
#' @examples
#' \dontrun{
#'
#' # Retrieve all privileges entitled for Operations - Activity
#' get_license_requirements(con)
#'
#' # Retrieve specific privileges
#' get_license_requirements(
#'   con,
#'   privilege_identifiers = c(
#'     "WHSLOADPLANNINGWORKBENCHVIEW",
#'     "WHSLOADPLANNINGWORKBENCHMAINTAIN"
#'   )
#' )
#'
#' # Analyse a different license SKU
#' get_license_requirements(
#'   con,
#'   sku_name = "Operations - Task"
#' )
#'
#' }
#'
#' @export
get_license_requirements <- function(
    con,
    privilege_identifiers = character(),
    sku_name = "Operations - Activity") {

  # =========================================
  # ABFRAGE DEFINIEREN
  # =========================================

  query <- "SELECT
    SP.IDENTIFIER,
    LPRDV.AOTNAME,
    LPRDV.SKUNAME,
    LPRDV.ENTITLED,
    LPRDV.NOTENTITLED,
    LPRDV.ACCESSLEVEL
  FROM LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW LPRDV
  INNER JOIN SECURITYPRIVILEGE SP ON SP.RECID = LPRDV.SECURITYPRIVILEGE
  WHERE 1 = 1"

  # =========================================
  # FILTER HINZUFÜGEN
  # =========================================

  if (!is.null(sku_name) && length(sku_name) > 0 && nzchar(sku_name)) {
    query <- paste0(
      query,
      "\nAND LPRDV.SKUNAME = '", gsub("'", "''", sku_name), "'"
    )
  }

  if (length(privilege_identifiers) > 0) {
    privilege_list <- paste0(
      "'", gsub("'", "''", privilege_identifiers), "'",
      collapse = ","
    )
    query <- paste0(
      query,
      "\nAND SP.IDENTIFIER IN (", privilege_list, ")"
    )
  }

  # =========================================
  # ABFRAGE AUSFÜHREN
  # =========================================

  return(DBI::dbGetQuery(con, query))
}
