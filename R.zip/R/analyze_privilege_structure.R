#' D365FO Privilege-Struktur analysieren
#'
#' Analysiert die Struktur eines D365FO Privileges anhand der
#' zuvor extrahierten XML-Knoten und ermittelt, welche Arten
#' von Security-Komponenten enthalten sind.
#'
#' Die Funktion dient zur schnellen Strukturanalyse eines
#' Privileges und liefert eine kompakte Übersicht über die
#' enthaltenen Security-Objekte.
#'
#' Typische Anwendungsfälle:
#' - Reverse Engineering
#' - XML-Vergleiche
#' - Privilege Splitting
#' - XML-Generierung
#' - Qualitätsprüfungen
#' - Analyse von Security-Strukturen
#'
#' @param privilege_analysis Ergebnis von
#'        `analyze_privilege_entrypoints()`.
#'
#' @return Liste der Klasse `D365PrivilegeStructure`
#'         mit logischen Indikatoren für die enthaltenen
#'         Security-Komponenten.
#'
#' Enthaltene Elemente:
#'
#' \describe{
#'   \item{HasEntryPoints}{
#'   Gibt an, ob EntryPoints vorhanden sind.
#'   }
#'
#'   \item{HasForms}{
#'   Gibt an, ob Formularreferenzen vorhanden sind.
#'   }
#'
#'   \item{HasControls}{
#'   Gibt an, ob Formular-Controls referenziert werden.
#'   }
#'
#'   \item{HasDataSources}{
#'   Gibt an, ob Form Data Sources referenziert werden.
#'   }
#'
#'   \item{HasDataEntityPermissions}{
#'   Gibt an, ob Data Entity Permissions vorhanden sind.
#'   }
#'
#'   \item{HasDataEntityMethods}{
#'   Gibt an, ob Data Entity Method Permissions vorhanden sind.
#'   }
#'
#'   \item{HasDirectAccessPermissions}{
#'   Gibt an, ob Direct Access Permissions vorhanden sind.
#'   }
#' }
#'
#' @details
#' Die Analyse erfolgt anhand der in
#' `analyze_privilege_entrypoints()` ermittelten XML-Knoten.
#'
#' Für jede unterstützte Security-Komponente wird geprüft,
#' ob der entsprechende XML-Knotentyp im Privilege enthalten
#' ist.
#'
#' Die Funktion liefert ausschließlich strukturelle
#' Informationen und keine Detailinformationen zu den
#' einzelnen Security-Objekten.
#'
#' @examples
#' privilege_analysis <-
#'   analyze_privilege_entrypoints(
#'     "CustTableMaintain.xml"
#'   )
#'
#' structure_info <-
#'   analyze_privilege_structure(
#'     privilege_analysis
#'   )
#'
#' structure_info
#'
#' structure_info$HasEntryPoints
#'
#' @seealso
#' analyze_privilege_entrypoints()
#'
#' @export
analyze_privilege_structure <- function(
    privilege_analysis
){

  xml_nodes <- unique(
    privilege_analysis$XmlNode
  )

  result <- list(

    HasEntryPoints =
      "AxSecurityEntryPointReference" %in% xml_nodes,

    HasForms =
      "AxSecurityEntryPointReferenceForm" %in% xml_nodes,

    HasControls =
      "AxSecurityEntryPointReferenceFormControl" %in% xml_nodes,

    HasDataSources =
      "AxSecurityEntryPointReferenceFormDataSource" %in% xml_nodes,

    HasDataEntityPermissions =
      "AxSecurityDataEntityPermission" %in% xml_nodes,

    HasDataEntityMethods =
      "AxSecurityDataEntityMethodPermission" %in% xml_nodes,

    HasDirectAccessPermissions =
      any(
        xml_nodes %in%
          c(
            "AxSecurityDataEntityReference",
            "AxSecurityDataEntityFieldReference"
          )
      )
  )

  class(result) <- "D365PrivilegeStructure"

  return(result)
}
