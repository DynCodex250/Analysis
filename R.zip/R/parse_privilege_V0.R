#' D365FO Privilege XML in ein Standardmodell einlesen
#'
#' Liest eine D365FO Privilege XML-Datei ein und wandelt die
#' enthaltenen Sicherheitsinformationen in ein standardisiertes
#' R-Modell um.
#'
#' Die Funktion dient als zentrale Grundlage für:
#'
#' - Analyse von Privileges
#' - Vergleich von Privileges
#' - Roundtrip-Tests
#' - Lizenzoptimierung
#' - Reverse Engineering
#' - XML-Neugenerierung mittels generate_privilege_xml()
#'
#' Folgende Komponenten werden aus der XML extrahiert:
#'
#' - Metadata
#' - EntryPoints
#' - DataEntityPermissions
#' - DataEntityMethods
#' - DirectAccessPermissions
#' - DirectAccessFields
#'
#' Das Ergebnis wird als standardisiertes Objekt der Klasse
#' "D365Privilege" zurückgegeben.
#'
#' @param xml_file Pfad zur D365FO Privilege XML-Datei
#'
#' @return Objekt der Klasse "D365Privilege" mit den Komponenten:
#'
#' \describe{#'   \item{Metadata}{
#'     Allgemeine Informationen zum Privilege
#'     (Name, Description, Label)
#'   }
#'
#'   \item{EntryPoints}{
#'     Referenzierte Menüeinträge inklusive Berechtigungen
#'   }
#'
#'   \item{DataEntityPermissions}{
#'     Data Entities inklusive Integrationsmodus und
#'     Berechtigungen#'   }
#'
#'   \item{DataEntityMethods}{
#'     Methodenberechtigungen von Data Entities
#'   }
#'
#'   \item{DirectAccessPermissions}{
#'     Direct-Access-Objekte inklusive Objektberechtigungen#'   }
#'
#'   \item{DirectAccessFields}{
#'     Feldberechtigungen innerhalb von
#'     Direct-Access-Objekten#'   }
#' }
#'
#' @details#' Die Funktion unterstützt aktuell:
#'
#' - EntryPoint Grants#' - DataEntity Grants
#' - DataEntity Methods
#' - DirectAccess Permissions
#' - DirectAccess Field Permissions
#'
#'
#' Die erzeugte Struktur ist kompatibel mit
#' generate_privilege_xml() und ermöglicht vollständige
#' Roundtrip-Tests.
#'
#' @examples#' privilege_model <- parse_privilege(
#'   xml_file = "CustCustomerEntityMaintain.xml"
#' )
#'
#' privilege_model$Metadata
#'
#' privilege_model$EntryPoints
#'
#' privilege_model$DirectAccessPermissions
#'
#' @export



parse_privilege_V0 <- function(xml_file){

  xml_doc <- xml2::read_xml(xml_file)

  # =====================================
  #   METADATA
  # =====================================

  metadata <- tibble::tibble(

    Name =
      xml2::xml_text(
        xml2::xml_find_first(
          xml_doc,
          "//AxSecurityPrivilege/Name")
      ),

    Description =
      xml2::xml_text(
        xml2::xml_find_first(
          xml_doc,
          "//AxSecurityPrivilege/Description")
      ),

    Label =
      xml2::xml_text(
        xml2::xml_find_first(
          xml_doc,
          "//AxSecurityPrivilege/Label")
      )

  )

  # =====================================
  #   ENTRYPOINTS
  # =====================================

  entrypoints <- xml2::xml_find_all(xml_doc, "//EntryPoints/AxSecurityEntryPointReference")

  entrypoint_df <- purrr::map_dfr(entrypoints,function(node){

    tibble::tibble(

      Name =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./Name")
        ),

      ObjectName =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./ObjectName")
        ),

      ObjectType =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./ObjectType")
        ),

      ObjectChildName =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./ObjectChildName")
        ),

      HasForms =
        !inherits(
          xml2::xml_find_first(
            node, "./Forms"),
          "xml_missing"
        ),

      Read =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./Grant/Read")
        ),

      Create =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./Grant/Create")
        ),

      Update =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./Grant/Update")
        ),

      Delete =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./Grant/Delete")
        ),

      Correct =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./Grant/Correct")
        ),

      Invoke =
        xml2::xml_text(
          xml2::xml_find_first(
            node,
            "./Grant/Invoke")
        )
    )
  }

  )

  # =====================================
  #   ENTRY POINT FORMS
  # =====================================

  form_nodes <- xml2::xml_find_all(xml_doc,"//EntryPoints//Forms/")

  entrypoint_forms_df <- purrr::map_dfr(form_nodes,function(form_node){

    entrypoint_node <-
      xml2::xml_parent(
        xml2::xml_parent(form_node)
      )

    tibble::tibble(
      EntryPointName =
        xml2::xml_text(
          xml2::xml_find_first(
            entrypoint_node,
            "./Name")
        ),

      FormName =
        xml2::xml_text(
          xml2::xml_find_first(
            form_node,
            "./Name")
        )
    )
  }

  )

  #Sicherstellen, dass leere Ergebnisse
  #die erwartete Struktur besitzen

  if(ncol(entrypoint_forms_df) == 0){

    entrypoint_forms_df <- tibble::tibble(
      EntryPointName = character(),
      FormName = character()
    )

  }

  # =====================================
  #   ENTRY POINT CONTROLS
  # =====================================

  control_nodes <- xml2::xml_find_all(xml_doc,"//EntryPoints//Forms//Controls/*")

  entrypoint_controls_df <- purrr::map_dfr(control_nodes,function(control_node){

    form_node <-
      xml2::xml_parent(
        xml2::xml_parent(control_node)
      )

    entrypoint_node <-
      xml2::xml_parent(
        xml2::xml_parent(form_node)
      )

    grant_node <-
      xml2::xml_find_first(
        control_node,
        "./Grant")

    tibble::tibble(

      EntryPointName =
        xml2::xml_text(
          xml2::xml_find_first(
            entrypoint_node,
            "./Name")
        ),

      FormName =
        xml2::xml_text(
          xml2::xml_find_first(
            form_node,
            "./Name")
        ),

      ControlName =
        xml2::xml_text(
          xml2::xml_find_first(
            control_node,
            "./Name")
        ),

      Read =
        xml2::xml_text(
          xml2::xml_find_first(
            grant_node,
            "./Read")
        ),

      Create =
        xml2::xml_text(
          xml2::xml_find_first(
            grant_node,
            "./Create")
        ),

      Update =
        xml2::xml_text(
          xml2::xml_find_first(
            grant_node,
            "./Update")
        ),

      Delete =
        xml2::xml_text(
          xml2::xml_find_first(
            grant_node,
            "./Delete")
        ),

      Correct =
        xml2::xml_text(
          xml2::xml_find_first(
            grant_node,
            "./Correct")
        ),

      Invoke =
        xml2::xml_text(
          xml2::xml_find_first(
            grant_node,
            "./Invoke")
        )
    )
  }

  )

  if(ncol(entrypoint_controls_df) == 0){

    entrypoint_controls_df <- tibble::tibble(

      EntryPointName = character(),
      FormName = character(),
      ControlName = character(),

      Correct = character(),
      Create = character(),
      Delete = character(),
      Invoke = character(),
      Read = character(),
      Update = character()

    )

  }

  # =====================================
  #   ENTRY POINT FORM DATASOURCES
  # =====================================

  datasource_nodes <- xml2::xml_find_all(xml_doc,"//EntryPoints//Forms//DataSources//AxSecurityEntryPointReferenceFormDataSource")

  entrypoint_datasources_df <- purrr::map_dfr(

    datasource_nodes,

    function(datasource_node){

      form_node <-
        xml2::xml_parent(
          xml2::xml_parent(
            datasource_node)
        )

      entrypoint_node <-
        xml2::xml_parent(
          xml2::xml_parent(
            form_node)
        )

      tibble::tibble(

        EntryPointName =
          xml2::xml_text(
            xml2::xml_find_first(
              entrypoint_node,
              "./Name")
          ),

        FormName =
          xml2::xml_text(
            xml2::xml_find_first(
              form_node,
              "./Name")
          ),

        DataSourceName =
          xml2::xml_text(
            xml2::xml_find_first(
              datasource_node,
              "./Name")
          )
      )
    }

  )

  # =====================================
  #   DATA ENTITY PERMISSIONS
  # =====================================

  entities <- xml2::xml_find_all(xml_doc,"//DataEntityPermissions/AxSecurityDataEntityPermission")

  entity_df <- purrr::map_dfr(

    entities,

    function(node){

      tibble::tibble(

        EntityName =
          xml2::xml_text(
            xml2::xml_find_first(
              node,
              "./Name")
          ),

        IntegrationMode =
          xml2::xml_text(
            xml2::xml_find_first(
              node,
              "./IntegrationMode")
          ),

        Read =
          xml2::xml_text(
            xml2::xml_find_first(
              node,
              "./Grant/Read")
          ),

        Create =
          xml2::xml_text(
            xml2::xml_find_first(
              node,
              "./Grant/Create")
          ),

        Update =
          xml2::xml_text(
            xml2::xml_find_first(
              node,
              "./Grant/Update")
          ),

        Delete =
          xml2::xml_text(
            xml2::xml_find_first(
              node,
              "./Grant/Delete")
          ),

        Correct =
          xml2::xml_text(
            xml2::xml_find_first(
              node,
              "./Grant/Correct")
          ),

        Invoke =
          xml2::xml_text(
            xml2::xml_find_first(
              node,
              "./Grant/Invoke")
          )
      )
    }

  )

  # =====================================
  #   DATA ENTITY METHODS
  # =====================================

  entity_nodes <- xml2::xml_find_all(xml_doc,"//DataEntityPermissions/AxSecurityDataEntityPermission")

  method_df <- purrr::map_dfr(

    entity_nodes,

    function(entity_node){

      entity_name <- xml2::xml_text(
        xml2::xml_find_first(
          entity_node,
          "./Name")
      )

      methods <- xml2::xml_find_all(
        entity_node,
        "./Methods/AxSecurityDataEntityMethodPermission"
      )

      purrr::map_dfr(

        methods,

        function(method_node){

          tibble::tibble(

            EntityName =
              entity_name,

            MethodName =
              xml2::xml_text(
                xml2::xml_find_first(
                  method_node,
                  "./Name")
              ),

            Read =
              xml2::xml_text(
                xml2::xml_find_first(
                  method_node,
                  "./Grant/Read")
              ),

            Create =
              xml2::xml_text(
                xml2::xml_find_first(
                  method_node,
                  "./Grant/Create")
              ),

            Update =
              xml2::xml_text(
                xml2::xml_find_first(
                  method_node,
                  "./Grant/Update")
              ),

            Delete =
              xml2::xml_text(
                xml2::xml_find_first(
                  method_node,
                  "./Grant/Delete")
              ),

            Correct =
              xml2::xml_text(
                xml2::xml_find_first(
                  method_node,
                  "./Grant/Correct")
              ),

            Invoke =
              xml2::xml_text(
                xml2::xml_find_first(
                  method_node,
                  "./Grant/Invoke")
              )
          )
        }
      )
    }

  )

  # =====================================
  #   DIRECT ACCESS
  # =====================================

  direct_access <- xml2::xml_find_all(xml_doc,"//DirectAccessPermissions/*")

  direct_access_df <- purrr::map_dfr(
    direct_access,

    function(node){

      grant_node <-
        xml2::xml_find_first(
          node,
          "./Grant")

      tibble::tibble(
        XmlNode =
          xml2::xml_name(node),

        ObjectName =
          xml2::xml_text(
            xml2::xml_find_first(
              node,
              "./Name")
          ),

        Read =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Read")
          ),

        Create =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Create")
          ),

        Update =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Update")
          ),

        Delete =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Delete")
          ),

        Correct =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Correct")
          ),

        Invoke =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Invoke")
          )
      )
    }

  )

  # =====================================
  #   DIRECT ACCESS FIELDS
  # =====================================

  field_nodes <- xml2::xml_find_all(xml_doc,"//DirectAccessPermissions//Fields/")

  direct_access_fields_df <- purrr::map_dfr(

    field_nodes,

    function(field_node){
      parent_permission <-
        xml2::xml_parent(
          xml2::xml_parent(field_node)
        )

      grant_node <-
        xml2::xml_find_first(
          field_node,
          "./Grant")

      tibble::tibble(

        ParentObject =
          xml2::xml_text(
            xml2::xml_find_first(
              parent_permission,
              "./Name"
            )
          ),

        ParentXmlNode =
          xml2::xml_name(
            parent_permission
          ),

        FieldName =

          xml2::xml_text(
            xml2::xml_find_first(
              field_node,
              "./Name"
            )
          ),

        Read =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Read")
          ),

        Create =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Create")
          ),

        Update =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Update")
          ),

        Delete =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Delete")
          ),

        Correct =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Correct")
          ),

        Invoke =
          xml2::xml_text(
            xml2::xml_find_first(
              grant_node,
              "./Invoke")
          )
      )
    }

  )

  if(ncol(direct_access_fields_df) == 0){

    direct_access_fields_df <- tibble::tibble(

      ParentObject = character(),
      ParentXmlNode = character(),
      FieldName = character(),
      Create = character(),
      Correct = character(),
      Delete = character(),
      Invoke = character(),
      Read = character(),
      Update = character()
    )

  }



  # =====================================
  #   FORM CONTROL OVERRIDES
  # =====================================

  override_nodes <-xml2::xml_find_all(xml_doc,"//FormControlOverrides//AxSecurityFormControlReference")

  form_control_overrides_df <-
    purrr::map_dfr(
      override_nodes,

      function(control_node){

        controls_node <-
          xml2::xml_parent(
            control_node)

        collection_node <-
          xml2::xml_parent(
            controls_node)

        tibble::tibble(

          ParentForm =
            xml2::xml_text(
              xml2::xml_find_first(
                collection_node,
                "./Name")
            ),

          ControlName =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Name")
            ),

          Read =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Read")
            ),

          Create =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Create")
            ),

          Update =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Update")
            ),

          Delete =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Delete")
            ),

          Correct =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Correct")
            ),

          Invoke =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Invoke")
            )
        )

      }

    )

  # =====================================
  #   RETURN
  # =====================================

  structure(

    list(
      Metadata                = metadata,
      EntryPoints             = entrypoint_df,
      EntryPointForms         = entrypoint_forms_df,
      EntryPointControls      = entrypoint_controls_df,
      EntryPointFormDataSources  = entrypoint_datasources_df,
      DataEntityPermissions   = entity_df,
      DataEntityMethods       = method_df,
      DirectAccessPermissions = direct_access_df,
      DirectAccessFields      = direct_access_fields_df,
      FormControlOverrides    = form_control_overrides_df
    ),

    class = "D365Privilege"

  )

}
