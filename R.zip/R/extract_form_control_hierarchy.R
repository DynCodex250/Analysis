#' Control-Hierarchie extrahieren
#'
#' Rekonstruiert die vollständige Parent-Child-Hierarchie
#' eines D365FO Formulars.
#'
#' Die Funktion basiert auf den Parent-Beziehungen der Controls
#' und bildet die tatsächliche Struktur des Formulars nach.
#'
#' @param form_model Ergebnis von [analyze_form()].
#' @param root Optionaler Name eines Root-Controls.
#'   Wird kein Root angegeben, werden alle Root-Controls
#'   des Formulars analysiert.
#'
#' @return Verschachtelte Liste der Klasse `D365FormHierarchy`.
#'   Jeder Knoten enthält:
#'
#'   * `Name` — Technischer Name
#'   * `Type` — Control-Typ
#'   * `Parent` — Übergeordnetes Control
#'   * `Level` — Tiefe in der Hierarchie
#'   * `Path` — Vollständiger Pfad
#'   * `Children` — Liste untergeordneter Controls
#'
#' @seealso [analyze_form()], [extract_form_controls_by_type()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#'
#' # Vollständige Hierarchie
#' hierarchy <- extract_form_control_hierarchy(form_model)
#'
#' # Teilbaum ab einem bestimmten Control
#' hierarchy <- extract_form_control_hierarchy(
#'   form_model,
#'   "TabSalesDemographics"
#' )
#' }
#'
#' @export
extract_form_control_hierarchy <- function(
    form_model,
    root = NULL) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  controls <- form_model$Controls

  # ================================
  # REKURSIVE HILFSFUNKTION
  # ================================

  build_node <- function(node_name) {

    current <-
      controls |>
      dplyr::filter(Name == node_name)

    if (nrow(current) == 0) {
      return(NULL)
    }

    children <-
      controls |>
      dplyr::filter(Parent == node_name)

    child_nodes <- list()

    if (nrow(children) > 0) {

      for (i in seq_len(nrow(children))) {

        child_name <- children$Name[[i]]

        child_nodes[[child_name]] <-
          build_node(child_name)
      }
    }

    list(
      Name     = current$Name[[1]],
      Type     = current$Type[[1]],
      Parent   = current$Parent[[1]],
      Level    = current$Level[[1]],
      Path     = current$Path[[1]],
      Children = child_nodes
    )
  }

  # ================================
  # ROOT ERMITTELN
  # ================================

  if (is.null(root)) {

    root_controls <-
      controls |>
      dplyr::filter(is.na(Parent))

    result <- list()

    for (i in seq_len(nrow(root_controls))) {

      root_name <- root_controls$Name[[i]]

      result[[root_name]] <-
        build_node(root_name)
    }

  } else {

    result <- build_node(root)
  }

  # ================================
  # KLASSE SETZEN
  # ================================

  class(result) <- c("D365FormHierarchy", "list")

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
