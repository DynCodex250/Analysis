#' Export data frame to Excel
#'
#' Exports a data frame to a Microsoft Excel
#' workbook.
#'
#' The function optionally creates hyperlinks
#' for one column and adds a dropdown list
#' for manual review workflows.
#'
#' The generated workbook contains:
#'
#' \itemize{
#'   \item Auto filter
#'   \item Auto column width
#'   \item Frozen header row
#'   \item Optional hyperlinks
#'   \item Optional dropdown validation
#' }
#'
#' @param data Data frame to export.
#'
#' @param file Full path of the Excel file to
#'   create.
#'
#' @param hyperlink_column Optional column
#'   whose values are converted into Excel
#'   hyperlinks.
#'
#' @param base_url Base URL used to generate
#'   hyperlinks.
#'
#' @param dropdown_col_name Optional column
#'   that receives an Excel dropdown list.
#'
#' @param dropdown_values Character vector
#'   containing the allowed dropdown values.
#'
#' @return Invisibly returns the path of the
#' generated Excel workbook.
#'
#' @details
#' The function creates a workbook using the
#' \pkg{openxlsx} package.
#'
#' If a hyperlink column is specified, every
#' non-empty value is converted into an Excel
#' hyperlink using the supplied base URL.
#'
#' If dropdown information is supplied, Excel
#' data validation is applied to the selected
#' column for all exported rows.
#'
#' The worksheet is formatted automatically by
#' enabling filters, adjusting column widths
#' and freezing the header row.
#'
#' @examples
#' \dontrun{
#'
#' export_excel_review(
#'   data = review_table,
#'   file = "SecurityReview.xlsx",
#'   hyperlink_column = "RESOURCE",
#'   base_url =
#'     "https://operations.eu.dynamics.com/",
#'   dropdown_col_name = "Decision",
#'   dropdown_values = c(
#'     "Keep",
#'     "Remove",
#'     "Review",
#'     "Ask Business"
#'   )
#' )
#'
#' }
#'
#' @export
export_excel_review <- function(
    data,
    file,
    hyperlink_column = NULL,
    base_url = NULL,
    dropdown_col_name = NULL,
    dropdown_values = NULL
){
  
  #===========================================================
  # VALIDATE INPUT
  #===========================================================
  
  if (!is.data.frame(data)) {
    stop("'data' muss ein DataFrame sein.")
  }
  
  if (!is.null(dropdown_col_name)) {
    data[[dropdown_col_name]] <- NA_character_
  }
  
  #===========================================================
  # CREATE WORKBOOK
  #===========================================================
  
  wb <- openxlsx::createWorkbook()
  
  openxlsx::addWorksheet(
    wb = wb,
    sheetName = "Export"
  )
  
  openxlsx::writeData(
    wb = wb,
    sheet = "Export",
    x = data,
    withFilter = TRUE
  )
  
  #===========================================================
  # CREATE HYPERLINKS
  #===========================================================
  
  if (!is.null(hyperlink_column)) {
    
    if (!hyperlink_column %in% names(data)) {
      stop(
        paste0(
          "Spalte '",
          hyperlink_column,
          "' wurde nicht gefunden."
        )
      )
    }
    
    if (is.null(base_url)) {
      stop(
        "'base_url' muss angegeben werden, wenn 'hyperlink_column' verwendet wird."
      )
    }
    
    hyperlink_col <-
      which(names(data) == hyperlink_column)
    
    for (i in seq_len(nrow(data))) {
      
      value <-
        as.character(
          data[[hyperlink_column]][i]
        )
      
      if (!is.na(value) && nzchar(value)) {
        
        openxlsx::writeFormula(
          wb = wb,
          sheet = "Export",
          x = openxlsx::makeHyperlinkString(
            file = paste0(base_url, value),
            text = value
          ),
          startCol = hyperlink_col,
          startRow = i + 1
        )
        
      }
      
    }
    
  }
  
  #===========================================================
  # CREATE DROPDOWN
  #===========================================================
  
  if (!is.null(dropdown_col_name) &&
      !is.null(dropdown_values)) {
    
    dropdown_col <-
      which(names(data) == dropdown_col_name)
    
    openxlsx::dataValidation(
      wb = wb,
      sheet = "Export",
      cols = dropdown_col,
      rows = 2:(nrow(data) + 1),
      type = "list",
      value = paste0(
        "\"",
        paste(dropdown_values,
              collapse = ","),
        "\""
      )
    )
    
  }
  
  #===========================================================
  # FORMAT WORKSHEET
  #===========================================================
  
  openxlsx::setColWidths(
    wb = wb,
    sheet = "Export",
    cols = seq_len(ncol(data)),
    widths = "auto"
  )
  
  openxlsx::freezePane(
    wb = wb,
    sheet = "Export",
    firstRow = TRUE
  )
  
  #===========================================================
  # SAVE WORKBOOK
  #===========================================================
  
  openxlsx::saveWorkbook(
    wb = wb,
    file = file,
    overwrite = TRUE
  )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  invisible(file)
  
}