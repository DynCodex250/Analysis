#' Detect D365FO privilege type
#'
#' Determines the structural type of a
#' Microsoft Dynamics 365 Finance &
#' Operations privilege based on the
#' contained resource types.
#'
#' The detected privilege type is used during
#' XML generation to determine which XML
#' structure must be created.
#'
#' Supported privilege types are:
#'
#' \itemize{
#'   \item EntryPointPrivilege
#'   \item DataEntityPrivilege
#'   \item DataEntityActionPrivilege
#'   \item HybridFormPrivilege
#'   \item DirectAccessPrivilege
#' }
#'
#' @param privilege_data Data frame
#' containing all resources belonging to
#' a single privilege.
#'
#' @return A character string containing the
#' detected privilege type.
#'
#' @details
#' The function analyses the values stored in
#' the column \code{RESOURCETYPE}.
#'
#' The evaluation is performed in the
#' following order:
#'
#' \enumerate{
#'   \item Data Entity Action
#'   \item Form Controls / Data Sources
#'   \item Data Entities
#'   \item Direct Access
#'   \item Entry Points
#' }
#'
#' If no supported resource combination is
#' found, the function returns
#' \code{"Unknown"}.
#'
#' @examples
#' \dontrun{
#'
#' privilege_type <-
#'   detect_privilege_type(
#'     privilege_data
#'   )
#'
#' }
#'
#' @export
detect_privilege_type <- function(privilege_data){
  
  #===========================================================
  # RESOURCE TYPES READ
  #===========================================================
  
  resource_types <-
    unique(privilege_data$RESOURCETYPE)
  
  #===========================================================
  # DATA ENTITY ACTION PRIVILEGE
  #===========================================================
  
  if(any(resource_types == "Data entity action")){
    
    return(
      "DataEntityActionPrivilege"
    )
    
  }
  
  #===========================================================
  # HYBRID FORM PRIVILEGE
  #===========================================================
  
  if(any(
    resource_types %in%
    c(
      "Form control",
      "Form Data Source"
    )
  )){
    
    return(
      "HybridFormPrivilege"
    )
    
  }
  
  #===========================================================
  # DATA ENTITY PRIVILEGE
  #===========================================================
  
  if(all(
    resource_types %in%
    c("Data entity")
  )){
    
    return(
      "DataEntityPrivilege"
    )
    
  }
  
  #===========================================================
  # DIRECT ACCESS PRIVILEGE
  #===========================================================
  
  if(all(
    resource_types %in%
    c(
      "Table",
      "Table Field"
    )
  )){
    
    return(
      "DirectAccessPrivilege"
    )
    
  }
  
  #===========================================================
  # ENTRY POINT PRIVILEGE
  #===========================================================
  
  if(any(
    resource_types %in%
    c(
      "Menu item display",
      "Menu item action",
      "Menu item output",
      "Service operation"
    )
  )){
    
    return(
      "EntryPointPrivilege"
    )
    
  }
  
  #===========================================================
  # UNKNOWN TYPE
  #===========================================================
  
  return("Unknown")
  
}