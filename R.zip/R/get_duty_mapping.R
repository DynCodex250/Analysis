#' Ermittelt die Zuordnung zwischen Privileges und Duties einer D365FO Security-Rolle
#'
#' Diese Funktion ermittelt für eine Menge von Privileges alle
#' übergeordneten Duties innerhalb einer bestimmten Security-Rolle.
#'
#' Die Informationen werden aus der Tabelle
#' `UserSecGovRelatedObjects` gelesen und bilden die Beziehung:
#'
#' Privilege → Duty
#'
#' Die Funktion dient insbesondere zum schrittweisen Aufbau der
#' vollständigen D365FO Security-Hierarchie aus SQL-Daten.
#'
#' @param con Offene ODBC-Datenbankverbindung.
#'
#' @param role_name Name oder Identifier der Security-Rolle.
#' Es wird sowohl auf `ROLENAME` als auch auf
#' `ROLEIDENTIFIER` gefiltert.
#'
#' @param privileges Data Frame oder Tibble mit mindestens der
#' Spalte `PRIVILEGEIDENTIFIER`.
#'
#' @details
#' Für alle übergebenen Privileges wird die Tabelle
#' `UserSecGovRelatedObjects` durchsucht.
#'
#' Es werden ausschließlich Datensätze berücksichtigt, die der
#' angegebenen Security-Rolle zugeordnet sind.
#'
#' Liefert zu jedem Privilege die referenzierte Duty.
#'
#' Ist `privileges` leer, wird sofort ein leeres Tibble
#' zurückgegeben.
#'
#' @return
#' Tibble mit den Spalten:
#'
#' * `DUTYIDENTIFIER`
#' * `DUTYNAME`
#' * `PRIVILEGEIDENTIFIER`
#' * `PRIVILEGENAME`
#'
#' @examples
#' \dontrun{
#'
#' con <- get_connection("PROD")
#'
#' duties <- get_duty_mapping(
#'   con,
#'   role_name = "_WIBU Logistik Mitarbeiter",
#'   privileges
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{get_privilege_mapping}}
#' \code{\link{get_sql_security_hierarchy}}
#'
#' @export
get_duty_mapping <- function(
    con,
    role_name,
    privileges){
  
  if(nrow(privileges) == 0)
  {
    return(tibble())
  }
  
  privilege_list <- paste0(
    
    "'",
    
    privileges$PRIVILEGEIDENTIFIER,
    
    "'",
    
    collapse = ","
    
  )
  
  sql <- glue::glue("

    SELECT DISTINCT

      DUTYIDENTIFIER,
      DUTYNAME,
      PRIVILEGEIDENTIFIER,
      PRIVILEGENAME

    FROM
      UserSecGovRelatedObjects

    WHERE
      PRIVILEGEIDENTIFIER IN ({privilege_list})
      AND
      (
        ROLENAME LIKE '%{role_name}%'
        OR
        ROLEIDENTIFIER LIKE '%{role_name}%'
      )

    ORDER BY
      DUTYIDENTIFIER ASC

  ")
  
  result <- odbc::dbGetQuery(
    con,
    sql
  )
  
  return(result)
}