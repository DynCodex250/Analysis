SECURITY_PRIVILEGE_MAPPING <- tibble::tribble(
  
  ~resource_type,
  ~xml_section,
  ~xml_node,
  ~parent_node,
  ~xml_subnode,
  ~object_type,
  ~resource_pattern,
  ~supports_grants,
  ~supports_fields,
  ~supports_subpermissions,
  ~notes,
  
  # =====================================================
  # MENU ITEM DISPLAY
  # =====================================================
  
  "Menu item display",
  "EntryPoints",
  "AxSecurityMenuItemDisplayReference",
  "EntryPoints",
  NA,
  "MenuItemDisplay",
  NA,
  TRUE,
  FALSE,
  FALSE,
  "Display MenuItems",
  
  # =====================================================
  # MENU ITEM ACTION
  # =====================================================
  
  "Menu item action",
  "EntryPoints",
  "AxSecurityMenuItemActionReference",
  "EntryPoints",
  NA,
  "MenuItemAction",
  NA,
  TRUE,
  FALSE,
  FALSE,
  "Action MenuItems",
  
  # =====================================================
  # MENU ITEM OUTPUT
  # =====================================================
  
  "Menu item output",
  "EntryPoints",
  "AxSecurityMenuItemOutputReference",
  "EntryPoints",
  NA,
  "MenuItemOutput",
  NA,
  TRUE,
  FALSE,
  FALSE,
  "Output MenuItems",
  
  # =====================================================
  # SERVICE OPERATION
  # =====================================================
  
  "Service operation",
  "EntryPoints",
  "AxSecurityServiceOperationReference",
  "EntryPoints",
  NA,
  "ServiceOperation",
  NA,
  TRUE,
  FALSE,
  FALSE,
  "Service operations",
  
  # =====================================================
  # DATA ENTITY
  # =====================================================
  
  "Data entity",
  "DataEntityPermissions",
  "AxSecurityDataEntityPermission",
  "DataEntityPermissions",
  NA,
  "DataEntity",
  "Data Management\\\\|Data services\\\\",
  TRUE,
  FALSE,
  TRUE,
  "Data entities",
  
  # =====================================================
  # DATA ENTITY ACTION
  # =====================================================
  
  "Data entity action",
  "DataEntityPermissions",
  "AxSecurityDataEntityMethodPermission",
  "DataEntityPermissions",
  "Methods",
  "DataEntityAction",
  "Data services\\\\",
  TRUE,
  FALSE,
  TRUE,
  "Entity methods/actions",
  
  # =====================================================
  # TABLE
  # =====================================================
  
  "Table",
  "DirectAccessPermissions",
  "AxSecurityDataEntityReference",
  "DirectAccessPermissions",
  NA,
  "Table",
  NA,
  TRUE,
  TRUE,
  TRUE,
  "Direct table permissions",
  
  # =====================================================
  # TABLE FIELD
  # =====================================================
  
  "Table Field",
  "DirectAccessPermissions",
  "AxSecurityDataEntityFieldReference",
  "Fields",
  NA,
  "TableField",
  NA,
  TRUE,
  FALSE,
  FALSE,
  "Direct table field permissions",
  
  # =====================================================
  # FORM CONTROL
  # =====================================================
  
  "Form control",
  "EntryPoints",
  "AxSecurityEntryPointReferenceFormControl",
  "FormControlOverrides",
  NA,
  "FormControl",
  NA,
  TRUE,
  FALSE,
  TRUE,
  "Form controls",
  
  # =====================================================
  # FORM DATA SOURCE
  # =====================================================
  
  "Form Data Source",
  "EntryPoints",
  "AxSecurityEntryPointReferenceFormDataSource",
  "FormControlOverrides",
  NA,
  "FormDataSource",
  NA,
  TRUE,
  TRUE,
  TRUE,
  "Form datasource permissions"
)