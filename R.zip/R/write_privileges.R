write_privileges <- function(
    parent_node,
    privileges){
  
  privileges_node <- xml_add_child(
    parent_node,
    "Privileges"
  )
  
  if(length(privileges) == 0)
  {
    return(privileges_node)
  }
  
  for(privilege in privileges)
  {
    privilege_ref <- xml_add_child(
      privileges_node,
      "AxSecurityPrivilegeReference"
    )
    
    xml_add_child(
      privilege_ref,
      "Name",
      privilege
    )
  }
  
  return(privileges_node)
}