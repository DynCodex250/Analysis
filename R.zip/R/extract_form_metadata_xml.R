#' Formular-Name extrahieren
#'
#' Extrahiert den technischen Namen eines D365FO
#' Formulars aus einem XML-Knoten.
#'
#' @param xml_doc XML-Dokument eines D365FO Formulars.
#'
#' @return Technischer Name des Formulars als `character`.
#'
#' @details
#' **Bekannter Fehler:** Im Funktionskörper wird
#' `root_node` referenziert, welches nicht als Parameter
#' definiert ist. Der korrekte Parameter wäre `xml_doc`.
#' Die Funktion muss vor dem Einsatz korrigiert werden.
#'
#' @seealso [analyze_form()]
#'
#' @keywords internal
extract_form_metadata_xml <- function(xml_doc) {

  return(
    xml2::xml_text(
      xml2::xml_find_first(
        xml_doc,
        "./*[local-name()='Name']"
      )
    )
  )
}
