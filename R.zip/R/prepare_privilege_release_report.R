#' Release-Report für Privilege-Vergleiche vorbereiten
#'#' Erstellt die Datenbasis für einen D365FO
#' Privilege Release-Report.
#'#' Die Funktion konsolidiert die Ergebnisse der
#' Compare-Funktionen in eine einheitliche
#' Report-Struktur, die anschließend für
#' Excel-, HTML- oder PDF-Exporte verwendet
#' werden kann.
#'#' @param release_comparison Ergebnis von
#' compare_privileges_release().
#'#' @param security_comparison Optionales Ergebnis
#' von compare_privileges_security().
#'#' @param risk_analysis Optionales Ergebnis von
#' compare_privileges_risk_analysis().
#'#' @return Objekt der Klasse
#' D365PrivilegeReleaseReport.
#'#' @details#' Die Funktion erstellt folgende Report-Bereiche:
#'#' * ReportInfo#' * ExecutiveSummary
#' * ReleaseOverview#' * AddedObjects
#' * RemovedObjects#' * SecurityChanges
#' * RiskAnalysis#'#' Die Darstellung der Added- und Removed-Objekte
#' wird über die Report-Mapping-Konfiguration
#' gesteuert.
#'#' Die erzeugte Struktur dient als Grundlage für
#' export_privilege_release_report().
#'#' @seealso#' compare_privileges_release()
#'#' @seealso#' export_privilege_release_report()
#'#' @examples#' report <-
#'   prepare_privilege_release_report(
#'     release_comparison#'   )
#'#' @export



prepare_privilege_release_report <- function(
    release_comparison,
    security_comparison = NULL,
    risk_analysis = NULL){

  # ================================
  #   EINGABEPARAMETER VALIDIEREN
  # ================================

    if(!inherits(release_comparison, "D365PrivilegeReleaseComparison")){

      stop("release_comparison muss ein D365PrivilegeReleaseComparison sein.")

    }

  # ================================
  #   DATEN AUFBEREITEN
  # ================================

    existence <-release_comparison$Existence

    report_mapping <-load_report_mapping()

    # ================================
    #   REPORT INFORMATIONEN ERSTELLEN
    # ================================

      report_metadata  <-create_report_metadata(release_comparison)



    # ================================
    #   RELEASE OVERVIEW ERSTELLEN
    # ================================

      release_overview <-create_release_overview(existence)

    # ================================
    #   ADDED OBJECTS ERSTELLEN
    # ================================

      added_objects <-normalize_existence_objects(
        existence_comparison = existence,
        change_type          = "Added",
        report_mapping       = report_mapping

      )

    # ================================
    #   REMOVED OBJECTS ERSTELLEN
    # ================================

      removed_objects <-normalize_existence_objects(
        existence_comparison = existence,
        change_type          = "Removed",
        report_mapping       = report_mapping

      )

    # ================================
    #   EXECUTIVE SUMMARY ERSTELLEN
    # ================================

      executive_summary <-release_comparison$Summary

    # ================================
    #   NORMALIZE
    # ================================

      security_changes <-

      if(!is.null(security_comparison)){

        normalize_security_changes(
          security_comparison)

      } else {
        NULL
      }

    risk_analysis_report <-

      if(!is.null(risk_analysis)){

        normalize_risk_analysis(
          risk_analysis)
      } else {
        NULL
      }

    # ================================
    #   REPORT ERSTELLEN
    # ================================

      result <-list(
        ReportInfo       = report_metadata,
        ExecutiveSummary = executive_summary,
        ReleaseOverview  = release_overview,
        AddedObjects     = added_objects,
        RemovedObjects   = removed_objects,
        SecurityChanges  = security_changes,
        RiskAnalysis     = risk_analysis_report)

    # ================================
    #   KLASSE SETZEN
    # ================================

      class(result) <-c("D365PrivilegeReleaseReport","list")

    # ================================
    #   ERGEBNIS ZURÜCKGEBEN
    # ================================

      return(result)

}
