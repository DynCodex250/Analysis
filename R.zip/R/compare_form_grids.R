#' D365FO Formular-Grids vergleichen
#'
#' Vergleicht die Grid-Dokumentation zweier
#' D365FO Formulardokumentationen und ermittelt,
#' welche Grids hinzugefügt oder entfernt wurden.
#'
#' Der Vergleich erfolgt auf Basis der fachlichen
#' Identität eines Grids.
#'
#' Hierzu werden die folgenden Eigenschaften als
#' Vergleichsschlüssel verwendet:
#'
#' - GridName
#' - DataSource
#'
#' Die Funktion eignet sich insbesondere für:
#' - Release-Vergleiche
#' - Formularanalysen
#' - Regressionstests
#' - Dokumentationsvergleiche
#' - Reverse Engineering
#'
#' @param old_documentation Dokumentation der
#'        ursprünglichen Formularversion.
#'        Objekt der Klasse
#'        `D365FormDocumentation`.
#'
#' @param new_documentation Dokumentation der
#'        neuen Formularversion.
#'        Objekt der Klasse
#'        `D365FormDocumentation`.
#'
#' @return Liste mit den Elementen:
#'
#' \describe{
#'   \item{Added}{
#'   Neu hinzugefügte Grids einschließlich
#'   aller verfügbaren Grid-Informationen.
#'   }
#'
#'   \item{Removed}{
#'   Entfernte Grids einschließlich
#'   aller verfügbaren Grid-Informationen.
#'   }
#' }
#'
#' @details
#' Die Funktion analysiert ausschließlich die
#' Existenz von Grids.
#'
#' Änderungen innerhalb eines bestehenden Grids
#' werden nicht erkannt.
#'
#' Ein Grid gilt als identisch, wenn die
#' Kombination aus:
#'
#' - GridName
#' - DataSource
#'
#' übereinstimmt.
#'
#' Die vollständigen Grid-Informationen bleiben
#' im Ergebnis erhalten, sodass nachgelagerte
#' Analysen möglich sind.
#'
#' Die Funktion bildet die Grundlage für
#' Formular-Release-Vergleiche und strukturelle
#' Formularanalysen.
#'
#' @seealso
#' compare_forms_documentation()
#' compare_form_datasources()
#' compare_form_controls()
#'
#' @examples
#' compare_form_grids(
#'   old_documentation,
#'   new_documentation
#' )
#'
#' @export
compare_form_grids <- function(
    old_documentation,
    new_documentation){

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if(!inherits(old_documentation, "D365FormDocumentation")){

    stop("old_documentation muss ein D365FormDocumentation sein.")
  }

  if(!inherits(new_documentation, "D365FormDocumentation")){

    stop("new_documentation muss ein D365FormDocumentation sein.")
  }

  # ================================
  # GRIDS LADEN
  # ================================

  old_grids <- old_documentation$Grids

  new_grids <- new_documentation$Grids

  # ================================
  # VERGLEICHSSCHLÜSSEL
  # ================================

  key_columns <-

    c("GridName", "DataSource")

  # ================================
  # HINZUGEFÜGT
  # ================================

  added <-

    dplyr::anti_join(
      new_grids,
      old_grids,
      by = key_columns
    )

  # ================================
  # ENTFERNT
  # ================================

  removed <-

    dplyr::anti_join(
      old_grids,
      new_grids,
      by = key_columns
    )

  # ================================
  # ERGEBNIS
  # ================================

  result <-
    list(
      Added = added,
      Removed = removed
    )

  return(result)

}
