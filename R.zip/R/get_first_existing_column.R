#' Erste vorhandene Spalte ermitteln#'#' Ermittelt aus einer Liste möglicher#' Spaltennamen die erste tatsächlich#' vorhandene Spalte eines Data Frames.#'#' Die Funktion wird verwendet, um#' unterschiedliche Security-Komponenten#' mit verschiedenen Tabellenstrukturen#' einheitlich auszulesen.#'#' @param data Data Frame oder Tibble.#'#' @param candidates Vektor möglicher#' Spaltennamen.#'#' @return Vektor mit Spaltenwerten oder#' NA-Werte falls keine Spalte vorhanden ist.#'#' @details#' Die Funktion wird intern von#' normalize_existence_objects()#' verwendet.#'#' @examples#' get_first_existing_column(#'   data,#'   c(#'     "Name",#'     "ObjectName"#'   )#' )

get_first_existing_column <- function(data,candidates){

  # ================================
  #   EINGABEPARAMETER VALIDIEREN
  # ================================

    if(!is.data.frame(data)){

      stop("data muss ein Data Frame sein.")

    }

  if(!is.character(candidates)){

    stop("candidates muss ein Character-Vektor sein.")

  }

  # ================================
  #   VERARBEITUNG DURCHFÜHREN
  # ================================

    for(column_name in candidates){

      if(column_name %in% names(data)){
        return(data[[column_name]])
      }

    }

  # ================================
  #   ERGEBNIS ZURÜCKGEBEN
  # ================================

    return(rep(NA_character_,nrow(data)))

}
