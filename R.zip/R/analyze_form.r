#' D365FO Formular analysieren
#'
#' Analysiert ein D365FO Formular und erstellt ein
#' standardisiertes Formularmodell der Klasse
#' `D365FormModel`.
#'
#' Die Funktion extrahiert die wichtigsten Metadaten
#' eines Formulars sowie enthaltene Data Sources,
#' Controls und Parts.
#'
#' Das erzeugte Modell dient als Grundlage für:
#' - Formularanalysen
#' - Reverse Engineering
#' - Dokumentationen
#' - Abhängigkeitsanalysen
#' - Sicherheitsanalysen
#'
#' @param xml_doc XML-Dokument eines D365FO Formulars.
#'        Typischerweise eingelesen mit
#'        `xml2::read_xml()`.
#'
#' @return Objekt der Klasse `D365FormModel`.
#'
#' Das Ergebnis enthält typischerweise folgende
#' Komponenten:
#'
#' \describe{
#'   \item{Metadata}{
#'   Allgemeine Formularinformationen wie Name,
#'   FormTemplate, InteractionClass und DataSourceQuery.
#'   }
#'
#'   \item{DataSources}{
#'   Enthaltene Form Data Sources.
#'   }
#'
#'   \item{Controls}{
#'   Enthaltene Form Controls.
#'   }
#'
#'   \item{Parts}{
#'   Referenzierte Formularbestandteile.
#'   }
#' }
#'
#' @details
#' Die Funktion erstellt zunächst ein leeres
#' Formularmodell über `empty_form_model()`
#' und ergänzt anschließend die aus dem XML
#' extrahierten Informationen.
#'
#' Die eigentliche Analyse der einzelnen
#' Formularbestandteile erfolgt über die
#' spezialisierten Hilfsfunktionen:
#'
#' - extract_form_datasources()
#' - extract_form_controls()
#' - extract_form_parts()
#'
#' @examples
#' xml_doc <- xml2::read_xml(
#'   "CustTable.xml"
#' )
#'
#' form_model <- analyze_form(
#'   xml_doc
#' )
#'
#' form_model$Metadata
#'
#' form_model$DataSources
#'
#' form_model$Controls
#'
#' form_model$Parts
#'
#' @seealso
#' empty_form_model()
#' extract_form_datasources()
#' extract_form_controls()
#' extract_form_parts()
#'
#' @export
analyze_form <- function(
    xml_doc
){

  # ================================
  # LEERES MODELL ERSTELLEN
  # ================================

  result <- empty_form_model()

  # ================================
  # METADATEN AUSLESEN
  # ================================
  root_node <-
    xml2::xml_root(xml_doc)

  result$Metadata$Name <-
    xml2::xml_text(
      xml2::xml_find_first(
        root_node, "./*[local-name()='Name']")
    )

  result$Metadata$FormTemplate <-
    xml2::xml_text(
      xml2::xml_find_first(
        root_node, "./*[local-name()='FormTemplate']")
    )

  result$Metadata$InteractionClass <-
    xml2::xml_text(
      xml2::xml_find_first(
        root_node, "./*[local-name()='InteractionClass']")
    )

  result$Metadata$DataSourceQuery <-
    xml2::xml_text(
      xml2::xml_find_first(
        root_node, "./*[local-name()='DataSourceQuery']")
    )

  result$DataSources <-
    extract_form_datasources(
      xml_doc
    )

  result$Controls <-
    extract_form_controls(
      xml_doc
    )

  # ================================
  # PARTS AUSLESEN
  # ================================

  result$Parts <-
    extract_form_parts(
      xml_doc
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)

}