#' D365FO Privilege Release Report nach Excel exportieren
#'
#' Exportiert einen vorbereiteten D365FO Privilege Release Report in eine
#' Excel-Datei.
#'
#' Die Funktion erstellt ein Workbook mit mehreren Worksheets und schreibt die
#' einzelnen Report-Bereiche in getrennte Tabellenblätter.
#'
#' Folgende Bereiche werden unterstützt:
#' - ExecutiveSummary
#' - ReleaseOverview
#' - AddedObjects
#' - RemovedObjects
#' - SecurityChanges
#' - RiskAnalysis
#'
#' Nicht vorhandene oder leere Bereiche werden automatisch übersprungen.
#'
#' @param report Objekt der Klasse `D365PrivilegeReleaseReport`.
#'
#' @param output_file Vollständiger Pfad zur Excel-Datei.
#'        Die Datei muss die Endung .xlsx besitzen.
#'
#' @return Unsichtbar den Pfad der erzeugten Excel-Datei.
#'
#' @details
#' Die Funktion verwendet openxlsx zur Erstellung des Workbooks.
#'
#' Die eigentliche Ausgabe eines einzelnen Worksheets erfolgt über die interne
#' Hilfsfunktion `write_report_sheet()`.
#'
#' Dadurch wird die Formatierung aller Worksheets zentral gesteuert.
#'
#' @seealso
#' prepare_privilege_release_report()
#'
#' @seealso
#' write_report_sheet()
#'
#' @examples
#' \dontrun{
#' report <-
#'   prepare_privilege_release_report(
#'     release_comparison
#'   )
#'
#' export_privilege_release_report(
#'   report,
#'   "c:/temp/release_report.xlsx"
#' )
#' }
#'
#' @export
export_privilege_release_report <- function(
    report,
    output_file) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(report, "D365PrivilegeReleaseReport")) {
    stop("report muss ein D365PrivilegeReleaseReport sein.")
  }

  if (!is.character(output_file)) {
    stop("output_file muss ein Character sein.")
  }

  if (length(output_file) != 1) {
    stop("output_file muss genau einen Wert enthalten.")
  }

  if (tools::file_ext(output_file) != "xlsx") {
    stop("output_file muss eine .xlsx Datei sein.")
  }

  # =========================================
  # WORKBOOK ERSTELLEN
  # =========================================

  workbook <- openxlsx::createWorkbook()

  # =========================================
  # REPORT INFORMATIONEN EXPORTIEREN
  # =========================================

  if (!is.null(report$ReportInfo) && nrow(report$ReportInfo) > 0) {
    write_report_sheet(
      workbook = workbook,
      sheet_name = "00_ReportInfo",
      data = report$ReportInfo
    )
  }

  # =========================================
  # EXECUTIVE SUMMARY EXPORTIEREN
  # =========================================

  if (!is.null(report$ExecutiveSummary) && nrow(report$ExecutiveSummary) > 0) {
    write_report_sheet(
      workbook = workbook,
      sheet_name = "01_ExecutiveSummary",
      data = report$ExecutiveSummary
    )
  }

  # =========================================
  # RELEASE OVERVIEW EXPORTIEREN
  # =========================================

  if (!is.null(report$ReleaseOverview) && nrow(report$ReleaseOverview) > 0) {
    write_report_sheet(
      workbook = workbook,
      sheet_name = "02_ReleaseOverview",
      data = report$ReleaseOverview
    )
  }

  # =========================================
  # ADDED OBJECTS EXPORTIEREN
  # =========================================

  if (!is.null(report$AddedObjects) && nrow(report$AddedObjects) > 0) {
    write_report_sheet(
      workbook = workbook,
      sheet_name = "03_AddedObjects",
      data = report$AddedObjects
    )
  }

  # =========================================
  # REMOVED OBJECTS EXPORTIEREN
  # =========================================

  if (!is.null(report$RemovedObjects) && nrow(report$RemovedObjects) > 0) {
    write_report_sheet(
      workbook = workbook,
      sheet_name = "04_RemovedObjects",
      data = report$RemovedObjects
    )
  }

  # =========================================
  # SECURITY CHANGES EXPORTIEREN
  # =========================================

  if (!is.null(report$SecurityChanges) && nrow(report$SecurityChanges) > 0) {
    write_report_sheet(
      workbook = workbook,
      sheet_name = "05_SecurityChanges",
      data = report$SecurityChanges
    )
  }

  # =========================================
  # RISK ANALYSIS EXPORTIEREN
  # =========================================

  if (!is.null(report$RiskAnalysis) && nrow(report$RiskAnalysis) > 0) {
    write_report_sheet(
      workbook = workbook,
      sheet_name = "06_RiskAnalysis",
      data = report$RiskAnalysis
    )
  }

  # =========================================
  # WORKBOOK SPEICHERN
  # =========================================

  openxlsx::saveWorkbook(
    wb = workbook,
    file = output_file,
    overwrite = TRUE
  )

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(invisible(output_file))
}
