#' Alle WIBU-Rollen laden
#'
#' Lädt alle Sicherheitsrollen aus SECURITYROLE,
#' die einen WIBU-Bezug im Namen oder Identifier haben.
#'
#' Eine Rolle wird zurückgegeben, wenn:
#'
#' * der Anzeigename WIBU enthält, oder
#' * der technische Identifier WIBU enthält.
#'
#' Das Ergebnis umfasst sowohl Dev-Rollen (AOT/VS)
#' als auch Config-Rollen (UI-erstellt).
#'
#' @param connection DBI-Verbindung zur D365FO-Datenbank.
#'
#' @return Tibble mit zwei Spalten:
#'
#' \describe{
#'   \item{AOTNAME}{Technischer Identifier der Rolle.}
#'   \item{NAME}{Anzeigename der Rolle.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' all_wibu <- load_all_wibu_roles(connection)
#'
#' }
#'
#' @seealso
#' \code{\link{load_dev_roles}}
#' \code{\link{load_config_roles}}
#' \code{\link{load_role_mapping}}
#'
#' @export

load_all_wibu_roles <- function(connection) {

  sql <- "
SELECT
    SR.AOTNAME,
    SR.NAME
FROM SECURITYROLE SR
WHERE SR.AOTNAME LIKE '%WIBU%'
   OR SR.NAME    LIKE '%WIBU%'
ORDER BY SR.NAME ASC
"

  result <- DBI::dbGetQuery(connection, sql)

  tibble::as_tibble(result)

}
