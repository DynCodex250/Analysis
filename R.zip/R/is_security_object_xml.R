#' Prüft den Typ eines D365FO Security-Objekts
#'
#' Liest eine XML-Datei ein und prüft anhand des Root-Knotens,
#' ob die Datei dem erwarteten D365FO Security-Objekttyp#' entspricht.
#'
#' Die Funktion kann für Privileges, Duties, Roles und andere#' Security-Artefakte verwendet werden und eignet sich
#' insbesondere für automatisierte Tests und XML-Validierungen.
#'
#' Mögliche Werte für object_type sind beispielsweise:
#' - "AxSecurityPrivilege"
#' - "AxSecurityDuty"
#' - "AxSecurityRole"
#'
#' @param xml_file Vollständiger Pfad zur XML-Datei
#' @param object_type Erwarteter Root-Knoten der XML-Datei
#'
#' @return TRUE, wenn der Root-Knoten dem angegebenen
#'         Objekttyp entspricht, sonst FALSE
#'
#' @export

is_security_object_xml <- function(xml_file,object_type){

  #XML-Datei einlesen

  xml_doc <- xml2::read_xml(xml_file)

  #Root-Knoten ermitteln

  root_node <- xml2::xml_name(xml2::xml_root(xml_doc))

  #Objekttyp vergleichen

  return(identical(root_node,object_type))

}
