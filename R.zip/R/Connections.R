 # cred_path <- "C:/Users/Cedric/Documents/RProjects/D365Security/inst/config/report_mapping.xlsx"
# credentials <- readxl::read_excel( cred_path, sheet = "AllConnections", col_types = "text" )

get_connection_ <- function(env) {
  row <- credentials %>% dplyr::filter(Umgebung == env)
  if (nrow(row) == 0) {
    stop(paste("Keine Credentials für Umgebung:", env))
  }

  dbConnect(
    drv = odbc::odbc(),
    Driver = "SQL Server",
    server = row$server,
    database = row$database,
    uid = row$uid,
    pwd = row$pwd )

}
