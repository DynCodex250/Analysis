#' SQL Security-Hierarchien vergleichen
#'
#' Vergleicht zwei Security-Hierarchien, die aus
#' D365FO über get_sql_security_hierarchy()
#' geladen wurden.
#'
#' Die Funktion analysiert Unterschiede auf den Ebenen:
#'
#' * Duties
#' * Privileges
#' * SubRoles
#' * Ressourcen (MenuItems, Forms, Services usw.)
#'
#' Für jede Ebene werden ermittelt:
#'
#' * Objekte nur in Rolle 1
#' * Objekte nur in Rolle 2
#' * Gemeinsame Objekte
#'
#' Die Funktion eignet sich insbesondere für:
#'
#' * PROD ↔ TST Vergleiche
#' * Standardrolle ↔ kundenspezifische Rolle
#' * Security Reviews
#' * Berechtigungskonzepte
#' * Rollenmigrationen
#'
#' @param role_1 Data Frame mit der Security-Hierarchie
#'   der ersten Rolle.
#'
#'   Die Daten werden typischerweise über
#'   get_sql_security_hierarchy() geladen.
#'
#' @param role_2 Data Frame mit der Security-Hierarchie
#'   der zweiten Rolle.
#'
#'   Die Daten werden typischerweise über
#'   get_sql_security_hierarchy() geladen.
#'
#' @details
#'
#' Die Eingabeparameter werden normalerweise wie folgt erzeugt:
#'
#' Rolle aus PROD:
#'
#' \preformatted{
#' cnn_prod <- get_connection("PROD")
#'
#' role_prod <-
#'   get_sql_security_hierarchy(
#'     con = cnn_prod,
#'     role_identifiers =
#'       "E65B0D45-4A5B-4247-B0D9-FC75A4208462"
#'   )
#' }
#'
#' Rolle aus TST:
#'
#' \preformatted{
#' cnn_tst <- get_connection("TST")
#'
#' role_tst <-
#'   get_sql_security_hierarchy(
#'     con = cnn_tst,
#'     role_identifiers =
#'       "BAE596D5-2FDE-4E72-B729-8EF610AF9864"
#'   )
#' }
#'
#' Anschließend:
#'
#' \preformatted{
#' comparison <-
#'   compare_sql_security_hierarchies(
#'     role_prod,
#'     role_tst
#'   )
#' }
#'
#' Die Funktion erwartet mindestens folgende Spalten:
#'
#' \itemize{
#' \item ROLEIDENTIFIER
#' \item ROLENAME
#' \item SUBROLEIDENTIFIER
#' \item DUTYIDENTIFIER
#' \item PRIVILEGEIDENTIFIER
#' \item RESOURCE_
#' }
#'
#' Diese Spalten werden von
#' get_sql_security_hierarchy()
#' bereitgestellt.
#'
#' @return
#'
#' Liste mit folgenden Elementen:
#'
#' \describe{
#'
#' \item{Role_1}{
#' Name der ersten Rolle
#' }
#'
#' \item{Role_2}{
#' Name der zweiten Rolle
#' }
#'
#' \item{duties}{
#' Vergleich der Duties
#' }
#'
#' \item{privileges}{
#' Vergleich der Privileges
#' }
#'
#' \item{subroles}{
#' Vergleich der SubRoles
#' }
#'
#' \item{resources}{
#' Vergleich der Ressourcen
#' }
#'
#' }
#'
#' Jede Vergleichsebene enthält:
#'
#' \preformatted{
#' only_in_role_1
#' only_in_role_2
#' common
#' }
#'
#' @examples
#' \dontrun{
#'
#' cnn_prod <- get_connection("PROD")
#' cnn_tst  <- get_connection("TST")
#'
#' role_prod <-
#'   get_sql_security_hierarchy(
#'     con = cnn_prod,
#'     role_identifiers =
#'       "E65B0D45-4A5B-4247-B0D9-FC75A4208462"
#'   )
#'
#' role_tst <-
#'   get_sql_security_hierarchy(
#'     con = cnn_tst,
#'     role_identifiers =
#'       "BAE596D5-2FDE-4E72-B729-8EF610AF9864"
#'   )
#'
#' comparison <-
#'   compare_sql_security_hierarchies(
#'     role_prod,
#'     role_tst
#'   )
#'
#' comparison$duties$only_in_role_1
#' comparison$duties$only_in_role_2
#' comparison$privileges$common
#' comparison$subroles$common
#' comparison$resources$only_in_role_2
#'
#' }
#'
#' @seealso
#' \code{\link{get_sql_security_hierarchy}}
#'
#' @export
compare_sql_security_hierarchies <- function(
    role_1,
    role_2
) {
  
  list(
    
    Role_1 =
      unique(role_1$ROLENAME)[1],
    
    Role_2 =
      unique(role_2$ROLENAME)[1],
    
    duties = list(
      
      only_in_role_1 =
        setdiff(
          unique(role_1$DUTYIDENTIFIER),
          unique(role_2$DUTYIDENTIFIER)
        ),
      
      only_in_role_2 =
        setdiff(
          unique(role_2$DUTYIDENTIFIER),
          unique(role_1$DUTYIDENTIFIER)
        ),
      
      common =
        intersect(
          unique(role_1$DUTYIDENTIFIER),
          unique(role_2$DUTYIDENTIFIER)
        )
      
    ),
    
    privileges = list(
      
      only_in_role_1 =
        setdiff(
          unique(role_1$PRIVILEGEIDENTIFIER),
          unique(role_2$PRIVILEGEIDENTIFIER)
        ),
      
      only_in_role_2 =
        setdiff(
          unique(role_2$PRIVILEGEIDENTIFIER),
          unique(role_1$PRIVILEGEIDENTIFIER)
        ),
      
      common =
        intersect(
          unique(role_1$PRIVILEGEIDENTIFIER),
          unique(role_2$PRIVILEGEIDENTIFIER)
        )
      
    ),
    
    subroles = list(
      
      only_in_role_1 =
        setdiff(
          unique(role_1$SUBROLEIDENTIFIER),
          unique(role_2$SUBROLEIDENTIFIER)
        ),
      
      only_in_role_2 =
        setdiff(
          unique(role_2$SUBROLEIDENTIFIER),
          unique(role_1$SUBROLEIDENTIFIER)
        ),
      
      common =
        intersect(
          unique(role_1$SUBROLEIDENTIFIER),
          unique(role_2$SUBROLEIDENTIFIER)
        )
      
    ),
    
    resources = list(
      
      only_in_role_1 =
        setdiff(
          unique(role_1$RESOURCE_),
          unique(role_2$RESOURCE_)
        ),
      
      only_in_role_2 =
        setdiff(
          unique(role_2$RESOURCE_),
          unique(role_1$RESOURCE_)
        ),
      
      common =
        intersect(
          unique(role_1$RESOURCE_),
          unique(role_2$RESOURCE_)
        )
      
    )
    
  )
  
}