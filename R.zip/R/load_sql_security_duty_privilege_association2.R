#' Lädt Duty-Privilege-Zuordnungen aus UserSecGovRelatedObjects
#'
#' Liest die Tabelle `UserSecGovRelatedObjects` aus der D365FO-Datenbank und
#' extrahiert die Beziehungen zwischen Duties und Privileges.
#'
#' Die Funktion wird als Grundlage für Security-Analysen verwendet, insbesondere
#' zur Rekonstruktion der Berechtigungshierarchie und zur Zuordnung von Formularen,
#' Menu Items und Entry Points zu den entsprechenden Privileges.
#'
#' Es werden ausschließlich Datensätze berücksichtigt, bei denen ein
#' Duty-Identifier vorhanden ist.
#'
#' Die Abfrage liefert jede Duty-Privilege-Kombination nur einmal zurück.
#'
#' Geladene Informationen:
#'
#' * Duty-Identifier
#' * Duty-Name
#' * Privilege-Identifier
#'
#' Verwendete Datenquelle:
#'
#' * UserSecGovRelatedObjects
#'
#' Typische Einsatzgebiete:
#'
#' * Aufbau von Security-Hierarchien
#' * Analyse von Rollenabhängigkeiten
#' * Rekonstruktion von Duty-Privilege-Beziehungen
#' * Security Governance Reporting
#' * Berechtigungsdokumentationen
#'
#' @param connection Offene DBI-Datenbankverbindung zur D365FO-Datenbank.
#'
#' @return Tibble mit den Spalten:
#'
#' * `DUTYIDENTIFIER` Technischer Name des Duties.
#'
#' * `DUTYNAME` Anzeigename des Duties.
#'
#' * `PRIVILEGEIDENTIFIER` Technischer Name des zugeordneten Privileges.
#'
#' Jede Zeile repräsentiert eine eindeutige Zuordnung zwischen Duty und Privilege.
#'
#' @details
#' Die Tabelle `UserSecGovRelatedObjects` enthält bereits aufbereitete
#' Beziehungen zwischen Security-Objekten.
#'
#' Im Gegensatz zum direkten Parsen von XML-Dateien können dadurch
#' Security-Zuordnungen schnell aus der Datenbank geladen werden.
#'
#' Die Funktion filtert Datensätze ohne Duty-Identifier heraus, da diese für
#' den Aufbau der Security-Hierarchie nicht relevant sind.
#'
#' @examples
#' user_sec_gov_related_objects <-
#'   load_sql_usersecgovrelatedobjects_duty_privilege_association(
#'     connection
#'   )
#'
#' head(
#'   user_sec_gov_related_objects
#' )
#'
#' dplyr::count(
#'   user_sec_gov_related_objects,
#'   DUTYIDENTIFIER
#' )
#'
#' @seealso
#' get_sql_security_hierarchy
#' load_sql_security_hierarchy
#' get_privilege_mapping
#' get_duty_mapping
#'
#' @export

load_sql_security_duty_privilege_association2 <- function(
    connection,
    resources = character(),
    privilege_identifiers = character()
) {
  
  # ==========================
  # SQL
  # ==========================
  
  sql <- "
  SELECT DISTINCT
      USGRO.DUTYIDENTIFIER,
      USGRO.DUTYNAME,
      USGRO.PRIVILEGEIDENTIFIER,
      USGRO.PRIVILEGENAME,
      USGRO.RESOURCETYPE,
      USGRO.RESOURCE_
  FROM UserSecGovRelatedObjects USGRO
  WHERE
  (
    USGRO.DUTYIDENTIFIER != ''
    AND
    USGRO.PRIVILEGEIDENTIFIER != ''
  )
  "
  
  if (length(resources) > 0) {
    
    menuitem_list <- paste0(
      "'",
      gsub("'", "''", resources),
      "'",
      collapse = ","
    )
    
    sql <- paste0(
      sql,
      "\nAND USGRO.RESOURCE_ IN (",
      menuitem_list,
      ")"
    )
  }
  
  if (length(privilege_identifiers) > 0) {
    
    privilege_list <- paste0(
      "'",
      gsub("'", "''", privilege_identifiers),
      "'",
      collapse = ","
    )
    
    sql <- paste0(
      sql,
      "\nAND USGRO.PRIVILEGEIDENTIFIER IN (",
      privilege_list,
      ")"
    )
  }
  
  # ==========================
  # AUSFÜHREN
  # ==========================
  
  result <- DBI::dbGetQuery(
    connection,
    sql
  )
  
  # ==========================
  # TIBBLE
  # ==========================
  
  result <- tibble::as_tibble(
    result
  )
  
  return(result)
}