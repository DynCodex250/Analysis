#' Standardisierte Reihenfolge für Security Grants
#'
#' Liefert die von Microsoft D365FO üblicherweise verwendete
#' Reihenfolge der Security-Berechtigungen innerhalb eines
#' Grant-Knotens.
#'
#' Die Funktion wird bei der XML-Generierung verwendet, um
#' eine möglichst identische Reihenfolge zur ursprünglichen
#' D365FO-XML zu erzeugen und unnötige Unterschiede bei
#' XML-Vergleichen zu vermeiden.
#'
#' Standardreihenfolge:
#' - Correct
#' - Create
#' - Delete
#' - Invoke
#' - Read
#' - Update
#'
#' @return Character-Vektor mit der standardisierten
#'         Reihenfolge der Security Grants
#'
#' @examples
#' get_grant_order()
#'
#' @export
get_grant_order <- function() {

  c(
    "Correct",
    "Create",
    "Delete",
    "Invoke",
    "Read",
    "Update"
  )

}
