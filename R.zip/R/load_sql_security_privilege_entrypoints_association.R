
#' Security Objekte laden#'#' Lädt die Inhalte der Tabelle#' UserSecGovRelatedObjects.#'#' Die Daten werden später für die#' Verknüpfung von Formularen,#' MenuItems und Privileges verwendet.#'#' @param connection DBI Connection.#'#' @return Tibble.#'#' @examples#' user_sec_gov_related_objects <-#'   load_user_sec_gov_related_objects(#'     connection#'   )#'#' @export

load_sql_security_privilege_entrypoints_association <- function(connection){

  # ================================
  #   SQL
  # ================================

    sql <-
      "
SELECT DISTINCT
   USGRO.PRIVILEGEIDENTIFIER,
   USGRO.PRIVILEGENAME,
   USGRO.RESOURCETYPE,
   USGRO.RESOURCE_,
   USGRO.CORRECTACCESS,
   USGRO.CREATEACCESS,
   USGRO.DELETEACCESS,
   USGRO.INVOKEACCESS,
   USGRO.READACCESS,
   USGRO.UPDATEACCESS
FROM UserSecGovRelatedObjects USGROWHERE USGRO.RESOURCETYPE LIKE '%menu item%'
"

    # ================================
    #   AUSFÜHREN
    # ================================

      result <-

        DBI::dbGetQuery(
          cnn,
          sql
        )

      # ================================
      #   TIBBLE
      # ================================

        result <-
          tibble::as_tibble(
            result
          )

        return(result)

}
