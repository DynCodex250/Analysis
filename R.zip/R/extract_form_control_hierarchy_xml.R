#' Form-Control rekursiv extrahieren
#'
#' Liest einen `AxFormControl`-Knoten inklusive aller
#' Child-Controls rekursiv aus dem XML-Dokument aus.
#'
#' Die Funktion wird intern von [extract_form_controls_xml()]
#' aufgerufen und sollte nicht direkt verwendet werden.
#'
#' @param control_node XML-Knoten eines `AxFormControl`.
#' @param parent Name des übergeordneten Controls.
#'   Standard: `NA_character_` (Root-Level).
#' @param level Aktuelle Hierarchietiefe. Standard: `0`.
#' @param path Bisheriger Pfad im Formular. Standard: `NULL`.
#'
#' @return Liste von Tibbles, je eines pro Control.
#'   Jedes Tibble enthält:
#'
#'   * `Name` — Technischer Name
#'   * `Type` — Control-Typ
#'   * `Parent` — Name des übergeordneten Controls
#'   * `Level` — Hierarchietiefe
#'   * `Path` — Vollständiger Pfad
#'   * `Properties` — Benannte Liste mit Control-Properties
#'
#' @seealso [extract_form_controls_xml()],
#'   [extract_form_control_properties()]
#'
#' @keywords internal
extract_form_control_hierarchy_xml <- function(
    control_node,
    parent = NA_character_,
    level  = 0,
    path   = NULL) {

  # ================================
  # CONTROL INFORMATIONEN
  # ================================

  name <-
    xml2::xml_text(
      xml2::xml_find_first(
        control_node,
        "./*[local-name()='Name']"
      )
    )

  type <-
    xml2::xml_text(
      xml2::xml_find_first(
        control_node,
        "./*[local-name()='Type']"
      )
    )

  # ================================
  # NAMEN ABSICHERN
  # ================================

  if (is.na(name) || length(name) == 0 || identical(name, "")) {
    name <- paste0("UnnamedControl_", level)
  }

  current_path <-
    if (is.null(path)) {
      name
    } else {
      paste(path, name, sep = "/")
    }

  # ================================
  # AKTUELLES CONTROL
  # ================================

  result <-
    list(
      tibble::tibble(
        Name       = name,
        Type       = type,
        Parent     = parent,
        Level      = level,
        Path       = current_path,
        Properties = list(
          extract_form_control_properties(control_node)
        )
      )
    )

  # ================================
  # CHILD CONTROLS
  # ================================

  child_nodes <-
    xml2::xml_find_all(
      control_node,
      "./[local-name()='Controls']/[local-name()='AxFormControl']"
    )

  # ================================
  # REKURSION
  # ================================

  for (child_node in child_nodes) {

    result <-
      c(
        result,
        extract_form_control_hierarchy_xml(
          control_node = child_node,
          parent       = name,
          level        = level + 1,
          path         = current_path
        )
      )
  }

  # ================================
  # ERGEBNIS
  # ================================

  return(result)
}
