#' EntryPoints eines Privileges extrahieren
#'
#' Extrahiert alle EntryPoints eines D365FO
#' Security Privileges.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit allen EntryPoints.
#'
#' @details
#' Die Funktion liest alle
#' AxSecurityEntryPointReference-Knoten aus.
#'
#' @seealso
#' parse_privilege()
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#'
#' entrypoints <-
#'   extract_entrypoints(
#'     xml_doc
#'   )
#' }
#'
#' @export
extract_entrypoints <- function(xml_doc) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # =========================================
  # ENTRYPOINTS EXTRAHIEREN
  # =========================================

  entrypoints <- xml2::xml_find_all(
    xml_doc,
    "//EntryPoints/AxSecurityEntryPointReference"
  )

  result <- purrr::map_dfr(entrypoints, function(node) {
    tibble::tibble(
      Name = xml2::xml_text(
        xml2::xml_find_first(node, "./Name")
      ),

      ObjectName = xml2::xml_text(
        xml2::xml_find_first(node, "./ObjectName")
      ),

      ObjectType = xml2::xml_text(
        xml2::xml_find_first(node, "./ObjectType")
      ),

      ObjectChildName = xml2::xml_text(
        xml2::xml_find_first(node, "./ObjectChildName")
      ),

      HasForms = !inherits(
        xml2::xml_find_first(node, "./Forms"),
        "xml_missing"
      ),

      Read = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Read")
      ),

      Create = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Create")
      ),

      Update = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Update")
      ),

      Delete = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Delete")
      ),

      Correct = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Correct")
      ),

      Invoke = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Invoke")
      )
    )
  })

  # =========================================
  # LEERE STRUKTUR ABSICHERN
  # =========================================

  if (ncol(result) == 0) {
    result <- empty_entrypoints()
  }

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}