#' D365FO Security-Rollen massenhaft vergleichen
#'
#' Führt einen strukturierten Vergleich mehrerer D365FO
#' Security-Rollen anhand einer Mapping-Tabelle durch.
#'
#' Die Funktion vergleicht jeweils eine Rolle aus einer
#' Referenzkonfiguration mit einer Rolle aus einer
#' Zielkonfiguration und konsolidiert die Ergebnisse in
#' einer gemeinsamen Auswertung.
#'
#' Verglichen werden:
#' - Duties
#' - Privileges
#' - SubRoles
#' - Direct Access Permissions
#'
#' Zusätzlich wird automatisch eine Excel-Datei mit den
#' vollständigen Vergleichsergebnissen erzeugt.
#'
#' Typische Anwendungsfälle:
#' - Security-Migrationen
#' - Release-Vergleiche
#' - Rollenkonsolidierungen
#' - Qualitätsprüfungen
#' - Security-Reviews
#'
#' @param roleMapping Data Frame oder Tibble mit der
#'        Zuordnung zwischen Referenz- und Zielrollen.
#'
#' @param ConfigFolder Verzeichnis mit den XML-Dateien der
#'        Referenzrollen.
#'
#' @param DevFolder Verzeichnis mit den XML-Dateien der
#'        Zielrollen.
#'
#' @param outputFile Name der zu erzeugenden Excel-Datei.
#'        Standardwert ist `"RoleComparison.xlsx"`.
#'
#' @return Tibble mit allen Vergleichsergebnissen.
#'
#' Typische Spalten:
#'
#' \describe{
#'   \item{category}{
#'   Verglichene Security-Komponente.
#'   }
#'
#'   \item{type}{
#'   Vergleichsergebnis, beispielsweise
#'   `only_in_role_1`,
#'   `only_in_role_2`
#'   oder `common`.
#'   }
#'
#'   \item{value}{
#'   Name des Security-Objekts.
#'   }
#'
#'   \item{CONFROLE}{
#'   Name der Referenzrolle.
#'   }
#'
#'   \item{DEVROLE}{
#'   Name der Zielrolle.
#'   }
#' }
#'
#' @details
#' Für jede Zeile der Mapping-Tabelle wird ein
#' Rollenvergleich mittels `compare_security_roles()`
#' durchgeführt.
#'
#' Auftretende Fehler werden abgefangen und als
#' Ergebnisdatensätze zurückgegeben, sodass die
#' Verarbeitung weiterer Rollen fortgesetzt werden kann.
#'
#' Nach Abschluss der Verarbeitung werden drei
#' Arbeitsblätter in eine Excel-Datei exportiert:
#'
#' - RoleComparison
#' - RoleMapping
#' - DifferencesOnly
#'
#' @examples
#' result <- compare_all_roles(
#'   roleMapping = role_mapping,
#'   ConfigFolder = "ConfigRoles",
#'   DevFolder = "DevRoles"
#' )
#'
#' result
#'
#' dplyr::filter(
#'   result,
#'   type != "common"
#' )
#'
#' @seealso
#' compare_security_roles()
#' find_file_ci()
#' writexl::write_xlsx()
#'
#' @export
compare_all_roles <- function(
    roleMapping,
    ConfigFolder,
    DevFolder,
    outputFile = "RoleComparison.xlsx"
) {

  results <- roleMapping %>%

    pmap(function(
    CONFIDENT,
    CONFROLE,
    DEVIDENT,
    DEVROLE,
    ...
    ) {

      conRoleXml <- paste0(
        ConfigFolder,
        "\\",
        CONFIDENT,
        ".xml"
      )

      devRoleXml <-  find_file_ci( DevFolder, DEVIDENT)

      cat(
        "\nComparing:",
        CONFROLE,
        "vs",
        DEVROLE
      )

      comparison <- tryCatch(

        compare_security_roles(
          role_file_1 = conRoleXml,
          role_file_2 = devRoleXml
        ),

        error = function(e) {

          return(
            tibble(
              category = "ERROR",
              type = "ERROR",
              value = as.character(e)
            )
          )

        }

      )

      if(is.data.frame(comparison)) {
        return(comparison)
      }

      result <- bind_rows(

        tibble(
          category = "duties",
          type = "only_in_role_1",
          value = comparison$duties$only_in_role_1
        ),

        tibble(
          category = "duties",
          type = "only_in_role_2",
          value = comparison$duties$only_in_role_2
        ),

        tibble(
          category = "duties",
          type = "common",
          value = comparison$duties$common
        ),

        tibble(
          category = "privileges",
          type = "only_in_role_1",
          value = comparison$privileges$only_in_role_1
        ),

        tibble(
          category = "privileges",
          type = "only_in_role_2",
          value = comparison$privileges$only_in_role_2
        ),

        tibble(
          category = "privileges",
          type = "common",
          value = comparison$privileges$common
        ),

        tibble(
          category = "subroles",
          type = "only_in_role_1",
          value = comparison$subroles$only_in_role_1
        ),

        tibble(
          category = "subroles",
          type = "only_in_role_2",
          value = comparison$subroles$only_in_role_2
        ),

        tibble(
          category = "subroles",
          type = "common",
          value = comparison$subroles$common
        ),

        tibble(
          category = "direct_access_permissions",
          type = "only_in_role_1",
          value = comparison$direct_access_permissions$only_in_role_1
        ),

        tibble(
          category = "direct_access_permissions",
          type = "only_in_role_2",
          value = comparison$direct_access_permissions$only_in_role_2
        ),

        tibble(
          category = "direct_access_permissions",
          type = "common",
          value = comparison$direct_access_permissions$common
        )

      )

      result %>%
        mutate(
          CONFROLE = CONFROLE,
          CONFIDENT = CONFIDENT,
          DEVROLE = DEVROLE,
          DEVIDENT = DEVIDENT
        )

    })

  finalResult <- bind_rows(results)

  differencesOnly <- finalResult %>%
    filter(
      type != "common"
    )


  writexl::write_xlsx(
    list(
      RoleComparison = finalResult,
      RoleMapping = roleMapping,
      DifferencesOnly = differencesOnly
    ),
    outputFile
  )

  return(finalResult)
}
