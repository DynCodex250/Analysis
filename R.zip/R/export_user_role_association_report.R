#' Benutzer-Rollen-Zuweisungsbericht exportieren
#'
#' Erstellt einen Excel-Bericht mit den Benutzer-Rollen-Zuweisungen
#' und einer Pivot-Tabelle der eindeutigen Zuweisungen.
#'
#' Der Bericht enthält zwei Tabellenblätter:
#' - **RoleAssignments**: Die detaillierten Rohdaten der Zuweisungen.
#' - **Pivot**: Eine aggregierte Ansicht der eindeutigen Rollen pro Benutzer.
#'
#' @param con Ein gültiges Datenbankverbindungsobjekt (DBI connection).
#'
#' @param output_file Zeichenkette mit dem Pfad zur Ausgabedatei (.xlsx).
#'
#' @param user_ids Optionaler Vektor von Benutzer-IDs zur Filterung.
#'        Standardmäßig werden alle Benutzer exportiert.
#'
#' @return Der Pfad zur erstellten Datei (unsichtbar).
#'
#' @export
export_user_role_association_report <- function(
    con,
    output_file,
    user_ids = character()) {

  # =========================================
  # DATEN LADEN
  # =========================================

  role_data <- get_sql_user_role_association(
    con = con,
    user_ids = user_ids
  )

  # =========================================
  # PIVOT-DATEN ERZEUGEN
  # =========================================

  pivot_data <- role_data %>%
    dplyr::distinct(USERID, SECURITYROLENAME) |>
    dplyr::arrange(USERID, SECURITYROLENAME)

  # =========================================
  # WORKBOOK ERSTELLEN
  # =========================================

  wb <- openxlsx::createWorkbook()

  # Blatt 1: Rohdaten
  openxlsx::addWorksheet(
    wb,
    sheetName = "RoleAssignments"
  )

  openxlsx::writeDataTable(
    wb,
    sheet = "RoleAssignments",
    x = role_data
  )

  # Blatt 2: Pivot
  openxlsx::addWorksheet(
    wb,
    sheetName = "Pivot"
  )

  openxlsx::writeDataTable(
    wb,
    sheet = "Pivot",
    x = pivot_data
  )

  # =========================================
  # OPTISCHE FORMATIERUNG
  # =========================================

  openxlsx::setColWidths(
    wb,
    sheet = "RoleAssignments",
    cols = 1:ncol(role_data),
    widths = "auto"
  )

  openxlsx::setColWidths(
    wb,
    sheet = "Pivot",
    cols = 1:ncol(pivot_data),
    widths = "auto"
  )

  openxlsx::freezePane(
    wb,
    sheet = "RoleAssignments",
    firstRow = TRUE
  )

  openxlsx::freezePane(
    wb,
    sheet = "Pivot",
    firstRow = TRUE
  )

  # =========================================
  # SPEICHERN UND BEENDEN
  # =========================================

  openxlsx::saveWorkbook(
    wb,
    file = output_file,
    overwrite = TRUE
  )

  return(invisible(output_file))
}
