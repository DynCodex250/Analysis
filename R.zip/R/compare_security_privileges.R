#' D365FO Security-Privileges vergleichen
#'
#' Vergleicht zwei D365FO Privilege-XML-Dateien und
#' ermittelt Unterschiede in den enthaltenen
#' Security-Komponenten.
#'
#' Die Analyse erfolgt auf Basis der aus den XML-Dateien
#' extrahierten Security-Objekte.
#'
#' Verglichen werden:
#' - Data Entity Permissions
#' - EntryPoints
#' - Forms
#' - Form Controls
#'
#' Für jede Kategorie werden folgende Informationen
#' ermittelt:
#'
#' - Nur in Privilege 1 vorhanden
#' - Nur in Privilege 2 vorhanden
#' - In beiden Privileges vorhanden
#'
#' Typische Anwendungsfälle:
#' - Release-Vergleiche
#' - Security-Reviews
#' - Privilege-Migrationen
#' - Qualitätsprüfungen
#' - Reverse Engineering
#'
#' @param privilege_file_1 Vollständiger Pfad zur ersten
#'        Privilege-XML-Datei.
#'
#' @param privilege_file_2 Vollständiger Pfad zur zweiten
#'        Privilege-XML-Datei.
#'
#' @return Liste mit den Vergleichsergebnissen.
#'
#' Enthaltene Elemente:
#'
#' \describe{
#'   \item{privilege_1}{
#'   Name des ersten Privileges.
#'   }
#'
#'   \item{privilege_2}{
#'   Name des zweiten Privileges.
#'   }
#'
#'   \item{data_entity_permissions}{
#'   Vergleich der Data Entity Permissions.
#'   }
#'
#'   \item{entrypoints}{
#'   Vergleich der EntryPoints.
#'   }
#'
#'   \item{forms}{
#'   Vergleich der Form-Referenzen.
#'   }
#'
#'   \item{controls}{
#'   Vergleich der Form Controls.
#'   }
#' }
#'
#' Jede Vergleichskategorie enthält:
#'
#' \describe{
#'   \item{only_in_file_1}{
#'   Objekte, die ausschließlich im ersten
#'   Privilege vorhanden sind.
#'   }
#'
#'   \item{only_in_file_2}{
#'   Objekte, die ausschließlich im zweiten
#'   Privilege vorhanden sind.
#'   }
#'
#'   \item{common}{
#'   Objekte, die in beiden Privileges
#'   vorhanden sind.
#'   }
#' }
#'
#' @details
#' Die Funktion liest beide Privilege-XML-Dateien ein
#' und extrahiert die enthaltenen Security-Komponenten.
#'
#' Anschließend erfolgt ein mengenbasierter Vergleich
#' mittels `dplyr::anti_join()` und
#' `dplyr::inner_join()`.
#'
#' Es werden ausschließlich Unterschiede in den
#' referenzierten Security-Objekten analysiert.
#'
#' Berechtigungsänderungen innerhalb identischer
#' Objekte werden nicht betrachtet.
#'
#' @examples
#' result <- compare_security_privileges(
#'   privilege_file_1 = "CustTableMaintain.xml",
#'   privilege_file_2 = "CustTableMaintain_New.xml"
#' )
#'
#' result$entrypoints
#'
#' result$data_entity_permissions
#'
#' @seealso
#' compare_component_existence()
#' compare_component_security()
#'
#' @export
  compare_security_privileges <- function(
    privilege_file_1,
    privilege_file_2
) {

  xml_1 <- xml2::read_xml(privilege_file_1)
  xml_2 <- xml2::read_xml(privilege_file_2)

  privilege_name_1 <- xml2::xml_text(
    xml2::xml_find_first(xml_1, "//Name")
  )

  privilege_name_2 <- xml2::xml_text(
    xml2::xml_find_first(xml_2, "//Name")
  )

  extract_grants <- function(node) {

    grant_node <- xml2::xml_find_first(node, "./Grant")

    if (inherits(grant_node, "xml_missing")) {
      return(character())
    }

    xml2::xml_children(grant_node) |>
      xml2::xml_name()
  }

  data_entities_1 <- extract_data_entities(xml_1)
  data_entities_2 <- extract_data_entities(xml_2)

  entrypoints_1 <- extract_entrypoints(xml_1)
  entrypoints_2 <- extract_entrypoints(xml_2)

  forms_1 <- extract_forms(xml_1)
  forms_2 <- extract_forms(xml_2)

  controls_1 <- extract_controls(xml_1)
  controls_2 <- extract_controls(xml_2)

  diff_tbl <- function(df1, df2) {

    list(

      only_in_file_1 =
        dplyr::anti_join(df1, df2),

      only_in_file_2 =
        dplyr::anti_join(df2, df1),

      common =
        dplyr::inner_join(df1, df2)
    )
  }

  result <- list(

    privilege_1 = privilege_name_1,

    privilege_2 = privilege_name_2,

    data_entity_permissions =
      diff_tbl(
        data_entities_1,
        data_entities_2
      ),

    entrypoints =
      diff_tbl(
        entrypoints_1,
        entrypoints_2
      ),

    forms =
      diff_tbl(
        forms_1,
        forms_2
      ),

    controls =
      diff_tbl(
        controls_1,
        controls_2
      )
  )

  return(result)
}
