#' D365FO Privileges auf Release-Ebene vergleichen
#'
#' Führt einen vollständigen Vergleich zweier D365FO
#' Privilege-Modelle durch und erstellt einen
#' konsolidierten Release-Bericht.
#'
#' Die Funktion stellt den zentralen Einstiegspunkt für
#' Privilege-Vergleiche dar und kombiniert mehrere
#' Analyseebenen zu einem gemeinsamen Ergebnisobjekt.
#'
#' Folgende Analysen werden durchgeführt:
#'
#' - Existenzvergleich von Security-Objekten
#' - Vergleich von Berechtigungsänderungen
#' - Risikobewertung der Änderungen
#' - Aggregation von Kennzahlen
#'
#' Die Funktion kombiniert:
#'
#' - compare_privileges_existence()
#' - compare_privileges_security()
#' - compare_privileges_risk_analysis()
#'
#' zu einem vollständigen Release-Bericht.
#'
#' Typische Anwendungsfälle:
#' - Release-Analysen
#' - Security Reviews
#' - Audits
#' - Regressionstests
#' - Compliance-Prüfungen
#' - Dokumentationen
#'
#' @param privilege_a Erstes D365FO Privilege-Modell.
#'        Typischerweise die Referenzversion.
#'
#' @param privilege_b Zweites D365FO Privilege-Modell.
#'        Typischerweise die Ziel- oder neue Version.
#'
#' @return Liste der Klasse
#'         `D365PrivilegeReleaseComparison`.
#'
#' Enthaltene Elemente:
#'
#' \describe{
#'   \item{Metadata}{
#'   Metadaten der verglichenen Privileges.
#'   }
#'
#'   \item{Summary}{
#'   Zusammenfassende Kennzahlen des Vergleichs.
#'   }
#'
#'   \item{Existence}{
#'   Ergebnis von
#'   `compare_privileges_existence()`.
#'   }
#'
#'   \item{SecurityChanges}{
#'   Ergebnis von
#'   `compare_privileges_security()`.
#'   }
#'
#'   \item{RiskAnalysis}{
#'   Ergebnis von
#'   `compare_privileges_risk_analysis()`.
#'   }
#' }
#'
#' Die Summary enthält:
#'
#' \describe{
#'   \item{AddedObjects}{
#'   Anzahl neu hinzugefügter Objekte.
#'   }
#'
#'   \item{RemovedObjects}{
#'   Anzahl entfernter Objekte.
#'   }
#'
#'   \item{SecurityChanges}{
#'   Anzahl geänderter Berechtigungen.
#'   }
#'
#'   \item{HighRiskChanges}{
#'   Anzahl kritischer Änderungen.
#'   }
#'
#'   \item{MediumRiskChanges}{
#'   Anzahl mittlerer Risiken.
#'   }
#'
#'   \item{LowRiskChanges}{
#'   Anzahl geringer Risiken.
#'   }
#'
#'   \item{ComponentsChanged}{
#'   Anzahl betroffener Komponenten.
#'   }
#' }
#'
#' @details
#' Die Funktion führt zunächst alle
#' Teilanalysen durch und aggregiert die
#' Ergebnisse anschließend in einem
#' gemeinsamen Bericht.
#'
#' Dadurch entsteht eine vollständige Sicht
#' auf strukturelle Änderungen,
#' Berechtigungsänderungen und die damit
#' verbundenen Risiken.
#'
#' Die Funktion eignet sich insbesondere als
#' Grundlage für spätere Reporting- und
#' Exportfunktionen wie:
#'
#' - Excel-Berichte
#' - HTML-Reports
#' - PDF-Dokumentationen
#' - Audit-Berichte
#'
#' @seealso
#' compare_privileges_existence()
#' compare_privileges_security()
#' compare_privileges_risk_analysis()
#'
#' @examples
#' privilege_old <- parse_privilege(
#'   "CustTableMaintain.xml"
#' )
#'
#' privilege_new <- parse_privilege(
#'   "CustTableMaintain_v2.xml"
#' )
#'
#' release_report <-
#'   compare_privileges_release(
#'     privilege_old,
#'     privilege_new
#'   )
#'
#' release_report$Summary
#'
#' release_report$SecurityChanges
#'
#' release_report$RiskAnalysis
#'
#' @export
#'
compare_privileges_release <- function(privilege_a, privilege_b) {
  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================
  if(!inherits(privilege_a, "D365Privilege"))
  {
    stop("privilege_a muss ein D365Privilege sein.")
  }
  if(!inherits(privilege_b, "D365Privilege")){

    stop("privilege_b muss ein D365Privilege sein.")
  }

  # ================================
  # VERGLEICHE DURCHFÜHREN
  # ================================

  existence_result <- compare_privileges_existence(privilege_a, privilege_b)
  security_changes <- compare_privileges_security(privilege_a, privilege_b)
  risk_analysis <- compare_privileges_risk_analysis(security_changes)

  # ================================
  # KENNZAHLEN ERMITTELN
  # ================================

  added_objects <-
    sum(
      purrr::map_int(
        existence_result, ~ nrow(.x$Added))
      )

  removed_objects <-
    sum(
      purrr::map_int(
        existence_result, ~ nrow(.x$Removed))
      )

  components_changed <- sum(
    purrr::map_lgl(
      existence_result, ~ nrow(.x$Added) > 0 ||
      nrow(.x$Removed) > 0))

  summary <-
    tibble::tibble(
    AddedObjects      = added_objects,
    RemovedObjects    = removed_objects,
    SecurityChanges   = nrow(security_changes),
    HighRiskChanges   = sum(risk_analysis$RiskLevel == "High", na.rm = TRUE),
    MediumRiskChanges = sum(risk_analysis$RiskLevel == "Medium", na.rm = TRUE),
    LowRiskChanges    = sum(risk_analysis$RiskLevel == "Low", na.rm = TRUE),
    ComponentsChanged = components_changed
  )

  #================================
  # REPORT ERSTELLEN
  # ================================
  report <- list(

    Metadata = list(
      SourcePrivilege = original_model$Metadata,
      TargetPrivilege = new_model$Metadata
    ),
    Summary = summary,
    Existence = existence_result,
    SecurityChanges = security_changes,
    RiskAnalysis = risk_analysis
  )
  # ================================ # OBJEKTTYP SETZEN # ================================

  class(report) <- c("D365PrivilegeReleaseComparison", "list")

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================
  return(report)
  }
