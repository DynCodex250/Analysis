
#' Worksheet in Report-Workbook schreiben
#'#' Erstellt ein neues Worksheet in einem
#' openxlsx Workbook und schreibt die
#' übergebenen Daten hinein.
#'#' Die Funktion wird intern von
#' export_privilege_release_report()
#' verwendet.
#'#' Standardmäßig werden:
#'#' * Header formatiert
#' * Autofilter aktiviert
#' * Spaltenbreiten automatisch angepasst
#'#' @param workbook openxlsx Workbook.
#'#' @param sheet_name Name des Worksheets.
#'#' @param data Data Frame oder Tibble mit den
#' zu exportierenden Daten.
#'#' @return Das Workbook wird direkt verändert.
#'#' @details#' Leere Tabellen werden nicht geschrieben.
#'#' Die Funktion dient ausschließlich der
#' Darstellung von Report-Daten.
#'#' @examples#' write_report_sheet(#'   workbook,
#'   "AddedObjects",
#'   report$AddedObjects
#' )

write_report_sheet <- function(workbook,sheet_name,data){

  # ================================
  #   EINGABEPARAMETER VALIDIEREN
  # ================================

  if(!inherits(workbook, "Workbook")){
    stop("workbook muss ein openxlsx Workbook sein.")
    }

  if(!is.character(sheet_name)){
    stop("sheet_name muss ein Character sein.")
    }

  if(length(sheet_name) != 1){
    stop("sheet_name muss genau einen Wert enthalten.")
    }

  if(!is.data.frame(data)){
    stop("data muss ein Data Frame sein.")
    }

  # ================================
  #   LEERE TABELLEN ÜBERSPRINGEN
  # ================================

    if(nrow(data) == 0){return(invisible(NULL))}

  # ================================
  #   WORKSHEET ERSTELLEN
  # ================================

    openxlsx::addWorksheet(wb = workbook,sheetName = sheet_name)

  # ================================
  #   DATEN SCHREIBEN
  # ================================

    openxlsx::writeData(wb = workbook,sheet = sheet_name,x = data,withFilter = TRUE)

  # ================================
  #   HEADER FORMATIEREN
  # ================================

    header_style <-

      openxlsx::createStyle(
        textDecoration = "bold"
      )

    openxlsx::addStyle(wb = workbook,sheet = sheet_name,style = header_style,rows = 1,cols = seq_len(ncol(data)),gridExpand = TRUE)

    # ================================
    #   SPALTENBREITEN ANPASSEN
    # ================================

      openxlsx::setColWidths(wb = workbook,sheet = sheet_name,cols = seq_len(ncol(data)),widths = "auto")

    # ================================
    #   ERGEBNIS ZURÜCKGEBEN
    # ================================

      return(invisible(NULL))

}
