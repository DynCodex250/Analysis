#' Lizenzfreundliche Privilege-Alternativen ermitteln
#'
#' Identifiziert für lizenzkritische Privileges mögliche
#' Standard-Alternativen mit geringerem Access Level.
#'
#' Die Funktion sucht zunächst alle Privileges mit
#' `NOTENTITLED > 0`.
#'
#' Anschließend werden für dieselben Entry Points
#' (`AOTNAME`) sämtliche Privileges mit
#' `ACCESSLEVEL = 1` ermittelt.
#'
#' Dadurch lassen sich häufig vorhandene Microsoft-
#' View-Privileges identifizieren, bevor eigene
#' Security-Objekte erstellt werden müssen.
#'
#' @param licenses Tibble mit den Ergebnissen von
#'   `get_license_requirements()`.
#'
#'   Erforderliche Spalten:
#'
#'   * IDENTIFIER
#'   * AOTNAME
#'   * NOTENTITLED
#'   * ACCESSLEVEL
#'
#' @return Tibble mit den Spalten:
#'
#' \describe{
#' \item{ProblemPrivilege}{Lizenzkritisches Privilege}
#' \item{AOTNAME}{Zugehöriger Entry Point}
#' \item{AlternativePrivilege}{Mögliche Alternative}
#' \item{HasAlternative}{TRUE/FALSE}
#' }
#'
#' @examples
#' \dontrun{
#'
#' licenses <- get_license_requirements(con)
#'
#' alternatives <-
#'   find_license_alternatives(
#'     licenses
#'   )
#'
#' alternatives
#'
#' }
#'
#' @export
find_license_alternatives <- function(
    licenses
) {
  
  problem_privileges <-
    
    licenses |>
    
    dplyr::filter(
      NOTENTITLED > 0
    ) |>
    
    dplyr::select(
      ProblemPrivilege = IDENTIFIER,
      AOTNAME
    ) |>
    
    dplyr::distinct()
  
  alternatives <-
    
    licenses |>
    
    dplyr::filter(
      ACCESSLEVEL == 1
    ) |>
    
    dplyr::select(
      AOTNAME,
      AlternativePrivilege = IDENTIFIER
    ) |>
    
    dplyr::distinct()
  
  result <-
    
    problem_privileges |>
    
    dplyr::left_join(
      alternatives,
      by = "AOTNAME"
    ) |>
    
    dplyr::filter(
      is.na(AlternativePrivilege) |
        ProblemPrivilege != AlternativePrivilege
    ) |>
    
    dplyr::mutate(
      HasAlternative =
        !is.na(AlternativePrivilege)
    ) |>
    
    dplyr::arrange(
      ProblemPrivilege,
      AlternativePrivilege
    )
  
  result
  
}