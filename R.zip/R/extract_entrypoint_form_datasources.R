#' EntryPoint-Form-Datasources extrahieren
#'
#' Extrahiert alle Datasources innerhalb von
#' EntryPoint-Formularen.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit EntryPointName, FormName
#'         und DataSourceName.
#'
#' @details
#' Die Funktion liest sämtliche Datasources aus,
#' die innerhalb von EntryPoint-Forms definiert sind.
#'
#' Leere Ergebnisse werden als Tibble mit definierter
#' Struktur zurückgegeben.
#'
#' @seealso
#' parse_privilege()
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#'
#' datasources <-
#'   extract_entrypoint_form_datasources(
#'     xml_doc
#'   )
#' }
#'
#' @export
extract_entrypoint_form_datasources <- function(xml_doc) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # =========================================
  # DATASOURCES EXTRAHIEREN
  # =========================================

  datasource_nodes <- xml2::xml_find_all(
    xml_doc,
    "//EntryPoints//Forms//DataSources//AxSecurityEntryPointReferenceFormDataSource"
  )

  result <- purrr::map_dfr(datasource_nodes, function(datasource_node) {

    form_node <- xml2::xml_parent(
      xml2::xml_parent(datasource_node)
    )

    entrypoint_node <- xml2::xml_parent(
      xml2::xml_parent(form_node)
    )

    tibble::tibble(
      EntryPointName = xml2::xml_text(
        xml2::xml_find_first(entrypoint_node, "./Name")
      ),

      FormName = xml2::xml_text(
        xml2::xml_find_first(form_node, "./Name")
      ),

      DataSourceName = xml2::xml_text(
        xml2::xml_find_first(datasource_node, "./Name")
      )
    )
  })

  # =========================================
  # LEERE STRUKTUR ABSICHERN
  # =========================================

  if (ncol(result) == 0) {
    result <- empty_entrypoint_form_datasources()
  }

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}
