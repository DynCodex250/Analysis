# =========================================
#   GENERATE D365 PRIVILEGE XML
# =========================================
#
#
#
#   Erstellt D365FO Privilege XML-Dateien
#
# auf Basis einer Privilege-Mapping-Tabelle.
#


# Die Funktion verwendet das zentrale
#
# SECURITY_PRIVILEGE_MAPPING.
#
#
#
# Unterstützt:
#
#
#
#   - Menu item display
#
# - Menu item action
#
# - Menu item output
#
# - Service operation
#
# - Data entity
#
# - Data entity action
#
# - Table
#
# - Table Field
#
# - Form control
#
# - Form Data Source



# =========================================

  #' D365FO Privilege XML generieren#'#' Erstellt eine oder mehrere#' D365FO Privilege XML-Dateien#' aus einer Privilege Mapping Tabelle.#'#' @param privilege_mapping Tabelle mit#' Privilege-Daten.#'#' Erwartete Spalten:#' - PRIVILEGEIDENTIFIER#' - PRIVILEGENAME#' - RESOURCE_#' - RESOURCETYPE#' - CREATEACCESS#' - CORRECTACCESS#' - DELETEACCESS#' - INVOKEACCESS#' - READACCESS#' - UPDATEACCESS#'#' @param security_mapping#' SECURITY_PRIVILEGE_MAPPING#'#' @param output_folder#' Zielordner für XML-Dateien#'#' @return Unsichtbare Liste erzeugter Dateien#'#' @export

  generate_privilege_license_variant_V0<- function(
    privilege_mapping,
    security_mapping = SECURITY_PRIVILEGE_MAPPING,
    output_folder = "Privileges"){

    # =========================================
    #   OUTPUT FOLDER
    # =========================================

      if(!dir.exists(output_folder)){dir.create(output_folder,recursive = TRUE)}

    # =========================================
    #   PRIVILEGES
    # =========================================

      privilege_ids <- unique(privilege_mapping$PRIVILEGEIDENTIFIER)

    generated_files <- list()

    # =========================================
    #   PRIVILEGE LOOP
    # =========================================

      for(privilege_id in privilege_ids){dt_privilege <- privilege_mapping %>%dplyr::filter(PRIVILEGEIDENTIFIER == privilege_id)

      privilege_name <- unique(dt_privilege$PRIVILEGENAME)[1]

      # =========================================
      # ROOT
      # =========================================

      xml_doc <- xml2::xml_new_root(
        "AxSecurityPrivilege")

      xml2::xml_add_child(
        xml_doc,
        "Name",
        privilege_id)

      xml2::xml_add_child(
        xml_doc,
        "Label",
        privilege_name)

      # =========================================
      # XML SECTIONS
      # =========================================

      section_nodes <- list()

      # =========================================
      # ENTRYPOINTS
      # =========================================

      for(i in seq_len(nrow(dt_privilege))){

        row_data <- dt_privilege[i, ]

        mapping <- security_mapping %>%
          dplyr::filter(
            resource_type == row_data$RESOURCETYPE
          )

        if(nrow(mapping) == 0){
          warning(paste("Kein Mapping gefunden:",row_data$RESOURCETYPE ))
          next
        }

        section_name <- mapping$xml_section[1]

        # =========================================
        # SECTION ERZEUGEN
        # =========================================

        if(is.null(section_nodes[[section_name]])){

          section_nodes[[section_name]] <-
            xml2::xml_add_child(
              xml_doc,
              section_name)
        }

        section_node <- section_nodes[[section_name]]

        # =========================================
        # XML NODE
        # =========================================

        object_node <- xml2::xml_add_child(
          section_node,
          mapping$xml_node[1]
        )

        # =========================================
        # NAME
        # =========================================

        xml2::xml_add_child(
          object_node,
          "Name",
          row_data$EntryPoint)

        # =========================================
        # GRANTS
        # =========================================

        if(mapping$supports_grants[1]){

          grant_node <- xml2::xml_add_child(
            object_node,
            "Grant")

          permissions <- c(
            "Create",
            "Correct",
            "Delete",
            "Invoke",
            "Read",
            "Update"
          )

          for(permission in permissions){

            column_name <- paste0(
              toupper(permission),
              "ACCESS")

            if(!column_name %in% names(row_data)){
              next
            }

            permission_value <-
              row_data[[column_name]]

            if(is.na(permission_value)){
              next
            }

            # =====================================
            # SQL <U+2192> XML
            # =====================================

            if(permission_value == 1){

              xml2::xml_add_child(
                grant_node,
                permission,
                "Allow")
            }

            if(permission_value == 2){

              xml2::xml_add_child(
                grant_node,
                permission,
                "Deny")
            }
          }
        }
      }

      # =========================================
      # DATEI
      # =========================================

      output_file <- file.path(
        output_folder,
        paste0(
          privilege_id,
          ".xml"
        )
      )

      xml2::write_xml(
        xml_doc,
        output_file,
        options = "format"
      )

      generated_files[[privilege_id]] <-
        output_file

      }

    invisible(generated_files)
    }
