#' GUID-Informationen zu Security-Objekten ergänzen
#'
#' Ergänzt ein Data Frame um zusätzliche Indikatoren, die
#' anzeigen, ob enthaltene Security-Objektbezeichner dem
#' D365FO-GUID-Muster entsprechen.
#'
#' Die Funktion prüft automatisch, ob bestimmte
#' Standardspalten vorhanden sind, und erzeugt für jede
#' gefundene Spalte eine entsprechende GUID-Kennzeichnung.
#'
#' Unterstützte Spalten:
#' - ROLEIDENTIFIER
#' - SUBROLEIDENTIFIER
#' - DUTYIDENTIFIER
#' - PRIVILEGEIDENTIFIER
#'
#' Die Prüfung erfolgt über die Funktion
#' `is_guid_name()`.
#'
#' @param df Data Frame oder Tibble mit D365FO
#'        Security-Objektbezeichnern.
#'
#' @return Data Frame mit zusätzlichen logischen
#'         GUID-Indikatoren.
#'
#' Folgende Spalten können ergänzt werden:
#'
#' \describe{
#'   \item{RoleIsGUID}{
#'   Kennzeichnung für ROLEIDENTIFIER.
#'   }
#'
#'   \item{SubRoleIsGUID}{
#'   Kennzeichnung für SUBROLEIDENTIFIER.
#'   }
#'
#'   \item{DutyIsGUID}{
#'   Kennzeichnung für DUTYIDENTIFIER.
#'   }
#'
#'   \item{PrivilegeIsGUID}{
#'   Kennzeichnung für PRIVILEGEIDENTIFIER.
#'   }
#' }
#'
#' @details
#' Die Funktion verändert ausschließlich Spalten,
#' die im Eingabeobjekt vorhanden sind.
#'
#' Nicht vorhandene Identifier-Spalten werden
#' ignoriert.
#'
#' Die Funktion eignet sich insbesondere für:
#' - Security-Analysen
#' - Lizenzanalysen
#' - GUID-Bereinigungen
#' - Security-Dokumentationen
#'
#' @examples
#' df <- tibble::tibble(
#'   ROLEIDENTIFIER = c(
#'     "SystemAdministrator",
#'     "12345678-1234-1234-1234-123456789012"
#'   )
#' )
#'
#' result <- add_guid_information(df)
#'
#' result
#'
#' @seealso
#' is_guid_name()
#'
#' @export
add_guid_information <- function(df){

  if("ROLEIDENTIFIER" %in% colnames(df)){

    df <- df %>%

      mutate(

        RoleIsGUID =
          is_guid_name(
            ROLEIDENTIFIER
          )
      )
  }

  if("SUBROLEIDENTIFIER" %in% colnames(df)){

    df <- df %>%

      mutate(

        SubRoleIsGUID =
          is_guid_name(
            SUBROLEIDENTIFIER
          )
      )
  }


  if("DUTYIDENTIFIER" %in% colnames(df)){

    df <- df %>%

      mutate(

        DutyIsGUID =
          is_guid_name(
            DUTYIDENTIFIER
          )
      )
  }

  if("PRIVILEGEIDENTIFIER" %in% colnames(df)){

    df <- df %>%

      mutate(

        PrivilegeIsGUID =
          is_guid_name(
            PRIVILEGEIDENTIFIER
          )
      )
  }

  return(df)
}