#' Ermittelt die Zuordnung zwischen EntryPoints und Privileges einer D365FO Security-Rolle
#'
#' Diese Funktion ermittelt anhand einer Menge von EntryPoints
#' (MenuItems, Forms, Services, Klassen usw.) alle zugehörigen
#' Privileges innerhalb einer bestimmten Security-Rolle.
#'
#' Die Informationen werden aus der Tabelle
#' `UserSecGovRelatedObjects` gelesen und bilden die Beziehung:
#'
#' EntryPoint → Privilege
#'
#' Zusätzlich werden sämtliche Berechtigungsstufen des EntryPoints
#' zurückgegeben (Read, Update, Create, Delete, Correct und Invoke).
#'
#' Die Funktion wird typischerweise verwendet, nachdem die
#' EntryPoints eines Privileges oder einer Duty bestimmt wurden,
#' um daraus die vollständige Security-Hierarchie aufzubauen.
#'
#' @param con Offene ODBC-Datenbankverbindung.
#'
#' @param role_name Name oder Identifier der Security-Rolle.
#' Es wird sowohl auf `ROLENAME` als auch auf `ROLEIDENTIFIER`
#' gefiltert.
#'
#' @param entrypoints Data Frame oder Tibble mit mindestens der
#' Spalte `AOTNAME`, welche die EntryPoints enthält.
#'
#' @details
#' Für jeden übergebenen EntryPoint wird die Tabelle
#' `UserSecGovRelatedObjects` abgefragt.
#'
#' Es werden ausschließlich Datensätze der angegebenen Rolle
#' berücksichtigt.
#'
#' Die Funktion liefert pro EntryPoint sämtliche referenzierten
#' Privileges einschließlich der vergebenen Zugriffsrechte.
#'
#' Ist `entrypoints` leer, wird sofort ein leeres Tibble
#' zurückgegeben.
#'
#' @return
#' Tibble mit den Spalten:
#'
#' * `EntryPoint`
#' * `PRIVILEGEIDENTIFIER`
#' * `PRIVILEGENAME`
#' * `RESOURCETYPE`
#' * `CREATEACCESS`
#' * `CORRECTACCESS`
#' * `DELETEACCESS`
#' * `INVOKEACCESS`
#' * `READACCESS`
#' * `UPDATEACCESS`
#'
#' @examples
#' \dontrun{
#'
#' con <- get_connection("PROD")
#'
#' entrypoints <- get_entrypoint_mapping(
#'   con,
#'   role_name = "_WIBU Logistik Mitarbeiter",
#'   resources
#' )
#'
#' privileges <- get_privilege_mapping(
#'   con,
#'   role_name = "_WIBU Logistik Mitarbeiter",
#'   entrypoints
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{get_entrypoint_mapping}}
#' \code{\link{get_duty_mapping}}
#'
#' @export
get_privilege_mapping <- function(
    con,
    role_name,
    entrypoints){
  
  if(nrow(entrypoints) == 0)
  {
    return(tibble())
  }
  
  entrypoint_list <- paste0(
    
    "'",
    
    entrypoints$AOTNAME,
    
    "'",
    
    collapse = ","
    
  )
  
  sql <- glue::glue("

    SELECT DISTINCT

      RESOURCE_                 AS EntryPoint,
      PRIVILEGEIDENTIFIER,
      PRIVILEGENAME,
      RESOURCETYPE,
      CREATEACCESS,
      CORRECTACCESS,
      DELETEACCESS,
      INVOKEACCESS,
      READACCESS,
      UPDATEACCESS

    FROM
      UserSecGovRelatedObjects

    WHERE
      RESOURCE_ IN ({entrypoint_list})
      AND
      (
        ROLENAME LIKE '%{role_name}%'
        OR
        ROLEIDENTIFIER LIKE '%{role_name}%'
      )

    ORDER BY
      PRIVILEGEIDENTIFIER ASC

  ")
  
  result <- odbc::dbGetQuery(
    con,
    sql
  )
  
  return(result)
}