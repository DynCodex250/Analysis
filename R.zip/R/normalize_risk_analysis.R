#' Risikoanalyse für Reports aufbereiten#'#' Bereitet die Ergebnisse einer#' Privilege Risikoanalyse für die#' Verwendung in Reports auf.#'#' Die Funktion standardisiert die#' Spaltennamen und bringt die#' Risikoinformationen in eine für#' Reports optimierte Reihenfolge.#'#' Inhaltliche Änderungen an den Daten#' werden nicht vorgenommen.#'#' @param risk_analysis Ergebnis von#' compare_privileges_risk_analysis().#'#' @return Tibble mit standardisierten#' Report-Spalten.#'#' @details#' Die Funktion dient als zentrale#' Aufbereitungsschicht zwischen#' Compare-Framework und Reporting.#'#' Die Risikoattribute werden bewusst an#' den Anfang der Ausgabe gestellt, damit#' kritische Änderungen schneller erkannt#' werden können.#'#' @seealso#' compare_privileges_risk_analysis()#'#' @seealso#' prepare_privilege_release_report()#'#' @examples#' risk_report <-#'   normalize_risk_analysis(#'     risk_analysis#'   )#'#' @export

normalize_risk_analysis <- function(risk_analysis){

  # ================================
  #   EINGABEPARAMETER VALIDIEREN
  # ================================

    if(!inherits(risk_analysis,"D365PrivilegeRiskAnalysis")){

      stop(
        paste(
          "risk_analysis muss ein",
          "D365PrivilegeRiskAnalysis sein."))

    }

  # ================================
  #   DATEN AUFBEREITEN
  # ================================

    result <-

      risk_analysis |>

      dplyr::rename(

        `Risk Level` = RiskLevel,
        `Risk Type` = RiskType,
        `Old Value` = OldValue,
        `New Value` = NewValue

      ) |>

      dplyr::select(

        `Risk Level`,
        `Risk Type`,
        Component,
        Object,
        Permission,
        `Old Value`,
        `New Value`
      )

    # ================================
    #   ERGEBNIS ZURÜCKGEBEN
    # ================================

      return(result)

}
