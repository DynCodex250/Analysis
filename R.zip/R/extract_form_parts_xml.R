#' Form Parts extrahieren
#'
#' Extrahiert alle Parts eines D365FO Formulars
#' aus dem XML-Dokument.
#'
#' Die Funktion liest sämtliche
#' `AxFormPartReference`-Referenzen aus dem XML aus.
#'
#' @param xml_doc XML-Dokument eines D365FO Formulars.
#'
#' @return Tibble mit den Spalten:
#'
#' * `Name` — Technischer Name des Form Parts
#' * `DataSource` — Verwendete DataSource
#' * `MenuItemName` — Referenziertes MenuItem
#'
#' @details
#' Die Funktion dient als Grundlage für:
#'
#' * Form-Analyse
#' * Form-Dokumentation
#' * Form-Vergleich
#' * Reverse Engineering
#'
#' @seealso [extract_form_parts()], [analyze_form()]
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#' parts <- extract_form_parts_xml(xml_doc)
#' }
#'
#' @export
extract_form_parts_xml <- function(xml_doc) {

  # ================================
  # PARTS ERMITTELN
  # ================================

  part_nodes <-
    xml2::xml_find_all(
      xml_doc,
      ".//*[local-name()='AxFormPartReference']"
    )

  # ================================
  # PARTS AUSLESEN
  # ================================

  result <- list()

  for (part_node in part_nodes) {

    result[[length(result) + 1]] <-

      tibble::tibble(

        Name =
          xml2::xml_text(
            xml2::xml_find_first(
              part_node,
              "./*[local-name()='Name']"
            )
          ),

        DataSource =
          xml2::xml_text(
            xml2::xml_find_first(
              part_node,
              "./*[local-name()='DataSource']"
            )
          ),

        MenuItemName =
          xml2::xml_text(
            xml2::xml_find_first(
              part_node,
              "./*[local-name()='MenuItemName']"
            )
          )
      )
  }

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(dplyr::bind_rows(result))
}
