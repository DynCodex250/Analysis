#' StaticText Controls extrahieren
#'
#' Extrahiert alle `StaticText`-Controls eines
#' D365FO Formulars.
#'
#' Die Funktion dient als Grundlage für:
#'
#' * Formular-Dokumentationen
#' * Dialog-Analysen
#' * Release-Vergleiche
#'
#' @param form_model Ergebnis von [analyze_form()].
#'
#' @return Tibble mit den Spalten:
#'
#' * `Parent` — Übergeordnetes Control
#' * `StaticText` — Technischer Name des Controls
#' * `Path` — Vollständiger Pfad im Formular
#'
#' @details
#' Die Funktion analysiert Controls vom Typ `StaticText`.
#'
#' `StaticText`-Controls werden häufig in:
#'
#' * Dialogformularen
#' * Informationsseiten
#' * Assistenten (Wizards)
#'
#' verwendet.
#'
#' @seealso [analyze_form()], [extract_form_controls_by_type()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#' extract_form_static_texts(form_model)
#' }
#'
#' @export
extract_form_static_texts <- function(form_model) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # STATIC TEXTS ERMITTELN
  # ================================

  static_texts <-
    extract_form_controls_by_type(form_model, "StaticText")

  # ================================
  # LEERES MODELL
  # ================================

  if (nrow(static_texts) == 0) {
    return(empty_form_static_texts())
  }

  # ================================
  # FACHMODELL ERSTELLEN
  # ================================

  result <-
    static_texts |>
    dplyr::transmute(
      Parent,
      StaticText = Name,
      Path
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
