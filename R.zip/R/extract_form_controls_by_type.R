#' Controls eines bestimmten Typs extrahieren
#'
#' Extrahiert alle Controls eines bestimmten Typs
#' aus einem analysierten D365FO Formular.
#'
#' Die Funktion dient als generischer Zugriff auf die
#' Control-Hierarchie und ermöglicht die Analyse
#' beliebiger Control-Typen.
#'
#' @param form_model Ergebnis von [analyze_form()].
#' @param control_type Technischer Name des Control-Typs.
#'   Muss ein einzelner `character`-Wert sein.
#'
#' @return Tibble mit allen Controls des angegebenen Typs.
#'
#' @details
#' Beispiele für gültige Control-Typen:
#'
#' * `Grid`
#' * `Group`
#' * `Tab`
#' * `TabPage`
#' * `MenuFunctionButton`
#' * `ActionPane`
#' * `ActionPaneTab`
#' * `ReferenceGroup`
#' * `String`
#' * `ComboBox`
#'
#' Die Funktion arbeitet auf dem Form-Modell
#' und liest kein XML.
#'
#' @seealso [analyze_form()], [extract_form_control_types()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#'
#' extract_form_controls_by_type(form_model, "Grid")
#' extract_form_controls_by_type(form_model, "MenuFunctionButton")
#' }
#'
#' @export
extract_form_controls_by_type <- function(
    form_model,
    control_type) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  if (!is.character(control_type)) {
    stop("control_type muss ein Character sein.")
  }

  if (length(control_type) != 1) {
    stop("control_type muss genau einen Wert enthalten.")
  }

  # ================================
  # CONTROLS FILTERN
  # ================================

  result <-
    form_model$Controls |>
    dplyr::filter(Type == control_type)

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
