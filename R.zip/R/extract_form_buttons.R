#' Formular-Buttons extrahieren
#'
#' Extrahiert alle ausführbaren Button-Controls
#' eines D365FO Formulars.
#'
#' Unterstützte Typen:
#'
#' * `Button`
#' * `MenuFunctionButton`
#' * `MenuButton`
#' * `DropDialogButton`
#'
#' Die Funktion dient als Grundlage für:
#'
#' * Formular-Dokumentationen
#' * Release-Vergleiche
#' * Berechtigungsanalysen
#' * Menü-Item Analysen
#'
#' @param form_model Ergebnis von [analyze_form()].
#'
#' @return Tibble mit den Spalten:
#'
#' * `ButtonType` — Typ des Buttons (`Button`, `MenuFunctionButton`, etc.)
#' * `Name` — Technischer Name des Controls
#' * `MenuItemName` — Referenziertes MenuItem
#' * `MenuItemType` — Typ des MenuItems
#' * `NeededPermission` — Mindestberechtigung für den Button
#' * `Label` — Anzeigetext (aus Property `Text`)
#' * `Parent` — Übergeordnetes Control
#' * `Path` — Vollständiger Pfad im Formular
#'
#' @seealso [analyze_form()], [extract_form_menu_item_buttons()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#' buttons <- extract_form_buttons(form_model)
#' }
#'
#' @export
extract_form_buttons <- function(form_model) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # BUTTONS FILTERN
  # ================================

  buttons <-
    form_model$Controls |>
    dplyr::filter(
      Type %in% c(
        "Button",
        "MenuFunctionButton",
        "MenuButton",
        "DropDialogButton"
      )
    )

  # ================================
  # LEERES MODELL
  # ================================

  if (nrow(buttons) == 0) {
    return(empty_form_buttons())
  }

  # ================================
  # FACHMODELL ERSTELLEN
  # ================================

  result <-
    purrr::pmap_dfr(
      list(
        buttons$Name,
        buttons$Type,
        buttons$Parent,
        buttons$Path,
        buttons$Properties
      ),
      function(Name, Type, Parent, Path, Properties) {

        tibble::tibble(
          ButtonType       = Type,
          Name             = Name,
          MenuItemName     = get_property(Properties, "MenuItemName"),
          MenuItemType     = get_property(Properties, "MenuItemType"),
          NeededPermission = get_property(Properties, "NeededPermission"),
          Label            = get_property(Properties, "Text"),
          Parent           = Parent,
          Path             = Path
        )
      }
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
