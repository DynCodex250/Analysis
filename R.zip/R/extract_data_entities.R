#' Data Entities aus Privilege-XML extrahieren
#'
#' Extrahiert die referenzierten Data Entities und deren Berechtigungen aus
#' einer Privilege-XML-Struktur.
#'
#' @param xml_doc Ein geladenes XML-Dokument (xml_document).
#'
#' @return Ein Tibble mit den extrahierten Data-Entity-Berechtigungen.
#'
#' @export
extract_data_entities <- function(xml_doc) {

  # =========================================
  # INTERNE HILFSFUNKTION FÜR GRANTS
  # =========================================

  extract_grants <- function(node) {
    grant_node <- xml2::xml_find_first(node, "./Grant")

    if (inherits(grant_node, "xml_missing")) {
      return(character())
    }

    xml2::xml_children(grant_node) |>
      xml2::xml_name()
  }

  # =========================================
  # KNOTEN EXTRAHIEREN UND MAP-OPERATION
  # =========================================

  nodes <- xml2::xml_find_all(
    xml_doc,
    "//DataEntityPermissions/AxSecurityDataEntityPermission"
  )

  result <- purrr::map_dfr(nodes, function(node) {
    tibble::tibble(
      name = xml2::xml_text(
        xml2::xml_find_first(node, "./Name")
      ),

      integration_mode = xml2::xml_text(
        xml2::xml_find_first(node, "./IntegrationMode")
      ),

      grants = paste(
        sort(extract_grants(node)),
        collapse = "|"
      )
    )
  })

  return(result)
}