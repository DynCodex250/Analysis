#' Controls aus Privilege-XML extrahieren
#'
#' Extrahiert Formularsteuerelemente (Controls) und deren Berechtigungen aus
#' einer Privilege-XML-Struktur.
#'
#' @param xml_doc Ein geladenes XML-Dokument (xml_document).
#'
#' @return Ein Tibble mit den extrahierten Steuerelementen.
#'
#' @export
extract_controls <- function(xml_doc) {

  # =========================================
  # INTERNE HILFSFUNKTION FÜR GRANTS
  # =========================================

  extract_grants <- function(node) {
    grant_node <- xml2::xml_find_first(node, "./Grant")

    if (inherits(grant_node, "xml_missing")) {
      return(character())
    }

    xml2::xml_children(grant_node) |>
      xml2::xml_name()
  }

  # =========================================
  # ENTRYPOINTS FINDEN
  # =========================================

  entrypoint_nodes <- xml2::xml_find_all(
    xml_doc,
    "//EntryPoints/AxSecurityEntryPointReference"
  )

  result <- list()

  # =========================================
  # DURCH ENTRYPOINTS ITERIEREN
  # =========================================

  for (ep_node in entrypoint_nodes) {
    ep_name <- xml2::xml_text(
      xml2::xml_find_first(ep_node, "./Name")
    )

    form_nodes <- xml2::xml_find_all(
      ep_node,
      "./Forms/AxSecurityEntryPointReferenceForm"
    )

    for (form_node in form_nodes) {
      form_name <- xml2::xml_text(
        xml2::xml_find_first(form_node, "./Name")
      )

      control_nodes <- xml2::xml_find_all(
        form_node,
        "./Controls/AxSecurityEntryPointReferenceFormControl"
      )

      for (control_node in control_nodes) {
        result[[length(result) + 1]] <- tibble::tibble(
          entrypoint = ep_name,
          form_name = form_name,
          control_name = xml2::xml_text(
            xml2::xml_find_first(control_node, "./Name")
          ),
          grants = paste(
            sort(extract_grants(control_node)),
            collapse = "|"
          )
        )
      }
    }
  }

  # =========================================
  # ERGEBNIS ZUSAMMENFÜHREN
  # =========================================

  return(dplyr::bind_rows(result))
}