#' D365FO Privilege XML generieren
#'
#' Generiert eine D365FO-kompatible XML-Datei für ein
#' Security Privilege aus einer SQL-Sicherheitstabelle.
#'
#' Die Funktion baut die XML-Struktur eines
#' `AxSecurityPrivilege` auf und berücksichtigt:
#'
#' * EntryPoints (MenuItems)
#' * DataEntityPermissions
#' * DirectAccessPermissions
#' * Form Control References
#'
#' @param security_table Data Frame mit den
#'   Security-Daten aus der D365FO-Datenbank.
#'   Muss die Spalten enthalten:
#'   `PRIVILEGEIDENTIFIER`, `PRIVILEGENAME`,
#'   `RESOURCETYPE`, `RESOURCE_`,
#'   `CREATEACCESS`, `CORRECTACCESS`,
#'   `DELETEACCESS`, `INVOKEACCESS`,
#'   `READACCESS`, `UPDATEACCESS`.
#' @param privilege_identifier Technischer Name
#'   des Privileges (entspricht `PRIVILEGEIDENTIFIER`).
#' @param output_file Optionaler Pfad zur
#'   Ausgabedatei. Wird `NULL` übergeben,
#'   wird keine Datei geschrieben.
#'
#' @return XML-Dokument als `xml_node`-Objekt
#'   (Wurzelelement `AxSecurityPrivilege`).
#'
#' @details
#' Die Funktion verarbeitet drei Ressourcentypen:
#'
#' * **Data Entity** — wird als
#'   `AxSecurityDataEntityPermission` eingetragen
#' * **Menu Item Display / Action / Output** — wird als
#'   `AxSecurityEntryPointReference` eingetragen
#' * **Form Controls** — werden als
#'   `AxSecurityEntryPointReferenceFormControl` eingetragen
#'
#' Grant-Knoten (`Read`, `Create`, `Update`,
#' `Delete`, `Correct`, `Invoke`) werden nur
#' erzeugt, wenn der jeweilige Zugriff = 1.
#'
#' @seealso [parse_privilege()],
#'   [generate_privilege_xml()]
#'
#' @examples
#' \dontrun{
#' xml_root <- generate_d365_privilege_xml(
#'   security_table        = sql_data,
#'   privilege_identifier  = "SalesOrderMaintain"
#' )
#'
#' # Mit Dateiausgabe
#' generate_d365_privilege_xml(
#'   security_table        = sql_data,
#'   privilege_identifier  = "SalesOrderMaintain",
#'   output_file           = "SalesOrderMaintain.xml"
#' )
#' }
#'
#' @export



generate_d365_privilege_xml <- function(security_table,
                                        privilege_identifier,
                                        output_file = NULL) {
  df <- security_table |>
    dplyr::filter(PRIVILEGEIDENTIFIER == privilege_identifier)

  if (nrow(df) == 0) {
    stop("Privilege not found")
  }

  privilege_label <- unique(df$PRIVILEGENAME)[1]

  add_grant_nodes <- function(parent, row) {
    grant_node <- xml2::xml_add_child(parent, "Grant")

    if (row$CREATEACCESS == 1)
      xml2::xml_add_child(grant_node, "Create", "Allow")

    if (row$CORRECTACCESS == 1)
      xml2::xml_add_child(grant_node, "Correct", "Allow")

    if (row$DELETEACCESS == 1)
      xml2::xml_add_child(grant_node, "Delete", "Allow")

    if (row$INVOKEACCESS == 1)
      xml2::xml_add_child(grant_node, "Invoke", "Allow")

    if (row$READACCESS == 1)
      xml2::xml_add_child(grant_node, "Read", "Allow")

    if (row$UPDATEACCESS == 1)
      xml2::xml_add_child(grant_node, "Update", "Allow")

  }

  map_object_type <- function(resource_type) {
    case_when(
      stringr::str_to_lower(resource_type) == "menu item display" ~ "MenuItemDisplay",
      stringr::str_to_lower(resource_type) == "menu item action" ~ "MenuItemAction",
      stringr::str_to_lower(resource_type) == "menu item output" ~ "MenuItemOutput",
      TRUE ~ "MenuItemDisplay"
    )

  }

  root <- xml_new_root("AxSecurityPrivilege")

  xml2::xml_set_attr(root, "xmlns", "")

  xml2::xml_add_child(
    root,
    "Name",
    privilege_identifier)

  xml2::xml_add_child(
    root,
    "Label",
    privilege_label)

  data_entity_node <- xml2::xml_add_child(
    root, "DataEntityPermissions")

  data_entities <- df |>
    dplyr::filter(
      stringr::str_to_lower(RESOURCETYPE) == "data entity"
    ) |>
    dplyr::mutate(
      entity_name = stringr::str_split_fixed(RESOURCE_, "\\\\", 2)[, 2]
    ) |>
    distinct(entity_name, .keep_all = TRUE)


  for (i in seq_len(nrow(data_entities))) {
    row <- data_entities[i, ]

    entity_node <- xml2::xml_add_child(data_entity_node, "AxSecurityDataEntityPermission")
    add_grant_nodes(entity_node, row)

    xml2::xml_add_child(entity_node, "IntegrationMode", "DataServices")
    xml2::xml_add_child(entity_node, "Name", row$entity_name)
    xml2::xml_add_child(entity_node, "Fields")
    xml2::xml_add_child(entity_node, "Methods")

  }

  direct_access_node <- xml2::xml_add_child(root, "DirectAccessPermissions")

  for (i in seq_len(nrow(data_entities))) {
    row <- data_entities[i, ]

    entity_node <- xml2::xml_add_child(direct_access_node, "AxSecurityDataEntityReference")

    add_grant_nodes(entity_node, row)
    xml2::xml_add_child(entity_node, "Name", row$entity_name)

    xml2::xml_add_child(entity_node, "Fields")

  }

  entrypoints_node <- xml2::xml_add_child(root, "EntryPoints")

  menu_items <- df |> dplyr::filter(str_detect(stringr::str_to_lower(RESOURCETYPE), "menu item"))

  base_entrypoints <- menu_items |> dplyr::filter(!stringr::str_detect(RESOURCE_, "\\\\"))

  for (i in seq_len(nrow(base_entrypoints))) {
    row <- base_entrypoints[i, ]

    ep_node <- xml2::xml_add_child(entrypoints_node, "AxSecurityEntryPointReference")

    object_type <- map_object_type(row$RESOURCETYPE)

    xml2::xml_add_child(ep_node, "Name", paste0(row$RESOURCE_, "_", object_type))

    add_grant_nodes(ep_node, row)

    xml2::xml_add_child(ep_node, "ObjectName", row$RESOURCE_)

    xml2::xml_add_child(ep_node, "ObjectType", object_type)

    forms_node <- xml2::xml_add_child(ep_node, "Forms")

    related_rows <- menu_items |>
      dplyr::filter(stringr::str_detect(RESOURCE_, paste0("^", row$RESOURCE_, "\\\\\\\\")))

    if (nrow(related_rows) == 0) {
      next
    }

    parsed_forms <- related_rows |>
      dplyr::mutate(
        path_parts = stringr::str_split(RESOURCE_, "\\\\\\\\"))

    form_names <- unique(purr::map_chr(parsed_forms$path_parts, ~ ifelse(length(.x) >= 2, .x[2], NA)))

    form_names <- form_names[!is.na(form_names)]

    for (form_name in form_names) {

      form_node <- xml2::xml_add_child(forms_node, "AxSecurityEntryPointReferenceForm")

      xml2::xml_add_child(form_node, "Name", form_name)

      controls_node <- xml2::xml_add_child(form_node, "Controls")

      form_rows <- parsed_forms |>
        dplyr::filter(
          purr::map_chr(path_parts, ~ ifelse(length(.x) >= 2, .x[2], "")) == form_name)

      control_rows <- form_rows |>
        dplyr::filter(
          purr::map_int(
            path_parts, length) >= 3)

      added_controls <- c()

      for (j in seq_len(nrow(control_rows))) {
        crow <- control_rows[j, ]
        control_name <- crow$path_parts[[1]][3]

        if (control_name %in% added_controls)
          next

        added_controls <- c(added_controls, control_name)

        control_node <- xml2::xml_add_child(
          controls_node,
          "AxSecurityEntryPointReferenceFormControl")

        add_grant_nodes(control_node, crow)

        xml2::xml_add_child(
          control_node,
          "Name",
          control_name)
      }

      xml2::xml_add_child(form_node, "DataSources")
    }

  }

  xml2::xml_add_child(root, "FormControlOverrides")

  if (!is.null(output_file)) {
    xml2::write_xml(root, output_file, options = "format")

  }

  return(root)
}

