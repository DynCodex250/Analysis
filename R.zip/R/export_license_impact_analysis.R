#' Export license impact analysis
#'
#' Exports the result of a D365FO license impact analysis to an
#' Excel workbook.
#'
#' The workbook contains multiple worksheets summarizing the
#' licensing analysis for a security role.
#'
#' The exported workbook contains:
#'
#' \itemize{
#'   \item Role information
#'   \item Not entitled entry points
#'   \item Privilege mapping
#'   \item Duty mapping
#'   \item License impact summary
#' }
#'
#' The output filename is automatically generated from the
#' supplied role name.
#'
#' @param analysis_result Result returned by
#'   \code{analyze_role_license_impact()}.
#'
#' @param role_name Character value containing the
#'   security role name.
#'
#' @param export_folder Folder where the Excel workbook
#'   should be written.
#'
#' @return
#' Character value containing the full path of the
#' generated Excel workbook.
#'
#' @details
#' The function exports the complete result of a license
#' analysis into a structured Excel workbook.
#'
#' The workbook contains the following worksheets:
#'
#' \itemize{
#'   \item RoleInformation
#'   \item NotEntitledEntryPoints
#'   \item PrivilegeMapping
#'   \item DutyMapping
#'   \item LicenseImpactSummary
#' }
#'
#' Spaces in the role name are automatically replaced with
#' underscores when generating the filename.
#'
#' @examples
#' \dontrun{
#'
#' result <-
#'   analyze_role_license_impact(
#'     role_identifier = "WHSWarehouseWorker"
#'   )
#'
#' export_license_impact_analysis(
#'   analysis_result = result,
#'   role_name = "Warehouse Worker"
#' )
#'
#' export_license_impact_analysis(
#'   analysis_result = result,
#'   role_name = "Warehouse Worker",
#'   export_folder = "Output"
#' )
#'
#' }
#'
#' @author
#' Cedric Kameni
#'
#' @export

export_license_impact_analysis <- function(
    analysis_result,
    role_name,
    export_folder = "Data"
) {
  
  # ==========================================
  # CREATE EXPORT PATH
  # ==========================================
  
  export_path <- paste0(
    export_folder,
    "/D365FO_License_Impact_",
    gsub(" ", "_", role_name),
    ".xlsx"
  )
  
  # ==========================================
  # EXPORT TO EXCEL
  # ==========================================
  
  writexl::write_xlsx(
    
    list(
      
      RoleInformation =
        analysis_result$RoleInformation,
      
      NotEntitledEntryPoints =
        analysis_result$NotEntitledEntryPoints,
      
      PrivilegeMapping =
        analysis_result$PrivilegeMapping,
      
      DutyMapping =
        analysis_result$DutyMapping,
      
      LicenseImpactSummary =
        analysis_result$LicenseImpactSummary
      
    ),
    
    path = export_path
    
  )
  
  # ==========================================
  # RETURN EXPORT PATH
  # ==========================================
  
  return(export_path)
  
}