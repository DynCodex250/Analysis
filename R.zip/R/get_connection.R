get_connection <- function(env, cred_path) {

 #p <-"C:/Users/ckam_admin/Documents/RProjects/D365_Admin/db_credentials.xlsx"
  #cred_path <- "C:/Users/Cedric/Documents/RProjects/D365Security/inst/config/report_mapping.xlsx"
  credentials <- readxl::read_excel(path = cred_path,sheet = "AllConnections",col_types = "text")

  row <- credentials |>
    dplyr::filter(Umgebung == env)

  if (nrow(row) == 0) {
    stop(paste("Keine Credentials für Umgebung:", env))
  }

  DBI::dbConnect(
    drv = odbc::odbc(),
    Driver   = "SQL Server",
    server   = row$server,
    database = row$database,
    uid      = row$uid,
    pwd      = row$pwd)


}
