#' Formular-Parts extrahieren (V1)
#'
#' Aktuelle Version von [extract_form_parts()].
#'
#' Extrahiert die Form Parts eines D365FO Formulars.
#'
#' Die Funktion arbeitet auf einem `D365FormModel` und
#' liefert die im Formular eingebundenen Form Parts.
#'
#' Die Funktion dient als Grundlage für:
#'
#' * Formular-Dokumentationen
#' * Release-Vergleiche
#' * Formularanalysen
#' * Abhängigkeitsanalysen
#'
#' @param form_model Ergebnis von [analyze_form()].
#'
#' @return Tibble mit den Spalten:
#'
#' * `Name` — Technischer Name des Form Parts
#' * `DataSource` — Verwendete DataSource
#' * `MenuItemName` — Referenziertes MenuItem
#'
#' @details
#' Form Parts stellen eingebettete Formulare oder
#' Formularbereiche dar.
#'
#' @seealso [extract_form_parts()], [extract_form_parts_xml()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#' extract_form_parts_V1(form_model)
#' }
#'
#' @export
extract_form_parts_V1 <- function(form_model) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # LEERES MODELL
  # ================================

  if (is.null(form_model$Parts)) {
    return(empty_form_parts())
  }

  if (nrow(form_model$Parts) == 0) {
    return(empty_form_parts())
  }

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(form_model$Parts)
}
