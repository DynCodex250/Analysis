#' D365FO Security-Berechtigungen einer Komponente vergleichen
#'
#' Vergleicht zwei D365FO Security-Komponenten und ermittelt
#' Änderungen an Berechtigungen innerhalb identischer Objekte.
#'
#' Die Funktion bildet die technische Grundlage für
#' `compare_privileges_security()`.
#'
#' Im Gegensatz zu `compare_component_existence()`
#' werden ausschließlich Änderungen an Berechtigungen
#' analysiert.
#'
#' Hinzugefügte oder entfernte Objekte werden nicht
#' berücksichtigt.
#'
#' Verglichen werden ausschließlich Objekte, die in
#' beiden Komponenten vorhanden sind.
#'
#' Typische Einsatzgebiete:
#' - EntryPoint-Berechtigungen vergleichen
#' - Data Entity Permissions vergleichen
#' - Direct Access Permissions vergleichen
#' - Form Controls vergleichen
#' - Form Data Sources vergleichen
#'
#' @param component_a Erste Security-Komponente als
#'        Data Frame oder Tibble.
#'
#' @param component_b Zweite Security-Komponente als
#'        Data Frame oder Tibble.
#'
#' @param component_name Anzeigename der Security-Komponente.
#'        Dieser Wert wird im Ergebnis ausgegeben.
#'
#' @param key_columns Schlüsselspalten zur eindeutigen
#'        Identifikation eines Security-Objekts.
#'
#' @return Tibble mit allen gefundenen
#' Berechtigungsänderungen.
#'
#' Enthaltene Spalten:
#'
#' \describe{
#'   \item{Component}{
#'   Name der analysierten Security-Komponente.
#'   }
#'
#'   \item{Object}{
#'   Eindeutige Objektidentifikation auf Basis
#'   der Schlüsselspalten.
#'   }
#'
#'   \item{Permission}{
#'   Name der geänderten Berechtigung.
#'   }
#'
#'   \item{OldValue}{
#'   Ursprünglicher Berechtigungswert.
#'   }
#'
#'   \item{NewValue}{
#'   Neuer Berechtigungswert.
#'   }
#' }
#'
#' @details
#' Die Funktion führt zunächst einen Join über die
#' angegebenen Schlüsselspalten durch und analysiert
#' anschließend alle Berechtigungen aus
#' `get_grant_order()`.
#'
#' Verglichen werden typischerweise:
#'
#' - Read
#' - Create
#' - Update
#' - Delete
#' - Correct
#' - Invoke
#'
#' Änderungen werden erkannt, wenn:
#'
#' - ein Wert hinzugefügt wurde
#' - ein Wert entfernt wurde
#' - sich der Berechtigungswert geändert hat
#'
#' Objekte ohne Berechtigungsänderungen werden
#' nicht im Ergebnis aufgeführt.
#'
#' @examples
#' component_a <- tibble::tibble(
#'   Name = "CustTable",
#'   Read = "Allow",
#'   Update = NA
#' )
#'
#' component_b <- tibble::tibble(
#'   Name = "CustTable",
#'   Read = "Allow",
#'   Update = "Allow"
#' )
#'
#' compare_component_security(
#'   component_a,
#'   component_b,
#'   component_name = "EntryPoints",
#'   key_columns = "Name"
#' )
#'
#' @seealso
#' compare_component_existence()
#' compare_privileges_security()
#' get_grant_order()
#'
#' @export
compare_component_security <- function(
    component_a,
    component_b,
    component_name,
    key_columns
){

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if(nrow(component_a) == 0 ||
     nrow(component_b) == 0){
    return(tibble::tibble())
  }

  if(!inherits(component_a, "data.frame")){
    stop("component_a muss ein DataFrame sein.")
  }

  if(!inherits(component_b, "data.frame")){
    stop("component_b muss ein DataFrame sein.")
  }

  # ================================
  # DATEN AUFBEREITEN
  # ================================

  joined <-
    dplyr::inner_join(
      component_a,
      component_b,
      by = key_columns,
      suffix = c("_old", "_new"))

  if(nrow(joined) == 0){
    return(tibble::tibble())
  }

  permissions <- get_grant_order()

  result <- list()

  # ================================
  # VERARBEITUNG DURCHFÜHREN
  # ================================

  for(permission  in permissions){

    old_column <- paste0(permission, "_old")
    new_column <- paste0(permission, "_new")

    if(!old_column %in% names(joined)){
      next
    }

    if(!new_column %in% names(joined)){
      next
    }

    changed_rows <-
      joined |>
      dplyr::filter(

        xor(
          is.na(.data[[old_column]]),
          is.na(.data[[new_column]])
        )
        |
          (
            !is.na(.data[[old_column]])
            &
              !is.na(.data[[new_column]])
            &
              .data[[old_column]] != .data[[new_column]]
          )
      )

    if(nrow(changed_rows) == 0){
      next
    }

    object_name <-
      apply(
        changed_rows[, key_columns, drop = FALSE],
        1,
        paste,
        collapse = " | "
      )

    result[[permission]] <-
      tibble::tibble(
        Component = component_name,
        Object = object_name,
        Permission = permission,
        OldValue = changed_rows[[old_column]],
        NewValue = changed_rows[[new_column]]
      )
  }

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(
    dplyr::bind_rows(result)
  )

}
