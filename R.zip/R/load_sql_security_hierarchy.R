#' Security-Hierarchie laden#'#' Lädt die Beziehungen zwischen#' Roles, Duties und Privileges#' aus UserSecGovRelatedObjects.#'#' Die Daten bilden die Grundlage#' für Security-Analysen:#'#' Role#' <U+2193>#' Duty#' <U+2193>#' Privilege#'#' @param connection DBI Connection.#'#' @return Tibble.#'#' Enthält:#'#' * ROLEIDENTIFIER#' * ROLENAME#' * DUTYIDENTIFIER#' * DUTYNAME#' * PRIVILEGEIDENTIFIER#' * PRIVILEGENAME#'#' @examples#' security_hierarchy <-#'   load_sql_security_hierarchy(#'     connection#'   )#'#' @export

load_sql_security_hierarchy <- function(connection){

  # ================================
  #   SQL
  # ================================

    sql <-
      "
SELECT
DISTINCT
USGRO.ROLEIDENTIFIER,
USGRO.ROLENAME,
USGRO.DUTYIDENTIFIER,
USGRO.DUTYNAME,
USGRO.PRIVILEGEIDENTIFIER,
USGRO.PRIVILEGENAME
FROM UserSecGovRelatedObjects USGRO"

    # ================================
    #   AUSFÜHREN
    # ================================

      result <-

        DBI::dbGetQuery(
          connection,
          sql
        )

      # ================================
      #   TIBBLE
      # ================================

        result <-

          tibble::as_tibble(
            result
          )

        # ================================
        #   ERGEBNIS
        # ================================

          return(result)

}
