#' D365FO Privilege-Roundtrip auf Komponentenebene vergleichen
#'
#' Vergleicht zwei D365FO Privilege-XML-Dateien auf Ebene
#' der einzelnen Modellkomponenten.
#'
#' Beide XML-Dateien werden zunächst mit
#' `parse_privilege()` eingelesen und anschließend
#' komponentenweise mittels `all.equal()`
#' verglichen.
#'
#' Die Funktion dient insbesondere zur Validierung
#' von XML-Roundtrips und ermöglicht eine gezielte
#' Identifikation der betroffenen Komponenten.
#'
#' Typischer Ablauf:
#'
#' Original XML
#' -> parse_privilege()
#' -> generate_privilege_xml()
#' -> parse_privilege()
#' -> compare_privilege_roundtrip_components()
#'
#' Im Gegensatz zu
#' `compare_privilege_roundtrip_model()`
#' erfolgt hier kein Vergleich des vollständigen
#' Modells, sondern eine Analyse der einzelnen
#' Komponenten.
#'
#' Dadurch kann schnell erkannt werden,
#' welche Bereiche eines Privileges von
#' einer Abweichung betroffen sind.
#'
#' Typische Anwendungsfälle:
#' - Roundtrip-Tests
#' - Regressionstests
#' - XML-Generator-Validierung
#' - Reverse Engineering
#' - Fehlersuche bei Modellunterschieden
#'
#' @param original_xml Vollständiger Pfad zur
#'        Original-XML-Datei.
#'
#' @param generated_xml Vollständiger Pfad zur
#'        generierten XML-Datei.
#'
#' @return Tibble mit den verglichenen Komponenten
#'         und dem Vergleichsergebnis.
#'
#' Enthaltene Spalten:
#'
#' \describe{
#'   \item{component}{
#'   Name der verglichenen Komponente.
#'   }
#'
#'   \item{Equal}{
#'   TRUE, wenn die Komponente identisch ist,
#'   andernfalls FALSE.
#'   }
#' }
#'
#' Verglichene Komponenten:
#'
#' - Metadata
#' - EntryPoints
#' - EntryPointForms
#' - EntryPointControls
#' - EntryPointFormDataSources
#' - DataEntityPermissions
#' - DataEntityMethods
#' - DirectAccessPermissions
#' - DirectAccessFields
#' - FormControlOverrides
#'
#' @details
#' Für jede Komponente wird ein Vergleich mittels
#' `all.equal()` durchgeführt.
#'
#' Das Ergebnis wird anschließend auf einen
#' logischen Wert reduziert.
#'
#' Dadurch eignet sich die Funktion besonders
#' für automatisierte Tests und Build-Pipelines,
#' da sofort sichtbar wird, welche Komponenten
#' erfolgreich reproduziert wurden.
#'
#' Für einen Vergleich des vollständigen
#' D365Privilege-Modells sollte
#' `compare_privilege_roundtrip_model()`
#' verwendet werden.
#'
#' Für einen direkten XML-Vergleich eignet sich
#' `compare_xml_structure_notepad()`.
#'
#' @seealso
#' parse_privilege()
#' compare_privilege_roundtrip_model()
#' compare_xml_structure_notepad()
#'
#' @examples
#' compare_privilege_roundtrip_components(
#'   original_xml = "Original.xml",
#'   generated_xml = "Roundtrip.xml"
#' )
#'
#' @export
compare_privilege_roundtrip_components <- function(
    original_xml,
    generated_xml) {

  # =====================================
  # XML-DATEIEN EINLESEN
  # =====================================

  original_model <- parse_privilege(
    original_xml
  )

  generated_model <- parse_privilege(
    generated_xml
  )

  # =====================================
  # KOMPONENTEN DEFINIEREN
  # =====================================

  components = c(
    "Metadata",
    "EntryPoints",
    "EntryPointForms",
    "EntryPointControls",
    "EntryPointFormDataSources",
    "DataEntityPermissions",
    "DataEntityMethods",
    "DirectAccessPermissions",
    "DirectAccessFields",
    "FormControlOverrides"
  )

  # =====================================
  # KOMPONENTEN VERGLEICHEN
  # =====================================

  result <- tibble::tibble(

    component = components,

    Equal = purrr::map_lgl(

      components,

      function(component){

        isTRUE(

          all.equal(

            original_model[[component]],

            generated_model[[component]]

          )

        )

      }

    )

  )

  # =====================================
  # ERGEBNIS ZURÜCKGEBEN
  # =====================================

  return(result)

}
