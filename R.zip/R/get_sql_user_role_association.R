#' Benutzer-Rollen-Zuweisung abfragen
#'
#' Ruft die aktiven Zuweisungen von Sicherheitsrollen zu Benutzern aus der Tabelle/View
#' `SystemSecurityUserRoleAssociationEntity` ab.
#'
#' @param con Ein gültiges Datenbankverbindungsobjekt (DBI connection).
#'
#' @param user_ids Optionaler Vektor von Benutzer-IDs (USERID) zur Filterung.
#'
#' @return Ein Data Frame mit den aktiven Rollenzuweisungen.
#'
#' @export
get_sql_user_role_association <- function(
    con,
    user_ids = character()) {

  # =========================================
  # BASIS-ABFRAGE
  # =========================================

  query <- "SELECT
    USERID,
    SECURITYROLEIDENTIFIER,
    SECURITYROLENAME,
    SECURITYROLE,
    ASSIGNMENTSTATUS
  FROM SystemSecurityUserRoleAssociationEntity
  WHERE ASSIGNMENTSTATUS = 1"

  # =========================================
  # FILTER HINZUFÜGEN
  # =========================================

  if (length(user_ids) > 0) {
    user_list <- paste0(
      "'", gsub("'", "''", user_ids), "'",
      collapse = ","
    )
    query <- paste0(
      query,
      "\nAND USERID IN (", user_list, ")"
    )
  }

  # =========================================
  # ABFRAGE AUSFÜHREN
  # =========================================

  return(DBI::dbGetQuery(con, query))
}
