# =========================================
#   GENERATE LICENSE VARIANT PRIVILEGE
# =========================================
#
#
#
#   Erstellt eine Privilege-Variante,
#
# die ausschließlich die problematischen
#
# EntryPoints enthält.
#
#
#
# Beispiel:
#
#
#
#   Original:
#
#   ProcessBankAccountReconciliation
#
#
#
# Neu:
#
#   ProcessBankAccountReconciliation_SCM
# =========================================

#' Lizenzspezifische Privilege-Variante erzeugen
#'#' Erstellt auf Basis eines bestehenden
#' D365FO Privilege XMLs eine neue Variante,
#' die ausschließlich die angegebenen
#' EntryPoints enthält.
#'#' @param privilege_name Name des Original-Privileges
#'#' @param problematic_entrypoints Character-Vektor
#' mit den zu behaltenden EntryPoints
#'#' @param license_suffix Lizenzsuffix
#' z.B. SCM, FIN, TM
#'#' @param output_folder Zielordner
#'#' @param package_directory
#' D365FO PackagesLocalDirectory
#'#' @return Pfad der erzeugten XML-Datei
#'#' @export

  generate_privilege_license_variant <- function(
    privilege_name,
    problematic_entrypoints,
    license_suffix,output_folder,
    package_directory ="K:/AosService/PackagesLocalDirectory"){

    # =========================================
    #   ORIGINAL XML FINDEN
    # =========================================

      xml_file <- find_security_object_file(
        object_name = privilege_name,
        category = "Privilege",
        root_folder = package_directory)

    if(is.null(xml_file))  {
      stop(paste("Privilege nicht gefunden:",privilege_name))
      }

    # =========================================
    #   XML LADEN
    # =========================================

      xml_doc <- xml2::read_xml(xml_file[1]  )

    # =========================================
    #   ALLE NODES MIT NAME SUCHEN
    # =========================================

      name_nodes <- xml2::xml_find_all(xml_doc, ".//*[Name]")

    # =========================================
    #   ENTRYPOINTS FILTERN
    # =========================================

      for(node in name_nodes){

        name_node <- xml2::xml_find_first(node, "./Name")

        if(inherits(name_node, "xml_missing")){
          next
        }

        object_name <- xml2::xml_text(name_node)

        if(!object_name %in% problematic_entrypoints)    {
          xml2::xml_remove(node)
        }

      }

    # =========================================
    #   PRIVILEGE NAME ÄNDERN
    # =========================================

      privilege_name_node <-xml2::xml_find_first(xml_doc, "//Name[1]")

    xml2::xml_set_text(
      privilege_name_node,
      paste0(privilege_name,"_", license_suffix)
      )

    # =========================================
    #   SPEICHERORDNER
    # =========================================

      if(!dir.exists(output_folder)){
        dir.create(output_folder,recursive = TRUE)
        }

    # =========================================
    #   XML SPEICHERN
    # =========================================

      output_file <- file.path(output_folder,paste0( privilege_name,"_",license_suffix,".xml"))

    xml2::write_xml(xml_doc,output_file,options = "format")

    return(output_file)
  }
