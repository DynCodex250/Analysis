#' D365FO Security-Komponente auf Existenzebene vergleichen
#'
#' Vergleicht zwei D365FO Security-Komponenten und ermittelt,
#' welche Objekte hinzugefügt oder entfernt wurden.
#'
#' Die Funktion basiert auf einem zeilenweisen Vergleich
#' mittels `dplyr::anti_join()` und berücksichtigt
#' ausschließlich die Existenz von Datensätzen.
#'
#' Es werden keine Änderungen an Berechtigungen oder
#' Attributen erkannt. Die Funktion prüft lediglich,
#' ob Datensätze vorhanden oder nicht vorhanden sind.
#'
#' Typische Einsatzgebiete:
#' - EntryPoints vergleichen
#' - Form Controls vergleichen
#' - Form Data Sources vergleichen
#' - Data Entities vergleichen
#' - Direct Access Permissions vergleichen
#' - Form Control Overrides vergleichen
#'
#' Die Funktion dient als technische Grundlage für:
#' - compare_privileges_existence()
#' - compare_privileges_security()
#' - compare_privileges_risk_analysis()
#' - compare_privileges_release()
#'
#' @param component_a Erstes Security-Objekt als
#'        Data Frame oder Tibble.
#'
#' @param component_b Zweites Security-Objekt als
#'        Data Frame oder Tibble.
#'
#' @return Liste mit den Elementen:
#'
#' \describe{
#'   \item{Added}{
#'   Datensätze, die ausschließlich in
#'   `component_b` vorhanden sind.
#'   }
#'
#'   \item{Removed}{
#'   Datensätze, die ausschließlich in
#'   `component_a` vorhanden sind.
#'   }
#' }
#'
#' @details
#' Die Funktion behandelt auch leere Komponenten.
#'
#' Sind beide Komponenten leer, werden zwei leere
#' Tibbles zurückgegeben.
#'
#' Ist nur eine der Komponenten leer, werden alle
#' Datensätze der anderen Komponente als hinzugefügt
#' beziehungsweise entfernt betrachtet.
#'
#' Der Vergleich erfolgt anhand aller vorhandenen
#' Spalten der jeweiligen Komponente.
#'
#' @examples
#' component_a <- tibble::tibble(
#'   Name = c(
#'     "EntryPointA",
#'     "EntryPointB"
#'   )
#' )
#'
#' component_b <- tibble::tibble(
#'   Name = c(
#'     "EntryPointA",
#'     "EntryPointC"
#'   )
#' )
#'
#' result <- compare_component_existence(
#'   component_a,
#'   component_b
#' )
#'
#' result$Added
#'
#' result$Removed
#'
#' @seealso
#' compare_privileges_existence()
#' compare_privileges_security()
#' compare_privileges_risk_analysis()
#' compare_privileges_release()
#'
#' @export
compare_component_existence <- function(
    component_a,
    component_b
){

  # ================================
  # LEERE KOMPONENTEN BEHANDELN
  # ================================

  if(ncol(component_a) == 0 &&
     ncol(component_b) == 0){
    return(
      list(
        Added = tibble::tibble(),
        Removed = tibble::tibble()))
  }

  if(ncol(component_a) == 0 &&
     ncol(component_b) > 0){

    return(
      list(
        Added = component_b,
        Removed = tibble::tibble()))
  }

  if(ncol(component_b) == 0 &&
     ncol(component_a) > 0){

    return(
      list(
        Added = tibble::tibble(),
        Removed = component_a))
  }

  added <-
    dplyr::anti_join(
      component_b,
      component_a,
      by = names(component_b)
    )

  removed <-
    dplyr::anti_join(
      component_a,
      component_b,
      by = names(component_a)
    )

  list(
    Added = added,
    Removed = removed
  )

}
