#' Convert SQL export into a D365 security role
#'
#' Converts the result of a SQL query into a
#' structured D365 security role object.
#'
#' The function extracts all relevant role
#' information from a flattened SQL export and
#' transforms it into a structured list that can
#' be used for further analysis, comparison or
#' XML generation.
#'
#' The following information is extracted:
#'
#' \itemize{
#'   \item Role metadata
#'   \item Duties
#'   \item Privileges
#'   \item Subroles
#'   \item Direct Access Permissions
#' }
#'
#' Permission values are translated into the
#' corresponding security actions:
#'
#' \itemize{
#'   \item 1 = Allow
#'   \item 2 = Deny
#'   \item Other values = empty
#' }
#'
#' @param df A data frame containing the SQL
#'   export of a D365FO security role.
#'
#' @return A list containing the structured
#' security role information.
#'
#' The returned object contains:
#'
#' \itemize{
#'   \item role_name
#'   \item role_description
#'   \item role_label
#'   \item duties
#'   \item privileges
#'   \item subroles
#'   \item duty_count
#'   \item privilege_count
#'   \item subrole_count
#'   \item has_direct_access_permissions
#'   \item direct_access_permissions
#' }
#'
#' @details
#' The function expects a flattened SQL result
#' containing role metadata together with duties,
#' privileges, subroles and direct access
#' permissions.
#'
#' Duplicate identifiers are automatically
#' removed using \code{unique()}.
#'
#' Direct Access Permissions are normalized into
#' readable values ("Allow" / "Deny") to simplify
#' downstream processing and XML generation.
#'
#' @examples
#' \dontrun{
#'
#' role <-
#'   convert_sql_to_security_role(
#'     security_sql_export
#'   )
#'
#' role$role_name
#'
#' role$duties
#'
#' role$direct_access_permissions
#'
#' }
#'
#' @export
convert_sql_to_security_role <- function(df){
  role_name <- unique(df$ROLENAME)[1]
  role_description <- unique(df$ROLEIDENTIFIER)[1]
  role_label <- unique(df$ROLELABEL)[1]
  
  duties <-
    df |>
    dplyr::filter(
      DUTYIDENTIFIER != "",
      !is.na(DUTYIDENTIFIER)
    ) |>
    dplyr::pull(DUTYIDENTIFIER) |>
    unique()
  
  privileges <-
    df |>
    dplyr::filter(
      PRIVILEGEIDENTIFIER != "",
      !is.na(PRIVILEGEIDENTIFIER)
    ) |>
    dplyr::pull(PRIVILEGEIDENTIFIER) |>
    unique()
  
  subroles <-
    df |>
    dplyr::filter(
      SUBROLEIDENTIFIER != "",
      !is.na(SUBROLEIDENTIFIER)
    ) |>
    dplyr::pull(SUBROLEIDENTIFIER) |>
    unique()
  
  direct_access_permissions <-
    df |>
    dplyr::filter(
      ObjektTyp != "",
      !is.na(ObjektTyp)
    ) |>
    dplyr::select(
      ObjektTyp,
      Objektname,
      Ebene,
      Feldname,
      Create,
      Correct,
      Delete,
      Invoke,
      Read,
      Update
    ) |>
    dplyr::mutate(
      Create =
        ifelse(
          Create == 1,
          "Allow",
          ifelse(Create == 2, "Deny", "")
        ),
      Correct =
        ifelse(
          Correct == 1,
          "Allow",
          ifelse(Correct == 2, "Deny", "")
        ),
      Delete =
        ifelse(
          Delete == 1,
          "Allow",
          ifelse(Delete == 2, "Deny", "")
        ),
      Invoke =
        ifelse(
          Invoke == 1,
          "Allow",
          ifelse(Invoke == 2, "Deny", "")
        ),
      Read =
        ifelse(
          Read == 1,
          "Allow",
          ifelse(Read == 2, "Deny", "")
        ),
      Update =
        ifelse(
          Update == 1,
          "Allow",
          ifelse(Update == 2, "Deny", "")
        ),
      Feldname =
        ifelse(
          Feldname == "",
          "-",
          Feldname
        )
    )
  
  result <-
    list(
      role_name = role_name,
      role_description = role_description,
      role_label = role_label,
      duties = duties,
      privileges = privileges,
      subroles = subroles,
      duty_count = length(duties),
      privilege_count = length(privileges),
      subrole_count = length(subroles),
      has_direct_access_permissions = nrow(direct_access_permissions) > 0,
      direct_access_permissions = direct_access_permissions
    )
  
  return(result)
  
}