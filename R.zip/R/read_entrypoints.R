read_entrypoints <- function(doc){

  xml_find_all(doc,"//EntryPoints/*/Name") %>%

    xml_text()

}
