#' Lizenzauswirkungen einer D365FO Rolle analysieren
#'
#' Analysiert die Auswirkungen einer D365FO Security-Rolle auf
#' ein angegebenes Lizenzmodell.
#'
#' Die Funktion identifiziert EntryPoints, die durch die
#' angegebene Lizenz nicht abgedeckt werden, und ermittelt die
#' betroffenen Privileges und Duties innerhalb der Rolle.
#'
#' Die Analyse dient insbesondere zur:
#' - Lizenzoptimierung
#' - Lizenzvalidierung
#' - Security-Analyse
#' - Rollenbereinigung
#' - Vorbereitung von Lizenzmigrationen
#'
#' @param con Datenbankverbindung zu einer D365FO Datenbank.
#'
#' @param role_name Name der zu analysierenden Security-Rolle.
#'
#' @param target_license Ziel-Lizenzmodell, gegen das die Rolle
#'        geprüft werden soll.
#'
#' @return Liste mit den Analyseergebnissen.
#'
#' Enthaltene Elemente:
#'
#' \describe{
#'   \item{RoleInformation}{
#'   Stammdaten der analysierten Rolle.
#'   }
#'
#'   \item{NotEntitledEntryPoints}{
#'   EntryPoints, die nicht durch die Ziel-Lizenz
#'   abgedeckt werden.
#'   }
#'
#'   \item{PrivilegeMapping}{
#'   Zuordnung betroffener Privileges zu den
#'   identifizierten EntryPoints.
#'   }
#'
#'   \item{DutyMapping}{
#'   Zuordnung betroffener Duties zu den
#'   identifizierten Privileges.
#'   }
#'
#'   \item{LicenseImpactSummary}{
#'   Zusammenfassende Kennzahlen der Analyse.
#'   }
#' }
#'
#' @details
#' Die Analyse erfolgt in mehreren Schritten:
#'
#' 1. Ermittlung der Rolleninformationen
#' 2. Ermittlung nicht lizenzierter EntryPoints
#' 3. Zuordnung betroffener Privileges
#' 4. Zuordnung betroffener Duties
#' 5. Ergänzung von GUID-Kennzeichnungen
#' 6. Erstellung einer Zusammenfassung
#'
#' Die Funktion aggregiert die Ergebnisse der einzelnen
#' Analyseschritte in einem zentralen Ergebnisobjekt.
#'
#' @examples
#' result <- analyze_role_license_impact(
#'   con = con,
#'   role_name = "SystemAdministrator",
#'   target_license = "Activity"
#' )
#'
#' result$LicenseImpactSummary
#'
#' result$NotEntitledEntryPoints
#'
#' @seealso
#' get_role_information()
#' get_not_entitled_entrypoints()
#' get_privilege_mapping()
#' get_duty_mapping()
#' create_license_impact_summary()
#' add_guid_information()
#'
#' @export
analyze_role_license_impact <- function(
    con,
    role_name,
    target_license){

  # =========================================
  # ROLLE
  # =========================================

  role_info <- get_role_information(
    con,
    role_name
  )

  role_recid <- role_info$RECID[1]

  # =========================================
  # ENTRYPOINTS
  # =========================================

  not_entitled_entrypoints <-
    get_not_entitled_entrypoints(
      con,
      role_recid,
      target_license
    )

  # =========================================
  # PRIVILEGES
  # =========================================

  privilege_mapping <-
    get_privilege_mapping(
      con,
      role_name,
      not_entitled_entrypoints
    )

  # =========================================
  # DUTIES
  # =========================================

  duty_mapping <-
    get_duty_mapping(
      con,
      role_name,
      privilege_mapping
    )

  # =========================================
  # GUID INFORMATION
  # =========================================

  privilege_mapping <-
    add_guid_information(
      privilege_mapping
    )

  duty_mapping <-
    add_guid_information(
      duty_mapping
    )

  # =========================================
  # SUMMARY
  # =========================================

  summary <-
    create_license_impact_summary(
      not_entitled_entrypoints,
      privilege_mapping,
      duty_mapping
    )

  # =========================================
  # RESULT
  # =========================================

  result <- list(

    RoleInformation =
      role_info,

    NotEntitledEntryPoints =
      not_entitled_entrypoints,

    PrivilegeMapping =
      privilege_mapping,

    DutyMapping =
      duty_mapping,

    LicenseImpactSummary =
      summary
  )

  return(result)
}
