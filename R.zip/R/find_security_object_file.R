#' D365FO Sicherheitsobjekt finden
#'
#' Sucht rekursiv innerhalb des
#' `PackagesLocalDirectory` nach einer
#' Sicherheitsobjekt-XML-Datei.
#'
#' Unterstützte Kategorien:
#'
#' * `Role`
#' * `Duty`
#' * `Privilege`
#' * `DirectAccess`
#' * `Policy`
#'
#' @param object_name Technischer Name des Security-Objekts.
#' @param category Kategorie des Objekts.
#'   Zulässige Werte: `"Role"`, `"Duty"`,
#'   `"Privilege"`, `"DirectAccess"`, `"Policy"`.
#' @param root_folder D365FO Root-Verzeichnis.
#'   Standard: `"K:/AosService/PackagesLocalDirectory"`.
#'
#' @return Vollständiger Dateipfad als `character`,
#'   oder `NULL` wenn kein Treffer gefunden wurde.
#'   Bei mehreren Treffern wird eine Warnung ausgegeben
#'   und alle Treffer zurückgegeben.
#'
#' @details
#' Die Funktion filtert XML-Dateien anhand des
#' Verzeichnispfads und sucht dann nach einer Datei
#' mit dem Namen `<object_name>.xml`.
#'
#' Die Suche ist case-insensitive.
#'
#' Die Kategorie-Zuordnung:
#'
#' | Kategorie | Verzeichnismuster |
#' |---|---|
#' | `Role` | `SecurityRole` |
#' | `Duty` | `SecurityDuty` |
#' | `Privilege` | `SecurityPrivilege` |
#' | `DirectAccess` | `DirectAccessPermission` |
#' | `Policy` | `AxSecurityPolicy` |
#'
#' @seealso [analyze_security_object()], [parse_privilege()]
#'
#' @examples
#' \dontrun{
#' # Privilege finden
#' path <- find_security_object_file(
#'   "SalesOrderView",
#'   "Privilege"
#' )
#'
#' # Role finden
#' path <- find_security_object_file(
#'   "SystemAdministrator",
#'   "Role"
#' )
#' }
#'
#' @export
find_security_object_file <- function(
    object_name,
    category,
    root_folder = "K:/AosService/PackagesLocalDirectory") {

  # =========================================
  # KATEGORIE VALIDIEREN
  # =========================================

  valid_categories <- c(
    "Role",
    "Duty",
    "Privilege",
    "DirectAccess",
    "Policy"
  )

  if (!category %in% valid_categories) {
    stop(paste("Ungültige Kategorie:", category))
  }

  # Name der gesuchten XML-Datei
  target_file <- paste0(object_name, ".xml")

  # =========================================
  # KATEGORIE-ORDNER IDENTIFIZIEREN (Optimiert)
  # =========================================

  category_pattern <-
    switch(
      category,
      "Role"         = "SecurityRole",
      "Duty"         = "SecurityDuty",
      "Privilege"    = "SecurityPrivilege",
      "DirectAccess" = "DirectAccessPermission",
      "Policy"       = "AxSecurityPolicy"
    )

  # Schnellere Ordner-Suche: Nur in Ziel-Verzeichnissen scannen
  # 1. Pakete auflisten (1. Ebene)
  packages <- list.dirs(root_folder, recursive = FALSE, full.names = TRUE)
  
  # 2. Modelle auflisten (2. Ebene)
  models <- list.dirs(packages, recursive = FALSE, full.names = TRUE)
  
  # 3. Alle AOT-Ordner auflisten (3. Ebene) und nach Kategorie filtern
  all_subdirs <- list.dirs(models, recursive = FALSE, full.names = TRUE)
  target_dirs <- all_subdirs[grepl(category_pattern, basename(all_subdirs), ignore.case = TRUE)]
  
  # Fallback für flache Verzeichnisstrukturen (z. B. in lokalen Tests)
  if (length(target_dirs) == 0) {
    all_dirs <- list.dirs(root_folder, recursive = TRUE, full.names = TRUE)
    target_dirs <- all_dirs[grepl(category_pattern, basename(all_dirs), ignore.case = TRUE)]
  }

  # =========================================
  # NUR IN DIESEN ZIELORDNERN NACH XML SUCHEN
  # =========================================

  xml_files <-
    list.files(
      path       = target_dirs,
      pattern    = "\\.xml$",
      recursive  = FALSE,
      full.names = TRUE
    )

  # =========================================
  # DATEI SUCHEN
  # =========================================

  matching_files <-
    xml_files[
      tolower(basename(xml_files)) == tolower(target_file)
    ]

  # =========================================
  # ERGEBNIS
  # =========================================

  if (length(matching_files) == 0) {

    warning(paste("Objekt nicht gefunden:", object_name))
    return(NULL)
  }

  if (length(matching_files) > 1) {

    warning(paste("Mehrere Treffer gefunden:", object_name))
  }

  return(matching_files)
}

