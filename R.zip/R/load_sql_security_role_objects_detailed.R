#' Security-Rolle detailliert laden
#'
#' Lädt die vollständige Security-Struktur
#' einer Rolle aus UserSecGovRelatedObjects.
#'
#' Im Gegensatz zu
#' load_sql_security_role_objects()
#' werden keine Informationen
#' ausgeblendet.
#'
#' @param con DBI Connection.
#' @param role_identifier Role Identifier oder Role Name.
#'
#' @return Tibble.
#'
#' @export
load_sql_security_role_objects_detailed <- function(
    con,
    role_identifier
){
  
  sql <- glue::glue("

SELECT DISTINCT

    ROLEIDENTIFIER,

    ROLENAME AS ROLELABEL,

    ROLENAME,

    SUBROLEIDENTIFIER,

    DUTYIDENTIFIER,

    PRIVILEGEIDENTIFIER,

    CASE

        WHEN RESOURCETYPE = 'Table'
          OR RESOURCETYPE = 'Tabelle'
        THEN 'AxSecurityDataEntityReference'

        WHEN RESOURCETYPE = 'Table Field'
          OR RESOURCETYPE = 'Tabellenfeld'
        THEN 'AxSecurityDataEntityFieldReference'

        ELSE RESOURCETYPE

    END AS ObjektTyp,

    CASE

        WHEN CHARINDEX(
            '\\\\',
            RESOURCE_
        ) > 0

        THEN LEFT(

            RESOURCE_,

            CHARINDEX(
                '\\\\',
                RESOURCE_
            ) - 1

        )

        ELSE RESOURCE_

    END AS Objektname,

    CASE

        WHEN RESOURCETYPE = 'Table'
          OR RESOURCETYPE = 'Tabelle'
        THEN 'Entity'

        WHEN RESOURCETYPE = 'Table Field'
          OR RESOURCETYPE = 'Tabellenfeld'
        THEN 'Field'

        ELSE RESOURCETYPE

    END AS Ebene,

    CASE

        WHEN CHARINDEX(
            '\\\\',
            RESOURCE_
        ) > 0

        THEN SUBSTRING(

            RESOURCE_,

            CHARINDEX(
                '\\\\',
                RESOURCE_
            ) + 1,

            LEN(RESOURCE_)

        )

        ELSE ''

    END AS Feldname,

    RESOURCE_,

    RESOURCETYPE,

    CREATEACCESS  AS [Create],

    CORRECTACCESS AS [Correct],

    DELETEACCESS  AS [Delete],

    INVOKEACCESS  AS [Invoke],

    UPDATEACCESS  AS [Update],

    READACCESS    AS [Read]

FROM
    UserSecGovRelatedObjects

WHERE

       ROLEIDENTIFIER = '{role_identifier}'

    OR ROLENAME = '{role_identifier}'

ORDER BY

    ROLEIDENTIFIER,

    Objektname DESC

")
  
  result <-
    
    DBI::dbGetQuery(
      con,
      sql
    ) |>
    
    tibble::as_tibble()
  
  return(result)
  
}