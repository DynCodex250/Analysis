
#' Existenzänderungen für Release-Reports normalisieren#'#' Normalisiert die Ergebnisse einer#' D365FO Privilege-Existenzanalyse für die#' Verwendung in Release-Reports.#'#' Die Funktion verarbeitet die verschiedenen#' Security-Komponenten eines#' D365PrivilegeExistenceComparison-Objekts#' und überführt diese in ein einheitliches#' Berichtsformat.#'#' Die konkrete Darstellung der einzelnen#' Komponenten wird über die#' Report-Mapping-Konfiguration gesteuert.#'#' @param existence_comparison Objekt der Klasse#' D365PrivilegeExistenceComparison.#'#' @param change_type Typ der zu exportierenden#' Änderung.#'#' Erlaubte Werte:#'#' * "Added"#' * "Removed"#'#' @param report_mapping Report-Konfiguration aus#' load_report_mapping().#'#' @return Tibble mit den Spalten:#'#' * Component#' * Object#' * Details#'#' @details#' Die Funktion wird intern von#' prepare_privilege_release_report()#' verwendet.#'#' Die einzelnen Security-Komponenten werden#' über normalize_component_for_report()#' normalisiert.#'#' @seealso#' normalize_component_for_report()#'#' @examples#' mapping <-#'   load_report_mapping()#'#' added_objects <-#'   normalize_existence_objects(#'     existence_comparison,#'     "Added",#'     mapping#'   )#'#' @export

normalize_existence_objects <- function(existence_comparison,change_type,report_mapping){

  # ================================
  #   EINGABEPARAMETER VALIDIEREN
  # ================================

    if(!inherits(existence_comparison,"D365PrivilegeExistenceComparison")){stop("existence_comparison muss ein D365PrivilegeExistenceComparison sein.")}

  if(!change_type %in% c("Added","Removed")){stop("change_type muss 'Added' oder 'Removed' sein.")}

  if(!is.data.frame(report_mapping)){stop("report_mapping muss ein Data Frame sein.")}

  # ================================
  #   DATEN AUFBEREITEN
  # ================================

    result <- list()

    # ================================
    #   VERARBEITUNG DURCHFÜHREN
    # ================================

      for(component_name in names(existence_comparison)){

        component_data <-
          existence_comparison[[component_name]][[change_type]]

        if(nrow(component_data) == 0){
          next
        }

        result[[length(result) + 1]] <-

          normalize_component_for_report(

            component_name =
              component_name,

            component_data =
              component_data,

            report_mapping =
              report_mapping

          )

      }

    # ================================
    #   LEERES ERGEBNIS BEHANDELN
    # ================================

      if(length(result) == 0){

        return(

          tibble::tibble(

            Component =
              character(),

            Object =
              character(),

            Details =
              character()

          )

        )

      }

    # ================================
    #   ERGEBNIS ZURÜCKGEBEN
    # ================================

      return(dplyr::bind_rows(result))

}
