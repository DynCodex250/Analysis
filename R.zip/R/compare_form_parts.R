#' Compare form parts between two D365FO form documentations
#'
#' Compares the form parts of two
#' \code{D365FormDocumentation} objects.
#'
#' The function identifies newly added and
#' removed form parts by comparing the
#' logical structure of the form.
#'
#' @param old_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the original form documentation.
#'
#' @param new_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the updated form documentation.
#'
#' @return A list containing:
#' \describe{
#'   \item{Added}{
#'     Form parts that exist only in the new documentation.
#'   }
#'   \item{Removed}{
#'     Form parts that exist only in the old documentation.
#'   }
#' }
#'
#' @details
#' The function compares the
#' \code{Parts} tables of two
#' \code{D365FormDocumentation} objects.
#'
#' Form parts are uniquely identified
#' by their Name.
#'
#' Typical use cases:
#'
#' \itemize{
#'   \item Detect newly added form parts.
#'   \item Identify removed form parts after application updates.
#'   \item Compare customized forms between environments.
#'   \item Validate structural changes in embedded forms.
#' }
#'
#' @examples
#' \dontrun{
#'
#' comparison <-
#'   compare_form_parts(
#'     old_documentation,
#'     new_documentation
#'   )
#'
#' comparison$Added
#'
#' comparison$Removed
#'
#' }
#'
#' @export
compare_form_parts <- function(
    old_documentation,
    new_documentation
) {
  
  #===========================================================
  # VALIDATE INPUT PARAMETERS
  #===========================================================
  
  if (!inherits(
    old_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "old_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  if (!inherits(
    new_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "new_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  #===========================================================
  # LOAD PARTS
  #===========================================================
  
  old_parts <-
    old_documentation$Parts
  
  new_parts <-
    new_documentation$Parts
  
  #===========================================================
  # ADDED PARTS
  #===========================================================
  
  added <-
    
    dplyr::anti_join(
      new_parts,
      old_parts,
      by = "Name"
    )
  
  #===========================================================
  # REMOVED PARTS
  #===========================================================
  
  removed <-
    
    dplyr::anti_join(
      old_parts,
      new_parts,
      by = "Name"
    )
  
  #===========================================================
  # RESULT
  #===========================================================
  
  result <-
    
    list(
      Added = added,
      Removed = removed
    )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  return(result)
  
}