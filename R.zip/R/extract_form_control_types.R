#' Verteilung der Control-Typen ermitteln
#'
#' Ermittelt die Häufigkeit aller im Formular
#' verwendeten Control-Typen.
#'
#' Die Funktion dient zur Analyse der Formularstruktur
#' und hilft dabei, unterschiedliche Form-Patterns
#' (ListPage, Custom, TaskParentChild, usw.) zu erkennen.
#'
#' @param form_model Ergebnis von [analyze_form()].
#'
#' @return Tibble mit den Spalten:
#'
#' * `Type` — Control-Typ
#' * `Count` — Anzahl Controls dieses Typs
#'
#' Das Ergebnis ist absteigend nach `Count` sortiert.
#'
#' @details
#' Die Ausgabe dient als Grundlage für:
#'
#' * Architektur-Analysen
#' * Pattern-Erkennung
#' * Reverse Engineering
#' * Identifikation relevanter Control-Typen
#'
#' @seealso [analyze_form()], [extract_form_controls_by_type()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#' extract_form_control_types(form_model)
#' }
#'
#' @export
extract_form_control_types <- function(form_model) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # CONTROL-TYPEN ERMITTELN
  # ================================

  result <-
    form_model$Controls |>
    dplyr::filter(!is.na(Type)) |>
    dplyr::count(
      Type,
      name = "Count",
      sort = TRUE
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
