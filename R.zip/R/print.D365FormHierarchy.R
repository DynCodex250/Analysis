#' Print D365 form hierarchy
#'
#' Prints a complete
#' \code{D365FormHierarchy} as an ASCII tree.
#'
#' @param x A
#'   \code{D365FormHierarchy} object.
#'
#' @param ... Additional arguments passed to
#'   other print methods.
#'
#' @return Invisibly returns the supplied
#'   \code{D365FormHierarchy} object.
#'
#' @examples
#' \dontrun{
#'
#' hierarchy <-
#'   build_form_hierarchy(
#'     form_model
#'   )
#'
#' print(hierarchy)
#'
#' }
#'
#' @export
print.D365FormHierarchy <- function(
    x,
    ...){
  
  print_hierarchy_node(
    x
  )
  
  invisible(x)
}


#' Print hierarchy node
#'
#' Prints a single node of a
#' \code{D365FormHierarchy} including all of
#' its descendants.
#'
#' @param node A hierarchy node.
#'
#' @param prefix Character string used for
#'   indentation.
#'
#' @return Invisibly returns
#'   \code{NULL}.
#'
#' @keywords internal
print_hierarchy_node <- function(
    node,
    prefix = ""){
  
  if(is.null(node)){
    return(invisible(NULL))
  }
  
  cat(
    prefix,
    node$Name,
    " (",
    node$Type,
    ")\n",
    sep = ""
  )
  
  children <- node$Children
  
  if(length(children) == 0){
    return(invisible(NULL))
  }
  
  child_names <- names(children)
  
  for(i in seq_along(children)){
    
    child <- children[[i]]
    
    is_last <- i == length(children)
    
    branch <-
      if(is_last){
        "└─ "
      } else{
        "├─ "
      }
    
    child_prefix <-
      if(is_last){
        paste0(prefix,"   ")
      } else{
        paste0(prefix,"│  ")
      }
    
    cat(
      prefix,
      branch,
      child$Name,
      " (",
      child$Type,
      ")\n",
      sep = ""
    )
    
    print_hierarchy_children(
      child,
      child_prefix
    )
  }
  
  invisible(NULL)
}



#' Print hierarchy children
#'
#' Prints all child nodes of a hierarchy
#' recursively.
#'
#' @param node A hierarchy node.
#'
#' @param prefix Character string used for
#'   indentation.
#'
#' @return Invisibly returns
#'   \code{NULL}.
#'
#' @keywords internal
print_hierarchy_children <- function(
    node,
    prefix){
  
  children <- node$Children
  
  if(length(children) == 0){
    return(invisible(NULL))
  }
  
  for(i in seq_along(children)){
    
    child <- children[[i]]
    
    is_last <-
      i == length(children)
    
    branch <-
      if(is_last){
        "└─ "
      } else{
        "├─ "
      }
    
    cat(
      prefix,
      branch,
      child$Name,
      " (",
      child$Type,
      ")\n",
      sep = ""
    )
    
    next_prefix <-
      if(is_last){
        paste0(prefix,"   ")
      } else{
        paste0(prefix,"│  ")
      }
    
    print_hierarchy_children(
      child,
      next_prefix
    )
  }
  
  invisible(NULL)
}