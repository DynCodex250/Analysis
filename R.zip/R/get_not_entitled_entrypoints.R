get_not_entitled_entrypoints <- function(con,role_recid,target_license){

  sql <- glue::glue(
    "
SELECT
    AOTNAME,
    AOTCHILDNAME,
    ACCESSLEVEL,
    SKUNAME,
    ENTITLED,
    NOTENTITLED,
    GROUPNAME
FROM LICENSINGROLEREQUIREMENTSDETAILEDVIEW
WHERE SECURITYROLE = '{role_recid}'
    AND SKUNAME = '{target_license}'
    AND NOTENTITLED > 0
ORDER BY
    NOTENTITLED DESC,
    AOTNAME ASC
")

  result <- odbc::dbGetQuery(con,sql)

  return(result)
}
