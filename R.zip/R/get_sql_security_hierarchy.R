#' D365FO Sicherheits-Hierarchie abfragen
#'
#' Ruft die Sicherheits-Hierarchie (Rollen, Unterrollen, Duties, Privileges und
#' Ressourcen) aus der Tabelle/View `UserSecGovRelatedObjects` ab.
#'
#' @param con Ein gültiges Datenbankverbindungsobjekt (DBI connection).
#'
#' @param resources Optionaler Vektor von Ressourcen-Namen zur Filterung.
#'
#' @param role_identifiers Optionaler Vektor von Rollen-Identifikatoren zur Filterung.
#'
#' @param subrole_identifiers Optionaler Vektor von Unterrollen-Identifikatoren zur Filterung.
#'
#' @param duty_identifiers Optionaler Vektor von Duty-Identifikatoren zur Filterung.
#'
#' @param privilege_identifiers Optionaler Vektor von Privilege-Identifikatoren zur Filterung.
#'
#' @return Ein Data Frame mit den Spalten der Sicherheits-Hierarchie.
#'
#' @export
get_sql_security_hierarchy <- function(
    con,
    resources = character(),
    role_identifiers = character(),
    subrole_identifiers = character(),
    duty_identifiers = character(),
    privilege_identifiers = character()) {

  # =========================================
  # BASIS-ABFRAGE
  # =========================================

  query <- "SELECT DISTINCT
    USGRO.ROLEIDENTIFIER,
    USGRO.ROLENAME,
    USGRO.SUBROLEIDENTIFIER,
    USGRO.SUBROLENAME,
    USGRO.DUTYIDENTIFIER,
    USGRO.DUTYNAME,
    USGRO.PRIVILEGEIDENTIFIER,
    USGRO.PRIVILEGENAME,
    USGRO.RESOURCE_
  FROM UserSecGovRelatedObjects USGRO
  WHERE USGRO.RESOURCETYPE LIKE '%menu item%'"

  # =========================================
  # INTERNE FILTER-FUNKTION
  # =========================================

  add_in_filter <- function(query, column, values) {
    if (length(values) == 0) {
      return(query)
    }

    value_list <- paste0(
      "'", gsub("'", "''", values), "'",
      collapse = ","
    )

    paste0(
      query,
      "\nAND ", column, " IN (", value_list, ")"
    )
  }

  # =========================================
  # FILTER ANWENDEN
  # =========================================

  query <- add_in_filter(
    query,
    "USGRO.RESOURCE_",
    resources
  )

  query <- add_in_filter(
    query,
    "USGRO.ROLEIDENTIFIER",
    role_identifiers
  )

  query <- add_in_filter(
    query,
    "USGRO.SUBROLEIDENTIFIER",
    subrole_identifiers
  )

  query <- add_in_filter(
    query,
    "USGRO.DUTYIDENTIFIER",
    duty_identifiers
  )

  query <- add_in_filter(
    query,
    "USGRO.PRIVILEGEIDENTIFIER",
    privilege_identifiers
  )

  # =========================================
  # ABFRAGE AUSFÜHREN
  # =========================================

  return(DBI::dbGetQuery(con, query))
}
