#' Formular-Buttons extrahieren (V0)
#'
#' Ältere Version von [extract_form_buttons()].
#'
#' Extrahiert alle Button-Controls eines D365FO Formulars.
#'
#' Die Funktion analysiert sowohl klassische Buttons
#' als auch Menü-basierte Buttons.
#'
#' Unterstützte Typen:
#'
#' * `Button`
#' * `MenuFunctionButton`
#' * `MenuButton`
#' * `DropDialogButton`
#'
#' Die Funktion dient als Grundlage für:
#'
#' * Formular-Dokumentationen
#' * Release-Vergleiche
#' * Berechtigungsanalysen
#' * Feature-Erkennung
#'
#' @param form_model Ergebnis von [analyze_form()].
#'
#' @return Tibble mit den Spalten:
#'
#' * `ButtonType` — Typ des Buttons
#' * `Name` — Technischer Name des Controls
#' * `MenuItemName` — Referenziertes MenuItem
#' * `NeededPermission` — Mindestberechtigung für den Button
#' * `Parent` — Übergeordnetes Control
#' * `Path` — Vollständiger Pfad im Formular
#'
#' @note Gegenüber [extract_form_buttons()] fehlen die Spalten
#' `MenuItemType` und `Label`.
#'
#' @seealso [extract_form_buttons()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#' buttons <- extract_form_buttons_V0(form_model)
#' }
#'
#' @export
extract_form_buttons_V0 <- function(form_model) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # BUTTONS FILTERN
  # ================================

  buttons <-
    form_model$Controls |>
    dplyr::filter(
      Type %in% c(
        "Button",
        "MenuFunctionButton",
        "MenuButton",
        "DropDialogButton"
      )
    )

  # ================================
  # LEERES MODELL
  # ================================

  if (nrow(buttons) == 0) {
    return(empty_form_buttons())
  }

  # ================================
  # FACHMODELL ERSTELLEN
  # ================================

  result <-
    purrr::pmap_dfr(
      list(
        buttons$Name,
        buttons$Type,
        buttons$Parent,
        buttons$Path,
        buttons$Properties
      ),
      function(Name, Type, Parent, Path, Properties) {

        tibble::tibble(
          ButtonType       = Type,
          Name             = Name,
          MenuItemName     = get_property(Properties, "MenuItemName"),
          NeededPermission = get_property(Properties, "NeededPermission"),
          Parent           = Parent,
          Path             = Path
        )
      }
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
