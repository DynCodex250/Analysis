#' Create report metadata
#'
#' Creates the metadata section for a
#' privilege release report.
#'
#' The function extracts the relevant
#' information from a privilege release
#' comparison and converts it into a
#' standardized metadata table.
#'
#' @param release_comparison A
#'   \code{D365PrivilegeReleaseComparison}
#'   object returned by
#'   \code{compare_privileges_release()}.
#'
#' @return A tibble containing report
#' metadata.
#'
#' The returned table contains the
#' following properties:
#'
#' \itemize{
#'   \item Source Privilege
#'   \item Source Description
#'   \item Source Label
#'   \item Target Privilege
#'   \item Target Description
#'   \item Target Label
#'   \item Generated At
#' }
#'
#' @details
#' The metadata section provides the
#' contextual information for the generated
#' release report.
#'
#' If no metadata is available, an empty
#' tibble with the columns
#' \code{Property} and \code{Value} is
#' returned.
#'
#' The generation timestamp is created
#' dynamically using the current system
#' time.
#'
#' @examples
#' \dontrun{
#'
#' metadata <-
#'   create_report_metadata(
#'     release_comparison
#'   )
#'
#' metadata
#'
#' }
#'
#' @keywords internal
create_report_metadata <- function(
    release_comparison
){
  
  #===========================================================
  # NO METADATA AVAILABLE
  #===========================================================
  
  if (is.null(release_comparison$Metadata)) {
    
    return(
      
      tibble::tibble(
        
        Property = character(),
        
        Value = character()
        
      )
      
    )
    
  }
  
  #===========================================================
  # READ METADATA
  #===========================================================
  
  source_privilege <-
    
    release_comparison$Metadata$SourcePrivilege
  
  target_privilege <-
    
    release_comparison$Metadata$TargetPrivilege
  
  #===========================================================
  # CREATE REPORT METADATA
  #===========================================================
  
  result <-
    
    tibble::tibble(
      
      Property = c(
        
        "Source Privilege",
        
        "Source Description",
        
        "Source Label",
        
        "Target Privilege",
        
        "Target Description",
        
        "Target Label",
        
        "Generated At"
        
      ),
      
      Value = c(
        
        source_privilege$Name[[1]],
        
        source_privilege$Description[[1]],
        
        source_privilege$Label[[1]],
        
        target_privilege$Name[[1]],
        
        target_privilege$Description[[1]],
        
        target_privilege$Label[[1]],
        
        as.character(Sys.time())
        
      )
      
    )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  return(result)
  
}