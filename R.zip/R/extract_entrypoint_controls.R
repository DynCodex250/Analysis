#' EntryPoint-Control-Berechtigungen extrahieren
#'
#' Extrahiert alle Control-Berechtigungen innerhalb
#' von EntryPoint-Formularen.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit allen Form-Control-Berechtigungen.
#'
#' @details
#' Die Funktion liest sämtliche Controls innerhalb
#' der EntryPoint-Forms aus.
#'
#' Leere Ergebnisse werden als Tibble mit definierter
#' Struktur zurückgegeben.
#'
#' @seealso
#' parse_privilege()
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#'
#' controls <-
#'   extract_entrypoint_controls(
#'     xml_doc
#'   )
#' }
#'
#' @export
extract_entrypoint_controls <- function(xml_doc) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # =========================================
  # CONTROLS EXTRAHIEREN
  # =========================================

  control_nodes <- xml2::xml_find_all(
    xml_doc,
    "//EntryPoints//Forms//Controls/*"
  )

  result <- purrr::map_dfr(control_nodes, function(control_node) {

    form_node <- xml2::xml_parent(
      xml2::xml_parent(control_node)
    )

    entrypoint_node <- xml2::xml_parent(
      xml2::xml_parent(form_node)
    )

    grant_node <- xml2::xml_find_first(
      control_node,
      "./Grant"
    )

    tibble::tibble(
      EntryPointName = xml2::xml_text(
        xml2::xml_find_first(entrypoint_node, "./Name")
      ),

      FormName = xml2::xml_text(
        xml2::xml_find_first(form_node, "./Name")
      ),

      ControlName = xml2::xml_text(
        xml2::xml_find_first(control_node, "./Name")
      ),

      Read = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Read")
      ),

      Create = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Create")
      ),

      Update = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Update")
      ),

      Delete = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Delete")
      ),

      Correct = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Correct")
      ),

      Invoke = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Invoke")
      )
    )
  })

  # =========================================
  # LEERE STRUKTUR ABSICHERN
  # =========================================

  if (ncol(result) == 0) {
    result <- empty_entrypoint_controls()
  }

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}
