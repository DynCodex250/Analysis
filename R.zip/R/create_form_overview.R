#' Create a business overview of a D365FO form
#'
#' Creates a consolidated overview of the
#' analysis results of a
#' \code{D365FormModel}.
#'
#' The function aggregates the most important
#' information about a form into a single object
#' that can be used for documentation, reporting
#' and reverse engineering.
#'
#' The overview currently contains:
#'
#' \itemize{
#'   \item Metadata
#'   \item Grid DataSources
#'   \item DataSource Relations
#'   \item Reference Group Relations
#'   \item Action Pane Buttons
#' }
#'
#' @param form_model A
#'   \code{D365FormModel} object returned by
#'   \code{analyze_form()}.
#'
#' @return An object of class
#' \code{D365FormOverview}.
#'
#' The returned object contains:
#'
#' \itemize{
#'   \item Metadata
#'   \item Grids
#'   \item DataSources
#'   \item ReferenceGroups
#'   \item ActionPaneButtons
#' }
#'
#' @details
#' This function serves as the central business
#' overview for a completely analyzed D365FO
#' form.
#'
#' It internally calls several specialized
#' extraction functions and combines their
#' results into a single object.
#'
#' The generated overview is intended as the
#' foundation for reports, technical
#' documentation and security analyses.
#'
#' @examples
#' \dontrun{
#'
#' overview <-
#'   create_form_overview(
#'     form_model
#'   )
#'
#' overview$Metadata
#'
#' overview$Grids
#'
#' overview$DataSources
#'
#' overview$ReferenceGroups
#'
#' overview$ActionPaneButtons
#'
#' }
#'
#' @export
create_form_overview <- function(
    form_model
){
  
  #===========================================================
  # VALIDATE INPUT PARAMETERS
  #===========================================================
  
  if (!inherits(
    form_model,
    "D365FormModel"
  )) {
    
    stop(
      "form_model must be a D365FormModel object."
    )
    
  }
  
  #===========================================================
  # CREATE OVERVIEW
  #===========================================================
  
  result <-
    
    list(
      
      Metadata =
        form_model$Metadata,
      
      Grids =
        extract_form_grid_datasources(
          form_model
        ),
      
      DataSources =
        extract_form_datasource_relations(
          form_model
        ),
      
      ReferenceGroups =
        extract_form_reference_group_relations(
          form_model
        ),
      
      ActionPaneButtons =
        extract_form_action_pane_buttons(
          form_model
        )
      
    )
  
  #===========================================================
  # ASSIGN CLASS
  #===========================================================
  
  class(result) <-
    
    c(
      "D365FormOverview",
      class(result)
    )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  return(result)
  
}