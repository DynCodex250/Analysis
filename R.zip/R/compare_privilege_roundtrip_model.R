#' D365FO Privilege-Modelle auf Gesamtebene vergleichen
#'
#' Vergleicht zwei D365FO Privilege-XML-Dateien auf Ebene
#' des vollständigen D365Privilege-Modells.
#'
#' Beide XML-Dateien werden zunächst mit
#' `parse_privilege()` eingelesen und anschließend als
#' vollständige D365Privilege-Objekte mittels
#' `all.equal()` verglichen.
#'
#' Die Funktion eignet sich insbesondere zur Validierung
#' von XML-Roundtrips und Modelltransformationen.
#'
#' Typischer Ablauf:
#'
#' Original XML
#' -> parse_privilege()
#' -> generate_privilege_xml()
#' -> parse_privilege()
#' -> compare_privilege_roundtrip_model()
#'
#' Im Gegensatz zu
#' `compare_privilege_roundtrip_components()`
#' erfolgt hier kein komponentenweiser Vergleich,
#' sondern ein Vergleich des vollständigen
#' D365Privilege-Modells.
#'
#' Typische Anwendungsfälle:
#' - Roundtrip-Tests
#' - Regressionstests
#' - XML-Generator-Validierung
#' - Refactoring-Tests
#' - Qualitätsprüfungen
#'
#' @param original_xml Vollständiger Pfad zur
#'        Original-XML-Datei.
#'
#' @param generated_xml Vollständiger Pfad zur
#'        generierten XML-Datei.
#'
#' @return Ergebnis von `all.equal()`.
#'
#' Bei identischen Modellen wird typischerweise
#' `TRUE` zurückgegeben.
#'
#' Bei Unterschieden liefert `all.equal()`
#' eine Beschreibung der gefundenen Abweichungen.
#'
#' @details
#' Die Funktion validiert nicht die XML-Struktur,
#' sondern die fachliche Gleichheit der erzeugten
#' D365Privilege-Modelle.
#'
#' Dadurch können Unterschiede erkannt werden,
#' die nach dem Parsen der XML-Dateien bestehen
#' bleiben.
#'
#' Die Funktion eignet sich insbesondere als
#' automatisierter Test für Reverse-Engineering-
#' und XML-Generator-Funktionen.
#'
#' Für die Analyse einzelner Komponenten sollte
#' `compare_privilege_roundtrip_components()`
#' verwendet werden.
#'
#' Für den direkten Vergleich der XML-Dateien
#' eignet sich
#' `compare_xml_structure_notepad()`.
#'
#' @seealso
#' parse_privilege()
#' compare_privilege_roundtrip_components()
#' compare_xml_structure_notepad()
#'
#' @examples
#' compare_privilege_roundtrip_model(
#'   original_xml = "Original.xml",
#'   generated_xml = "Roundtrip.xml"
#' )
#'
#' @export
compare_privilege_roundtrip_model <- function(
    original_xml,
    generated_xml
) {

  # =====================================
  # XML-DATEIEN EINLESEN
  # =====================================

  original_model <- parse_privilege(
    original_xml
  )

  generated_model <- parse_privilege(
    generated_xml
  )

  # =====================================
  # GESAMTMODELL VERGLEICHEN
  # =====================================

  result <- all.equal(

    original_model,

    generated_model

  )

  # =====================================
  # ERGEBNIS ZURÜCKGEBEN
  # =====================================

  return(result)

}
