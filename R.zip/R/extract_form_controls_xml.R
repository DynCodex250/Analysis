#' Form-Controls extrahieren
#'
#' Extrahiert alle Controls eines D365FO Formulars
#' inklusive Hierarchieinformationen aus dem XML-Dokument.
#'
#' Die Funktion traversiert den gesamten Control-Baum
#' des Formulars und gibt eine flache Tibble-Struktur zurück.
#'
#' @param xml_doc XML-Dokument eines D365FO Formulars.
#'
#' @return Tibble mit den Spalten:
#'
#' * `Name` — Technischer Name des Controls
#' * `Type` — Control-Typ
#' * `Parent` — Name des übergeordneten Controls
#' * `Level` — Hierarchietiefe
#' * `Path` — Vollständiger Pfad im Formular
#' * `Properties` — Listen-Spalte mit Control-Properties
#'
#' @details
#' Die Funktion ruft intern
#' [extract_form_control_hierarchy_xml()] auf,
#' um die Hierarchie rekursiv aufzubauen.
#'
#' @seealso [analyze_form()],
#'   [extract_form_control_hierarchy_xml()]
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#' controls <- extract_form_controls_xml(xml_doc)
#' }
#'
#' @export
extract_form_controls_xml <- function(xml_doc) {

  # ================================
  # ROOT CONTROLS ERMITTELN
  # ================================

  root_controls <-
    xml2::xml_find_all(
      xml_doc,
      ".//[local-name()='Design']/[local-name()='Controls']/*[local-name()='AxFormControl']"
    )

  # ================================
  # CONTROLS AUSLESEN
  # ================================

  result <- list()

  for (control_node in root_controls) {

    result <-
      c(
        result,
        extract_form_control_hierarchy_xml(
          control_node = control_node
        )
      )
  }

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(dplyr::bind_rows(result))
}
