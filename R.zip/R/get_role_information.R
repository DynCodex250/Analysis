get_role_information <- function(con, role_name){

  sql <-  glue::glue(
    "SELECT TOP 1
        RECID,
        NAME,
        AOTNAME
    FROM SECURITYROLE
    WHERE AOTNAME LIKE '{role_name}'
    OR NAME LIKE '{role_name}'")

  result <- odbc::dbGetQuery(
    con,
    sql
    )

  return(result)

  }

