#' Privilege Roundtrip validieren
#'
#' Führt einen vollständigen Roundtrip-Test für ein D365FO
#' Privilege durch.
#'
#' Die Funktion liest die Original-XML ein, erzeugt daraus
#' mittels `generate_privilege_xml()` eine neue XML-Datei
#' und vergleicht anschließend die geparsten Modelle.
#'
#' Der Test gilt als erfolgreich, wenn beide Modelle
#' vollständig identisch sind.
#'
#' @param xml_file Pfad zur zu prüfenden Privilege XML-Datei
#'
#' @return TRUE bei erfolgreichem Roundtrip,
#' ansonsten FALSE
#'
#' @export
validate_privilege_roundtrip <- function(xml_file) {

  # Temporäre XML-Datei erzeugen
  temp_xml <- tempfile(
    fileext = ".xml"
  )

  # Originalmodell erzeugen
  original_model <- parse_privilege(
    xml_file
  )

  # Modell wieder als XML schreiben
  generate_privilege_xml(
    privilege_model = original_model,
    output_file = temp_xml
  )

  # Generierte XML erneut einlesen
  roundtrip_model <- parse_privilege(
    temp_xml
  )

  # Modelle vergleichen
  isTRUE(
    all.equal(
      original_model,
      roundtrip_model
    )
  )
}
