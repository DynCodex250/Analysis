
#' Lädt die Inhalte der Tabelle 
#' UserSecGovRelatedObjects. 
#' 
#' Die Daten werden später für die 
#' Verknüpfung von Formularen, 
#' MenuItems und Privileges verwendet. 
#' 
#' @param connection DBI Connection. 
#' 
#' @return Tibble. 
#' 
#' @examples 
#' user_sec_gov_related_objects <- 
#' load_sql_security_duty_privilege_association( 
#' connection 
#' ) 
#' 
#' @export 

load_sql_security_duty_privilege_association <- 
  function( connection){ 
    # ================================ 
    # SQL 
    # ================================ 
    sql <- "	
	SELECT DISTINCT 
	USGRO.DUTYIDENTIFIER, 
	USGRO.DUTYNAME, 
	USGRO.PRIVILEGEIDENTIFIER,
	USGRO.PRIVILEGENAME,
	USGRO.RESOURCETYPE,
	USGRO.RESOURCE_
	FROM UserSecGovRelatedObjects USGRO 
	WHERE 
		(
		USGRO.DUTYIDENTIFIER != ''  
		AND
		USGRO.PRIVILEGEIDENTIFIER != '' 
		)"
    
    # ================================
    #   AUSFÜHREN
    # ================================
    
    result <-
      
      DBI::dbGetQuery(
        cnn,
        sql
      )
    
    # ================================
    #   TIBBLE
    # ================================
    
    result <-
      tibble::as_tibble(
        result
      )
    
    return(result)
    
  }
