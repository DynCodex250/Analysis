#' Create a release overview
#'
#' Creates a summarized overview of all
#' changes per security component.
#'
#' The function aggregates the results of a
#' \code{D365PrivilegeExistenceComparison}
#' and calculates the number of added,
#' removed and total changed objects for
#' each security component.
#'
#' @param existence_comparison A
#'   \code{D365PrivilegeExistenceComparison}
#'   object returned by
#'   \code{compare_privileges_existence()}.
#'
#' @return A tibble with one row per
#' security component.
#'
#' The returned table contains:
#'
#' \itemize{
#'   \item Component
#'   \item Added
#'   \item Removed
#'   \item TotalChanges
#' }
#'
#' @details
#' This function creates the business
#' release overview used in privilege
#' release reports.
#'
#' Each component contained in the
#' comparison object is evaluated
#' individually.
#'
#' The number of added and removed
#' objects is determined and combined
#' into a single summary table.
#'
#' The overview can be used for:
#'
#' \itemize{
#'   \item Release documentation
#'   \item Change reports
#'   \item Impact analysis
#'   \item Management summaries
#' }
#'
#' @seealso
#' \code{\link{compare_privileges_existence}}
#'
#' @seealso
#' \code{\link{prepare_privilege_release_report}}
#'
#' @examples
#' \dontrun{
#'
#' release_overview <-
#'   create_release_overview(
#'     existence_comparison
#'   )
#'
#' release_overview
#'
#' }
#'
#' @export
create_release_overview <- function(
    existence_comparison
){
  
  #===========================================================
  # VALIDATE INPUT PARAMETERS
  #===========================================================
  
  if (!inherits(
    existence_comparison,
    "D365PrivilegeExistenceComparison"
  )) {
    
    stop(
      paste(
        "existence_comparison must be a",
        "D365PrivilegeExistenceComparison object."
      )
    )
    
  }
  
  #===========================================================
  # CREATE RELEASE OVERVIEW
  #===========================================================
  
  result <-
    
    purrr::imap_dfr(
      
      existence_comparison,
      
      function(
    component_result,
    component_name
      ) {
        
        added_count <-
          nrow(component_result$Added)
        
        removed_count <-
          nrow(component_result$Removed)
        
        tibble::tibble(
          
          Component = component_name,
          
          Added = added_count,
          
          Removed = removed_count,
          
          TotalChanges =
            added_count +
            removed_count
          
        )
        
      }
    
    )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  return(result)
  
}