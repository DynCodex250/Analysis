read_role_metadata <- function(doc){

  tibble(

    RoleName =
      xml_text(
        xml_find_first(
          doc,
          "//Name"
        )
      ),

    RoleLabel =
      xml_text(
        xml_find_first(
          doc,
          "//Label"
        )
      )

  ) %>%

    mutate(
      IsGUID =
        is_guid_name(RoleName)
    )
}
