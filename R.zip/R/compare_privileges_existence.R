#' D365FO Privileges auf Existenzebene vergleichen
#'
#' Vergleicht zwei D365FO Privilege-Modelle und ermittelt,
#' welche Security-Komponenten hinzugefügt oder entfernt
#' wurden.
#'
#' Die Funktion betrachtet ausschließlich die Existenz von
#' Security-Objekten.
#'
#' Änderungen an Berechtigungen wie:
#'
#' - Read
#' - Create
#' - Update
#' - Delete
#' - Correct
#' - Invoke
#'
#' werden nicht berücksichtigt.
#'
#' Verglichene Komponenten:
#'
#' - EntryPoints
#' - EntryPointForms
#' - EntryPointControls
#' - EntryPointFormDataSources
#' - DataEntityPermissions
#' - DataEntityMethods
#' - DirectAccessPermissions
#' - DirectAccessFields
#' - FormControlOverrides
#'
#' Die Funktion stellt die erste Stufe eines vollständigen
#' Privilege-Vergleichs dar und dient als Grundlage für:
#'
#' - compare_privileges_security()
#' - compare_privileges_risk_analysis()
#' - compare_privileges_release()
#'
#' @param privilege_a Erstes D365FO Privilege-Modell.
#'        Typischerweise das Referenzmodell.
#'
#' @param privilege_b Zweites D365FO Privilege-Modell.
#'        Typischerweise das Zielmodell.
#'
#' @return Liste der Klasse
#'         `D365PrivilegeExistenceComparison`.
#'
#' Jede Komponente enthält:
#'
#' \describe{
#'   \item{Added}{
#'   Security-Objekte, die ausschließlich
#'   in `privilege_b` vorhanden sind.
#'   }
#'
#'   \item{Removed}{
#'   Security-Objekte, die ausschließlich
#'   in `privilege_a` vorhanden sind.
#'   }
#' }
#'
#' Enthaltene Komponenten:
#'
#' \describe{
#'   \item{EntryPoints}{
#'   Vergleich der EntryPoints.
#'   }
#'
#'   \item{EntryPointForms}{
#'   Vergleich der Formularreferenzen.
#'   }
#'
#'   \item{EntryPointControls}{
#'   Vergleich der Form Controls.
#'   }
#'
#'   \item{EntryPointFormDataSources}{
#'   Vergleich der Form Data Sources.
#'   }
#'
#'   \item{DataEntityPermissions}{
#'   Vergleich der Data Entity Permissions.
#'   }
#'
#'   \item{DataEntityMethods}{
#'   Vergleich der Data Entity Methods.
#'   }
#'
#'   \item{DirectAccessPermissions}{
#'   Vergleich der Direct Access Permissions.
#'   }
#'
#'   \item{DirectAccessFields}{
#'   Vergleich der Direct Access Fields.
#'   }
#'
#'   \item{FormControlOverrides}{
#'   Vergleich der Form Control Overrides.
#'   }
#' }
#'
#' @details
#' Die Funktion führt einen strukturellen Vergleich
#' der einzelnen Security-Komponenten durch.
#'
#' Für jede Komponente werden ausschließlich
#' hinzugefügte und entfernte Objekte ermittelt.
#'
#' Änderungen an Berechtigungen innerhalb
#' identischer Objekte werden nicht analysiert.
#'
#' Für Berechtigungsvergleiche sollte
#' `compare_privileges_security()`
#' verwendet werden.
#'
#' Die Funktion eignet sich insbesondere für:
#'
#' - Release-Vergleiche
#' - Security-Reviews
#' - Regressionstests
#' - Dokumentationen
#' - Reverse Engineering
#'
#' @seealso
#' compare_component_existence()
#' compare_privileges_security()
#' compare_privileges_risk_analysis()
#' compare_privileges_release()
#'
#' @examples
#'
#' privilege_a <- parse_privilege(
#'   "Privilege_A.xml"
#' )
#'
#' privilege_b <- parse_privilege(
#'   "Privilege_B.xml"
#' )
#'
#' result <- compare_privileges_existence(
#'   privilege_a,
#'   privilege_b
#' )
#'
#' result$EntryPoints$Added
#'
#' result$EntryPoints$Removed
#'
#' result$EntryPointControls$Added
#'
#' result$EntryPointControls$Removed
#'
#' @export
compare_privileges_existence <- function(
    privilege_a,
    privilege_b
){

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if(!inherits(privilege_a, "D365Privilege")){

    stop("privilege_a muss ein D365Privilege sein.")

  }

  if(!inherits(privilege_b, "D365Privilege")){

    stop("privilege_b muss ein D365Privilege sein.")
  }

  # ================================
  # KOMPONENTEN DEFINIEREN
  # ================================

  components <- c(
    "EntryPoints",
    "EntryPointForms",
    "EntryPointControls",
    "EntryPointFormDataSources",
    "DataEntityPermissions",
    "DataEntityMethods",
    "DirectAccessPermissions",
    "DirectAccessFields",
    "FormControlOverrides"
  )

  # ================================
  # KOMPONENTEN VERGLEICHEN
  # ================================

  result <-
    purrr::map(
      components,

      function(component){
        compare_component_existence(
          privilege_a[[component]],
          privilege_b[[component]]
        )
      }
    )

  names(result) <- components

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  class(result) <-
    c(
      "D365PrivilegeExistenceComparison",
      "list"
    )

  return(result)

}
