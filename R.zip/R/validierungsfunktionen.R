# =========================================================================
# Validierungsfunktionen
# =========================================================================
# This file contains the data validation and helper functions for the package.
# =========================================================================

#' Datenbankverbindung aufbauen
#'
#' Baut eine Verbindung zur SQL-Datenbank anhand einer Excel-Credential-Datei auf.
#'
#' @param cred_path Pfad zur Credential-Datei (Excel-Format).
#'
#' @return Ein DBI-Verbindungsobjekt (Conn).
#' @export
getDatabaseConnection <- function(cred_path)
{
  credentials <- readxl::read_excel(
    cred_path,
    sheet = "Connection",
    col_types = "text"
  )
  
  server <- credentials |>
    dplyr::filter(key == "server") |>
    dplyr::pull(value)
  
  database <- credentials |>
    dplyr::filter(key == "database") |>
    dplyr::pull(value)
  
  uid <- credentials |>
    dplyr::filter(key == "uid") |>
    dplyr::pull(value)
  
  pwd <- credentials |>
    dplyr::filter(key == "pwd") |>
    dplyr::pull(value)
  
  Conn <- DBI::dbConnect(
    drv = odbc::odbc(),
    Driver = "SQL Server",
    server = server,
    database = database,
    uid = uid,
    pwd = pwd,
    Encrypt = "yes",
    TrustServerCertificate = "no"
  )
  
  return(Conn)
}

#' Breite Tabelle in lange Tabelle transformieren (Entwurf)
#'
#' Konvertiert ein breites Data Frame in ein langes Data Frame mit Entity und Clause.
#'
#' @param df_wide Die breite Tabelle (Data Frame).
#'
#' @return Ein tibble mit Entity und Clause.
#' @export
transform_wide_to_long <- function(df_wide)
{
  result <- tibble(
    Entity = entities,
    Clause = clauses
  )
  
  return(result)
}

#' Datenvalidierung gegen Referenztabellen
#'
#' Validiert Quelldaten gegen eine Referenzdatenbank anhand einer Konfigurationstabelle.
#'
#' @param p_SQLAzureConn Ein DBI-Verbindungsobjekt zur SQL-Datenbank.
#' @param p_source_df Ein Data Frame mit den Quelldaten.
#' @param p_config_df Ein Data Frame mit der Validierungs-Konfiguration.
#'
#' @return Eine Liste mit ungültigen Referenzen pro validiertem Feld.
#' @export
validate_entity_against_references <- function(
    p_SQLAzureConn,
    p_source_df,
    p_config_df
){
  
  results <- list()
  
  for(i in seq_len(nrow(p_config_df))){
    
    ref_table      <- p_config_df$Table[i]
    ref_field      <- p_config_df$RelatedField[i]
    source_field   <- p_config_df$ToValidate[i]
    
    # Nur Referenzspalte laden
    query <- paste0(
      "SELECT DISTINCT ", ref_field,
      " FROM ", ref_table
    )
    
    ref_values <- DBI::dbGetQuery(p_SQLAzureConn, query)[[1]]
    
    # Source-Werte holen
    source_values <- unique(p_source_df[[source_field]])
    
    # Invalid-Werte bestimmen
    invalid_values <- setdiff(source_values, ref_values)
    
    # Nur wenn es Abweichungen gibt
    if(length(invalid_values) > 0){
      results[[source_field]] <- invalid_values
    } else {
      results[[source_field]] <- character(0)
    }
  }
  
  return(results)
}

#' DMF-Entitäten mit Clause aus Mapping abrufen
#'
#' Holt DMF-Entitäten und die zugehörigen Filter-Clauses aus einer Mapping-Datei.
#'
#' @param file_path Pfad zur Excel-Mapping-Datei.
#'
#' @return Ein Data Frame mit den Spalten Entity, Clause und TableWithClause.
#' @export
get_dmf_entities_with_Clause_from_mapping <- function(
    file_path
){
  # Erste Zeile einlesen (enthält Entity-Namen)
  entities <- readxl::read_excel(file_path, n_max = 2)%>%
    arrange(Mapping)
  
  # Optional: Struktur anzeigen wie in deinem Code
  names(entities) <- paste0("col_",1:ncol(entities))
  
  entities_clauses <- 
    transform_wide_to_long(entities) %>%
    mutate(
      TableWithClause = paste(Entity,Clause)
    )
  return(entities_clauses)
}

#' Validierungskonfiguration erstellen
#'
#' Erstellt die Konfigurationstabelle für die anschließende Datenvalidierung.
#'
#' @param file_path Pfad zur Excel-Datei.
#' @param ref_col Referenzspalte.
#' @param entities_clauses Data Frame mit Entitäten und Clauses.
#'
#' @return Ein Data Frame mit der Validierungskonfiguration.
#' @export
create_validation_config <- function(
    file_path,
    ref_col,
    entities_clauses
){
  
  # Referenzspalte definieren (jetzt Parameter)
  ref_col <- ref_col
  
  # Datei einlesen (jetzt Parameter)
  df_raw <- readxl::read_excel(file_path, skip = 2) %>%
    dplyr::filter(!is.na(.data[[ref_col]])) %>%
    dplyr::select(
      where(~ any(!is.na(.) & . != ""))
    )
  
  # Prüfen ob vorhanden  (NICHT verändert)
  if(!ref_col %in% colnames(df_raw)){
    stop("Referenzspalte nicht gefunden.")
  }
  
  # Transformation (positionsunabhängig)  (NICHT verändert)
  df_result <- df_raw %>%
    tidyr::pivot_longer(
      cols = -all_of(ref_col),
      names_to = "Table",
      values_to = "RelatedField"
    ) %>%
    dplyr::filter(!is.na(RelatedField), RelatedField != "") %>%
    dplyr::select(
      Table,
      RelatedField,
      ToValidate = all_of(ref_col)
    ) %>%
    dplyr::filter(
      grepl("\\*", RelatedField)
    ) %>%
    dplyr::mutate(
      RelatedField = gsub("\\*", "", RelatedField)
    )
  
  df_result %>% 
    left_join(entities_clauses, by = c("Table"="Entity"), keep = T) %>%
    mutate(
      Table = ifelse(is.na(TableWithClause) | TableWithClause=="",
                     Table,
                     TableWithClause)
    ) %>%
    select(all_of(names(df_result)))
}

#' DMF-Entitäten aus Mapping abrufen
#'
#' Lädt DMF-Entitäten aus Excel und verknüpft sie mit der SQL-Datenbanktabelle DMFENTITY.
#'
#' @param SQLAzureConn Ein DBI-Verbindungsobjekt zur SQL-Datenbank.
#' @param entities_xlsx Ein Data Frame mit Entitäten aus Excel.
#'
#' @return Ein Data Frame mit gemappten Entitäten.
#' @export
get_dmf_entities_from_mapping <- function(
    SQLAzureConn,
    entities_xlsx 
){
  
  # 1 Spalte normalisieren
  table_a <- entities_xlsx %>%
    mutate(
      Name = trimws(as.character(Name)),
      Name = tolower(Name)
    )
  
  # 2. Verbindung zur SQL-Datenbank
  dmfentity <- dbGetQuery(
    SQLAzureConn, 
    "
    SELECT ENTITYNAME, 
    TARGETENTITY
    FROM DMFENTITY
    "
  )
  
  dmfentity <- dmfentity %>%
    mutate(
      ENTITYNAME = trimws(as.character(ENTITYNAME)),
      ENTITYNAME = tolower(ENTITYNAME)
    )
  
  
  # 4. Left Join durchführen
  result <- table_a %>%
    left_join(dmfentity, by = c("Name" = "ENTITYNAME"))
  
  
  return(result)
}

#' Breite Tabelle in lange Tabelle transformieren (Implementierung)
#'
#' Transformiert ein zweizeiliges breites Mapping-Format in ein strukturiertes langes Format.
#'
#' @param df_wide Die breite Tabelle (Data Frame).
#'
#' @return Ein tibble mit Entity und Clause.
#' @export
transform_wide_to_long <- function(df_wide){
  
  # Erste Zeile = Entity
  entities <- as.character(unlist(df_wide[1, ]))
  # Zweite Zeile = Clause
  clauses  <- as.character(unlist(df_wide[2, ]))
  # Falls zweite Zeile kürzer / NA → ""
  clauses[is.na(clauses)] <- ""
  
  result <- tibble(
    Entity = entities,
    Clause = clauses
  )
  
  return(result)
}

#' Entity Name suchen
#'
#' Sucht in der Tabelle DMFENTITY nach Übereinstimmungen für den angegebenen Tabellennamen.
#'
#' @param conn Ein DBI-Verbindungsobjekt.
#' @param tableName Gesuchter Tabellenname.
#'
#' @return Ein Data Frame (dmfentity).
#' @export
getEntityName <- function(conn, tableName)
{
  dmfentity <- DBI::dbGetQuery(
    conn,
    paste0(
      "SELECT ENTITYNAME, TARGETENTITY
       FROM DMFENTITY
       WHERE ENTITYNAME LIKE '%", tableName,
      "%'
       OR TARGETENTITY LIKE '%", tableName, "%'"
    )
  )
  
  return(dmfentity)
}

#' Artikelnummern und Kreditoren validieren und vorbereiten
#'
#' Validiert Artikelnummern und Kreditorenkonten und exportiert das Ergebnis in Excel.
#'
#' @param filesLoad Vektor von verfügbaren Dateinamen.
#' @param pfadDatenload Verzeichnispfad für den Datenload.
#' @param pfadStammdaten Verzeichnispfad für die Stammdaten.
#' @param regex_pattern Regulärer Ausdruck für die Dateisuche.
#' @param rp Released Products Data Frame zur Validierung.
#' @param vendor_vector Vektor von gültigen Kreditorenkonten.
#' @param item_col Name der Artikelnummer-Spalte (Standard: "ITEMNUMBER").
#' @param vendor_col Name der Kreditorenkonto-Spalte (Standard: "VENDORACCOUNTNUMBER").
#' @param output_name Basisname der Ausgabedatei.
#' @param col_types Spaltentypen für read_excel (Standard: "text").
#'
#' @return Das gefilterte Data Frame oder NULL.
#' @export
validate_and_prepare_entity_Itemnum_Vend <- function(
    filesLoad,
    pfadDatenload,
    pfadStammdaten,
    regex_pattern,
    rp,
    vendor_vector,
    item_col = "ITEMNUMBER",
    vendor_col ="VENDORACCOUNTNUMBER",
    output_name,
    col_types = "text"
){
  
  file_match <- grep(regex_pattern, tolower(filesLoad), value = TRUE)
  
  if(length(file_match) != 1){
    message(paste("Keine Daten für", output_name))
    return(NULL)
  }
  
  df <- read_excel(
    paste0(pfadDatenload, file_match),
    col_types = col_types
  )
  
  message(paste("Datensatz geladen:", output_name, "- Zeilen:", nrow(df)))
  distinct_items <- n_distinct(df[[item_col]])
  
  if(distinct_items != nrow(rp)){
    message(paste(output_name, "enthält mehr Artikel als Released Products V2"))
    
    df <- df %>%
      inner_join(rp, by = setNames(item_col, item_col)) %>%
      select(all_of(names(df)))
    
    df <- df[df[[vendor_col]] %in% vendor_vector, ]
  }
  
  output_path <- paste0(pfadStammdaten, output_name, "_gekürzt2.xlsx")
  writexl::write_xlsx(df, output_path)
  message(paste("Datei geschrieben:", output_path))
  
  return(df)
}

#' Artikelnummern validieren und vorbereiten
#'
#' Validiert Artikelnummern gegen Released Products und exportiert das Ergebnis in Excel.
#'
#' @param filesLoad Vektor von verfügbaren Dateinamen.
#' @param pfadDatenload Verzeichnispfad für den Datenload.
#' @param pfadStammdaten Verzeichnispfad für die Stammdaten.
#' @param regex_pattern Regulärer Ausdruck für die Dateisuche.
#' @param rp Released Products Data Frame zur Validierung.
#' @param source_item_col Name der Artikelnummer-Spalte in Quelldaten.
#' @param rp_item_col Name der Artikelnummer-Spalte in Released Products (Standard: "ITEMNUMBER").
#' @param output_name Basisname der Ausgabedatei.
#' @param col_types Spaltentypen für read_excel (Standard: "text").
#'
#' @return Das gefilterte Data Frame oder NULL.
#' @export
validate_and_prepare_entity_Itemnum <- function(
    filesLoad,
    pfadDatenload,
    pfadStammdaten,
    regex_pattern,
    rp,
    source_item_col,
    rp_item_col = "ITEMNUMBER",
    output_name,
    col_types = "text"
){
  
  file_match <- grep(regex_pattern, tolower(filesLoad), value = TRUE)
  
  if(length(file_match) != 1){
    message(paste("Keine Daten für", output_name))
    return(NULL)
  }
  
  df <- readxl::read_excel(
    paste0(pfadDatenload, file_match),
    col_types = col_types
  )
  
  message(paste("Datensatz geladen:", output_name, "- Zeilen:", nrow(df)))
  distinct_items <- dplyr::n_distinct(df[[source_item_col]])
  
  if(distinct_items != dplyr::n_distinct(rp[[rp_item_col]])){
    message(paste(output_name, "enthält Artikel, die nicht in Released Products V2 existieren"))
    
    df <- df %>%
      dplyr::inner_join(
        rp,
        by = setNames(rp_item_col, source_item_col)
      ) %>%
      dplyr::select(all_of(names(df)))
  }
  
  output_path <- paste0(pfadStammdaten, output_name, ".xlsx")
  writexl::write_xlsx(df, output_path)
  message(paste("Datei geschrieben:", output_path))
  return(df)
}
