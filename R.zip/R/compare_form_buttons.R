#' Compare form buttons between two D365FO form documentations
#'
#' Compares the buttons of two
#' \code{D365FormDocumentation} objects.
#'
#' The function identifies newly added and
#' removed buttons by comparing the logical
#' button structure of the form.
#'
#' The comparison includes the following
#' button types:
#'
#' \itemize{
#'   \item Button
#'   \item MenuFunctionButton
#'   \item MenuButton
#'   \item DropDialogButton
#' }
#'
#' @param old_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the original form documentation.
#'
#' @param new_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the updated form documentation.
#'
#' @return A list containing:
#' \describe{
#'   \item{Added}{
#'     Buttons that exist only in the new documentation.
#'   }
#'   \item{Removed}{
#'     Buttons that exist only in the old documentation.
#'   }
#' }
#'
#' @details
#' The function compares the
#' \code{Buttons} tables of two
#' \code{D365FormDocumentation} objects.
#'
#' Buttons are uniquely identified by the
#' combination of:
#'
#' \itemize{
#'   \item ButtonType
#'   \item Name
#' }
#'
#' Typical use cases:
#'
#' \itemize{
#'   \item Detect newly introduced buttons.
#'   \item Identify removed buttons after application updates.
#'   \item Compare customized forms between environments.
#'   \item Validate UI changes affecting user interactions.
#' }
#'
#' @examples
#' \dontrun{
#'
#' comparison <-
#'   compare_form_buttons(
#'     old_documentation,
#'     new_documentation
#'   )
#'
#' comparison$Added
#'
#' comparison$Removed
#'
#' }
#'
#' @export
compare_form_buttons <- function(
    old_documentation,
    new_documentation
) {
  
  #===========================================================
  # VALIDATE INPUT PARAMETERS
  #===========================================================
  
  if (!inherits(
    old_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "old_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  if (!inherits(
    new_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "new_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  #===========================================================
  # LOAD BUTTONS
  #===========================================================
  
  old_buttons <-
    old_documentation$Buttons
  
  new_buttons <-
    new_documentation$Buttons
  
  #===========================================================
  # ADDED BUTTONS
  #===========================================================
  
  added <-
    
    dplyr::anti_join(
      new_buttons,
      old_buttons,
      by = c(
        "ButtonType",
        "Name"
      )
    )
  
  #===========================================================
  # REMOVED BUTTONS
  #===========================================================
  
  removed <-
    
    dplyr::anti_join(
      old_buttons,
      new_buttons,
      by = c(
        "ButtonType",
        "Name"
      )
    )
  
  #===========================================================
  # RESULT
  #===========================================================
  
  result <-
    
    list(
      Added = added,
      Removed = removed
    )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  return(result)
  
}