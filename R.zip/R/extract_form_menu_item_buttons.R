#' MenuItem Buttons aus einem Formular extrahieren
#'
#' Extrahiert alle `MenuFunctionButton`-Controls eines
#' analysierten D365FO Formulars.
#'
#' Die Funktion liefert eine fachliche Sicht auf die
#' Aktionen, die dem Benutzer innerhalb eines Formulars
#' zur Verfügung stehen.
#'
#' @param form_model Ergebnis von [analyze_form()].
#'
#' @return Tibble mit den Spalten:
#'
#' * `Name` — Technischer Name des Buttons
#' * `MenuItemName` — Referenziertes MenuItem
#' * `OpenMode` — Öffnungsmodus
#' * `Primary` — Primär-Button-Flag
#' * `Big` — Große Darstellung (ActionPane)
#' * `Parent` — Übergeordnetes Control
#' * `Path` — Vollständiger Pfad im Formular
#'
#' @details
#' Die Funktion basiert auf der Control-Hierarchie
#' des Formulars und wertet ausschließlich Controls
#' vom Typ `MenuFunctionButton` aus.
#'
#' Die Funktion dient als Grundlage für:
#'
#' * Form-Dokumentation
#' * Form-Analyse
#' * Security-Analyse
#' * Form-Vergleich
#'
#' @seealso [analyze_form()], [extract_form_buttons()],
#'   [extract_form_menu_items()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#' buttons <- extract_form_menu_item_buttons(form_model)
#' }
#'
#' @export
extract_form_menu_item_buttons <- function(form_model) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # MENU ITEM BUTTONS FILTERN
  # ================================

  buttons <-
    form_model$Controls |>
    dplyr::filter(Type == "MenuFunctionButton")

  # ================================
  # FACHMODELL ERSTELLEN
  # ================================

  if (nrow(buttons) == 0) {
    return(empty_form_menu_item_buttons())
  }

  result <-
    purrr::pmap_dfr(
      list(
        buttons$Name,
        buttons$Parent,
        buttons$Path,
        buttons$Properties
      ),
      function(Name, Parent, Path, Properties) {

        tibble::tibble(
          Name         = Name,
          MenuItemName = get_property(Properties, "MenuItemName"),
          OpenMode     = get_property(Properties, "OpenMode"),
          Primary      = get_property(Properties, "Primary"),
          Big          = get_property(Properties, "Big"),
          Parent       = Parent,
          Path         = Path
        )
      }
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
