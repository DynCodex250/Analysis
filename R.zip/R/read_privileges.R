read_privileges <- function(doc){

  xml_find_all(doc,"//Privileges/AxSecurityPrivilegeReference/Name") %>%

    xml_text()

}
