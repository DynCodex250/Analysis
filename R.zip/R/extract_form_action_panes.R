#' Action Pane Struktur extrahieren
#'
#' Extrahiert die ActionPane-Struktur eines analysierten D365FO Formulars.
#'
#' Die Funktion rekonstruiert die Ribbon-Struktur eines Formulars
#' anhand der Control-Hierarchie.
#'
#' @param form_model Ergebnis von `analyze_form()`.
#'
#' @return Tibble mit:
#' - ActionPaneTab
#' - ButtonGroup
#' - Path
#'
#' @details
#' Die Funktion liefert die Struktur:
#' ActionPane -> ActionPaneTab -> ButtonGroup
#'
#' Die eigentlichen Aktionen werden nicht berücksichtigt.
#' Diese können über `extract_form_menu_item_buttons()` analysiert werden.
#'
#' @examples
#' \dontrun{
#' extract_form_action_panes(
#'   form_model
#' )
#' }
#'
#' @export
extract_form_action_panes <- function(form_model) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # =========================================
  # BUTTON GROUPS ERMITTELN
  # =========================================

  button_groups <- form_model$Controls |>
    dplyr::filter(Type == "ButtonGroup")

  # =========================================
  # ACTION PANE STRUKTUR ERSTELLEN
  # =========================================

  result <- button_groups |>
    dplyr::transmute(
      ActionPaneTab = Parent,
      ButtonGroup = Name,
      Path = Path
    )

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}
