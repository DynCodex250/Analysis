#' Zwei D365FO Privilege XML-Dateien vergleichen
#'
#' Liest zwei Privilege XML-Dateien ein, parst diese mittels
#' `parse_privilege()` und vergleicht die einzelnen Komponenten
#' des erzeugten Privilege-Modells.
#'
#' Die Funktion eignet sich insbesondere für Roundtrip-Tests,
#' bei denen überprüft werden soll, ob eine erzeugte XML-Datei
#' fachlich identisch zur ursprünglichen XML-Datei ist.
#'
#' Verglichen werden:
#'
#' - Metadata
#' - EntryPoints
#' - DataEntityPermissions
#' - DataEntityMethods
#' - DirectAccessPermissions
#' - DirectAccessFields
#'
#' @param original_xml Pfad zur Original-Privilege-XML
#' @param generated_xml Pfad zur generierten Privilege-XML
#'
#' @return Tibble mit Vergleichsergebnis je Modellkomponente
#'
#' @export
compare_privilege_roundtrip <- function(
    original_xml,
    generated_xml) {

  # =====================================
  # XML-DATEIEN EINLESEN
  # =====================================

  original_model <- parse_privilege(
    original_xml
  )

  generated_model <- parse_privilege(
    generated_xml
  )

  # =====================================
  # KOMPONENTEN VERGLEICHEN
  # =====================================

  result <- tibble::tibble(

    Component = c(
      "Metadata",
      "EntryPoints",
      "DataEntityPermissions",
      "DataEntityMethods",
      "DirectAccessPermissions",
      "DirectAccessFields"
    ),

    Equal = c(

      isTRUE(
        all.equal(
          original_model$Metadata,
          generated_model$Metadata
        )
      ),

      isTRUE(
        all.equal(
          original_model$EntryPoints,
          generated_model$EntryPoints
        )
      ),

      isTRUE(
        all.equal(
          original_model$DataEntityPermissions,
          generated_model$DataEntityPermissions
        )
      ),

      isTRUE(
        all.equal(
          original_model$DataEntityMethods,
          generated_model$DataEntityMethods
        )
      ),

      isTRUE(
        all.equal(
          original_model$DirectAccessPermissions,
          generated_model$DirectAccessPermissions
        )
      ),

      isTRUE(
        all.equal(
          original_model$DirectAccessFields,
          generated_model$DirectAccessFields
        )
      )
    )
  )

  # =====================================
  # ERGEBNIS ZURÜCKGEBEN
  # =====================================

  return(result)
}
