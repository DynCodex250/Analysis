#' Property-Wert sicher auslesen#'#' Liest einen Property-Wert aus einer#' Properties-Liste aus.#'#' @param properties Properties-Liste.#' @param property_name Name der Property.#'#' @return Property-Wert oder NA.#'#' @keywords

internalget_property <- function(properties,property_name){

  if(property_name %in% names(properties)){

    return(
      properties[[property_name]]
    )

  }

  return(NA_character_)

}
