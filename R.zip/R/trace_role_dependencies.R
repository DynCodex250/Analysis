trace_role_dependencies <- function(
    role_file,
    duties_folder = NULL,
    privileges_folder = NULL){

  # =========================================
  #   ROLE XML LADEN
  # =========================================

    role_doc <- read_xml(role_file)

  # =========================================
  #   ROLE INFOS
  # =========================================

    role_name <- xml_text(xml_find_first(role_doc,"//Name"))

  role_label <- xml_text(xml_find_first(role_doc,"//Label"))

  # =========================================
  #   DUTIES
  # =========================================

    duties <- xml_find_all(role_doc,"//Duties/AxSecurityDutyReference/Name") %>%

    xml_text()

  duties_df <- tibble(DutyName = duties) %>%

    mutate(

      IsGUID =
        is_guid_name(DutyName),

      ExistsAsXML =
        ifelse(
          is.null(duties_folder),
          NA,

          file.exists(
            file.path(
              duties_folder,
              paste0(
                DutyName,
                ".xml"
              )
            )
          )
        )
    )

  # =========================================
  #   PRIVILEGES AUS DUTIES
  # =========================================

    all_privileges <- list()

  if(!is.null(duties_folder)){

    for(duty_name in duties)
    {

      duty_file <- file.path(
        duties_folder,
        paste0(
          duty_name,
          ".xml"
        )
      )

      if(file.exists(duty_file))
      {

        duty_doc <- read_xml(duty_file)

        privilege_names <- xml_find_all(
          duty_doc,
          "//Privileges/AxSecurityPrivilegeReference/Name"
        ) %>%

          xml_text()

        if(length(privilege_names) > 0)
        {

          temp_df <- tibble(

            DutyName = duty_name,

            PrivilegeName = privilege_names
          ) %>%

            mutate(

              IsGUID =
                is_guid_name(
                  PrivilegeName
                ),

              ExistsAsXML =
                ifelse(
                  is.null(privileges_folder),
                  NA,

                  file.exists(
                    file.path(
                      privileges_folder,
                      paste0(
                        PrivilegeName,
                        ".xml"
                      )
                    )
                  )
                )
            )

          all_privileges[[duty_name]] <- temp_df
        }
      }
    }

  }

  # =========================================
  #   PRIVILEGES COMBINEN
  # =========================================

    privileges_df <- bind_rows(all_privileges)

  # =========================================
  #   ENTRYPOINTS
  # =========================================

    all_entrypoints <- list()

  if(!is.null(privileges_folder)){

    if(nrow(privileges_df) > 0)
    {

      for(privilege_name in privileges_df$PrivilegeName)
      {

        privilege_file <- file.path(
          privileges_folder,
          paste0(
            privilege_name,
            ".xml"
          )
        )

        if(file.exists(privilege_file))
        {

          privilege_doc <- read_xml(
            privilege_file
          )

          entrypoints <- xml_find_all(
            privilege_doc,
            "//EntryPoints/*/Name"
          ) %>%

            xml_text()

          if(length(entrypoints) > 0)
          {

            temp_df <- tibble(

              PrivilegeName =
                privilege_name,

              EntryPoint =
                entrypoints
            )

            all_entrypoints[[privilege_name]] <- temp_df
          }
        }
      }
    }

  }

  # =========================================
  #   ENTRYPOINTS COMBINEN
  # =========================================

    entrypoints_df <- bind_rows(all_entrypoints)

  # =========================================
  #   ERGEBNIS
  # =========================================

    result <- list(

      role = tibble(

        RoleName = role_name,

        RoleLabel = role_label,

        IsGUID =
          is_guid_name(role_name)
      ),

      duties = duties_df,

      privileges = privileges_df,

      entrypoints = entrypoints_df

    )

  return(result)

  }
