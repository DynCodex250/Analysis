#' Formularfelder extrahieren
#'
#' Extrahiert fachlich relevante Formularelemente aus einem
#' D365FO Formularmodell.
#'
#' Optional kann die Analyse auf einen bestimmten Tab
#' eingeschränkt werden.
#'
#' Berücksichtigt werden aktuell:
#'
#' * `Group`
#' * `String`
#' * `Integer`
#' * `Real`
#' * `Date`
#' * `DateTime`
#' * `CheckBox`
#' * `ComboBox`
#' * `ReferenceGroup`
#'
#' Die Funktion liefert eine flache Liste aller
#' gefundenen Elemente.
#'
#' @param form_model Ergebnis von [analyze_form()].
#' @param tab_name Optionaler technischer Tabname.
#'   Wird kein Tab angegeben (`""`), werden alle
#'   Felder des Formulars zurückgegeben.
#'
#' @return Tibble mit den Spalten:
#'
#' * `Type` — Control-Typ
#' * `Name` — Technischer Name
#' * `DataSource` — Zugehörige DataSource
#' * `DataField` — Referenziertes Datenbankfeld
#' * `Label` — Anzeigename
#' * `Parent` — Übergeordnetes Control
#' * `Level` — Hierarchietiefe
#' * `Path` — Vollständiger Pfad im Formular
#'
#' Das Ergebnis ist nach `Level` und `Path` sortiert.
#'
#' @seealso [extract_form_field_metadata()], [analyze_form()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#'
#' # Alle Felder
#' extract_form_fields(form_model)
#'
#' # Nur Felder eines bestimmten Tabs
#' extract_form_fields(
#'   form_model,
#'   "TabSalesDemographics"
#' )
#' }
#'
#' @export
extract_form_fields <- function(
    form_model,
    tab_name = "") {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # RELEVANTE CONTROL-TYPEN
  # ================================

  field_types <- c(
    "Group",
    "String",
    "Integer",
    "Real",
    "Date",
    "DateTime",
    "CheckBox",
    "ComboBox",
    "ReferenceGroup"
  )

  # ================================
  # CONTROLS FILTERN
  # ================================

  controls <-
    form_model$Controls |>
    dplyr::filter(Type %in% field_types)

  # ================================
  # TAB FILTER
  # ================================

  if (!identical(tab_name, "")) {

    controls <-
      controls |>
      dplyr::filter(
        stringr::str_detect(
          Path,
          stringr::fixed(tab_name)
        )
      )
  }

  # ================================
  # FACHMODELL ERSTELLEN
  # ================================

  result <-
    purrr::pmap_dfr(
      list(
        controls$Type,
        controls$Name,
        controls$Parent,
        controls$Level,
        controls$Path,
        controls$Properties
      ),
      function(Type, Name, Parent, Level, Path, Properties) {

        tibble::tibble(
          Type       = Type,
          Name       = Name,
          DataSource = get_property(Properties, "DataSource"),
          DataField  = get_property(Properties, "DataField"),
          Label      = get_property(Properties, "Label"),
          Parent     = Parent,
          Level      = Level,
          Path       = Path
        )
      }
    )

  # ================================
  # SORTIEREN
  # ================================

  result <-
    result |>
    dplyr::arrange(Level, Path)

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
