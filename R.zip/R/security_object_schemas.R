#' Änderungen an der Struktur von empty_metadata
#' sollten ausschließlich in dieser Funktion#
#' vorgenommen werden.

empty_metadata <- function(){

return(tibble::tibble(
  Name =
    character(),

  Description =
    character(),

  Label =
    character()

))

}

#' Leeres EntryPointForms-Schema erzeugen#'#' Erstellt ein leeres Tibble für die Komponente#' EntryPointForms eines D365FO Privileges.#'#' Die Funktion stellt sicher, dass auch bei#' leeren Ergebnissen immer die erwartete#' Tabellenstruktur zurückgegeben wird.#'#' Änderungen an der Struktur von EntryPointForms#' sollten ausschließlich in dieser Funktion#' vorgenommen werden.#'#' @return Leeres Tibble mit der definierten#' Struktur von EntryPointForms.#'#' @export

empty_entrypoints <- function(){

return(
  tibble::tibble(
    Name = character(),
    ObjectName = character(),
    ObjectType = character(),
    ObjectChildName = character(),
    HasForms = logical(),
    Read = character(),
    Create = character(),
    Update = character(),
    Delete = character(),
    Correct = character(),
    Invoke = character()
  )

)

}

#' Änderungen an der Struktur von empty_entrypoint_forms#' sollten ausschließlich in dieser Funktion#' vorgenommen werden.

empty_entrypoint_forms <- function(){

return(tibble::tibble(EntryPointName = character(), FormName = character()))

}



#' Leeres EntryPointControls-Schema erzeugen#'#' Erstellt ein leeres Tibble für die Komponente#' EntryPointControls eines D365FO Privileges.#'#' Die Funktion dient als zentrale Definition#' der Tabellenstruktur.#'#' Änderungen an der Struktur von#' EntryPointControls sollten ausschließlich#' in dieser Funktion vorgenommen werden.#'#' @return Leeres Tibble mit der definierten#' Struktur von EntryPointControls.#'#' @export

empty_entrypoint_controls <- function(){

return(
  tibble::tibble(
    EntryPointName = character(),
    FormName = character(),
    ControlName = character(),
    Correct = character(),
    Create = character(),
    Delete = character(),
    Invoke = character(),
    Read = character(),
    Update = character()
  )
)}


#' Änderungen an der Struktur von empty_entrypoint_form_datasources#' sollten ausschließlich in dieser Funktion#' vorgenommen werden.

empty_entrypoint_form_datasources <- function(){

return(
  tibble::tibble(
    EntryPointName = character(),
    FormName = character(),
    DataSourceName = character()
  )
)

}



#' Leeres DataEntityPermissions-Schema erzeugen#'#' Erstellt ein leeres Tibble für die Komponente#' DataEntityPermissions eines D365FO Privileges.#'#' Die Funktion dient als zentrale Definition#' der Tabellenstruktur.#'#' Änderungen an der Struktur von#' DataEntityPermissions sollten ausschließlich#' in dieser Funktion vorgenommen werden.#'#' @return Leeres Tibble mit der definierten#' Struktur von DataEntityPermissions.#'#' @export

empty_data_entity_permissions <- function(){

return(
  tibble::tibble(
    EntityName = character(),
    IntegrationMode = character(),
    Read = character(),
    Create = character(),
    Update = character(),
    Delete = character(),
    Correct = character(),
    Invoke = character()
  )
)}

#' Änderungen an der Struktur von empty_data_entity_methods#' sollten ausschließlich in dieser Funktion#' vorgenommen werden.
empty_data_entity_methods <- function(){

return(
  tibble::tibble(
    EntityName = character(),
    MethodName = character(),
    Read = character(),
    Create = character(),
    Update = character(),
    Delete = character(),
    Correct = character(),
    Invoke = character()
  )

)}

#' Änderungen an der Struktur von empty_direct_access_permissions#' sollten ausschließlich in dieser Funktion#' vorgenommen werden.

empty_direct_access_permissions <- function(){

return(
  tibble::tibble(
    XmlNode = character(),
    ObjectName = character(),
    Read = character(),
    Create = character(),
    Update = character(),
    Delete = character(),
    Correct = character(),
    Invoke = character()
  )
)}



#' Änderungen an der Struktur von empty_direct_access_fields#' sollten ausschließlich in dieser Funktion#' vorgenommen werden.

empty_direct_access_fields <- function(){

return(
  tibble::tibble(
    ParentObject = character(),
    ParentXmlNode = character(),
    FieldName = character(),
    Read = character(),
    Create = character(),
    Update = character(),
    Delete = character(),
    Correct = character(),
    Invoke = character()
  )
)}



#' Änderungen an der Struktur von empty_form_control_overrides#' sollten ausschließlich in dieser Funktion#' vorgenommen werden.

empty_form_control_overrides <- function(){

return(
  tibble::tibble(
    ParentForm = character(),
    ControlName = character(),
    Read = character(),
    Create = character(),
    Update = character(),
    Delete = character(),
    Correct = character(),
    Invoke = character()
  )
)}

#' Leeres Form-Metadatenobjekt erstellen#'#' Erstellt die Standardstruktur für die#' Metadaten eines D365FO Formulars.#'#' @return Liste mit Metadatenfeldern.#'#' @keywords internal

empty_form_metadata <- function(){

list(
  Name = character(),
  Caption = character(),
  Pattern = character(),
  Style = character(),
  FormTemplate = character(),
  InteractionClass = character(),
  DataSourceQuery = character()
)}



#' Leere Form-DataSources erstellen#'#' Erstellt die Standardstruktur für die#' DataSources eines D365FO Formulars.#'#' @return Leeres Tibble.#'#' @keywords internal


empty_form_datasources <- function(){

tibble::tibble(
  Name = character(),
  Table = character(),
  JoinSource = character(),
  ParentDataSource = character()
)}



#' Leere Form-Parts erstellen#'#' Erstellt die Standardstruktur für die#' Parts eines D365FO Formulars.#'#' @return Leeres Tibble.#'#' @keywords internal

empty_form_parts <- function(){

tibble::tibble(Name = character(),
               PartType = character(),
               MenuItemName = character())

}




#' Leeres Form-Modell erstellen#'#' Erstellt die Standardstruktur eines#' analysierten D365FO Formulars.#'#' @return Objekt der Klasse#' D365FormModel.#'#' @keywords internal

empty_form_model <- function(){

result <- list(
  Metadata = empty_form_metadata(),
  DataSources = empty_form_datasources(),
  Controls = empty_form_controls(),
  Parts = empty_form_parts()
)

class(result) <- c("D365FormModel", "list")

return(result)

}


#' Leere Form-Controls erstellen#'#' Erstellt die Standardstruktur für die#' Controls eines D365FO Formulars.#'#' Jeder Control-Knoten wird unabhängig#' von seinem konkreten D365-Typ#' gespeichert.#'#' @return Leeres Tibble.#'#' @details#' Der tatsächliche D365-Typ wird in der#' Spalte Type gespeichert.#'#' Beispiele:#'#' * ActionPane#' * Group#' * Tab#' * Grid#' * MenuItemButton#' * StringControl#'#' @keywords internal

empty_form_controls <- function(){

  tibble::tibble(
    Name = character(),
    Type = character(),
    Parent = character(),
    Path = character(),
    Properties = list()
  )}


#' Leere Form-Controls erstellen#'#' Erstellt die Standardstruktur für#' Form Controls.#'#' @return Leeres Tibble.#'#' @keywords internal

# empty_form_controls <- function(){
#
# tibble::tibble(
#   Name = character(),
#   Type = character(),
#   Parent = character(),
#   Level = integer(),
#   Path = character()
# )
#
# }

#' Leeres ReferenceGroup-Modell erzeugen#'#' Erstellt ein leeres Ergebnisobjekt#' für ReferenceGroup-Auswertungen.#'#' @return Leeres Tibble mit der#' Struktur von#' extract_form_reference_group_relations().#'#' @export

empty_form_reference_groups <- function(){

result <-

  tibble::tibble(
    Name = character(),
    DataSource = character(),
    ReferenceField = character(),
    ReplacementFieldGroup = character(),
    Label = character(),
    Parent = character(),
    Path = character()
  )

return(result)

}

#' Leeres Formularvergleichsobjekt erzeugen
#'
#' Erstellt ein leeres Vergleichsobjekt
#' für Formularanalysen.
#'
#' Die Funktion dient als Standard-
#' Rückgabeobjekt für Vergleichsfunktionen
#' wie:
#'
#' * compare_form_action_buttons()
#' * compare_form_grids()
#' * compare_form_reference_groups()
#' * compare_form_datasources()
#'
#' @return Liste mit den Elementen:
#'
#' * Added
#' * Removed
#'
#' Beide Elemente enthalten ein leeres
#' Tibble.
#'
#' @details
#' Die Funktion stellt sicher, dass
#' Vergleichsfunktionen auch dann eine
#' konsistente Struktur zurückgeben,
#' wenn keine Unterschiede gefunden
#' wurden.
#'
#' @examples
#' empty_form_comparison()
#'
#' @export
empty_form_comparison <- function(){

  result <-
    list(
      Added = tibble::tibble(),
      Removed = tibble::tibble()
    )
  return(result)
}


empty_form_action_pane_buttons <- function(){

  result <- tibble::tibble(
    ActionPaneTab = character(),
    ButtonGroup = character(),
    Button = character(),
    MenuItemName = character(),
    OpenMode = character(),
    Primary = character(),
    Big = character(),
    Path = character()

  )
  return(result)
}


#' Leeres MenuItemButton-Modell erzeugen
#'
#' Erstellt ein leeres Ergebnisobjekt
#' für MenuItemButton-Auswertungen.
#'
#' @return Leeres Tibble mit der
#' Struktur von
#' extract_form_menu_item_buttons().
#'
#' @export
empty_form_menu_item_buttons <- function(){

  result <-

    tibble::tibble(

      Name = character(),

      MenuItemName = character(),

      OpenMode = character(),

      Primary = character(),

      Big = character(),

      Parent = character(),

      Path = character()

    )

  return(result)

}


#' Leere Tab-Struktur erzeugen
#'
#' Erstellt ein leeres Ergebnisobjekt
#' für Tab-Strukturen.
#'
#' @return Leeres Tibble mit:
#'
#' * Tab
#' * TabPage
#' * Path
#'
#' @export
empty_form_tab_structure <- function(){

  result <-

    tibble::tibble(
      Tab = character(),
      TabPage = character(),
      Path = character()
    )

  return(result)

}
