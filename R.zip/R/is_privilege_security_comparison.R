#' Prüfen ob ein Privilege-Securityvergleich vorliegt#'#' Prüft, ob ein Objekt das Ergebnis eines#' compare_privileges_security()-Aufrufs ist.#'#' @param x Zu prüfendes Objekt.#'#' @return TRUE wenn das Objekt ein#' D365PrivilegeSecurityComparison ist,#' ansonsten FALSE.#'#' @details#' Die Prüfung erfolgt über die Objektklasse.#'#' @seealso#' compare_privileges_security()#'#' @examples#' result <-#'   compare_privileges_security(#'     privilege_a,#'     privilege_b#'   )#'#' is_privilege_security_comparison(#'   result#' )#'#' @export

is_privilege_security_comparison <- function(x){

  #================================
  #OBJEKT PRÜFEN
  #================================

  result <-inherits(x,"D365PrivilegeSecurityComparison")

  #================================
  #ERGEBNIS ZURÜCKGEBEN
  #================================

  return(result)

}
