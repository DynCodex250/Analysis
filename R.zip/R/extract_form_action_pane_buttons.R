#' Action Pane Buttons extrahieren
#'
#' Extrahiert alle Buttons einer ActionPane inklusive ihrer Ribbon-Struktur.
#'
#' Die Funktion verbindet ActionPaneTab, ButtonGroup und MenuFunctionButton
#' zu einer fachlichen Sicht auf die im Formular verfügbaren Aktionen.
#'
#' @param form_model Ergebnis von `analyze_form()`.
#'
#' @return Tibble mit:
#' - ActionPaneTab
#' - ButtonGroup
#' - Button
#' - MenuItemName
#' - OpenMode
#' - Primary
#' - Big
#' - Path
#'
#' @examples
#' \dontrun{
#' extract_form_action_pane_buttons(
#'   form_model
#' )
#' }
#'
#' @export
extract_form_action_pane_buttons <- function(form_model) {
  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # =========================================
  # BUTTONS ERMITTELN
  # =========================================

  buttons <- extract_form_menu_item_buttons(form_model)

  # =========================================
  # LEERES MODELL ABSICHERN
  # =========================================

  if (nrow(buttons) == 0) {
    return(empty_form_action_pane_buttons())
  }

  # =========================================
  # ACTION PANE INFORMATIONEN ERSTELLEN
  # =========================================

  result <- buttons |>
    dplyr::mutate(
      ActionPaneTab = stringr::word(
        Path,
        start = 2,
        end = 2,
        sep = stringr::fixed("/")
      ),
      ButtonGroup = Parent
    ) |>
    dplyr::select(
      ActionPaneTab,
      ButtonGroup,
      Button = Name,
      MenuItemName,
      OpenMode,
      Primary,
      Big,
      Path
    )

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}
