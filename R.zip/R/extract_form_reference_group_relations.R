#' ReferenceGroup-Beziehungen extrahieren
#'
#' Extrahiert die fachlichen Beziehungen
#' aller ReferenceGroups eines analysierten
#' D365FO Formulars.
#'
#' Eine ReferenceGroup stellt typischerweise
#' eine Referenz auf einen anderen Datensatz
#' dar, beispielsweise:
#'
#' * Mitarbeiter
#' * Kunde
#' * Lieferant
#' * Produkt
#' * Kalenderjahr
#'
#' Die Funktion transformiert die
#' verschachtelten Properties der Controls
#' in eine flache fachliche Struktur.
#'
#' @param form_model Ergebnis von
#' analyze_form().
#'
#' @return Tibble mit:
#'
#' * Name
#' * DataSource
#' * ReferenceField
#' * ReplacementFieldGroup
#' * Label
#' * Parent
#' * Path
#'
#' @examples
#' extract_form_reference_group_relations(
#'   form_model
#' )
#'
#' @export
extract_form_reference_group_relations <- function(
    form_model){

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if(!inherits(form_model,"D365FormModel")){

    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # REFERENCE GROUPS ERMITTELN
  # ================================

  reference_groups <-

    extract_form_controls_by_type(
      form_model,
      "ReferenceGroup"
    )

  # ================================
  # LEERES ERGEBNIS ZURÜCKGEBEN
  # ================================

  if(nrow(reference_groups) == 0){

    return(
      empty_form_reference_groups()
    )

  }

  # ================================
  # FACHMODELL ERSTELLEN
  # ================================

  result <-

    purrr::pmap_dfr(

      list(
        reference_groups$Name,
        reference_groups$Parent,
        reference_groups$Path,
        reference_groups$Properties
      ),

      function(
    Name,
    Parent,
    Path,
    Properties){

        tibble::tibble(

          Name = Name,

          DataSource =
            get_property(
              Properties,
              "DataSource"
            ),

          ReferenceField =
            get_property(
              Properties,
              "ReferenceField"
            ),

          ReplacementFieldGroup =
            get_property(
              Properties,
              "ReplacementFieldGroup"
            ),

          Label =
            get_property(
              Properties,
              "Label"
            ),

          Parent = Parent,

          Path = Path

        )

      }

    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)

}
