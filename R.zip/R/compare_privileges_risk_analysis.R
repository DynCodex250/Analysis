#' D365FO Security-Änderungen risikobasiert bewerten
#'
#' Analysiert die Ergebnisse eines Security-Vergleichs und
#' bewertet jede Berechtigungsänderung hinsichtlich ihres
#' potenziellen Security-Risikos.
#'
#' Die Funktion stellt die zweite Stufe der Security-Analyse
#' dar.
#'
#' Während `compare_privileges_security()` ausschließlich
#' Berechtigungsänderungen identifiziert, klassifiziert
#' diese Funktion die Änderungen nach Risiko und fachlicher
#' Auswirkung.
#'
#' Die Funktion eignet sich insbesondere für:
#' - Security Reviews
#' - Release Assessments
#' - Compliance-Prüfungen
#' - Audits
#' - Berechtigungsfreigaben
#' - Security Governance
#'
#' @param security_changes Ergebnis von
#'        `compare_privileges_security()`.
#'
#' @return Tibble mit den ursprünglichen
#' Security-Änderungen sowie einer zusätzlichen
#' Risikobewertung.
#'
#' Zusätzliche Spalten:
#'
#' \describe{
#'   \item{RiskLevel}{
#'   Risikoklassifizierung der Änderung.
#'   }
#'
#'   \item{RiskType}{
#'   Fachliche Einordnung der Änderung.
#'   }
#' }
#'
#' Das Ergebnis besitzt zusätzlich die Klasse
#' `D365PrivilegeRiskAnalysis`.
#'
#' @details
#' Die Funktion bewertet ausschließlich Änderungen
#' bestehender Berechtigungen.
#'
#' Existenzänderungen von Security-Objekten werden
#' nicht berücksichtigt.
#'
#' Folgende Risikoregeln werden verwendet:
#'
#' \itemize{
#'   \item Deny -> Allow = High
#'   \item NA -> Allow = High
#'   \item Allow -> Deny = Low
#'   \item Allow -> NA = Medium
#'   \item Deny -> NA = Medium
#'   \item NA -> Deny = Low
#' }
#'
#' Folgende Änderungstypen werden vergeben:
#'
#' \itemize{
#'   \item Privilege Escalation
#'   \item Privilege Reduction
#'   \item Permission Change
#' }
#'
#' Die Ergebnisse werden nach Risikostufe sortiert:
#'
#' \itemize{
#'   \item High
#'   \item Medium
#'   \item Low
#'   \item Informational
#' }
#'
#' Dadurch können kritische Änderungen schneller
#' identifiziert werden.
#'
#' @seealso
#' compare_privileges_security()
#' compare_privileges_existence()
#' compare_privileges_release()
#'
#' @examples
#'
#' # Security-Änderungen erzeugen
#' security_changes <-
#'   compare_privileges_security(
#'     privilege_old,
#'     privilege_new
#'   )
#'
#' # Risikoanalyse durchführen
#' risk_analysis <-
#'   compare_privileges_risk_analysis(
#'     security_changes
#'   )
#'
#' # Alle Risiken anzeigen
#' risk_analysis
#'
#' # Nur High Risks anzeigen
#' dplyr::filter(
#'   risk_analysis,
#'   RiskLevel == "High"
#' )
#'
#' @export
compare_privileges_risk_analysis <- function(
    security_changes){

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if(!inherits(security_changes, "data.frame")){
    stop("security_changes muss ein DataFrame sein.")
  }

  required_columns <- c(
    "Component",
    "Object",
    "Permission",
    "OldValue",
    "NewValue"
  )

  missing_columns <-
    setdiff(required_columns,
            names(security_changes))

  if(length(missing_columns) > 0){

    stop(paste("Folgende Spalten fehlen:",
               paste(missing_columns,collapse = ", ")
    ))
  }

  # ================================
  # DATEN AUFBEREITEN
  # ================================

  result <- security_changes

  # ================================
  # RISIKO BEWERTEN
  # ================================

  result <-
    result |>
    dplyr::mutate(

      RiskLevel = dplyr::case_when(
        OldValue == "Deny" & NewValue == "Allow"
        ~ "High",

        is.na(OldValue) & NewValue == "Allow"
        ~ "High",

        OldValue == "Allow" & NewValue == "Deny"
        ~ "Low",

        OldValue == "Allow" & is.na(NewValue)
        ~ "Medium",

        OldValue == "Deny" & is.na(NewValue)
        ~ "Medium",

        is.na(OldValue) & NewValue == "Deny"
        ~ "Low",

        TRUE
        ~ "Informational"
      ),

      RiskType = dplyr::case_when(
        (OldValue == "Deny" & NewValue == "Allow")
        |
          (is.na(OldValue) & NewValue == "Allow")
        ~ "Privilege Escalation",

        (OldValue == "Allow" & NewValue == "Deny")
        |
          (OldValue == "Allow" & is.na(NewValue))
        ~ "Privilege Reduction",

        TRUE
        ~ "Permission Change"
      )
    )

  # ================================
  # RISIKEN SORTIEREN
  # ================================

  result <-

    result |>
    dplyr::arrange(
      factor(
        RiskLevel,
        levels = c(
          "High",
          "Medium",
          "Low",
          "Informational"
        )
      )
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  class(result) <-
    c(
      "D365PrivilegeRiskAnalysis",
      "tbl_df",
      "tbl",
      "data.frame"
    )

  return(result)
}
