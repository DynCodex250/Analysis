#' Gruppenstruktur extrahieren
#'
#' Extrahiert alle Gruppen eines D365FO Formulars.
#'
#' Die Funktion dient als Grundlage für:
#'
#' * Formular-Dokumentationen
#' * Release-Vergleiche
#' * Layout-Analysen
#'
#' @param form_model Ergebnis von [analyze_form()].
#'
#' @return Tibble mit den Spalten:
#'
#' * `Parent` — Übergeordnetes Control
#'   (`TabPage`, `Group` oder `Grid`)
#' * `Group` — Technischer Name der Gruppe
#' * `Path` — Vollständiger Pfad im Formular
#'
#' @details
#' Die Funktion analysiert Controls vom Typ `Group`.
#'
#' Der Parent kann dabei ein `TabPage`, eine `Group`
#' oder ein `Grid` sein.
#'
#' @seealso [analyze_form()], [extract_form_controls_by_type()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#' extract_form_groups(form_model)
#' }
#'
#' @export
extract_form_groups <- function(form_model) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # GROUPS ERMITTELN
  # ================================

  groups <-
    extract_form_controls_by_type(form_model, "Group")

  # ================================
  # LEERES MODELL
  # ================================

  if (nrow(groups) == 0) {
    return(empty_form_groups())
  }

  # ================================
  # FACHMODELL ERSTELLEN
  # ================================

  result <-
    groups |>
    dplyr::transmute(
      Parent,
      Group = Name,
      Path
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
