#' DataSource-Beziehungen extrahieren
#'
#' Extrahiert die DataSource-Struktur
#' eines analysierten D365FO Formulars.
#'
#' Die Funktion liefert eine vereinfachte
#' Sicht auf die DataSources eines
#' Formulars und deren Beziehungen.
#'
#' Enthalten sind:
#'
#' * DataSource
#' * Tabelle
#' * Parent DataSource
#' * Join Source
#'
#' Die Funktion dient als Grundlage für:
#'
#' * Formular-Dokumentationen
#' * Release-Vergleiche
#' * Grid-Analysen
#' * Berechtigungsanalysen
#'
#' @param form_model Ergebnis von
#' analyze_form().
#'
#' @return Tibble mit:
#'
#' * DataSource
#' * Table
#' * ParentDataSource
#' * JoinSource
#'
#' @details
#' Formulare besitzen nicht zwingend
#' DataSources.
#'
#' Beispielsweise enthalten viele
#' Dialog-Formulare ausschließlich
#' Controls und keine DataSources.
#'
#' In diesem Fall wird ein leeres
#' DataSource-Modell zurückgegeben.
#'
#' @examples
#' extract_form_datasource_relations(
#'   form_model
#' )
#'
#' @export
extract_form_datasource_relations <- function(
    form_model){

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if(!inherits(form_model,"D365FormModel")){

    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # LEERES DATASOURCE MODELL
  # ================================

  if(nrow(form_model$DataSources) == 0){

    return(
      empty_form_datasources()
    )

  }

  # ================================
  # DATASOURCE MODELL ERSTELLEN
  # ================================

  result <-

    form_model$DataSources |>

    dplyr::select(
      DataSource = Name,
      Table,
      ParentDataSource,
      JoinSource
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)

}
