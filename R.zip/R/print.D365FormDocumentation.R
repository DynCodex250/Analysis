#' Print D365 form documentation
#'
#' Prints a compact summary of a
#' \code{D365FormDocumentation} object.
#'
#' The summary contains the form name and
#' the number of extracted objects for every
#' supported form component.
#'
#' @param x A
#'   \code{D365FormDocumentation}
#'   object.
#'
#' @param ... Additional arguments passed to
#'   other print methods. Currently ignored.
#'
#' @return Invisibly returns the supplied
#'   \code{D365FormDocumentation} object.
#'
#' @details
#' This method is intended for interactive
#' inspection of generated form
#' documentation. Only aggregate counts are
#' displayed, making it suitable as a quick
#' overview before further analysis.
#'
#' @examples
#' \dontrun{
#'
#' documentation <-
#'   analyze_form(
#'     xml_document
#'   )
#'
#' print(documentation)
#'
#' }
#'
#' @export
print.D365FormDocumentation <- function(
    x,
    ...){

  cat("\n")

  cat(
    "Form: ",
    x$Metadata$Name,
    "\n\n",
    sep = ""
  )

  cat(
    "DataSources      : ",
    nrow(x$DataSources),
    "\n",
    sep = ""
  )

  cat(
    "Grids            : ",
    nrow(x$Grids),
    "\n",
    sep = ""
  )

  cat(
    "ReferenceGroups  : ",
    nrow(x$ReferenceGroups),
    "\n",
    sep = ""
  )

  cat(
    "ActionButtons    : ",
    nrow(x$ActionPaneButtons),
    "\n",
    sep = ""
  )

  cat(
    "Tabs             : ",
    nrow(x$TabStructure),
    "\n",
    sep = ""
  )

  cat(
    "Groups           : ",
    nrow(x$Groups),
    "\n",
    sep = ""
  )

  cat(
    "StaticTexts      : ",
    nrow(x$StaticTexts),
    "\n",
    sep = ""
  )

  cat(
    "Parts            : ",
    nrow(x$Parts),
    "\n",
    sep = ""
  )

  cat(
    "Fields           : ",
    nrow(x$Fields),
    "\n",
    sep = ""
  )

  cat(
    "MenuItems        : ",
    nrow(x$MenuItems),
    "\n",
    sep = ""
  )

  cat("\n")

  invisible(x)
}
