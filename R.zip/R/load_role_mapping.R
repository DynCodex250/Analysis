#' WIBU-Rollenmapping laden
#'
#' Liest alle WIBU-Rollen aus SECURITYROLE
#' und erzeugt eine Zuordnungstabelle
#' zwischen Dev-Rollen (AOT/Visual Studio)
#' und Config-Rollen (UI-erstellt).
#'
#' Unterscheidung:
#'
#' \describe{
#'   \item{Dev-Rolle}{
#'   AOTNAME enthält "WIBU".
#'   Technischer Identifier, leicht lesbar.
#'   Rollenname enthält optional ein Suffix
#'   in Klammern (z.B. "(\_WIBU\_Fibu\_Finanzbuchhaltung)").
#'   }
#'   \item{Config-Rolle}{
#'   AOTNAME enthält kein "WIBU",
#'   aber NAME enthält "WIBU".
#'   Identifier ist ein GUID oder
#'   systemgenerierter alphanumerischer Wert.
#'   }
#' }
#'
#' Mapping-Logik:
#'
#' Der Rollenname der Dev-Rolle wird bereinigt
#' (Klammer-Suffix entfernt) und mit dem
#' unveränderten Namen der Config-Rolle verglichen.
#'
#' Das Ergebnis enthält alle Kombinationen (FULL OUTER JOIN):
#'
#' * Zeilen mit beiden Werten = vollständige Matches
#' * Zeilen mit NA in CONFIDENT = Dev-Rolle ohne Config-Entsprechung
#' * Zeilen mit NA in DEVIDENT = Config-Rolle ohne Dev-Entsprechung
#'
#' @param connection DBI-Verbindung zur D365FO-Datenbank.
#'
#' @return Tibble mit vier Spalten:
#'
#' \describe{
#'   \item{CONFIDENT}{AOTNAME der Config-Rolle (NA wenn kein Match).}
#'   \item{CONFROLE}{Anzeigename der Config-Rolle (NA wenn kein Match).}
#'   \item{DEVIDENT}{AOTNAME der Dev-Rolle (NA wenn kein Match).}
#'   \item{DEVROLE}{Anzeigename der Dev-Rolle (NA wenn kein Match).}
#' }
#'
#' @details
#' Aus dem Ergebnis lassen sich fünf Untermengen ableiten:
#'
#' \preformatted{
#' mapping      <- filter(mapping_full, !is.na(CONFIDENT), !is.na(DEVIDENT))
#' dev_only     <- filter(mapping_full,  is.na(CONFIDENT))
#' config_only  <- filter(mapping_full,  is.na(DEVIDENT))
#' dev_mapping  <- filter(mapping_full, !is.na(DEVIDENT))
#' config_mapping <- filter(mapping_full, !is.na(CONFIDENT))
#' }
#'
#' `mapping` (nur vollständige Matches) wird als `roleMapping`-Argument
#' an `compare_all_roles()` übergeben.
#'
#' @examples
#' \dontrun{
#'
#' mapping <- load_role_mapping(connection)
#'
#' mapping
#'
#' compare_all_roles(
#'   roleMapping   = mapping,
#'   ConfigFolder  = "path/to/ConfigRoles",
#'   DevFolder     = "path/to/DevRoles",
#'   outputFile    = "RoleComparison.xlsx"
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{compare_all_roles}}
#' \code{\link{compare_security_roles}}
#'
#' @export

load_role_mapping <- function(connection) {

  sql <- "
WITH BaseRoles AS (
    SELECT
        SR.AOTNAME,
        SR.NAME
    FROM SECURITYROLE SR
),

ConfigRoles AS (
    SELECT
        AOTNAME AS CONFIDENT,
        NAME    AS CONFROLE,
        NAME    AS NAME2
    FROM BaseRoles
    WHERE AOTNAME NOT LIKE '%WIBU%'
      AND NAME     LIKE '%WIBU%'
),

DevRoles AS (
    SELECT
        AOTNAME AS DEVIDENT,
        NAME    AS DEVROLE,
        LTRIM(RTRIM(
            CASE
                WHEN CHARINDEX('(', NAME) > 0
                THEN LEFT(NAME, CHARINDEX('(', NAME) - 1)
                ELSE NAME
            END
        )) AS NAME2
    FROM BaseRoles
    WHERE AOTNAME LIKE '%WIBU%'
),

Mapping AS (
    SELECT
        c.CONFIDENT,
        c.CONFROLE,
        d.DEVIDENT,
        d.DEVROLE
    FROM ConfigRoles c
    FULL OUTER JOIN DevRoles d
        ON d.NAME2 = c.NAME2
)

SELECT *
FROM Mapping
ORDER BY COALESCE(CONFROLE, DEVROLE) ASC
"

  result <- DBI::dbGetQuery(connection, sql)

  tibble::as_tibble(result)

}
