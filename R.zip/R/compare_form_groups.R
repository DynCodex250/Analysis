#' Compare form groups between two D365FO form documentations
#'
#' Compares the Groups section of two
#' \code{D365FormDocumentation} objects and identifies
#' added and removed form groups.
#'
#' The comparison is performed using the combination
#' of group name and path to ensure that renamed or
#' relocated groups are detected correctly.
#'
#' @param old_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the original version.
#'
#' @param new_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the modified version.
#'
#' @return A list containing:
#' \describe{
#'   \item{Added}{
#'     Groups that exist only in the new documentation.
#'   }
#'   \item{Removed}{
#'     Groups that exist only in the old documentation.
#'   }
#' }
#'
#' @details
#' The function compares the
#' \code{Groups} tables of two
#' \code{D365FormDocumentation} objects.
#'
#' The comparison uses the columns:
#'
#' \itemize{
#'   \item Group
#'   \item Path
#' }
#'
#' These two attributes uniquely identify a form group
#' within a form hierarchy.
#'
#' Typical use cases:
#'
#' \itemize{
#'   \item Detect added form groups after an update.
#'   \item Detect removed form groups.
#'   \item Support regression testing.
#'   \item Compare different application versions.
#' }
#'
#' @examples
#' \dontrun{
#'
#' comparison <-
#'   compare_form_groups(
#'     old_documentation,
#'     new_documentation
#'   )
#'
#' comparison$Added
#'
#' comparison$Removed
#'
#' }
#'
#' @export
compare_form_groups <- function(
    old_documentation,
    new_documentation
) {
  
  #===========================================================
  # VALIDATION
  #===========================================================
  
  if (!inherits(
    old_documentation,
    "D365FormDocumentation"
  )) {
    stop(
      "old_documentation must be a D365FormDocumentation object."
    )
  }
  
  if (!inherits(
    new_documentation,
    "D365FormDocumentation"
  )) {
    stop(
      "new_documentation must be a D365FormDocumentation object."
    )
  }
  
  #===========================================================
  # LOAD GROUPS
  #===========================================================
  
  old_groups <-
    old_documentation$Groups
  
  new_groups <-
    new_documentation$Groups
  
  #===========================================================
  # ADDED GROUPS
  #===========================================================
  
  added <-
    
    dplyr::anti_join(
      new_groups,
      old_groups,
      by = c(
        "Group",
        "Path"
      )
    )
  
  #===========================================================
  # REMOVED GROUPS
  #===========================================================
  
  removed <-
    
    dplyr::anti_join(
      old_groups,
      new_groups,
      by = c(
        "Group",
        "Path"
      )
    )
  
  #===========================================================
  # RESULT
  #===========================================================
  
  return(
    list(
      Added = added,
      Removed = removed
    )
  )
  
}