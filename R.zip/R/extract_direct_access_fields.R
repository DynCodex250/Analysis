#' Direct Access Felder extrahieren
#'
#' Extrahiert sämtliche Feldberechtigungen innerhalb
#' von Direct Access Permissions.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit allen Direct Access Feldern.
#'
#' @details
#' Die Funktion liest alle Feldberechtigungen aus
#' DirectAccessPermissions.
#'
#' Leere Ergebnisse werden als Tibble mit definierter
#' Struktur zurückgegeben.
#'
#' @seealso
#' parse_privilege()
#' extract_direct_access_permissions()
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#'
#' fields <-
#'   extract_direct_access_fields(
#'     xml_doc
#'   )
#' }
#'
#' @export
extract_direct_access_fields <- function(xml_doc) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # =========================================
  # FELDER EXTRAHIEREN
  # =========================================

  field_nodes <- xml2::xml_find_all(
    xml_doc,
    "//DirectAccessPermissions//Fields/*"
  )

  result <- purrr::map_dfr(field_nodes, function(field_node) {

    parent_permission <- xml2::xml_parent(
      xml2::xml_parent(field_node)
    )

    grant_node <- xml2::xml_find_first(
      field_node,
      "./Grant"
    )

    tibble::tibble(
      ParentObject = xml2::xml_text(
        xml2::xml_find_first(parent_permission, "./Name")
      ),

      ParentXmlNode = xml2::xml_name(parent_permission),

      FieldName = xml2::xml_text(
        xml2::xml_find_first(field_node, "./Name")
      ),

      Read = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Read")
      ),

      Create = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Create")
      ),

      Update = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Update")
      ),

      Delete = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Delete")
      ),

      Correct = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Correct")
      ),

      Invoke = xml2::xml_text(
        xml2::xml_find_first(grant_node, "./Invoke")
      )
    )
  })

  # =========================================
  # LEERE STRUKTUR ABSICHERN
  # =========================================

  if (ncol(result) == 0) {
    result <- empty_direct_access_fields()
  }

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}
