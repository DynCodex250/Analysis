#' Formular durchsuchen
#'
#' Durchsucht eine D365FO-Formulardokumentation nach einem Suchbegriff
#' und liefert passende Formularobjekte zurück.
#'
#' Die Funktion unterstützt die Suche in folgenden Bereichen:
#'
#' - Data Sources
#' - Reference Groups
#' - Grids
#' - Action Pane Buttons
#' - Tabs
#' - Gruppen
#' - Static Texts
#' - Buttons
#' - Parts
#' - Menu Items
#'
#' @param documentation Objekt der Klasse `D365FormDocumentation`.
#' @param search_text Suchbegriff. Wird keiner angegeben, werden alle
#'   Objekte zurückgegeben.
#' @param type Optionaler Objekttyp.
#' @param details Soll die vollständige Objektstruktur zurückgegeben werden?
#'
#' @return Tibble mit Treffern oder bei `details = TRUE`
#' das vollständige Fachmodell des gewählten Objekttyps.
#'
#' @details
#' Unterstützte Typen:
#' DataSource, ReferenceGroup, Grid, ActionButton,
#' Tab, Group, StaticText, Button, Part und MenuItem.
#'
#' @examples
#' \dontrun{
#' search_form(documentation, "Invoice")
#' search_form(documentation, "Invoice", type = "ActionButton")
#' search_form(documentation, type = "MenuItem")
#' }
#'
#' @export
search_form <- function(documentation,
                        search_text,
                        type = NULL,
                        details = FALSE) {
  # ================================
  #   EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(documentation, "D365FormDocumentation")) {
    stop("documentation muss ein D365FormDocumentation sein.")

  }

  if (details && is.null(type)) {
    stop("details = TRUE erfordert die Angabe von type.")

  }

  # ================================
  #   SUCHBEGRIFF NORMALISIEREN
  # ================================

  if (missing(search_text) || is.null(search_text)) {
    search_text <- ""

  }

  show_all <- search_text == ""

  # Ensure all documentation components are non-null and have expected columns
  for (name in c("DataSources", "ReferenceGroups", "Grids", "ActionPaneButtons",
                 "TabStructure", "Groups", "StaticTexts", "Buttons", "Parts", "MenuItems")) {
    if (is.null(documentation[[name]]) || nrow(documentation[[name]]) == 0) {
      if (name == "ReferenceGroups") {
        documentation[[name]] <- tibble::tibble(Name = character(0), ReferenceField = character(0), Path = character(0))
      } else if (name == "DataSources") {
        documentation[[name]] <- tibble::tibble(DataSource = character(0), Table = character(0), ParentDataSource = character(0))
      } else if (name == "Grids") {
        documentation[[name]] <- tibble::tibble(GridName = character(0), DataSource = character(0), Path = character(0))
      } else if (name == "ActionPaneButtons") {
        documentation[[name]] <- tibble::tibble(Button = character(0), MenuItemName = character(0), NeededPermission = character(0), Path = character(0))
      } else if (name == "TabStructure") {
        documentation[[name]] <- tibble::tibble(Tab = character(0), TabPage = character(0), Path = character(0))
      } else if (name == "Groups") {
        documentation[[name]] <- tibble::tibble(Group = character(0), Path = character(0))
      } else if (name == "StaticTexts") {
        documentation[[name]] <- tibble::tibble(StaticText = character(0), Path = character(0))
      } else if (name == "Buttons") {
        documentation[[name]] <- tibble::tibble(Name = character(0), ButtonType = character(0), MenuItemName = character(0), NeededPermission = character(0), Path = character(0))
      } else if (name == "Parts") {
        documentation[[name]] <- tibble::tibble(Name = character(0), MenuItemName = character(0), PartType = character(0))
      } else if (name == "MenuItems") {
        documentation[[name]] <- tibble::tibble(MenuItemName = character(0), MenuItemType = character(0), Path = character(0))
      }
    }
  }

  # ================================
  #   REFERENCE GROUPS
  # ================================

  reference_groups <- if (show_all) {
    documentation$ReferenceGroups
  } else{
    documentation$ReferenceGroups |> dplyr::filter(
      stringr::str_detect(
        Name, stringr::regex(search_text, ignore_case = TRUE))
      |
        stringr::str_detect(
          ReferenceField,
          stringr::regex(search_text, ignore_case = TRUE)
        )
    )
  }

  # ================================
  #   DATA SOURCES
  # ================================

  datasources <-

    if (show_all) {
      documentation$DataSources
    } else{
      documentation$DataSources |>

        dplyr::filter(
          stringr::str_detect(
            DataSource,
            stringr::regex(search_text, ignore_case = TRUE)
          )
          |

            stringr::str_detect(
              Table, stringr::regex(search_text, ignore_case = TRUE))
          |

            stringr::str_detect(
              ParentDataSource,
              stringr::regex(search_text, ignore_case = TRUE)
            )
        )
    }

  # ================================
  #   GRIDS
  # ================================

  grids <- if (show_all) {
    documentation$Grids

  } else{
    documentation$Grids |>
      dplyr::filter(
        stringr::str_detect(
          GridName, stringr::regex(search_text, ignore_case = TRUE))
        |
          stringr::str_detect(
            DataSource,
            stringr::regex(search_text, ignore_case = TRUE)
          )
      )
  }

  # ================================
  #   ACTION BUTTONS
  # ================================

  buttons <- if (show_all) {
    documentation$ActionPaneButtons

  } else {
    documentation$ActionPaneButtons |>
      dplyr::filter(
        stringr::str_detect(
          Button, stringr::regex(search_text, ignore_case = TRUE))
        |
          stringr::str_detect(
            MenuItemName,
            stringr::regex(search_text, ignore_case = TRUE)
          )
      )
  }

  # ================================
  #   TABS
  # ================================

  tabs <-

    if (show_all) {
      documentation$TabStructure

    } else {
      documentation$TabStructure |>

        dplyr::filter(
          stringr::str_detect(
            Tab,
            stringr::regex(search_text, ignore_case = TRUE))
          |
            stringr::str_detect(
              TabPage,
              stringr::regex(search_text, ignore_case = TRUE))
        )
    }

  # ================================
  #   GROUPS
  # ================================

  groups <- if (show_all) {
    documentation$Groups

  } else {
    documentation$Groups |>

      dplyr::filter(
        stringr::str_detect(
          Group,
          stringr::regex(search_text, ignore_case = TRUE)))
  }

  # ================================
  #   STATIC TEXTS
  # ================================

  static_texts <-

    if (show_all) {
      documentation$StaticTexts

    } else {
      documentation$StaticTexts |>

        dplyr::filter(stringr::str_detect(
          StaticText,
          stringr::regex(
            search_text,
            ignore_case = TRUE)
        ))

    }

  # ================================
  #   BUTTONS
  # ================================

  buttons_all <-

    if (show_all) {
      documentation$Buttons

    } else {
      documentation$Buttons |>

        dplyr::filter(
          stringr::str_detect(
            Name,
            stringr::regex(search_text, ignore_case = TRUE))

          |

            stringr::str_detect(
              ButtonType,
              stringr::regex(search_text, ignore_case = TRUE)
            )

          |

            stringr::str_detect(
              MenuItemName,
              stringr::regex(search_text, ignore_case = TRUE)
            )

          |

            stringr::str_detect(
              NeededPermission,
              stringr::regex(search_text, ignore_case = TRUE)
            )

        )
    }

  # ================================
  #   MENU ITEMS
  # ================================

  menu_items <- if (show_all) {
    documentation$MenuItems

  } else {
    documentation$MenuItems |>
      dplyr::filter(
        stringr::str_detect(
          MenuItemName,
          stringr::regex(search_text, ignore_case = TRUE)
        )
        |
          stringr::str_detect(
            MenuItemType,
            stringr::regex(search_text, ignore_case = TRUE)
          )
      )

  }

  # ================================
  #   PARTS
  # ================================

  parts <-

    if (show_all) {
      documentation$Parts

    } else {
      documentation$Parts |>

        dplyr::filter(
          stringr::str_detect(
            Name,
            stringr::regex(search_text, ignore_case = TRUE))
          |
            stringr::str_detect(
              MenuItemName,
              stringr::regex(search_text, ignore_case = TRUE)
            )
          |
            stringr::str_detect(
              PartType,
              stringr::regex(search_text, ignore_case = TRUE))
        )
    }

  # ================================
  #   DETAILANSICHT
  # ================================

  if (details) {
    if (type == "DataSource") {
      return(datasources)
    }

    if (type == "ReferenceGroup") {
      return(reference_groups)

    }

    if (type == "Grid") {
      return(grids)

    }

    if (type == "ActionButton") {
      return(buttons)

    }

    if (type == "Tab") {
      return(tabs)

    }

    if (type == "Group") {
      return(groups)

    }

    if (type == "StaticText") {
      return(static_texts)

    }

    if (type == "Part") {
      return(parts)

    }

    if (type == "Button") {
      return(buttons_all)

    }

    if (type == "MenuItem") {
      return(menu_items)

    }

    stop("Ungültiger type.")

  }

  # ================================
  #   STANDARDANSICHT
  # ================================

  datasources <- datasources |> dplyr::transmute(
    ObjectType = "DataSource",
    Name = DataSource,
    Path = NA_character_,
    Source = "DataSources"
  )

  reference_groups <- reference_groups |>
    dplyr::transmute(
      ObjectType = "ReferenceGroup",
      Name,
      Path,
      Source = "ReferenceGroups")

  grids <- grids |>
    dplyr::transmute(
      ObjectType = "Grid",
      Name = GridName,
      Path,
      Source = "Grids")

  buttons <- buttons |>
    dplyr::transmute(
      ObjectType = "ActionButton",
      Name = Button,
      Path,
      Source = "ActionPaneButtons")

  tabs <- tabs |>
    dplyr::transmute(
      ObjectType = "Tab",
      Name = TabPage,
      Path,
      Source = "TabStructure")

  groups <- groups |>
    dplyr::transmute(
      ObjectType = "Group",
      Name = Group,
      Path,
      Source = "Groups")

  static_texts <- static_texts |>
    dplyr::transmute(
      ObjectType = "StaticText",
      Name = StaticText,
      Path,
      Source = "StaticTexts")

  buttons_all <- buttons_all |>
    dplyr::transmute(
      ObjectType = "Button",
      Name,
      Path,
      Source = "Buttons")

  parts <- parts |>
    dplyr::transmute(
      ObjectType = "Part",
      Name,
      Path = NA_character_,
      Source = "Parts")

  menu_items <- menu_items |>
    dplyr::transmute(
      ObjectType = "MenuItem",
      Name = MenuItemName,
      Path,
      Source = "MenuItems")

  # ================================
  #   ERGEBNIS ZUSAMMENFÜHREN
  # ================================

  result <-

    dplyr::bind_rows(
      datasources,
      reference_groups,
      grids,
      buttons,
      tabs,
      groups,
      static_texts,
      buttons_all,
      parts,
      menu_items
    )

  # ================================
  #   TYPFILTER
  # ================================

  if (!is.null(type)) {
    result <-
      result |>
      dplyr::filter(ObjectType == type)

  }

  # ================================
  #   ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
