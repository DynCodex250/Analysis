#' D365FO Privilege XML erzeugen
#'#' Erzeugt aus einem Privilege-Modell
#' eine D365FO Privilege XML-Datei.
#'#' @param privilege_model Ergebnis von parse_privilege()
#' @param output_file Zielpfad
#'#' @return Pfad zur erzeugten XML-Datei
#'#' @export

generate_privilege_xml <- function(privilege_model,output_file){

  # =====================================
  #   ROOT
  # =====================================

    root <- xml2::xml_new_root("AxSecurityPrivilege")

  xml2::xml_set_attr(root,"xmlns:i","http://www.w3.org/2001/XMLSchema-instance")

  # =====================================
  #   METADATA
  # =====================================

    xml2::xml_add_child(root,"Name",privilege_model$Metadata$Name[1])

  if("Description" %in%names(privilege_model$Metadata)){

    description_value <-
      privilege_model$
      Metadata$
      Description[1]

    if(
      !is.na(description_value) &&
      nzchar(description_value)
    ){

      xml2::xml_add_child(
        root,
        "Description",
        description_value
      )
    }

  }

  label_value <-privilege_model$Metadata$Label[1]

  if(!is.na(label_value) &&nzchar(label_value)){

    xml2::xml_add_child(
      root,
      "Label",
      label_value
    )

  }

  # =====================================
  #   DATA ENTITY PERMISSIONS
  # =====================================

    entity_root <-xml2::xml_add_child(root,"DataEntityPermissions")

  if(nrow(privilege_model$DataEntityPermissions) > 0){

    for(
      i in seq_len(
        nrow(privilege_model$DataEntityPermissions))){

      entity_node <-
        xml2::xml_add_child(
          entity_root,
          "AxSecurityDataEntityPermission"
        )

      # ==========================
      # GRANT
      # ==========================

      print("ENTITY")

      print(privilege_model$DataEntityPermissions[i, ])

      grant_node <-
        xml2::xml_add_child(
          entity_node,
          "Grant"
        )

      permissions <- get_grant_order()

      for(permission in permissions){

        permission_value <-
          privilege_model$
          DataEntityPermissions[
            i,
            permission
          ][[1]]

        print(permission)

        print(permission_value)

        if(
          !is.na(permission_value) &&
          permission_value != ""
        ){

          xml2::xml_add_child(
            grant_node,
            permission,
            permission_value
          )
        }
      }

      # ==========================
      # INTEGRATION
      # ==========================

      integration_mode <-
        privilege_model$
        DataEntityPermissions$
        IntegrationMode[i]

      if(
        !is.na(integration_mode) &&
        nzchar(integration_mode)
      ){

        xml2::xml_add_child(
          entity_node,
          "IntegrationMode",
          integration_mode
        )
      }

      # ==========================
      # NAME
      # ==========================

      xml2::xml_add_child(
        entity_node,
        "Name",
        privilege_model$
          DataEntityPermissions$
          EntityName[i]
      )

      # ==========================
      # FIELDS
      # ==========================

      xml2::xml_add_child(
        entity_node,
        "Fields"
      )

      # ==========================
      # METHODS
      # ==========================

      methods_node <-
        xml2::xml_add_child(
          entity_node,
          "Methods"
        )

      entity_methods <-
        privilege_model$
        DataEntityMethods

      if(nrow(entity_methods) > 0){

        entity_methods <-
          entity_methods[
            entity_methods$
              EntityName ==
              privilege_model$
              DataEntityPermissions$
              EntityName[i],]

        if(nrow(entity_methods) > 0){

          for(
            j in seq_len(
              nrow(entity_methods))){

            method_node <-
              xml2::xml_add_child(
                methods_node,
                "AxSecurityDataEntityMethodPermission")

            method_grant <-
              xml2::xml_add_child(
                method_node,
                "Grant")

            for(permission in permissions){

              permission_value <-
                entity_methods[
                  j,
                  permission
                ][[1]]

              if(
                !is.na(permission_value) &&
                permission_value != ""
              ){

                xml2::xml_add_child(
                  method_grant,
                  permission,
                  permission_value
                )
              }
            }

            xml2::xml_add_child(
              method_node,
              "Name",
              entity_methods$
                MethodName[j]
            )
          }
        }
      }
    }

  }

  # =====================================
  #   DIRECT ACCESS
  # =====================================

    direct_root <-xml2::xml_add_child(root,"DirectAccessPermissions")

  if(nrow(privilege_model$DirectAccessPermissions) > 0){

    for(
      i in seq_len(
        nrow(privilege_model$
             DirectAccessPermissions)
      )){

      node <-
        xml2::xml_add_child(
          direct_root,
          privilege_model$
            DirectAccessPermissions$
            XmlNode[i])

      grant_names <- get_grant_order()

      grant_values <-
        unlist(
          privilege_model$
            DirectAccessPermissions[
              i,
              grant_names])

      has_grant <-
        any(
          !is.na(grant_values) &
            grant_values != "")

      if(has_grant){

        grant_node <-
          xml2::xml_add_child(
            node,
            "Grant"
          )

        for(grant_name in grant_names){

          grant_value <-
            privilege_model$
            DirectAccessPermissions[
              i,
              grant_name
            ][[1]]

          if(
            !is.na(grant_value) &&
            nzchar(grant_value)){

            xml2::xml_add_child(
              grant_node,
              grant_name,
              grant_value)
          }
        }
      }

      xml2::xml_add_child(
        node,
        "Name",
        privilege_model$
          DirectAccessPermissions$
          ObjectName[i])

      fields_root <-
        xml2::xml_add_child(
          node,
          "Fields")

      field_rows <-
        privilege_model$
        DirectAccessFields |>
        dplyr::filter(
          ParentObject ==
            privilege_model$
            DirectAccessPermissions$
            ObjectName[i])

      if(nrow(field_rows) > 0){

        for(j in seq_len(nrow(field_rows))){

          field_node <-
            xml2::xml_add_child(
              fields_root,
              "AxSecurityDataEntityFieldReference"
            )

          xml2::xml_add_child(
            field_node,
            "Name",
            field_rows$FieldName[j])

          grant_node <-
            xml2::xml_add_child(
              field_node,
              "Grant")

          grant_names <- get_grant_order()

          for(grant_name in grant_names){

            grant_value <-
              field_rows[[grant_name]][j]

            if(!is.na(grant_value) &&
               nzchar(grant_value)){

              xml2::xml_add_child(
                grant_node,
                grant_name,
                grant_value)
            }
          }
        }

      } else {

        xml2::xml_add_child(
          node,
          "Fields")
      }

    }

  }

  # =====================================
  #   ENTRYPOINTS
  # =====================================

    entry_root <-xml2::xml_add_child(root,"EntryPoints")

  if(nrow(privilege_model$EntryPoints) > 0){

    permissions <- get_grant_order()

    for(i in seq_len(
      nrow(
        privilege_model$
        EntryPoints))){

      node <-
        xml2::xml_add_child(
          entry_root,
          "AxSecurityEntryPointReference")

      xml2::xml_add_child(
        node,
        "Name",
        privilege_model$
          EntryPoints$
          Name[i])

      grant_node <-
        xml2::xml_add_child(
          node,
          "Grant")

      for(permission in permissions){

        permission_value <-
          privilege_model$
          EntryPoints[
            i,
            permission
          ][[1]]

        if(
          !is.na(permission_value) &&
          permission_value != ""){

          xml2::xml_add_child(
            grant_node,
            permission,
            permission_value)
        }
      }

      object_child_name <-
        privilege_model$
        EntryPoints$
        ObjectChildName[i]

      if(!is.na(object_child_name) &&
         nzchar(object_child_name)){

        xml2::xml_add_child(
          node,
          "ObjectChildName",
          object_child_name
        )

      }

      xml2::xml_add_child(
        node,
        "ObjectName",
        privilege_model$
          EntryPoints$
          ObjectName[i])

      xml2::xml_add_child(
        node,
        "ObjectType",
        privilege_model$
          EntryPoints$
          ObjectType[i])

      # =====================================
      # FORMS
      # =====================================

      entry_forms <-
        privilege_model$
        EntryPointForms |>
        dplyr::filter(
          EntryPointName ==
            privilege_model$
            EntryPoints$
            Name[i]
        )

      has_forms <-
        privilege_model$
        EntryPoints$
        HasForms[i]

      if(isTRUE(has_forms)){

        forms_root <-
          xml2::xml_add_child(
            node,
            "Forms"
          )

        for(j in seq_len(nrow(entry_forms))){

          form_node <-
            xml2::xml_add_child(
              forms_root,
              "AxSecurityEntryPointReferenceForm"
            )

          xml2::xml_add_child(
            form_node,
            "Name",
            entry_forms$FormName[j]
          )

          # ==========================
          # CONTROLS
          # ==========================

          controls_root <-
            xml2::xml_add_child(
              form_node, "Controls")

          form_controls <-
            privilege_model$
            EntryPointControls |>
            dplyr::filter(
              EntryPointName ==entry_forms$EntryPointName[j] &
                FormName == entry_forms$FormName[j])

          if(nrow(form_controls) > 0){

            for(k in seq_len(nrow(form_controls))){

              control_node <-
                xml2::xml_add_child(
                  controls_root,
                  "AxSecurityEntryPointReferenceFormControl")


              control_grant <-
                xml2::xml_add_child(
                  control_node,"Grant")

              permissions <-get_grant_order()

              for(permission in permissions){

                permission_value <-
                  form_controls[
                    k,
                    permission
                  ][[1]]

                if(
                  !is.na(permission_value) &&
                  nzchar(permission_value)
                ){

                  xml2::xml_add_child(
                    control_grant,
                    permission,
                    permission_value
                  )
                }
              }

              xml2::xml_add_child(
                control_node,
                "Name",
                form_controls$
                  ControlName[k])

            }
          }

          # =====================================
          # DATASOURCES
          # =====================================

          if(ncol(privilege_model$EntryPointFormDataSources) > 0){

            form_datasources <-
              privilege_model$EntryPointFormDataSources |>
              dplyr::filter(
                EntryPointName == entry_forms$EntryPointName[j],
                FormName == entry_forms$FormName[j]
              )

          } else {

            form_datasources <- tibble::tibble()
          }

          datasources_root <-
            xml2::xml_add_child(
              form_node, "DataSources")

          if(nrow(form_datasources) > 0){

            for(k in seq_len(nrow(form_datasources))){

              datasource_node <-
                xml2::xml_add_child(
                  datasources_root,
                  "AxSecurityEntryPointReferenceFormDataSource")

              xml2::xml_add_child(
                datasource_node, "Name",
                form_datasources$DataSourceName[k])

              xml2::xml_add_child(
                datasource_node,
                "Fields")

            }

          }
        }
      }

    }

  }

  # =====================================
  #   FORM CONTROL OVERRIDES
  # =====================================

    overrides_root <-xml2::xml_add_child(root, "FormControlOverrides")

  if(nrow(privilege_model$FormControlOverrides) > 0){

    parent_forms <-
      unique(
        privilege_model$
          FormControlOverrides$
          ParentForm)

    for(parent_form in parent_forms){

      collection_node <-
        xml2::xml_add_child(
          overrides_root,
          "AxSecurityFormControlReferenceCollection")

      xml2::xml_add_child(
        collection_node,
        "Name", parent_form)

      controls_node <-
        xml2::xml_add_child(
          collection_node,
          "Controls")

      control_rows <-
        privilege_model$
        FormControlOverrides |>
        dplyr::filter(
          ParentForm == parent_form)

      for(i in seq_len(nrow(control_rows))){

        control_node <-
          xml2::xml_add_child(
            controls_node,
            "AxSecurityFormControlReference")

        xml2::xml_add_child(
          control_node,
          "Name",
          control_rows$
            ControlName[i])

        grant_node <-
          xml2::xml_add_child(
            control_node,
            "Grant")

        for(permission in get_grant_order()){

          permission_value <-
            control_rows[
              i,permission][[1]]

          if(!is.na(permission_value) &&
             nzchar(permission_value)){

            xml2::xml_add_child(
              grant_node,
              permission,
              permission_value)

          }

        }

      }

    }

  }

  # =====================================
  #   WRITE FILE
  # =====================================

    xml2::write_xml(root,output_file,options = "format")

  return(output_file)
}
