#' Benutzer-Rollen-Matrix erzeugen
#'
#' Erstellt eine Matrix für den
#' Fachbereich, die zeigt,
#' welche Benutzer welche
#' Sicherheitsrollen besitzen.
#'
#' Jede Zeile entspricht einem Benutzer.
#'
#' Jede Spalte entspricht einer Rolle.
#'
#' Der Wert "x" bedeutet,
#' dass die Rolle vorhanden ist.
#'
#' @param security_assignments Tibble.
#'
#' Erwartete Spalten:
#'
#' * USERID
#' * SECURITYROLEIDENTIFIER
#'
#' @return Tibble.
#'
#' @examples
#' \dontrun{
#' role_matrix <-
#'   create_role_matrix(
#'     security_assignments
#'   )
#' }
#'
#' @export
sec_create_role_matrix <- function(
  security_assignments
){
  #=============================================
  # VALIDIERUNG
  #=============================================
  required_columns <- c(
    "USERID",
    "SECURITYROLEIDENTIFIER"
  )
  
  missing_columns <- setdiff(
    required_columns,
    names(security_assignments)
  )
  
  if(length(missing_columns) > 0){
    stop(paste(
      "Folgende Spalten fehlen:",
      paste(missing_columns,
        collapse = ", ")
    ))
  }
  
  #=============================================
  # MATRIX AUFBAUEN
  #=============================================
  result <-
    security_assignments |>
    dplyr::distinct(
      USERID,
      SECURITYROLEIDENTIFIER
    ) |>
    dplyr::mutate(
      HasRole = "x"
    ) |>
    tidyr::pivot_wider(
      id_cols = USERID,
      names_from = SECURITYROLEIDENTIFIER,
      values_from = HasRole,
      values_fill = ""
    ) |>
    dplyr::arrange(
      USERID
    )
  
  return(result)
}
