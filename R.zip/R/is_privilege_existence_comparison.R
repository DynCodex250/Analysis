#' Prüfen ob ein Privilege-Existenzvergleich vorliegt#'#' Prüft, ob ein Objekt das Ergebnis eines#' compare_privileges_existence()-Aufrufs ist.#'#' Die Funktion dient zur Validierung von Eingabeobjekten#' innerhalb des D365Security-Pakets.#'#' Insbesondere wird sie von Reporting- und Exportfunktionen#' verwendet, um sicherzustellen, dass ein gültiges#' Existenzvergleichsobjekt übergeben wurde.#'#' @param x Zu prüfendes Objekt.#'#' @return TRUE wenn es sich um ein#' D365PrivilegeExistenceComparison handelt,#' ansonsten FALSE.#'#' @details#' Die Prüfung erfolgt über die Objektklasse.#'#' Erwartete Klasse:#'#' D365PrivilegeExistenceComparison#'#' @seealso#' compare_privileges_existence()#'#' @examples#' result <-#'   compare_privileges_existence(#'     privilege_a,#'     privilege_b#'   )#'#' is_privilege_existence_comparison(#'   result#' )#'#' @export
is_privilege_existence_comparison <- function(x){

  # ================================
  #   OBJEKT PRÜFEN
  # ================================

    result <-inherits(x,"D365PrivilegeExistenceComparison")

    # ================================
    #   ERGEBNIS ZURÜCKGEBEN
    # ================================

      return(result)

}
