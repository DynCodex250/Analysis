#' Duties in ein D365FO Security XML schreiben
#'
#' Schreibt referenzierte Duties in die XML-Struktur eines
#' D365FO Security-Objekts.
#'
#' Die Funktion erzeugt unterhalb des übergebenen XML-Knotens
#' einen `Duties`-Container und fügt für jede Duty einen
#' `AxSecurityDutyReference`-Knoten hinzu.
#'
#' Die erzeugte XML-Struktur entspricht dem von D365FO
#' verwendeten Security-Metadatenformat für referenzierte
#' Security Duties.
#'
#' Beispiel:
#'
#' \preformatted{
#' <Duties>
#'   <AxSecurityDutyReference>
#'     <Name>MaintainSalesOrders</Name>
#'   </AxSecurityDutyReference>
#'
#'   <AxSecurityDutyReference>
#'     <Name>MaintainPurchaseOrders</Name>
#'   </AxSecurityDutyReference>
#' </Duties>
#' }
#'
#' @param parent_node XML-Knoten, unterhalb dessen der
#'   `Duties`-Container erzeugt werden soll.
#'
#' @param duties Character-Vektor mit den Namen der
#'   referenzierten D365FO Security Duties.
#'
#' @return XML-Knoten vom Typ `Duties`.
#'
#' Bei leerem `duties`-Vektor wird lediglich ein leerer
#' `Duties`-Knoten erzeugt und zurückgegeben.
#'
#' @details
#' Die Funktion verändert die übergebene XML-Struktur direkt.
#'
#' Für jede Duty wird ein XML-Knoten der Form
#' `AxSecurityDutyReference` erzeugt.
#'
#' Die Funktion wird typischerweise beim Generieren von
#' D365FO Security-Rollen verwendet, beispielsweise innerhalb
#' von `create_d365fo_role_xml()`.
#'
#' @examples
#' \dontrun{
#'
#' root <- xml2::xml_new_root(
#'   "AxSecurityRole"
#' )
#'
#' write_duties(
#'   parent_node = root,
#'   duties = c(
#'     "MaintainSalesOrders",
#'     "MaintainPurchaseOrders"
#'   )
#' )
#'
#' }
#'
#' @export
write_duties <- function(
    parent_node,
    duties
) {

  # ================================
  # DUTY-CONTAINER ERZEUGEN
  # ================================

  duties_node <- xml2::xml_add_child(
    parent_node,
    "Duties"
  )

  # ================================
  # LEEREN CONTAINER ZURÜCKGEBEN
  # ================================

  if (length(duties) == 0) {

    return(duties_node)

  }

  # ================================
  # DUTIES HINZUFÜGEN
  # ================================

  for (duty in duties) {

    duty_ref <- xml2::xml_add_child(
      duties_node,
      "AxSecurityDutyReference"
    )

    xml2::xml_add_child(
      duty_ref,
      "Name",
      duty
    )

  }

  # ================================
  # XML-KNOTEN ZURÜCKGEBEN
  # ================================

  return(duties_node)

}
