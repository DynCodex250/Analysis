#' Tab-Struktur extrahieren
#'
#' Extrahiert die Beziehung zwischen
#' Tabs und TabPages eines D365FO
#' Formulars.
#'
#' Die Funktion dient als Grundlage für:
#'
#' * Formular-Dokumentationen
#' * Release-Vergleiche
#' * Navigationsanalysen
#'
#' @param form_model Ergebnis von
#' analyze_form().
#'
#' @return Tibble mit:
#'
#' * Tab
#' * TabPage
#' * Path
#'
#' @details
#' Die Funktion analysiert Controls
#' vom Typ TabPage.
#'
#' Der Parent eines TabPage Controls
#' entspricht dem übergeordneten Tab.
#'
#' @examples
#' extract_form_tab_structure(
#'   form_model
#' )
#'
#' @export
extract_form_tab_structure <- function(
    form_model){

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if(!inherits(
    form_model,
    "D365FormModel"
  )){

    stop(
      "form_model muss ein D365FormModel sein."
    )

  }

  # ================================
  # TAB PAGES ERMITTELN
  # ================================

  tab_pages <-

    extract_form_controls_by_type(
      form_model,
      "TabPage"
    )

  # ================================
  # LEERES MODELL
  # ================================

  if(nrow(tab_pages) == 0){

    return(
      empty_form_tab_structure()
    )

  }

  # ================================
  # FACHMODELL ERSTELLEN
  # ================================

  result <-

    tab_pages |>

    dplyr::transmute(
      Tab = Parent,
      TabPage = Name,
      Path = Path
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)

}
