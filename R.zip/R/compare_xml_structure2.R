#' D365FO XML-Dateien auf Textebene vergleichen
#'
#' Vergleicht zwei XML-Dateien zeilenweise als
#' Textdokumente und zeigt alle Unterschiede
#' zwischen beiden Dateien an.
#'
#' Die Funktion analysiert die tatsächliche
#' Textdarstellung der XML-Dateien.
#'
#' Dadurch werden auch Unterschiede erkannt,
#' die fachlich möglicherweise keine Auswirkung
#' haben, beispielsweise:
#'
#' - Tag-Reihenfolgen
#' - Einrückungen
#' - Leerzeilen
#' - Formatierungsunterschiede
#' - XML-Kommentare
#'
#' Die Funktion eignet sich insbesondere für:
#' - Roundtrip-Debugging
#' - XML-Generator-Tests
#' - Entwicklungszwecke
#' - Analyse von Formatierungsunterschieden
#'
#' @param original_xml Vollständiger Pfad zur
#'        Original-XML-Datei.
#'
#' @param generated_xml Vollständiger Pfad zur
#'        generierten XML-Datei.
#'
#' @return Ausgabe von `waldo::compare()`.
#'
#' @details
#' Beide XML-Dateien werden mittels
#' `readLines()` eingelesen und anschließend
#' zeilenweise verglichen.
#'
#' Die XML-Struktur wird dabei nicht interpretiert.
#'
#' Daher können auch Unterschiede gemeldet werden,
#' obwohl die fachliche XML-Struktur identisch ist.
#'
#' Für einen strukturellen XML-Vergleich sollte
#' `compare_xml_structure2()` verwendet werden.
#'
#' @seealso
#' compare_xml_structure2()
#' compare_xml_structure_notepad()
#'
#' @examples
#' compare_xml_structure1(
#'   original_xml = "Original.xml",
#'   generated_xml = "Roundtrip.xml"
#' )
#'
#' @export
compare_xml_structure1 <- function(
    original_xml,
    generated_xml
)
{

  # XML-Dateien einlesen
  original_lines <-
    readLines(
      original_xml,
      warn = FALSE
    )

  generated_lines <-
    readLines(
      generated_xml,
      warn = FALSE
    )

  # Unterschiede anzeigen
  waldo::compare(
    original_lines,
    generated_lines
  )
}




#' D365FO XML-Strukturen auf DOM-Ebene vergleichen
#'
#' Vergleicht zwei XML-Dateien auf Basis ihrer
#' XML-Dokumentstruktur (DOM).
#'
#' Die XML-Dateien werden eingelesen und in
#' verschachtelte Listenstrukturen umgewandelt.
#'
#' Anschließend erfolgt ein struktureller Vergleich
#' der XML-Hierarchie.
#'
#' Im Gegensatz zu `compare_xml_structure1()`
#' werden reine Formatierungsunterschiede
#' ignoriert.
#'
#' Die Funktion eignet sich insbesondere zur Analyse von:
#'
#' - Fehlenden XML-Knoten
#' - Zusätzlichen XML-Knoten
#' - Falschen Verschachtelungen
#' - Abweichenden XML-Hierarchien
#' - XML-Roundtrip-Problemen
#'
#' Typische Anwendungsfälle:
#' - Reverse Engineering
#' - XML-Generator-Validierung
#' - Regressionstests
#' - Strukturanalysen
#'
#' @param original_xml Vollständiger Pfad zur
#'        Original-XML-Datei.
#'
#' @param generated_xml Vollständiger Pfad zur
#'        generierten XML-Datei.
#'
#' @return Ausgabe von `waldo::compare()`.
#'
#' @details
#' Beide XML-Dateien werden zunächst mit
#' `xml2::read_xml()` eingelesen.
#'
#' Anschließend werden die XML-Dokumente mittels
#' `xml2::as_list()` in verschachtelte
#' Listenstrukturen überführt.
#'
#' Der Vergleich erfolgt auf Basis dieser
#' Strukturrepräsentation.
#'
#' Dadurch werden Unterschiede in der XML-Hierarchie
#' sichtbar, während reine Formatierungsunterschiede
#' typischerweise keine Rolle spielen.
#'
#' Für einen textbasierten Vergleich sollte
#' `compare_xml_structure1()` verwendet werden.
#'
#' @seealso
#' compare_xml_structure1()
#' compare_xml_structure_notepad()
#'
#' @examples
#' compare_xml_structure2(
#'   original_xml = "Original.xml",
#'   generated_xml = "Roundtrip.xml"
#' )
#'
#' @export
compare_xml_structure2 <- function(
    original_xml,
    generated_xml
)
{

  # XML laden
  original_doc <-
    xml2::read_xml(
      original_xml
    )

  generated_doc <-
    xml2::read_xml(
      generated_xml
    )

  # XML als verschachtelte Listen
  original_dom <-
    xml2::as_list(
      original_doc
    )

  generated_dom <-
    xml2::as_list(
      generated_doc
    )

  # Strukturen vergleichen
  waldo::compare(
    original_dom,
    generated_dom
  )
}
