#' WIBU Config-Rollen laden
#'
#' Lädt alle WIBU-Konfigurationsrollen aus SECURITYROLE.
#'
#' Eine Rolle gilt als Config-Rolle, wenn:
#'
#' * der Anzeigename WIBU enthält
#' * der technische Identifier kein WIBU enthält
#'
#' Config-Rollen werden in der D365FO-Sicherheitskonfiguration
#' über die Benutzeroberfläche erstellt.
#' Ihr AOTNAME ist ein GUID oder systemgenerierter Wert.
#'
#' @param connection DBI-Verbindung zur D365FO-Datenbank.
#'
#' @return Tibble mit drei Spalten:
#'
#' \describe{
#'   \item{AOTNAME}{Systemgenerierter Identifier (GUID o.ä.).}
#'   \item{NAME}{Anzeigename der Rolle.}
#'   \item{NAME2}{Identisch mit NAME — Join-Key für das Rollenmapping.}
#' }
#'
#' @details
#' Die Spalte NAME2 wird für den Join mit Dev-Rollen benötigt.
#' Bei Config-Rollen entspricht NAME2 dem unveränderten NAME,
#' da kein Klammer-Suffix vorhanden ist.
#'
#' @examples
#' \dontrun{
#'
#' config_roles <- load_config_roles(connection)
#'
#' }
#'
#' @seealso
#' \code{\link{load_dev_roles}}
#' \code{\link{load_role_mapping}}
#'
#' @export

load_config_roles <- function(connection) {

  sql <- "
SELECT
    SR.AOTNAME,
    SR.NAME,
    SR.NAME AS NAME2
FROM SECURITYROLE SR
WHERE SR.AOTNAME NOT LIKE '%WIBU%'
  AND SR.NAME    LIKE '%WIBU%'
ORDER BY SR.NAME ASC
"

  result <- DBI::dbGetQuery(connection, sql)

  tibble::as_tibble(result)

}
