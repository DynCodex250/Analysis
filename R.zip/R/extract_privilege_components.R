#' Privilege-Komponenten extrahieren
#'
#' Extrahiert die verschiedenen Security-Komponenten
#' eines D365FO Security Privileges.
#'
#' Die Funktion unterscheidet zwischen:
#'
#' * EntryPoints
#' * DataEntityPermissions
#' * DataEntityMethods
#' * DirectAccessPermissions
#'
#' @param xml_file Pfad zur Privilege XML-Datei.
#'
#' @return Benannte Liste mit den Komponenten:
#'
#' * `$EntryPoints` — Tibble mit EntryPoint-Referenzen
#'   (`XmlNode`, `ObjectType`, `ObjectName`, `Name`)
#' * `$DataEntityPermissions` — Tibble mit
#'   Data-Entity-Namen (`EntityName`)
#' * `$DataEntityMethods` — Tibble mit
#'   Methoden-Namen (`MethodName`)
#' * `$DirectAccessPermissions` — Tibble mit
#'   DirectAccess-Objekten (`XmlNode`, `ObjectName`)
#'
#' @seealso [parse_privilege()], [extract_entrypoints()]
#'
#' @examples
#' \dontrun{
#' components <- extract_privilege_components(xml_file)
#' components$EntryPoints
#' components$DataEntityPermissions
#' }
#'
#' @export
extract_privilege_components <- function(xml_file) {

  xml_doc <- xml2::read_xml(xml_file)

  # =====================================
  # ENTRYPOINTS
  # =====================================

  entrypoints <-
    xml2::xml_find_all(xml_doc, "//EntryPoints/*")

  entrypoint_df <-
    purrr::map_dfr(
      entrypoints,
      function(node) {
        tibble::tibble(
          XmlNode =
            xml2::xml_name(node),
          ObjectType =
            xml2::xml_text(
              xml2::xml_find_first(node, "./ObjectType")
            ),
          ObjectName =
            xml2::xml_text(
              xml2::xml_find_first(node, "./ObjectName")
            ),
          Name =
            xml2::xml_text(
              xml2::xml_find_first(node, "./Name")
            )
        )
      }
    )

  # =====================================
  # DATA ENTITIES
  # =====================================

  entities <-
    xml2::xml_find_all(
      xml_doc,
      "//DataEntityPermissions/AxSecurityDataEntityPermission"
    )

  entity_df <-
    purrr::map_dfr(
      entities,
      function(node) {
        tibble::tibble(
          EntityName =
            xml2::xml_text(
              xml2::xml_find_first(node, "./Name")
            )
        )
      }
    )

  # =====================================
  # METHODS
  # =====================================

  methods <-
    xml2::xml_find_all(
      xml_doc,
      "//Methods/AxSecurityDataEntityMethodPermission"
    )

  method_df <-
    purrr::map_dfr(
      methods,
      function(node) {
        tibble::tibble(
          MethodName =
            xml2::xml_text(
              xml2::xml_find_first(node, "./Name")
            )
        )
      }
    )

  # =====================================
  # DIRECT ACCESS
  # =====================================

  direct_access <-
    xml2::xml_find_all(xml_doc, "//DirectAccessPermissions/*")

  direct_access_df <-
    purrr::map_dfr(
      direct_access,
      function(node) {
        tibble::tibble(
          XmlNode =
            xml2::xml_name(node),
          ObjectName =
            xml2::xml_text(
              xml2::xml_find_first(node, "./Name")
            )
        )
      }
    )

  # =====================================
  # RETURN
  # =====================================

  list(
    EntryPoints             = entrypoint_df,
    DataEntityPermissions   = entity_df,
    DataEntityMethods       = method_df,
    DirectAccessPermissions = direct_access_df
  )
}
