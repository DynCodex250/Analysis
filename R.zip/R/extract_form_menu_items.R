#' Formular MenuItems extrahieren
#'
#' Extrahiert alle MenuItem-Referenzen eines
#' D365FO Formulars.
#'
#' Die Funktion durchsucht alle Controls nach
#' `MenuItemName`- und `MenuItemType`-Properties
#' und liefert eine konsolidierte Liste aller
#' verwendeten MenuItems.
#'
#' @param form_model Ergebnis von [analyze_form()].
#'
#' @return Tibble mit den Spalten:
#'
#' * `ControlType` — Typ des Controls
#' * `ControlName` — Technischer Name des Controls
#' * `MenuItemName` — Referenziertes MenuItem
#' * `MenuItemType` — Typ des MenuItems
#' * `Parent` — Übergeordnetes Control
#' * `Path` — Vollständiger Pfad im Formular
#'
#' Duplikate werden entfernt.
#'
#' @seealso [analyze_form()], [extract_form_menu_item_buttons()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#' extract_form_menu_items(form_model)
#' }
#'
#' @export
extract_form_menu_items <- function(form_model) {

  # ================================
  # VALIDIERUNG
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # MENUITEM CONTROLS
  # ================================

  result <-
    form_model$Controls |>
    dplyr::mutate(
      MenuItemName =
        purrr::map_chr(
          Properties,
          ~ get_property(.x, "MenuItemName")
        ),
      MenuItemType =
        purrr::map_chr(
          Properties,
          ~ get_property(.x, "MenuItemType")
        )
    ) |>
    dplyr::filter(
      !is.na(MenuItemName),
      MenuItemName != ""
    ) |>
    dplyr::transmute(
      ControlType  = Type,
      ControlName  = Name,
      MenuItemName,
      MenuItemType,
      Parent,
      Path
    ) |>
    dplyr::distinct()

  # ================================
  # ERGEBNIS
  # ================================

  return(result)
}
