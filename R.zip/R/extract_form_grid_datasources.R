#' Grid DataSources extrahieren
#'
#' Extrahiert alle Grids eines analysierten D365FO Formulars
#' inklusive ihrer DataSource- und Tabelleninformationen.
#'
#' @param form_model Ergebnis von [analyze_form()].
#'
#' @return Tibble mit den Spalten:
#'
#' * `GridName` — Technischer Name des Grids
#' * `DataSource` — Verwendete DataSource
#' * `Table` — Referenzierte Tabelle
#' * `DefaultAction` — Standardaktion des Grids
#' * `Parent` — Übergeordnetes Control
#' * `Path` — Vollständiger Pfad im Formular
#'
#' @details
#' Die Funktion verbindet Grid-Informationen aus den Controls
#' mit den definierten DataSources des Formulars.
#'
#' Dadurch wird sichtbar:
#'
#' * welches Grid existiert
#' * welche DataSource verwendet wird
#' * welche Tabelle angezeigt wird
#' * welche Standardaktion ausgeführt wird
#'
#' @seealso [analyze_form()], [extract_form_datasource_relations()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#' extract_form_grid_datasources(form_model)
#' }
#'
#' @export
extract_form_grid_datasources <- function(form_model) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # GRIDS ERMITTELN
  # ================================

  grids <-
    extract_form_controls_by_type(form_model, "Grid")

  # ================================
  # LEERES GRID MODELL
  # ================================

  if (nrow(grids) == 0) {
    return(empty_form_grids())
  }

  # ================================
  # GRID MODELL ERSTELLEN
  # ================================

  result <-
    purrr::pmap_dfr(
      list(
        grids$Name,
        grids$Parent,
        grids$Path,
        grids$Properties
      ),
      function(Name, Parent, Path, Properties) {

        datasource <-
          get_property(Properties, "DataSource")

        datasource_info <-
          form_model$DataSources |>
          dplyr::filter(Name == datasource)

        table_name <-
          if (nrow(datasource_info) > 0) {
            datasource_info$Table[[1]]
          } else {
            NA_character_
          }

        tibble::tibble(
          GridName      = Name,
          DataSource    = datasource,
          Table         = table_name,
          DefaultAction = get_property(Properties, "DefaultAction"),
          Parent        = Parent,
          Path          = Path
        )
      }
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
