#' Feld-Metadaten extrahieren
#'
#' Extrahiert detaillierte Metadaten zu Formularfeldern
#' eines D365FO Formulars.
#'
#' Optional kann die Analyse auf einen bestimmten Tab
#' eingeschränkt werden.
#'
#' Die Funktion erweitert [extract_form_fields()] um
#' zusätzliche Informationen aus den Control-Properties.
#'
#' @param form_model Ergebnis von [analyze_form()].
#' @param tab_name Optionaler technischer Tabname.
#'   Wird kein Tab angegeben (`""`), werden alle
#'   Felder analysiert.
#'
#' @return Tibble mit Feldmetadaten und den Spalten:
#'
#' * `Name` — Technischer Name des Controls
#' * `Type` — Control-Typ
#' * `DataSource` — Zugehörige DataSource
#' * `DataField` — Referenziertes Datenbankfeld
#' * `Label` — Anzeigename
#' * `ExtendedDataType` — Erweiterter Datentyp (EDT)
#' * `Mandatory` — Pflichtfeld-Flag
#' * `AllowEdit` — Bearbeitbar-Flag
#' * `Visible` — Sichtbarkeit
#' * `Enabled` — Aktivierungsstatus
#' * `Parent` — Übergeordnetes Control
#' * `Level` — Hierarchietiefe
#' * `Path` — Vollständiger Pfad im Formular
#'
#' Das Ergebnis ist nach `Path` sortiert.
#'
#' @seealso [extract_form_fields()], [analyze_form()]
#'
#' @examples
#' \dontrun{
#' form_model <- analyze_form(xml_file)
#'
#' # Alle Felder
#' extract_form_field_metadata(form_model)
#'
#' # Nur Felder eines bestimmten Tabs
#' extract_form_field_metadata(
#'   form_model,
#'   "TabSalesDemographics"
#' )
#' }
#'
#' @export
extract_form_field_metadata <- function(
    form_model,
    tab_name = "") {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(form_model, "D365FormModel")) {
    stop("form_model muss ein D365FormModel sein.")
  }

  # ================================
  # RELEVANTE CONTROL-TYPEN
  # ================================

  field_types <- c(
    "String",
    "Integer",
    "Real",
    "Date",
    "DateTime",
    "CheckBox",
    "ComboBox",
    "ReferenceGroup"
  )

  controls <-
    form_model$Controls |>
    dplyr::filter(Type %in% field_types)

  # ================================
  # TAB FILTER
  # ================================

  if (tab_name != "") {

    controls <-
      controls |>
      dplyr::filter(
        stringr::str_detect(
          Path,
          stringr::fixed(tab_name)
        )
      )
  }

  # ================================
  # METADATEN EXTRAHIEREN
  # ================================

  result <-
    purrr::pmap_dfr(
      list(
        controls$Name,
        controls$Type,
        controls$Parent,
        controls$Level,
        controls$Path,
        controls$Properties
      ),
      function(Name, Type, Parent, Level, Path, Properties) {

        tibble::tibble(
          Name             = Name,
          Type             = Type,
          DataSource       = get_property(Properties, "DataSource"),
          DataField        = get_property(Properties, "DataField"),
          Label            = get_property(Properties, "Label"),
          ExtendedDataType = get_property(Properties, "ExtendedDataType"),
          Mandatory        = get_property(Properties, "Mandatory"),
          AllowEdit        = get_property(Properties, "AllowEdit"),
          Visible          = get_property(Properties, "Visible"),
          Enabled          = get_property(Properties, "Enabled"),
          Parent           = Parent,
          Level            = Level,
          Path             = Path
        )
      }
    )

  # ================================
  # SORTIEREN
  # ================================

  result <- result |> dplyr::arrange(Path)

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
