#' Get property value
#'
#' Safely retrieves a property value from a
#' list of XML or metadata properties.
#'
#' The function checks whether the requested
#' property exists before attempting to read
#' it. If the property is missing,
#' \code{NA_character_} is returned instead
#' of raising an error.
#'
#' @param properties Named list containing
#'   the available properties.
#'
#' @param property_name Name of the property
#'   to retrieve.
#'
#' @return The property value if available;
#' otherwise \code{NA_character_}.
#'
#' @details
#' This helper function is intended for
#' internal use when reading XML metadata.
#'
#' It avoids repetitive existence checks and
#' simplifies robust extraction of optional
#' properties from parsed XML structures.
#'
#' @examples
#' \dontrun{
#'
#' value <-
#'   get_property(
#'     properties,
#'     "Label"
#'   )
#'
#' }
#'
#' @keywords internal
get_property <- function(
    properties,
    property_name){
  
  #===========================================================
  # PROPERTY VORHANDEN
  #===========================================================
  
  if (property_name %in% names(properties)) {
    
    return(
      properties[[property_name]]
    )
    
  }
  
  #===========================================================
  # PROPERTY NICHT VORHANDEN
  #===========================================================
  
  return(
    NA_character_
  )
  
}