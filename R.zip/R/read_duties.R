read_duties <- function(doc){

  xml_find_all(doc,"//Duties/AxSecurityDutyReference/Name") %>%

    xml_text()

}
