#' Compare two D365FO form documentations
#'
#' Compares two
#' \code{D365FormDocumentation} objects and
#' aggregates the results of all available
#' comparison functions into a single object.
#'
#' Currently the following form components
#' are compared:
#'
#' \itemize{
#'   \item DataSources
#'   \item Tabs
#'   \item Groups
#'   \item Fields
#'   \item Buttons
#'   \item Parts
#' }
#'
#' @param old_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the original form documentation.
#'
#' @param new_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the updated form documentation.
#'
#' @return An object of class
#' \code{D365FormComparison} containing the
#' comparison results for all supported form
#' components.
#'
#' @details
#' This function acts as the central entry point
#' for comparing two form documentations.
#'
#' It internally executes:
#'
#' \itemize{
#'   \item \code{compare_form_datasources()}
#'   \item \code{compare_form_tabs()}
#'   \item \code{compare_form_groups()}
#'   \item \code{compare_form_fields()}
#'   \item \code{compare_form_buttons()}
#'   \item \code{compare_form_parts()}
#' }
#'
#' The resulting object is assigned the class
#' \code{D365FormComparison}, allowing dedicated
#' print, summary or reporting methods.
#'
#' Typical use cases:
#'
#' \itemize{
#'   \item Compare two versions of a D365FO form.
#'   \item Identify UI changes after an update.
#'   \item Detect customizations between environments.
#'   \item Generate documentation for form differences.
#' }
#'
#' @examples
#' \dontrun{
#'
#' comparison <-
#'   compare_forms_documentation(
#'     old_documentation,
#'     new_documentation
#'   )
#'
#' comparison$Fields
#'
#' comparison$Buttons
#'
#' }
#'
#' @export
compare_forms_documentation <- function(
    old_documentation,
    new_documentation
) {
  
  #===========================================================
  # VALIDATE INPUT PARAMETERS
  #===========================================================
  
  if (!inherits(
    old_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "old_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  if (!inherits(
    new_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "new_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  #===========================================================
  # EXECUTE COMPARISONS
  #===========================================================
  
  result <-
    
    list(
      
      DataSources =
        compare_form_datasources(
          old_documentation,
          new_documentation
        ),
      
      Tabs =
        compare_form_tabs(
          old_documentation,
          new_documentation
        ),
      
      Groups =
        compare_form_groups(
          old_documentation,
          new_documentation
        ),
      
      Fields =
        compare_form_fields(
          old_documentation,
          new_documentation
        ),
      
      Buttons =
        compare_form_buttons(
          old_documentation,
          new_documentation
        ),
      
      Parts =
        compare_form_parts(
          old_documentation,
          new_documentation
        )
      
    )
  
  #===========================================================
  # SET CLASS
  #===========================================================
  
  class(result) <-
    
    c(
      "D365FormComparison",
      "list"
    )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  return(result)
  
}