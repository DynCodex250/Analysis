#' SubRoles in ein D365FO Security XML schreiben
#'
#' Schreibt referenzierte SubRoles in die XML-Struktur eines
#' D365FO Security-Objekts.
#'
#' Die Funktion erzeugt unterhalb des übergebenen XML-Knotens
#' einen `SubRoles`-Container und fügt für jede SubRole einen
#' `AxSecurityRoleReference`-Knoten hinzu.
#'
#' Die erzeugte XML-Struktur entspricht dem von D365FO
#' verwendeten Security-Metadatenformat für verschachtelte
#' Security-Rollen.
#'
#' Beispiel:
#'
#' \preformatted{
#' <SubRoles>
#'   <AxSecurityRoleReference>
#'     <Name>WIBUSalesManager</Name>
#'   </AxSecurityRoleReference>
#'
#'   <AxSecurityRoleReference>
#'     <Name>WIBUWarehouseUser</Name>
#'   </AxSecurityRoleReference>
#' </SubRoles>
#' }
#'
#' @param parent_node XML-Knoten, unterhalb dessen der
#'   `SubRoles`-Container erzeugt werden soll.
#'
#' @param subroles Character-Vektor mit den Namen der
#'   referenzierten D365FO Security-Rollen.
#'
#' @return XML-Knoten vom Typ `SubRoles`.
#'
#' Bei leerem `subroles`-Vektor wird lediglich ein leerer
#' `SubRoles`-Knoten erzeugt und zurückgegeben.
#'
#' @details
#' Die Funktion verändert die übergebene XML-Struktur direkt.
#'
#' Für jede Rolle wird ein XML-Knoten der Form
#' `AxSecurityRoleReference` erzeugt.
#'
#' Die Funktion wird typischerweise beim Generieren von
#' Security-Rollen verwendet, beispielsweise innerhalb von
#' `create_d365fo_role_xml()`.
#'
#' @examples
#' \dontrun{
#'
#' root <- xml2::xml_new_root(
#'   "AxSecurityRole"
#' )
#'
#' write_subroles(
#'   parent_node = root,
#'   subroles = c(
#'     "WIBUSalesManager",
#'     "WIBUWarehouseUser"
#'   )
#' )
#'
#' }
#'
#' @export
write_subroles <- function(
    parent_node,
    subroles
) {

  # ================================
  # SUBROLE-CONTAINER ERZEUGEN
  # ================================

  subroles_node <- xml2::xml_add_child(
    parent_node,
    "SubRoles"
  )

  # ================================
  # LEEREN CONTAINER ZURÜCKGEBEN
  # ================================

  if (length(subroles) == 0) {

    return(subroles_node)

  }

  # ================================
  # SUBROLES HINZUFÜGEN
  # ================================

  for (role_name in subroles) {

    role_ref <- xml2::xml_add_child(
      subroles_node,
      "AxSecurityRoleReference"
    )

    xml2::xml_add_child(
      role_ref,
      "Name",
      role_name
    )

  }

  # ================================
  # XML-KNOTEN ZURÜCKGEBEN
  # ================================

  return(subroles_node)

}
