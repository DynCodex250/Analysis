#' Berechtigungsmatrix als formatiertes Excel-Arbeitsblatt exportieren
#'
#' Exportiert eine mit
#' \code{sec_create_permission_matrix()}
#' erzeugte Berechtigungsmatrix in ein
#' Excel-Arbeitsblatt einer bestehenden
#' Arbeitsmappe.
#'
#' Die Funktion erstellt ein neues worksheet,
#' schreibt die Matrix als Excel-Tabelle und
#' versieht sie mit einer benutzerfreundlichen
#' Farb- und Layoutformatierung.
#'
#' @details
#' Die Berechtigungsmatrix wird zunächst nach
#'
#' * SECURITYROLEIDENTIFIER
#' * ORGANIZATIONID
#'
#' sortiert.
#'
#' Anschließend werden Rollenblöcke ermittelt.
#'
#' Alle Zeilen, die zur selben Rolle gehören,
#' erhalten dieselbe Hintergrundfarbe.
#'
#' Beim Wechsel der Rolle wird automatisch zur
#' nächsten Hintergrundfarbe gewechselt.
#'
#' Dadurch entstehen optisch zusammenhängende
#' Rollenblöcke, welche die Analyse von
#' Berechtigungsunterschieden deutlich
#' erleichtern.
#'
#' Es werden zwei Farben verwendet:
#'
#' * hellblau
#' * hellgrau
#'
#' zusätzlich werden:
#'
#' * Filter aktiviert
#' * Kopfzeilen hervorgehoben
#' * Spaltenbreiten automatisch angepasst
#' * erste Zeile fixiert
#' * erste Spalte fixiert
#'
#' Die eigentliche Gruppierung erfolgt über
#' \code{SECURITYROLEIDENTIFIER}, da
#' unterschiedliche Rollen denselben
#' Rollennamen besitzen können.
#'
#' Dadurch bleibt die technische Eindeutigkeit
#' der Berechtigungen erhalten.
#'
#' @param wb Workbook-Objekt aus dem Paket
#' \pkg{openxlsx}.
#'
#' Das Workbook wird um ein neues worksheet
#' erweitert.
#'
#' @param sheet_name Name des zu erstellenden
#' Excel-Arbeitsblatts.
#'
#' @param x Berechtigungsmatrix.
#'
#' Typischerweise das Ergebnis von:
#'
#' \code{sec_create_permission_matrix()}.
#'
#' Erwartete Spalten:
#'
#' * SECURITYROLENAME
#' * SECURITYROLEIDENTIFIER
#' * ORGANIZATIONID
#' * Benutzerspalten
#'
#' @return workbook-objekt.
#'
#' Das workbook enthält zusätzlich das neu
#' erzeugte Arbeitsblatt.
#'
#' @examples
#' \dontrun{
#' wb <- openxlsx::createWorkbook()
#'
#' wb <-
#'   export_permission_matrix_sheet(
#'     wb,
#'     sheet_name = "05_permission_matrix",
#'     x = permission_matrix
#'   )
#'
#' openxlsx::saveWorkbook(
#'   wb,
#'   "D365FO_Benutzerberechtigungsvergleich.xlsx",
#'   overwrite = TRUE
#' )
#' }
#'
#' @section Formatierungen:
#'
#' Die Funktion wendet folgende Formatierungen an:
#'
#' * Tabellenformat (TableStyleLight1)
#' * Autofilter
#' * farbige Kopfzeile
#' * automatische Spaltenbreiten
#' * Freeze Pane
#' * rollenbasierte Farbblöcke
#'
#' @section Typische Verwendung:
#'
#' Die Funktion wird typischerweise zur
#' Erstellung des Excel-Blatts
#'
#' \preformatted{
#' 05_permission_matrix
#' }
#'
#' innerhalb einer Berechtigungsanalyse
#' verwendet.
#'
#' Dieses Blatt dient als technische und
#' fachliche Übersicht darüber, welche
#' Benutzer welche Rollen in welchen
#' Organisationen besitzen.
#'
#' @seealso
#' sec_create_permission_matrix
#'
#' @seealso
#' compare_user_permissions_fingerprint
#'
#' @seealso
#' compare_to_reference_user
#'
#' @seealso
#' compare_to_reference_user_details
#'
#' @seealso
#' create_permission_groups
#'
#' @export
export_permission_matrix_sheet <- function(
  wb,
  sheet_name,
  x
){
  
  #=============================================
  # Sortierung
  #=============================================
  x <- x |>
    dplyr::arrange(
      SECURITYROLEIDENTIFIER,
      ORGANIZATIONID
    )
  
  #=============================================
  # Farbgruppen bestimmen
  #=============================================
  x <- x |>
    dplyr::mutate(
      RoleGroup = cumsum(
        SECURITYROLEIDENTIFIER !=
          dplyr::lag(
            SECURITYROLEIDENTIFIER,
            default =
              dplyr::first(
                SECURITYROLEIDENTIFIER
              )
          )
      )
    )
  
  #=============================================
  # Exportspalten bestimmen
  # (ohne interne Hilfsspalte)
  #=============================================
  export_data <-
    x |>
    dplyr::select(
      -RoleGroup
    )
  
  export_cols <- seq_len(
    ncol(export_data)
  )
  
  #=============================================
  # worksheet
  #=============================================
  openxlsx::addWorksheet(
    wb,
    sheet_name
  )
  
  #=============================================
  # Daten schreiben
  #=============================================
  openxlsx::writeDataTable(
    wb,
    sheet_name,
    export_data,
    tableStyle = "TableStyleLight1",
    withFilter = TRUE
  )
  
  #=============================================
  # Styles
  #=============================================
  style_blue <-
    openxlsx::createStyle(
      fgFill = "#D9EAF7"
    )
  
  style_gray <-
    openxlsx::createStyle(
      fgFill = "#EAEAEA"
    )
  
  style_header <-
    openxlsx::createStyle(
      fgFill = "#5B9BD5",
      fontColour = "white",
      textDecoration = "bold",
      halign = "center"
    )
  
  style_one <-
    openxlsx::createStyle(
      fontColour = "#006100",
      textDecoration = "bold"
    )
  
  #=============================================
  # Header formatieren
  #=============================================
  openxlsx::addStyle(
    wb,
    sheet_name,
    style = style_header,
    rows = 1,
    cols = export_cols,
    gridExpand = TRUE
  )
  
  #=============================================
  # Rollenblöcke einfärben
  #=============================================
  for(g in unique(x$RoleGroup)){
    rows_current <-
      which(
        x$RoleGroup == g
      ) + 1
    current_style <-
      if(g %% 2 == 0){
        style_gray
      } else {
        style_blue
      }
    openxlsx::addStyle(
      wb,
      sheet_name,
      style = current_style,
      rows = rows_current,
      cols = export_cols,
      gridExpand = TRUE,
      stack = TRUE
    )
  }
  
  #=============================================
  # Benutzerspalten identifizieren
  #=============================================
  user_cols <-
    which(
      !names(x) %in%
        c(
          "SECURITYROLENAME",
          "SECURITYROLEIDENTIFIER",
          "ORGANIZATIONID",
          "RoleGroup"
        )
    )
  
  #=============================================
  # Berechtigungen hervorheben
  #=============================================
  if(length(user_cols) > 0){
    openxlsx::addStyle(
      wb,
      sheet_name,
      style = style_one,
      rows = 2:(nrow(x) + 1),
      cols = user_cols,
      gridExpand = TRUE,
      stack = TRUE
    )
  }
  
  #=============================================
  # Komfortfunktionen
  #=============================================
  openxlsx::freezePane(
    wb,
    sheet_name,
    firstRow = TRUE,
    firstCol = TRUE
  )
  
  openxlsx::setColWidths(
    wb,
    sheet_name,
    cols = export_cols,
    widths = "auto"
  )
  
  #=============================================
  # Workbook zurückgeben
  #=============================================
  return(wb)
}
