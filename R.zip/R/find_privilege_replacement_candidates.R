#' Ersatzkandidaten für Privileges ermitteln
#'
#' Analysiert Privileges mit NOTENTITLED > 0 und sucht nach alternativen
#' Privileges mit ACCESSLEVEL = 1 für dieselben Entry Points (AOTNAME).
#'
#' Die Funktion dient als erster Schritt einer Lizenzoptimierungsanalyse.
#'
#' @param licenses Tibble aus get_license_requirements().
#'
#' @return Tibble.
#'
#' Enthält:
#'
#' * AOTNAME
#' * ProblemPrivilege
#' * AlternativePrivilege
#' * Action
#'
#' Action:
#'
#' * REPLACE
#' * CUSTOMIZE
#'
#' @examples
#' candidates <-
#'   find_privilege_replacement_candidates(
#'     licenses
#'   )
#'
#' @export
find_privilege_replacement_candidates <- function(
    licenses){
  
  # ==========================
  # VALIDIERUNG
  # ==========================
  
  required_columns <-
    c(
      "IDENTIFIER",
      "AOTNAME",
      "NOTENTITLED",
      "ACCESSLEVEL"
    )
  
  missing_columns <-
    setdiff(
      required_columns,
      names(licenses)
    )
  
  if(length(missing_columns) > 0){
    stop(
      paste(
        "Folgende Spalten fehlen:",
        paste(
          missing_columns,
          collapse = ", "
        )
      )
    )
  }
  
  # ==========================
  # PROBLEMATISCHE PRIVILEGES
  # ==========================
  
  problem_privileges <-
    licenses |>
    dplyr::filter(
      NOTENTITLED > 0
    ) |>
    dplyr::distinct(
      IDENTIFIER,
      AOTNAME
    ) |>
    dplyr::rename(
      ProblemPrivilege =
        IDENTIFIER
    )
  
  # ==========================
  # ALTERNATIVEN
  # ==========================
  
  alternatives <-
    licenses |>
    dplyr::filter(
      ACCESSLEVEL == 1
    ) |>
    dplyr::distinct(
      AOTNAME,
      IDENTIFIER
    ) |>
    dplyr::rename(
      AlternativePrivilege =
        IDENTIFIER
    )
  
  # ==========================
  # MATCHING
  # ==========================
  
  result <-
    problem_privileges |>
    dplyr::left_join(
      alternatives,
      by = "AOTNAME"
    ) |>
    dplyr::mutate(
      Action =
        dplyr::if_else(
          is.na(AlternativePrivilege),
          "CUSTOMIZE",
          "REPLACE")
    ) |>
    dplyr::arrange(
      Action,
      ProblemPrivilege
    )
  
  return(result)
}