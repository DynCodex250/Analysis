#' Data Entity Berechtigungen extrahieren
#'
#' Extrahiert alle Data Entity Berechtigungen eines
#' D365FO Security Privileges.
#'
#' Die Funktion liest sämtliche
#' AxSecurityDataEntityPermission-Knoten aus der XML.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit allen Data Entity Berechtigungen.
#'
#' @details
#' Die Funktion extrahiert die Berechtigungen auf
#' Data Entity Ebene.
#'
#' Leere Ergebnisse werden als Tibble mit definierter
#' Struktur zurückgegeben.
#'
#' @seealso
#' parse_privilege()
#' extract_data_entity_methods()
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#'
#' permissions <-
#'   extract_data_entity_permissions(
#'     xml_doc
#'   )
#' }
#'
#' @export
extract_data_entity_permissions <- function(xml_doc) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # =========================================
  # DATA ENTITYS EXTRAHIEREN
  # =========================================

  entities <- xml2::xml_find_all(
    xml_doc,
    "//DataEntityPermissions/AxSecurityDataEntityPermission"
  )

  result <- purrr::map_dfr(entities, function(node) {
    tibble::tibble(
      EntityName = xml2::xml_text(
        xml2::xml_find_first(node, "./Name")
      ),

      IntegrationMode = xml2::xml_text(
        xml2::xml_find_first(node, "./IntegrationMode")
      ),

      Read = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Read")
      ),

      Create = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Create")
      ),

      Update = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Update")
      ),

      Delete = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Delete")
      ),

      Correct = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Correct")
      ),

      Invoke = xml2::xml_text(
        xml2::xml_find_first(node, "./Grant/Invoke")
      )
    )
  })

  # =========================================
  # LEERE STRUKTUR ABSICHERN
  # =========================================

  if (ncol(result) == 0) {
    result <- empty_data_entity_permissions()
  }

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}
