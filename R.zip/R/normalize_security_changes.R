#' Security-Änderungen für Reports aufbereiten#'#' Bereitet die Ergebnisse eines#' Privilege Security-Vergleichs für die#' Verwendung in Reports auf.#'#' Die Funktion standardisiert die#' Spaltennamen für die Darstellung in#' Excel-, HTML- oder PDF-Reports.#'#' Inhaltliche Änderungen an den Daten#' werden nicht vorgenommen.#'#' @param security_comparison Ergebnis von#' compare_privileges_security().#'#' @return Tibble mit standardisierten#' Report-Spalten.#'#' @details#' Die Funktion dient als zentrale#' Aufbereitungsschicht zwischen#' Compare-Framework und Reporting.#'#' Aktuell werden ausschließlich die#' Spaltennamen vereinheitlicht.#'#' @seealso#' compare_privileges_security()#'#' @seealso#' prepare_privilege_release_report()#'#' @examples#' security_changes <-#'   normalize_security_changes(#'     security_comparison#'   )#'#' @export

normalize_security_changes <- function(security_comparison){

  # ================================
  #   EINGABEPARAMETER VALIDIEREN
  # ================================

    if(!inherits(security_comparison,"D365PrivilegeSecurityComparison")){

      stop(
        paste(
          "security_comparison muss ein",
          "D365PrivilegeSecurityComparison sein."
        )
      )

    }

  # ================================
  #   DATEN AUFBEREITEN
  # ================================

    result <-

      security_comparison |>
      dplyr::rename(
        `Old Value` = OldValue,
        `New Value` = NewValue
      )

    # ================================
    #   ERGEBNIS ZURÜCKGEBEN
    # ================================

      return(result)

}
