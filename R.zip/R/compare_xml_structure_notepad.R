#' D365FO XML-Dokumente auf Strukturebene vergleichen
#'
#' Vergleicht zwei XML-Dateien direkt als XML-Dokumente
#' und zeigt die exakten Unterschiede zwischen einer
#' Original-XML und einer generierten XML-Datei an.
#'
#' Die Funktion eignet sich insbesondere zur Fehlersuche
#' beim Reverse Engineering und bei Roundtrip-Tests von
#' D365FO Security-Objekten.
#'
#' Im Gegensatz zu modellbasierten Vergleichen erfolgt
#' hier kein Vergleich geparster Objekte, sondern ein
#' direkter Vergleich der tatsächlichen XML-Struktur.
#'
#' Typische Anwendungsfälle:
#' - Fehlende XML-Knoten identifizieren
#' - Zusätzliche XML-Knoten erkennen
#' - Unterschiede zwischen Original- und Roundtrip-XML
#'   sichtbar machen
#' - XML-Generierung validieren
#' - XML-Strukturfehler analysieren
#'
#' Die Funktion eignet sich insbesondere zur Analyse
#' von:
#' - Privileges
#' - Duties
#' - Roles
#' - Security-Artefakten
#'
#' @param original_xml Vollständiger Pfad zur
#'        ursprünglichen XML-Datei.
#'
#' @param generated_xml Vollständiger Pfad zur
#'        generierten XML-Datei.
#'
#' @return Ausgabe von `waldo::compare()`.
#'
#' Die Rückgabe enthält eine strukturierte Beschreibung
#' aller gefundenen Unterschiede zwischen beiden
#' XML-Dokumenten.
#'
#' @details
#' Beide XML-Dateien werden zunächst als XML-Dokumente
#' eingelesen und anschließend in ihre Textdarstellung
#' konvertiert.
#'
#' Der eigentliche Vergleich erfolgt mittels
#' `waldo::compare()`.
#'
#' Dadurch können auch kleinste Unterschiede sichtbar
#' gemacht werden, beispielsweise:
#'
#' - fehlende XML-Elemente
#' - zusätzliche XML-Elemente
#' - unterschiedliche Attribute
#' - unterschiedliche Werte
#' - abweichende XML-Strukturen
#'
#' Die Funktion dient primär Debugging- und
#' Entwicklungszwecken.
#'
#' Für fachliche Vergleiche von geparsten Security-
#' Modellen sollten stattdessen die entsprechenden
#' Modellvergleichsfunktionen verwendet werden.
#'
#' @examples
#' compare_xml_structure_notepad(
#'   original_xml = "Original.xml",
#'   generated_xml = "Roundtrip.xml"
#' )
#'
#' @seealso
#' waldo::compare()
#' compare_privilege_roundtrip_model()
#' compare_privilege_roundtrip_components()
#'
#' @export
compare_xml_structure_notepad <- function(
    original_xml,
    generated_xml
) {

  # =====================================
  # XML-DATEIEN LADEN
  # =====================================

  doc1 <- xml2::read_xml(
    original_xml
  )

  doc2 <- xml2::read_xml(
    generated_xml
  )

  # =====================================
  # XML ALS TEXT DARSTELLEN
  # =====================================

  xml1 <- as.character(
    doc1
  )

  xml2 <- as.character(
    doc2
  )

  # =====================================
  # UNTERSCHIEDE ANZEIGEN
  # =====================================

  waldo::compare(
    xml1,
    xml2,
    max_diffs = Inf
  )
}
