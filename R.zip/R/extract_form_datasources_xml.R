#' Form-DataSources extrahieren
#'
#' Extrahiert alle DataSources eines D365FO Formulars
#' aus dem XML-Dokument.
#'
#' Die Funktion liest die DataSource-Definitionen und
#' liefert die wichtigsten Metadaten für weitere Analysen.
#'
#' @param xml_doc XML-Dokument eines D365FO Formulars.
#'
#' @return Tibble mit den Spalten:
#'
#' * `Name` — Technischer Name der DataSource
#' * `Table` — Referenzierte Tabelle
#' * `JoinSource` — Verknüpfte DataSource
#' * `ParentDataSource` — Übergeordnete DataSource
#'
#' @details
#' Die Funktion dient als Grundlage für:
#'
#' * Form-Analyse
#' * Form-Dokumentation
#' * Form-Vergleich
#' * Form Reverse Engineering
#'
#' Verschachtelte DataSources werden ebenfalls berücksichtigt.
#'
#' @seealso [analyze_form()], [extract_form_datasource_relations()]
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#' datasources <- extract_form_datasources_xml(xml_doc)
#' }
#'
#' @export
extract_form_datasources_xml <- function(xml_doc) {

  # ================================
  # DATASOURCES ERMITTELN
  # ================================

  datasource_nodes <-
    xml2::xml_find_all(
      xml_doc,
      ".//*[local-name()='AxFormDataSource']"
    )

  # ================================
  # DATASOURCES AUSLESEN
  # ================================

  result <- list()

  for (datasource_node in datasource_nodes) {

    result[[length(result) + 1]] <-

      tibble::tibble(

        Name =
          xml2::xml_text(
            xml2::xml_find_first(
              datasource_node,
              ".//*[local-name()='Name']"
            )
          ),

        Table =
          xml2::xml_text(
            xml2::xml_find_first(
              datasource_node,
              ".//*[local-name()='Table']"
            )
          ),

        JoinSource =
          xml2::xml_text(
            xml2::xml_find_first(
              datasource_node,
              ".//*[local-name()='JoinSource']"
            )
          ),

        ParentDataSource = NA_character_
      )
  }

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(dplyr::bind_rows(result))
}
