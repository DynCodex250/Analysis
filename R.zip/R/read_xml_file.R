read_xml_file <- function(file_path)
{
  xml2::read_xml(file_path)
}