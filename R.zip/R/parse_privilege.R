#' D365FO Privilege XML einlesen
#'
#' Liest ein D365FO Security Privilege XML ein und
#' wandelt dieses in ein strukturiertes R-Objekt um.
#'
#' Die Funktion bildet den zentralen Einstiegspunkt
#' für Reverse Engineering, Vergleiche, Roundtrip-Tests,
#' Security-Analysen und XML-Generierung.
#'
#' @param xml_file Pfad zur Privilege XML-Datei.
#'
#' @return Objekt der Klasse D365Privilege.
#'
#' @details
#' Die Funktion liest das XML-Dokument ein und delegiert
#' die Extraktion der einzelnen Security-Komponenten an
#' spezialisierte Extraktionsfunktionen.
#'
#' Enthaltene Komponenten:
#'
#' * Metadata
#' * EntryPoints
#' * EntryPointForms
#' * EntryPointControls
#' * EntryPointFormDataSources
#' * DataEntityPermissions
#' * DataEntityMethods
#' * DirectAccessPermissions
#' * DirectAccessFields
#' * FormControlOverrides
#'
#' Die Rückgabe erfolgt als Objekt der Klasse
#' D365Privilege.
#'
#' @examples
#' privilege <-
#'   parse_privilege(
#'     "CustTableMaintain.xml"
#'   )
#'
#' names(privilege)
#'
#' privilege$EntryPoints
#'
#' @seealso#' generate_privilege_xml()
#' compare_privileges_existence()
#' compare_privileges_security()
#' validate_privilege_roundtrip()
#'
#' @export

parse_privilege <- function(
    xml_file
    ){

  # ================================
  #   EINGABEPARAMETER VALIDIEREN
  # ================================

    if(!file.exists(xml_file)){
      stop("xml_file wurde nicht gefunden.")
      }

  # ================================
  #   XML EINLESEN
  # ================================

    xml_doc <- xml2::read_xml(xml_file)

    # ================================
    #   KOMPONENTEN EXTRAHIEREN
    # ================================

      metadata <-
        extract_metadata(
          xml_doc
          )

      entrypoints <-
        extract_entrypoints(
          xml_doc
          )

      entrypoint_forms <-
        extract_entrypoint_forms(
          xml_doc
          )

      entrypoint_controls <-
        extract_entrypoint_controls(
          xml_doc
          )

      entrypoint_form_datasources <-
        extract_entrypoint_form_datasources(
          xml_doc
          )

      data_entity_permissions <-
        extract_data_entity_permissions(
          xml_doc
          )

      data_entity_methods <-
        extract_data_entity_methods(
          xml_doc
          )

      direct_access_permissions <-
        extract_direct_access_permissions(
          xml_doc
          )

      direct_access_fields <-
        extract_direct_access_fields(
          xml_doc
          )

      form_control_overrides <-
        extract_form_control_overrides(
          xml_doc
          )

      # ================================
      #   PRIVILEGE MODELL ERSTELLEN
      # ================================

        privilege <-
        list(

          Metadata =
            metadata,

          EntryPoints =
            entrypoints,

          EntryPointForms =
            entrypoint_forms,

          EntryPointControls =
            entrypoint_controls,

          EntryPointFormDataSources =
            entrypoint_form_datasources,

          DataEntityPermissions =
            data_entity_permissions,

          DataEntityMethods =
            data_entity_methods,

          DirectAccessPermissions =
            direct_access_permissions,

          DirectAccessFields =
            direct_access_fields,

          FormControlOverrides =
            form_control_overrides

        )

      # ================================
      #   OBJEKTTYP SETZEN
      # ================================

        class(privilege) <-
        c(
          "D365Privilege",
          "list"
          )

      # ================================
      #   ERGEBNIS ZURÜCKGEBEN
      # ================================

        return(privilege)

}

