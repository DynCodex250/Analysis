#' Control Properties extrahieren
#'
#' Extrahiert alle direkten Properties eines
#' `AxFormControl`-Knotens aus dem XML-Dokument.
#'
#' Die Funktion überspringt den `Controls`-Unterknoten
#' und liest nur direkte Eigenschaften des Controls.
#'
#' @param control_node XML-Knoten eines `AxFormControl`.
#'
#' @return Benannte Liste mit Property-Werten.
#'   Die Namen entsprechen den XML-Knotennamen,
#'   die Werte dem jeweiligen Textinhalt.
#'
#' @seealso [extract_form_control_hierarchy_xml()]
#'
#' @keywords internal
extract_form_control_properties <- function(control_node) {

  # ================================
  # PROPERTY KNOTEN ERMITTELN
  # ================================

  child_nodes <- xml2::xml_children(control_node)

  # ================================
  # PROPERTIES EXTRAHIEREN
  # ================================

  result <- list()

  for (child_node in child_nodes) {

    node_name <- xml2::xml_name(child_node)

    if (node_name == "Controls") {
      next
    }

    value <- xml2::xml_text(child_node)

    result[[node_name]] <- value
  }

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)
}
