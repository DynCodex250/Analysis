#' D365FO Privilege-EntryPoints analysieren
#'
#' Liest eine D365FO Privilege XML-Datei ein und extrahiert
#' die enthaltenen Security-Objekte in einer flachen,
#' analysierbaren Struktur.
#'
#' Die Funktion dient insbesondere dem Reverse Engineering
#' von D365FO Privileges und ermöglicht einen schnellen
#' Überblick über die enthaltenen Security-Komponenten.
#'
#' Typische Anwendungsfälle:
#' - Reverse Engineering
#' - XML-Strukturanalyse
#' - Security-Dokumentation
#' - Privilege-Vergleiche
#' - Vorbereitung für XML-Generierung
#'
#' Die Analyse umfasst unter anderem:
#' - EntryPoints
#' - Forms
#' - Form Controls
#' - Form Data Sources
#' - Data Entity Permissions
#' - Data Entity Methods
#' - Direct Access Permissions
#'
#' @param xml_file Pfad zu einer D365FO Privilege XML-Datei.
#'
#' @return Tibble mit den Spalten:
#'
#' \describe{
#'   \item{XmlNode}{
#'   Name des aktuellen XML-Knotens.
#'   }
#'
#'   \item{ParentNode}{
#'   Name des übergeordneten XML-Knotens.
#'   }
#'
#'   \item{Name}{
#'   Inhalt des Name-Knotens.
#'   }
#' }
#'
#' @details
#' Die Funktion durchsucht die XML-Datei nach allen
#' Knoten, die ein untergeordnetes Element namens
#' `Name` enthalten.
#'
#' Für jeden gefundenen Knoten werden der Knotentyp,
#' der übergeordnete Knotentyp sowie der Name des
#' referenzierten Security-Objekts extrahiert.
#'
#' Doppelte Einträge werden am Ende entfernt.
#'
#' Das Ergebnis kann anschließend beispielsweise mit
#' `analyze_privilege_xml_structure()` weiter analysiert
#' werden.
#'
#' @examples
#' privilege_analysis <-
#'   analyze_privilege_entrypoints(
#'     "CustTableMaintain.xml"
#'   )
#'
#' privilege_analysis
#'
#' dplyr::count(
#'   privilege_analysis,
#'   XmlNode
#' )
#'
#' @seealso
#' analyze_privilege_xml_structure()
#' parse_privilege()
#'
#' @export
analyze_privilege_entrypoints <- function(xml_file)
{

  doc <- xml2::read_xml(xml_file)

  nodes <- xml2::xml_find_all(
    doc,
    ".//*[Name]"
  )

  result <- purrr::map_dfr(

    nodes,

    function(node)
    {

      tibble::tibble(

        XmlNode = xml2::xml_name(node),

        ParentNode = xml2::xml_name(xml2::xml_parent(node)),

        Name = xml2::xml_text(
          xml2::xml_find_first(node, "./Name"
          )
        )
      )
    }
  )

  dplyr::distinct(result)
}
