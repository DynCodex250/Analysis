#' Form Control Overrides extrahieren
#'
#' Extrahiert sämtliche Form Control Overrides eines
#' D365FO Security Privileges.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit allen Form Control Overrides
#'   und den Spalten:
#'
#' * `ParentForm` — Formularname
#' * `ControlName` — Name des Controls
#' * `Read` — Leseberechtigung
#' * `Create` — Erstellberechtigung
#' * `Update` — Änderungsberechtigung
#' * `Delete` — Löschberechtigung
#' * `Correct` — Korrekturberechtigung
#' * `Invoke` — Ausführberechtigung
#'
#' @details
#' Die Funktion liest alle
#' `AxSecurityFormControlReference`-Knoten innerhalb
#' von `FormControlOverrides`.
#'
#' Leere Ergebnisse werden als Tibble mit definierter
#' Struktur zurückgegeben.
#'
#' @seealso [parse_privilege()]
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#' overrides <- extract_form_control_overrides(xml_doc)
#' }
#'
#' @export
extract_form_control_overrides <- function(xml_doc) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # ================================
  # OVERRIDES EXTRAHIEREN
  # ================================

  override_nodes <-
    xml2::xml_find_all(
      xml_doc,
      "//FormControlOverrides//AxSecurityFormControlReference"
    )

  result <-
    purrr::map_dfr(
      override_nodes,
      function(control_node) {

        controls_node <-
          xml2::xml_parent(control_node)

        collection_node <-
          xml2::xml_parent(controls_node)

        tibble::tibble(

          ParentForm =
            xml2::xml_text(
              xml2::xml_find_first(
                collection_node,
                "./Name"
              )
            ),

          ControlName =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Name"
              )
            ),

          Read =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Read"
              )
            ),

          Create =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Create"
              )
            ),

          Update =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Update"
              )
            ),

          Delete =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Delete"
              )
            ),

          Correct =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Correct"
              )
            ),

          Invoke =
            xml2::xml_text(
              xml2::xml_find_first(
                control_node,
                "./Grant/Invoke"
              )
            )
        )
      }
    )

  if (ncol(result) == 0) {

    result <-
      tibble::tibble(
        ParentForm  = character(),
        ControlName = character(),
        Read        = character(),
        Create      = character(),
        Update      = character(),
        Delete      = character(),
        Correct     = character(),
        Invoke      = character()
      )
  }

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  #if (ncol(result) == 0) {
  #  result <- extract_form_control_overrides()
  #}

  return(result)
}
