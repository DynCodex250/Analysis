#' Formular-Referenzen aus Privilege extrahieren
#'
#' Extrahiert alle Formular-Referenzen aus den
#' EntryPoints eines D365FO Security Privileges.
#'
#' Die Funktion liest alle `AxSecurityEntryPointReference`-
#' Knoten und die darin referenzierten Formulare aus.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit den Spalten:
#'
#' * `entrypoint` — Name des EntryPoints
#' * `form_name` — Technischer Name des Formulars
#'
#' @seealso [parse_privilege()], [extract_entrypoints()]
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#' forms <- extract_forms(xml_doc)
#' }
#'
#' @export
extract_forms <- function(xml_doc) {

  entrypoint_nodes <-
    xml2::xml_find_all(
      xml_doc,
      "//EntryPoints/AxSecurityEntryPointReference"
    )

  result <- list()

  for (ep_node in entrypoint_nodes) {

    ep_name <-
      xml2::xml_text(
        xml2::xml_find_first(ep_node, "./Name")
      )

    form_nodes <-
      xml2::xml_find_all(
        ep_node,
        "./Forms/AxSecurityEntryPointReferenceForm"
      )

    for (form_node in form_nodes) {

      result[[length(result) + 1]] <-
        tibble::tibble(
          entrypoint = ep_name,
          form_name  =
            xml2::xml_text(
              xml2::xml_find_first(form_node, "./Name")
            )
        )
    }
  }

  dplyr::bind_rows(result)
}
