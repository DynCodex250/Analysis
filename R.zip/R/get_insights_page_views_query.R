#' Kusto-Abfrage für Insights Page Views generieren
#'
#' Erstellt eine Kusto (KQL) Abfrage zur Analyse von Seitenaufrufen (Page Views)
#' in Application Insights.
#'
#' Die Abfrage aggregiert die Aufrufe der letzten 700 Tage nach Benutzer-ID und
#' Name des Menüelements, berechnet die Gesamtverweildauer und die Anzahl
#' der Interaktionen (TouchesProUser).
#'
#' @param user_ids Optionaler Vektor von Benutzer-IDs (user_Id) zur Filterung.
#'
#' @param menu_items Optionaler Vektor von Menüelement-Namen zur Filterung.
#'
#' @return Eine Zeichenkette mit der KQL-Abfrage.
#'
#' @export
get_insights_page_views_query <- function(
    user_ids = character(),
    menu_items = character()) {

  # =========================================
  # BASIS-ABFRAGE
  # =========================================

  query <- "pageViews
| where timestamp > ago(700d)
| summarize timestamp = max(format_datetime(timestamp, 'dd.MM.yyyy')), duration = toint(sum(duration) / 1000), TouchesProUser = count() by user_Id, name
| sort by TouchesProUser desc, duration desc
| project timestamp, name, duration, TouchesProUser, user_Id"

  # =========================================
  # FILTER HINZUFÜGEN
  # =========================================

  if (length(menu_items) > 0) {
    menu_item_list <- paste0(
      "'", gsub("'", "''", menu_items), "'",
      collapse = ","
    )
    query <- paste0(
      query,
      "\n| where name in (", menu_item_list, ")"
    )
  }

  if (length(user_ids) > 0) {
    user_list <- paste0(
      "'", gsub("'", "''", user_ids), "'",
      collapse = ","
    )
    query <- paste0(
      query,
      "\n| where user_Id in (", user_list, ")"
    )
  }

  return(query)
}
