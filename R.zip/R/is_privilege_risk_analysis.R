#' Prüfen ob eine Privilege-Risikoanalyse vorliegt#'#' Prüft, ob ein Objekt das Ergebnis eines#' compare_privileges_risk_analysis()-Aufrufs ist.#'#' @param x Zu prüfendes Objekt.#'#' @return TRUE wenn das Objekt ein#' D365PrivilegeRiskAnalysis ist,#' ansonsten FALSE.#'#' @details#' Die Prüfung erfolgt über die Objektklasse.#'#' @seealso#' compare_privileges_risk_analysis()#'#' @examples#' result <-#'   compare_privileges_risk_analysis(#'     security_changes#'   )#'#' is_privilege_risk_analysis(#'   result#' )#'#' @export

is_privilege_risk_analysis <- function(x){

#================================
#    OBJEKT PRÜFEN
#================================

    result <-inherits(x,"D365PrivilegeRiskAnalysis")

#================================
#      ERGEBNIS ZURÜCKGEBEN
#================================

      return(result)

}
