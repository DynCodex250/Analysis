#' ActionPane Buttons vergleichen
#'
#' Vergleicht die ActionPane Buttons
#' zweier Formulardokumentationen.
#'
#' Die Funktion ermittelt:
#'
#' * Neu hinzugefügte Buttons
#' * Entfernte Buttons
#'
#' Der Vergleich erfolgt über die
#' Kombination aus:
#'
#' * ActionPaneTab
#' * ButtonGroup
#' * Button
#'
#' @param old_documentation
#' Dokumentation der alten Version.
#'
#' @param new_documentation
#' Dokumentation der neuen Version.
#'
#' @return Liste mit:
#'
#' * Added
#' * Removed
#'
#' @details
#' Die Funktion dient der Analyse von
#' Änderungen zwischen verschiedenen
#' Releases oder Formularversionen.
#'
#' @examples
#' compare_form_action_buttons(
#'   old_documentation,
#'   new_documentation
#' )
#'
#' @export
compare_form_action_buttons <- function(
    old_documentation,
    new_documentation){

  if(!inherits(
    old_documentation,
    "D365FormDocumentation")){

    stop(
      "old_documentation muss ein D365FormDocumentation sein."
    )
  }

  if(!inherits(
    new_documentation,
    "D365FormDocumentation")){

    stop(
      "new_documentation muss ein D365FormDocumentation sein."
    )
  }

  old_buttons <-

    old_documentation$ActionPaneButtons

  new_buttons <-

    new_documentation$ActionPaneButtons

  key_columns <-

    c(
      "ActionPaneTab",
      "ButtonGroup",
      "Button"
    )

  added <-

    dplyr::anti_join(
      new_buttons,
      old_buttons,
      by = key_columns
    )

  removed <-

    dplyr::anti_join(
      old_buttons,
      new_buttons,
      by = key_columns
    )

  result <-

    list(

      Added =
        added,

      Removed =
        removed

    )

  return(result)

}
