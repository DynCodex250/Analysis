# =========================================================================
# Rollenkopiefunktionen
# =========================================================================
# Funktionen zur Synchronisation und zum Kopieren von Benutzerrollen,
# Organisationszuordnungen und Benutzerattributen in D365FO.
# =========================================================================

#' Security Roles anhand eines Referenzusers synchronisieren
#'
#' Synchronisiert die Sicherheitsrollen eines Ziel-Users basierend auf den Rollen
#' eines Referenz-Users (COPY) und ermittelt die Abweichungen.
#'
#' @details
#' Für jeden Ziel-User wird eine Referenz (COPY) definiert.
#' Mathematisch werden drei Mengen gebildet:
#' \itemize{
#'   \item \strong{INSERT}: Rollen des Referenz-Users, die dem Ziel-User fehlen (C − T)
#'   \item \strong{DELETE}: Rollen des Ziel-Users, die der Referenz-User nicht hat (T − C)
#'   \item \strong{ACTUAL}: Schnittmenge der übereinstimmenden Rollen (T ∩ C)
#' }
#' Das Ergebnis ermöglicht eine saubere und vollständige Rollensynchronisation.
#'
#' @param df_roles Data Frame mit dem Rollenexport (enthält USERID, SECURITYROLEIDENTIFIER, etc.).
#' @param df_mapping Data Frame mit dem User-Mapping (enthält Spalten USERID und COPY).
#' @param output_path Pfad zum Ausgabeordner für Excel-Zusammenfassungen (Standard: "C:/Users/Import/").
#' @param dry_run Falls \code{TRUE} (Standard), wird die Synchronisation nur simuliert und keine Excel-Dateien geschrieben.
#'
#' @return Eine benannte Liste mit den Komponenten \code{delete}, \code{insert}, \code{actual} (jeweils Data Frames) und einem Ausführungs-\code{log}.
#' @export
sync_security_roles_by_copy <- function(
    df_roles,
    df_mapping,
    output_path = "C:/Users/Import/",
    dry_run = TRUE
) {
  df_roles$USERID   <- base::tolower(df_roles$USERID)
  df_mapping$USERID <- base::tolower(df_mapping$USERID)
  df_mapping$COPY   <- base::tolower(df_mapping$COPY)

  required_roles_cols <- c("USERID",
                           "SECURITYROLEIDENTIFIER",
                           "SECURITYROLENAME",
                           "ASSIGNMENTMODE",
                           "ASSIGNMENTSTATUS")

  required_mapping_cols <- c("USERID", "COPY")

  if (!all(required_roles_cols %in% colnames(df_roles))) {
    stop("df_roles hat nicht die erforderlichen Spalten.")
  }

  if (!all(required_mapping_cols %in% colnames(df_mapping))) {
    stop("df_mapping benötigt die Spalten USERID und COPY.")
  }

  df_mapping <- unique(df_mapping[, required_mapping_cols])

  delete_list <- list()
  insert_list <- list()
  actual_list <- list()
  log_list    <- list()

  for (i in seq_len(nrow(df_mapping))) {

    target_user <- df_mapping$USERID[i]
    copy_user   <- df_mapping$COPY[i]

    if (target_user == copy_user) {
      next
    }

    if (!(copy_user %in% df_roles$USERID)) {
      stop(paste("COPY-User existiert nicht im Rollentable:", copy_user))
    }

    target_roles <- df_roles[df_roles$USERID == target_user, ]
    copy_roles   <- df_roles[df_roles$USERID == copy_user, ]

    target_keys <- target_roles$SECURITYROLEIDENTIFIER
    copy_keys   <- copy_roles$SECURITYROLEIDENTIFIER

    # INSERT = C − T
    insert_mask <- !(copy_keys %in% target_keys)
    if (any(insert_mask)) {
      new_roles <- copy_roles[insert_mask, ]
      new_roles$USERID <- target_user
      insert_list[[length(insert_list) + 1]] <- new_roles
    }

    # DELETE = T − C
    delete_mask <- !(target_keys %in% copy_keys)
    if (any(delete_mask)) {
      roles_to_delete <- target_roles[delete_mask, ]
      delete_list[[length(delete_list) + 1]] <- roles_to_delete
    }

    # ACTUAL = T ∩ C
    actual_mask <- target_keys %in% copy_keys
    if (any(actual_mask)) {
      common_roles <- target_roles[actual_mask, ]
      actual_list[[length(actual_list) + 1]] <- common_roles
    }

    log_list[[length(log_list) + 1]] <- data.frame(
      TARGET_USER = target_user,
      COPY_USER   = copy_user,
      DELETE_COUNT = sum(delete_mask),
      INSERT_COUNT = sum(insert_mask),
      ACTUAL_COUNT = sum(actual_mask),
      DRY_RUN = dry_run,
      stringsAsFactors = FALSE
    )
  }

  delete_df <- if (length(delete_list) > 0) do.call(rbind, delete_list) else data.frame()
  insert_df <- if (length(insert_list) > 0) do.call(rbind, insert_list) else data.frame()
  actual_df <- if (length(actual_list) > 0) do.call(rbind, actual_list) else data.frame()
  log_df    <- if (length(log_list) > 0) do.call(rbind, log_list) else data.frame()

  if (nrow(delete_df) > 0) delete_df <- unique(delete_df)
  if (nrow(insert_df) > 0) insert_df <- unique(insert_df)
  if (nrow(actual_df) > 0) actual_df <- unique(actual_df)

  if (!dry_run) {
    writexl::write_xlsx(delete_df,
                        paste0(output_path, "SecurityUserRole_Delete_", Sys.Date(), ".xlsx"))

    writexl::write_xlsx(insert_df,
                        paste0(output_path, "SecurityUserRole_Insert_", Sys.Date(), ".xlsx"))

    writexl::write_xlsx(actual_df,
                        paste0(output_path, "SecurityUserRole_AlreadyExisting_", Sys.Date(), ".xlsx"))

    writexl::write_xlsx(log_df,
                        paste0(output_path, "SecurityUserRole_Log_", Sys.Date(), ".xlsx"))
  }

  return(list(
    delete = delete_df,
    insert = insert_df,
    actual = actual_df,
    log    = log_df
  ))
}


#' Rollen-Organisationszuordnungen anhand eines Referenzusers synchronisieren
#'
#' Synchronisiert Mandantenzuordnungen (Organisationszuordnungen) für Sicherheitsrollen
#' basierend auf einem Referenz-User (COPY).
#'
#' @details
#' Im Unterschied zur reinen Rollensynchronisation wird hier als Schlüssel die
#' Kombination aus \code{SECURITYROLEIDENTIFIER} und \code{ORGANIZATIONID} verwendet.
#' Dadurch wird berücksichtigt, dass dieselbe Rolle in mehreren Mandanten getrennt zugewiesen
#' sein kann.
#'
#' @param df_org_roles Data Frame mit den Organisationszuordnungen (enthält USERID, SECURITYROLEIDENTIFIER, etc.).
#' @param df_mapping Data Frame mit dem User-Mapping (enthält USERID und COPY).
#' @param output_path Pfad zum Ausgabeordner für Excel-Exporte (Standard: "C:/Users/Import/").
#' @param dry_run Falls \code{TRUE} (Standard), wird die Zuweisung nur simuliert und keine Excel-Dateien geschrieben.
#'
#' @return Eine benannte Liste mit den Komponenten \code{delete}, \code{insert}, \code{actual} und einem \code{log} Data Frame.
#' @export
sync_role_org_assignments_by_copy <- function(
    df_org_roles,
    df_mapping,
    output_path = "C:/Users/Import/",
    dry_run = TRUE) {

  # Normalisierung
  df_org_roles$USERID   <- base::tolower(df_org_roles$USERID)
  df_mapping$USERID     <- base::tolower(df_mapping$USERID)
  df_mapping$COPY       <- base::tolower(df_mapping$COPY)

  required_cols_roles <- c("USERID",
                           "SECURITYROLEIDENTIFIER",
                           "ORGANIZATIONTYPE",
                           "ORGANIZATIONID")

  required_cols_map <- c("USERID", "COPY")

  if (!all(required_cols_roles %in% colnames(df_org_roles))) {
    stop("df_org_roles hat nicht die erforderlichen Spalten.")
  }

  if (!all(required_cols_map %in% colnames(df_mapping))) {
    stop("df_mapping benötigt die Spalten USERID und COPY.")
  }

  df_mapping <- unique(df_mapping[, required_cols_map])

  delete_list <- list()
  insert_list <- list()
  actual_list <- list()
  log_list    <- list()

  for (i in seq_len(nrow(df_mapping))) {

    target_user <- df_mapping$USERID[i]
    copy_user   <- df_mapping$COPY[i]

    if (target_user == copy_user) {
      next
    }

    if (!(copy_user %in% df_org_roles$USERID)) {
      next
      #stop(paste("COPY-User existiert nicht im Org-Assignment-Table:", copy_user))
    }

    target_roles <- df_org_roles[df_org_roles$USERID == target_user, ]
    copy_roles   <- df_org_roles[df_org_roles$USERID == copy_user, ]

    target_keys <- paste(target_roles$SECURITYROLEIDENTIFIER,
                         target_roles$ORGANIZATIONID)

    copy_keys   <- paste(copy_roles$SECURITYROLEIDENTIFIER,
                         copy_roles$ORGANIZATIONID)

    # INSERT = C − T
    insert_mask <- !(copy_keys %in% target_keys)
    if (any(insert_mask)) {
      new_assignments <- copy_roles[insert_mask, ]
      new_assignments$USERID <- target_user
      insert_list[[length(insert_list) + 1]] <- new_assignments
    }

    # DELETE = T − C
    delete_mask <- !(target_keys %in% copy_keys)
    if (any(delete_mask)) {
      assignments_to_delete <- target_roles[delete_mask, ]
      delete_list[[length(delete_list) + 1]] <- assignments_to_delete
    }

    # ACTUAL = T ∩ C
    actual_mask <- target_keys %in% copy_keys
    if (any(actual_mask)) {
      common_assignments <- target_roles[actual_mask, ]
      actual_list[[length(actual_list) + 1]] <- common_assignments
    }

    log_list[[length(log_list) + 1]] <- data.frame(
      TARGET_USER = target_user,
      COPY_USER   = copy_user,
      DELETE_COUNT = sum(delete_mask),
      INSERT_COUNT = sum(insert_mask),
      ACTUAL_COUNT = sum(actual_mask),
      DRY_RUN = dry_run,
      stringsAsFactors = FALSE
    )
  }

  delete_df <- if (length(delete_list) > 0) do.call(rbind, delete_list) else data.frame()
  insert_df <- if (length(insert_list) > 0) do.call(rbind, insert_list) else data.frame()
  actual_df <- if (length(actual_list) > 0) do.call(rbind, actual_list) else data.frame()
  log_df    <- if (length(log_list) > 0) do.call(rbind, log_list) else data.frame()

  if (nrow(delete_df) > 0) delete_df <- unique(delete_df)
  if (nrow(insert_df) > 0) insert_df <- unique(insert_df)
  if (nrow(actual_df) > 0) actual_df <- unique(actual_df)

  if (!dry_run) {
    writexl::write_xlsx(delete_df,
               paste0(output_path, "RoleOrgAssignment_Delete_", Sys.Date(), ".xlsx"))

    writexl::write_xlsx(insert_df,
               paste0(output_path, "RoleOrgAssignment_Insert_", Sys.Date(), ".xlsx"))

    writexl::write_xlsx(actual_df,
               paste0(output_path, "RoleOrgAssignment_AlreadyExisting_", Sys.Date(), ".xlsx"))

    writexl::write_xlsx(log_df,
               paste0(output_path, "RoleOrgAssignment_Log_", Sys.Date(), ".xlsx"))
  }

  return(list(
    delete = delete_df,
    insert = insert_df,
    actual = actual_df,
    log    = log_df
  ))
}

#' Benutzer anhand eines Referenzusers synchronisieren
#'
#' Synchronisiert D365FO-Benutzereinstellungen (wie Sprache, Zeitzone, Theme, Company, etc.)
#' für Ziel-User basierend auf dem Profil eines Referenz-User-Templates.
#'
#' @details
#' Das Matching erfolgt ausschließlich über: \code{tolower(A$EMAIL) == tolower(C$ALIAS)}.
#' Wenn der User bereits existiert, werden seine Attribute überschrieben.
#' Wenn der User nicht existiert, wird ein neuer Datensatz erzeugt.
#' Die \code{USERID} wird automatisch aus der Mail (Präfix vor dem @) abgeleitet.
#' Es werden nur Einstellungen kopiert, keine Identitäts-IDs oder E-Mails.
#'
#' @param df_mapping Mapping-Tabelle (enthält EMAIL, USERID, USERNAME).
#' @param df_ui User-Informationen-Tabelle (User information).
#'
#' @return Data Frame mit den neuen bzw. aktualisierten Benutzern und ihren Systemattributen.
#' @export
sync_users_from_table_a <- function(
    df_mapping,
    df_ui
  ) {

  # 1. Referenz-Template ermitteln (Ruthe / Marc)
  ref <- df_ui[df_ui$USERID %in% df_mapping$USERID, ]

  if (nrow(ref) == 0) {
    stop("Referenz-User nicht in User information gefunden.")
  }

  # Falls beide existieren: erster gewinnt deterministisch
  ref <- ref[1, ]

  # 2. Ziel-User vorbereiten
  target <- data.frame(
    ALIAS = base::tolower(df_mapping$EMAIL),
    USERNAME = df_mapping$USERNAME,
    stringsAsFactors = FALSE
  )


  # 3. Bestehende User erkennen
  df_ui$ALIAS_LOWER <- base::tolower(df_ui$ALIAS)
  target <- base::merge(
    target,
    df_ui,
    by.x = "ALIAS",
    by.y = "ALIAS_LOWER",
    all.x = TRUE
  )
  col <- c("USERID","HELPLANGUAGE","NETWORKDOMAIN","USERINFO_LANGUAGE","USERNAME","EMAIL","ENABLED","THEME",
           "DENSITY", "PREFERREDLOCALE")

  # 4. Neue oder zu aktualisierende Datensätze bauen
  result <- lapply(seq_len(nrow(target)), function(i) {
    row <- target[i, ]
    col <- c("USERID","HELPLANGUAGE","NETWORKDOMAIN","USERINFO_LANGUAGE","USERNAME","EMAIL","ENABLED","THEME",
             "DENSITY", "PREFERREDLOCALE")

    if(is.na(row$USERID)){ #Neue  Datensätze bauen
      new_row <- ref
      # USERID ableiten (alles vor @)
      new_row$USERID <- sub("@.*", "", row$ALIAS)

      # Identitätsfelder setzen
      new_row$USERNAME <- row$USERNAME.x
      new_row$ALIAS <- row$ALIAS
      new_row$EMAIL <- row$ALIAS

      # Enabled bewusst auf TRUE (wie bei Ruthe)
      new_row$ENABLED <- TRUE
    }else{ #zu aktualisierende Datensätze bauen
      new_row <- row
      new_row$USERNAME <- row$USERNAME.x
    }

    new_row[,col]
  })

  result <- base::do.call(rbind, result)
  # 5. Technische Hilfsspalten entfernen

  #result$ALIAS_LOWER <- NULL
  # 6. Doppelte USERID entfernen (letzter gewinnt)
  result <- result[!base::duplicated(result$USERID),col ]
  return(result)
}
