#' Compare form fields between two D365FO form documentations
#'
#' Compares the Fields section of two
#' \code{D365FormDocumentation} objects and identifies
#' added and removed form fields.
#'
#' The comparison is based on the field type,
#' control name, data source and data field to
#' uniquely identify controls across form versions.
#'
#' @param old_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the original form documentation.
#'
#' @param new_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the updated form documentation.
#'
#' @return A list containing:
#' \describe{
#'   \item{Added}{
#'     Fields that exist only in the new documentation.
#'   }
#'   \item{Removed}{
#'     Fields that exist only in the old documentation.
#'   }
#' }
#'
#' @details
#' The function compares the
#' \code{Fields} tables of two
#' \code{D365FormDocumentation} objects.
#'
#' The comparison uses the following columns:
#'
#' \itemize{
#'   \item Type
#'   \item Name
#'   \item DataSource
#'   \item DataField
#' }
#'
#' These attributes uniquely identify controls
#' representing business data on a D365FO form.
#'
#' Typical use cases:
#'
#' \itemize{
#'   \item Detect newly added form fields.
#'   \item Detect removed controls.
#'   \item Validate metadata after Microsoft updates.
#'   \item Compare customized forms between environments.
#' }
#'
#' @examples
#' \dontrun{
#'
#' comparison <-
#'   compare_form_fields(
#'     old_documentation,
#'     new_documentation
#'   )
#'
#' comparison$Added
#'
#' comparison$Removed
#'
#' }
#'
#' @export
compare_form_fields <- function(
    old_documentation,
    new_documentation
) {
  
  #===========================================================
  # VALIDATE INPUT PARAMETERS
  #===========================================================
  
  if (!inherits(
    old_documentation,
    "D365FormDocumentation"
  )) {
    stop(
      "old_documentation must be a D365FormDocumentation object."
    )
  }
  
  if (!inherits(
    new_documentation,
    "D365FormDocumentation"
  )) {
    stop(
      "new_documentation must be a D365FormDocumentation object."
    )
  }
  
  #===========================================================
  # LOAD FIELDS
  #===========================================================
  
  old_fields <-
    old_documentation$Fields
  
  new_fields <-
    new_documentation$Fields
  
  #===========================================================
  # ADDED FIELDS
  #===========================================================
  
  added <-
    
    dplyr::anti_join(
      new_fields,
      old_fields,
      by = c(
        "Type",
        "Name",
        "DataSource",
        "DataField"
      )
    )
  
  #===========================================================
  # REMOVED FIELDS
  #===========================================================
  
  removed <-
    
    dplyr::anti_join(
      old_fields,
      new_fields,
      by = c(
        "Type",
        "Name",
        "DataSource",
        "DataField"
      )
    )
  
  #===========================================================
  # RESULT
  #===========================================================
  
  result <-
    
    list(
      Added = added,
      Removed = removed
    )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  return(result)
  
}