#' Datei suchen (Case-Insensitive)
#'
#' Sucht eine Datei innerhalb eines
#' Verzeichnisses unabhängig von Groß-
#' und Kleinschreibung.
#'
#' @param path Verzeichnis.
#' @param filename Dateiname ohne Erweiterung.
#' @param suffix Optionale Dateiendung
#'   (z.B. "xml", "xlsx", "csv").
#'
#' @return vollständiger Dateipfad.
#'
#' @export
find_file_ci <- function(
    path,
    filename,
    suffix = NULL){

  search_file <-
    if(is.null(suffix)){
      filename
    } else {
      paste0(filename, ".", suffix)
    }

  files <- list.files(path = path, full.names = TRUE)

  match <- files[tolower(basename(files)) == tolower(search_file)]

  if(length(match) == 0){
    stop(paste0("Datei nicht gefunden: ", search_file))
  }

  return(match[1])
}
