#' Compare form tabs between two D365FO form documentations
#'
#' Compares the tab structure of two
#' \code{D365FormDocumentation} objects.
#'
#' The function identifies newly added and
#' removed tabs by comparing the logical
#' tab structure of both form versions.
#'
#' @param old_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the original form documentation.
#'
#' @param new_documentation A
#'   \code{D365FormDocumentation} object representing
#'   the updated form documentation.
#'
#' @return A list containing:
#' \describe{
#'   \item{Added}{
#'     Tabs that exist only in the new documentation.
#'   }
#'   \item{Removed}{
#'     Tabs that exist only in the old documentation.
#'   }
#' }
#'
#' @details
#' The function compares the
#' \code{TabStructure} tables of two
#' \code{D365FormDocumentation} objects.
#'
#' Tabs are uniquely identified using:
#'
#' \itemize{
#'   \item Tab
#'   \item TabPage
#' }
#'
#' Typical use cases:
#'
#' \itemize{
#'   \item Detect newly added tabs after a Microsoft update.
#'   \item Identify removed navigation tabs.
#'   \item Compare customized forms.
#'   \item Validate structural differences between environments.
#' }
#'
#' @examples
#' \dontrun{
#'
#' comparison <-
#'   compare_form_tabs(
#'     old_documentation,
#'     new_documentation
#'   )
#'
#' comparison$Added
#'
#' comparison$Removed
#'
#' }
#'
#' @export
compare_form_tabs <- function(
    old_documentation,
    new_documentation
) {
  
  #===========================================================
  # VALIDATE INPUT PARAMETERS
  #===========================================================
  
  if (!inherits(
    old_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "old_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  if (!inherits(
    new_documentation,
    "D365FormDocumentation"
  )) {
    
    stop(
      "new_documentation must be a D365FormDocumentation object."
    )
    
  }
  
  #===========================================================
  # LOAD TAB STRUCTURE
  #===========================================================
  
  old_tabs <-
    old_documentation$TabStructure
  
  new_tabs <-
    new_documentation$TabStructure
  
  #===========================================================
  # ADDED TABS
  #===========================================================
  
  added <-
    
    dplyr::anti_join(
      new_tabs,
      old_tabs,
      by = c(
        "Tab",
        "TabPage"
      )
    )
  
  #===========================================================
  # REMOVED TABS
  #===========================================================
  
  removed <-
    
    dplyr::anti_join(
      old_tabs,
      new_tabs,
      by = c(
        "Tab",
        "TabPage"
      )
    )
  
  #===========================================================
  # RESULT
  #===========================================================
  
  result <-
    
    list(
      Added = added,
      Removed = removed
    )
  
  #===========================================================
  # RETURN RESULT
  #===========================================================
  
  return(result)
  
}