#' Privilege-Metadaten extrahieren
#'
#' Extrahiert die allgemeinen Metadaten eines
#' D365FO Security Privileges.
#'
#' Die Funktion liest Name, Beschreibung und Label
#' aus der XML-Datei und stellt diese als Tibble bereit.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit den Spalten:
#'
#' * `Name` — Technischer Name des Privileges
#' * `Description` — Beschreibung
#' * `Label` — Anzeigename
#'
#' @details
#' Die Funktion wird intern von [parse_privilege()]
#' verwendet.
#'
#' @seealso [parse_privilege()]
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#' metadata <- extract_metadata(xml_doc)
#' }
#'
#' @export
extract_metadata <- function(xml_doc) {

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # ================================
  # METADATEN EXTRAHIEREN
  # ================================

  result <-
    tibble::tibble(

      Name =
        xml2::xml_text(
          xml2::xml_find_first(
            xml_doc,
            "//AxSecurityPrivilege/Name"
          )
        ),

      Description =
        xml2::xml_text(
          xml2::xml_find_first(
            xml_doc,
            "//AxSecurityPrivilege/Description"
          )
        ),

      Label =
        xml2::xml_text(
          xml2::xml_find_first(
            xml_doc,
            "//AxSecurityPrivilege/Label"
          )
        )
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  if (ncol(result) == 0) {
    result <- empty_metadata()
  }

  return(result)
}
