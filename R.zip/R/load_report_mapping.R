#' Report-Mapping laden
#'
#' Lädt die Konfiguration für die
#' Darstellung von Security-Komponenten
#' in Release-Reports.
#'
#' Die Konfiguration definiert:
#'
#' * Anzeigenamen
#' * Objektspalten
#' * Detailspalten
#'
#' Änderungen an der Report-Darstellung
#' sollten über die Mapping-Datei erfolgen.
#'
#' @return Tibble mit der Report-Konfiguration.
#'
#' @export
load_report_mapping <- function(){

  # ================================
  # DATEI LADEN
  # ================================

  mapping_file <-
    system.file(
      "config",
      "report_mapping.csv",
      package = "D365Security"
    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(

    readr::read_csv(
      mapping_file,
      show_col_types = FALSE
    )

  )

}
