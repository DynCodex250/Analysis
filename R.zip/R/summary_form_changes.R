#' Formularänderungen zusammenfassen
#'#' Erstellt eine kompakte Übersicht
#' aller Änderungen eines
#' D365FormComparison Objekts.
#'#' @param comparison Ergebnis von
#' compare_forms_documentation().
#'#' @return Tibble mit Anzahl der
#' hinzugefügten und entfernten
#' Objekte.
#'#' @examples#' comparison <-
#'   compare_forms_documentation(
#'     documentation_old,
#'     documentation_new
#'   )
#'#' summary_form_changes(
#'   comparison
#' )
#'#' @export

summary_form_changes <- function(comparison){

  # ================================
  #   VALIDIERUNG
  # ================================

    if(!inherits(comparison,"D365FormComparison")){

      stop(
        "comparison muss ein D365FormComparison sein."
      )

    }

  # ================================
  #   ZUSAMMENFASSUNG
  # ================================

    result <-

      tibble::tibble(

        ObjectType = c(
          "DataSources",
          "Tabs",
          "Groups",
          "Fields",
          "Buttons",
          "Parts"
        ),

        Added = c(
          nrow(comparison$DataSources$Added),
          nrow(comparison$Tabs$Added),
          nrow(comparison$Groups$Added),
          nrow(comparison$Fields$Added),
          nrow(comparison$Buttons$Added),
          nrow(comparison$Parts$Added)
        ),

        Removed = c(
          nrow(comparison$DataSources$Removed),
          nrow(comparison$Tabs$Removed),
          nrow(comparison$Groups$Removed),
          nrow(comparison$Fields$Removed),
          nrow(comparison$Buttons$Removed),
          nrow(comparison$Parts$Removed)
        )

      )

    # ================================
    #   ERGEBNIS
    # ================================

      result <-result |>dplyr::mutate(TotalChanges = Added + Removed) |>dplyr::arrange(dplyr::desc(TotalChanges))

      return(result)

}
