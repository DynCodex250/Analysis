#' Benutzer nach identischen Berechtigungen gruppieren
#'
#' Gruppiert Benutzer anhand ihres
#' Berechtigungs-Fingerprints.
#'
#' Alle Benutzer innerhalb einer Gruppe besitzen
#' identische Berechtigungen.
#'
#' Die Funktion basiert auf dem Ergebnis von
#' compare_user_permissions_fingerprint().
#'
#' @param fingerprint_analysis Ergebnis von
#' compare_user_permissions_fingerprint().
#'
#' @return Tibble.
#'
#' Enthält:
#'
#' * FingerprintGroup
#' * UsersInGroup
#' * USERID
#'
#' @examples
#' \dontrun{
#' groups <-
#'   create_permission_groups(
#'     fingerprint_analysis
#'   )
#' }
#'
#' @export
sec_create_permission_groups <- function(
  fingerprint_analysis
){
  required_columns <- c(
    "USERID",
    "FingerprintGroup",
    "UsersInGroup"
  )
  
  missing_columns <- setdiff(
    required_columns,
    names(fingerprint_analysis)
  )
  
  if(length(missing_columns) > 0){
    stop(paste("Folgende Spalten fehlen:",
      paste(missing_columns, collapse = ", ")))
  }
  
  result <-
    fingerprint_analysis |>
    dplyr::group_by(
      FingerprintGroup,
      UsersInGroup
    ) |>
    dplyr::summarise(
      Users =
        paste(sort(USERID),
          collapse = ", "
        ),
      .groups = "drop"
    ) |>
    dplyr::arrange(
      dplyr::desc(UsersInGroup),
      FingerprintGroup
    )
  
  return(result)
}
