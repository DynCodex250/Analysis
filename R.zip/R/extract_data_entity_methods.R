#' Data Entity Methoden extrahieren
#'
#' Extrahiert sämtliche Methodenberechtigungen von
#' Data Entities eines D365FO Security Privileges.
#'
#' @param xml_doc XML-Dokument eines D365FO Privileges.
#'
#' @return Tibble mit allen Data Entity Methoden.
#'
#' @details
#' Die Funktion liest sämtliche
#' AxSecurityDataEntityMethodPermission-Knoten aus.
#'
#' Leere Ergebnisse werden als Tibble mit definierter
#' Struktur zurückgegeben.
#'
#' @seealso
#' parse_privilege()
#' extract_data_entity_permissions()
#'
#' @examples
#' \dontrun{
#' xml_doc <- xml2::read_xml(xml_file)
#'
#' methods <-
#'   extract_data_entity_methods(
#'     xml_doc
#'   )
#' }
#'
#' @export
extract_data_entity_methods <- function(xml_doc) {

  # =========================================
  # EINGABEPARAMETER VALIDIEREN
  # =========================================

  if (!inherits(xml_doc, "xml_document")) {
    stop("xml_doc muss ein xml_document sein.")
  }

  # =========================================
  # METHODEN EXTRAHIEREN
  # =========================================

  entity_nodes <- xml2::xml_find_all(
    xml_doc,
    "//DataEntityPermissions/AxSecurityDataEntityPermission"
  )

  result <- purrr::map_dfr(entity_nodes, function(entity_node) {

    entity_name <- xml2::xml_text(
      xml2::xml_find_first(entity_node, "./Name")
    )

    methods <- xml2::xml_find_all(
      entity_node,
      "./Methods/AxSecurityDataEntityMethodPermission"
    )

    purrr::map_dfr(methods, function(method_node) {

      tibble::tibble(
        EntityName = entity_name,

        MethodName = xml2::xml_text(
          xml2::xml_find_first(method_node, "./Name")
        ),

        Read = xml2::xml_text(
          xml2::xml_find_first(method_node, "./Grant/Read")
        ),

        Create = xml2::xml_text(
          xml2::xml_find_first(method_node, "./Grant/Create")
        ),

        Update = xml2::xml_text(
          xml2::xml_find_first(method_node, "./Grant/Update")
        ),

        Delete = xml2::xml_text(
          xml2::xml_find_first(method_node, "./Grant/Delete")
        ),

        Correct = xml2::xml_text(
          xml2::xml_find_first(method_node, "./Grant/Correct")
        ),

        Invoke = xml2::xml_text(
          xml2::xml_find_first(method_node, "./Grant/Invoke")
        )
      )
    })
  })

  # =========================================
  # LEERE STRUKTUR ABSICHERN
  # =========================================

  if (ncol(result) == 0) {
    result <- empty_data_entity_methods()
  }

  # =========================================
  # ERGEBNIS ZURÜCKGEBEN
  # =========================================

  return(result)
}
