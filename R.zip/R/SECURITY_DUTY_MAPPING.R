
SECURITY_PRIVILEGE_MAPPING <- tibble::tribble(

  ~resource_type,
  ~xml_section,
  ~xml_node,
  ~parent_node,
  ~xml_subnode,
  ~object_type,
  ~resource_pattern,
  ~supports_grants,
  ~supports_fields,
  ~supports_subpermissions,
  ~notes,

  # =========================================
  #   MENU ITEM DISPLAY
  # =========================================

    "Menu item display","EntryPoints","AxSecurityMenuItemDisplayReference","EntryPoints",NA,"MenuItemDisplay",NA,TRUE,FALSE,FALSE,"Display MenuItems",

  # =========================================
  #   MENU ITEM ACTION
  # =========================================

    "Menu item action","EntryPoints","AxSecurityMenuItemActionReference","EntryPoints",NA,"MenuItemAction",NA,TRUE,FALSE,FALSE,"Action MenuItems",

  # =========================================
  #   MENU ITEM OUTPUT
  # =========================================

    "Menu item output","EntryPoints","AxSecurityMenuItemOutputReference","EntryPoints",NA,"MenuItemOutput",NA,TRUE,FALSE,FALSE,"Output MenuItems",

  # =========================================
  #   SERVICE OPERATION
  # =========================================

    "Service operation","EntryPoints","AxSecurityServiceOperationReference","EntryPoints",NA,"ServiceOperation",NA,TRUE,FALSE,FALSE,"Service operations",

  # =========================================
  #   DATA ENTITY
  # =========================================

    "Data entity","DataEntityPermissions","AxSecurityDataEntityPermission","DataEntityPermissions",NA,"DataEntity","Data Management\\|Data services\\",TRUE,FALSE,TRUE,"Data entities",

  # =========================================
  #   DATA ENTITY ACTION
  # =========================================

    "Data entity action","DataEntityPermissions","AxSecurityDataEntityMethodPermission","DataEntityPermissions","Methods","DataEntityAction","Data services\\",TRUE,FALSE,TRUE,"Entity methods/actions",

  # =========================================
  #   TABLE
  # =========================================

    "Table","DirectAccessPermissions","AxSecurityDataEntityReference","DirectAccessPermissions",NA,"Table",NA,TRUE,TRUE,TRUE,"Direct table permissions",

  # =========================================
  #   TABLE FIELD
  # =========================================

    "Table Field","DirectAccessPermissions","AxSecurityDataEntityFieldReference","Fields",NA,"TableField",NA,TRUE,FALSE,FALSE,"Direct table field permissions",

  # =========================================
  #   FORM CONTROL
  # =========================================

    "Form control","EntryPoints","AxSecurityEntryPointReferenceFormControl","FormControlOverrides",NA,"FormControl",NA,TRUE,FALSE,TRUE,"Form controls",

  # =========================================
  #   FORM DATA SOURCE
  # =========================================

    "Form Data Source","EntryPoints","AxSecurityEntryPointReferenceFormDataSource","FormControlOverrides",NA,"FormDataSource",NA,TRUE,TRUE,TRUE,"Form datasource permissions")



# =========================================
#   D365FO ROLE SECURITY MAPPING
# =========================================
#
#   Dieses Mapping beschreibt,
# wie Security-Objekte innerhalb
# von AxSecurityRole XML-Dateien
# modelliert werden.
#
# Das Mapping gilt AUSSCHLIESSLICH
# für:
#
#
#   NICHT für:
#
#   - AxSecurityPrivilege
# - AxSecurityDuty
#
# Grundlage:
#
#   - echte Role XML Dateien
# - Reverse Engineering
# - SQL Analysen


#' D365FO Role XML Mapping#'#' Mapping zwischen XML-Sektionen#' und den entsprechenden
#' Security-Objekten innerhalb#' von AxSecurityRole.#'#' @format data.frame
#'#' @usage SECURITY_ROLE_MAPPING#'#' @export

  SECURITY_ROLE_MAPPING <- tibble::tribble(

    ~security_object,
    ~xml_section,
    ~xml_node,
    ~xml_subnode,
    ~reference_type,
    ~notes,

    # =========================================
    #   DUTIES
    # =========================================

      "Duty","Duties","AxSecurityDutyReference",NA,"Reference","Duty references inside roles",

    # =========================================
    #   PRIVILEGES
    # =========================================

      "Privilege","Privileges","AxSecurityPrivilegeReference",NA,"Reference","Direct privilege references inside roles",

    # =========================================
    #   SUBROLES
    # =========================================

      "SubRole","SubRoles","AxSecurityRoleReference",NA,"Reference","Nested role references",

    # =========================================
    #   DIRECT ACCESS TABLE
    # =========================================

      "Table","DirectAccessPermissions","AxSecurityDataEntityReference",NA,"Permission","Direct table permissions",

    # =========================================
    #   DIRECT ACCESS TABLE FIELD
    # =========================================

      "Table Field","DirectAccessPermissions","AxSecurityDataEntityFieldReference","Fields","Permission","Direct table field permissions")


# =========================================
#   D365FO DUTY SECURITY MAPPING
# =========================================
# Dieses Mapping beschreibt,
# wie Security-Objekte innerhalb
# von AxSecurityDuty XML-Dateien
# modelliert werden.
#
#
#
# Das Mapping gilt AUSSCHLIESSLICH
#
# für:
#
#   NICHT für:
#
#  - AxSecurityRole
#  - AxSecurityPrivilege
#
#
# Grundlage:
#
#  - Reverse Engineering
#  - echte Duty XML Dateien
#  - SQL Analysen
#  - Microsoft Security Architektur



#' D365FO Duty XML Mapping
#'#' Mapping zwischen XML-Sektionen
#' und den entsprechenden
#' Security-Objekten innerhalb
#' von AxSecurityDuty.
#'#' @format data.frame#'#' @usage SECURITY_DUTY_MAPPING
#'#' @export

SECURITY_DUTY_MAPPING <- tibble::tribble(

  ~security_object,
  ~xml_section,
  ~xml_node,
  ~xml_subnode,
  ~reference_type,
  ~notes,

  # =========================================
  #   PRIVILEGES
  # =========================================

  "Privilege",
  "Privileges",
  "AxSecurityPrivilegeReference",
  NA,
  "Reference",
  "Privilege references inside duties",

  # =========================================
  #   SUB DUTIES
  # =========================================

    "SubDuty","SubDuties","AxSecurityDutyReference",NA,"Reference","Nested duty references",

  # =========================================
  #   DIRECT ACCESS TABLE
  # =========================================

    "Table","DirectAccessPermissions","AxSecurityDataEntityReference",NA,"Permission","Direct table permissions",

  # =========================================
  #   DIRECT ACCESS TABLE FIELD
  # =========================================

    "Table Field","DirectAccessPermissions","AxSecurityDataEntityFieldReference","Fields","Permission","Direct table field permissions"
  )






#' # =========================================
#' #   D365FO PRIVILEGE SECURITY MAPPING
#' # =========================================
#' #
#' #
#' #   Dieses Mapping beschreibt,
#' # wie Security-Objekte aus SQL
#' # innerhalb von AxSecurityPrivilege
#' # XML-Dateien modelliert werden.
#' #
#' #
#' # Grundlage:
#' #
#' #   - echte Privilege XML Dateien
#' # - SQL Reverse Engineering
#' #
#' # - D365FO Metadata Analyse
#' #
#' # Das Mapping gilt AUSSCHLIESSLICH
#' #
#' # für:
#' #
#' #
#' #   NICHT für:
#' #
#' #  - AxSecurityRole
#' #  - AxSecurityDuty
#'
#'
#' #' D365FO Privilege XML Mapping#'#' Mapping zwischen SQL RESOURCETYPE
#' #' und der entsprechenden XML-Struktur
#' #' innerhalb von AxSecurityPrivilege.
#' #'#' @format data.frame
#' #'#' @usage SECURITY_PRIVILEGE_MAPPING#'#' @export
#'
#' SECURITY_PRIVILEGE_MAPPING <- tibble::tribble(
#'
#'   ~resource_type,
#'   ~xml_section,
#'   ~xml_node,
#'   ~xml_subnode,
#'   ~object_type,
#'   ~resource_pattern,
#'   ~notes,
#'
#'   # =========================================
#'   #   MENU ITEM DISPLAY
#'   # =========================================
#'
#'   "Menu item display","EntryPoints","AxSecurityEntryPointReference",NA,"MenuItemDisplay",NA,"Display MenuItems",
#'
#'   # =========================================
#'   #   MENU ITEM ACTION
#'   # =========================================
#'
#'   "Menu item action","EntryPoints","AxSecurityEntryPointReference",NA,"MenuItemAction",NA,"Action MenuItems",
#'
#'   # =========================================
#'   #   MENU ITEM OUTPUT
#'   # =========================================
#'
#'   "Menu item output","EntryPoints","AxSecurityEntryPointReference",NA,"MenuItemOutput",NA,"Output MenuItems",
#'
#'   # =========================================
#'   #   SERVICE OPERATION
#'   # =========================================
#'
#'   "Service operation","EntryPoints","AxSecurityEntryPointReference",NA,"ServiceOperation",NA,"Service Operations",
#'
#'   # =========================================
#'   #   DATA ENTITY
#'   # =========================================
#'
#'   "Data entity","DataEntityPermissions","AxSecurityDataEntityPermission",NA,NA,"Data Management\\|Data services\\","Data entities",
#'
#'   # =========================================
#'   #   DATA ENTITY ACTION
#'   # =========================================
#'
#'   "Data entity action","DataEntityPermissions","AxSecurityDataEntityMethodPermission","Methods",NA,"Data services\\","Entity methods/actions",
#'
#'   # =========================================
#'   #   TABLE
#'   # =========================================
#'
#'   "Table","DirectAccessPermissions","AxSecurityDataEntityReference",NA,NA,NA,"Direct table permissions",
#'
#'   # =========================================
#'   #   TABLE FIELD
#'   # =========================================
#'
#'   "Table Field","DirectAccessPermissions","AxSecurityDataEntityFieldReference","Fields",NA,NA,"Direct table field permissions",
#'
#'   # =========================================
#'   #   FORM CONTROL
#'   # =========================================
#'
#'   "Form control","EntryPoints","AxSecurityEntryPointReferenceFormControl","FormControlOverrides","FormControl",NA,"Form controls",
#'
#'   # =========================================
#'   #   FORM DATA SOURCE
#'   # =========================================
#'
#'   "Form Data Source","EntryPoints","AxSecurityEntryPointReferenceFormDataSource","FormControlOverrides","FormDataSource",NA,"Form datasource permissions")
#'
#'
#'
