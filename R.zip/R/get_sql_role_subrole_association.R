#' Security Subroles laden
#'
#' Lädt die Beziehungen zwischen
#' Security Roles und Security Subroles
#' aus SYSTEMSECURITYSUBROLEENTITY.
#'
#' Die Funktion kann verwendet werden,
#' um die Zusammensetzung einer Rolle
#' aus ihren enthaltenen Subrollen
#' zu analysieren.
#'
#' @param con DBI Connection.
#'
#' @param role_names Optionaler Vektor mit
#' Rollennamen.
#'
#' Wenn leer, werden alle verfügbaren
#' Rollen-Subrollen-Beziehungen geladen.
#'
#' @return Tibble mit:
#'
#' * SECURITYROLEIDENTIFIER
#' * SECURITYROLENAME
#' * SECURITYSUBROLEIDENTIFIER
#' * SECURITYSUBROLENAME
#'
#' @examples
#' \dontrun{
#'
#' get_sql_role_subrole_association(
#'   con
#' )
#'
#' get_sql_role_subrole_association(
#'   con,
#'   role_names = "Logistics manager"
#' )
#'
#' get_sql_role_subrole_association(
#'   con,
#'   role_names = c(
#'     "Logistics manager",
#'     "Warehouse worker"
#'   )
#' )
#'
#' }
#'
#' @export
get_sql_role_subrole_association <- function(
    con,
    role_names = character()
){
  
  # ================================
  # SQL
  # ================================
  
  query <- "
SELECT
    SSR.SECURITYROLEIDENTIFIER,
    SSR.SECURITYROLENAME,
    SSR.SECURITYSUBROLEIDENTIFIER,
    SSR.SECURITYSUBROLENAME
FROM SYSTEMSECURITYSUBROLEENTITY SSR
WHERE 1 = 1
"
  
  # ================================
  # FILTER
  # ================================
  
  if(length(role_names) > 0){
    
    role_list <- paste0(
      
      "'",
      
      gsub(
        "'",
        "''",
        role_names
      ),
      
      "'",
      
      collapse = ","
      
    )
    
    query <- paste0(
      
      query,
      
      "\nAND SSR.SECURITYROLENAME IN (",
      
      role_list,
      
      ")"
      
    )
    
  }
  
  # ================================
  # AUSFÜHREN
  # ================================
  
  result <-
    
    DBI::dbGetQuery(
      con,
      query
    )
  
  # ================================
  # TIBBLE
  # ================================
  
  result <-
    
    tibble::as_tibble(
      result
    )
  
  return(result)
  
}