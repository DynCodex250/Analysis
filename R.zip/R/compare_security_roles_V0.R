#' D365FO Security-Rollen vergleichen
#'
#' Vergleicht zwei D365FO Security-Rollen auf Basis ihrer
#' XML-Definitionen und ermittelt Unterschiede in den
#' referenzierten Security-Objekten.
#'
#' Die Funktion analysiert die Rollenstruktur direkt auf
#' XML-Ebene und vergleicht die enthaltenen:
#'
#' - Duties
#' - Privileges
#' - SubRoles
#' - Direct Access Permissions
#'
#' Für jede Kategorie werden gemeinsame sowie
#' ausschließlich in einer der beiden Rollen vorhandene
#' Objekte ermittelt.
#'
#' Typische Anwendungsfälle:
#' - Release-Vergleiche
#' - Security-Migrationen
#' - Rollenharmonisierung
#' - Qualitätsprüfungen
#' - Security-Reviews
#'
#' @param role_file_1 Vollständiger Pfad zur ersten
#'        Rollen-XML-Datei.
#'
#' @param role_file_2 Vollständiger Pfad zur zweiten
#'        Rollen-XML-Datei.
#'
#' @return Liste mit den Vergleichsergebnissen.
#'
#' Enthaltene Elemente:
#'
#' \describe{
#'   \item{role_1}{
#'   Name der ersten Rolle.
#'   }
#'
#'   \item{role_2}{
#'   Name der zweiten Rolle.
#'   }
#'
#'   \item{duties}{
#'   Vergleich der referenzierten Duties.
#'   }
#'
#'   \item{privileges}{
#'   Vergleich der referenzierten Privileges.
#'   }
#'
#'   \item{subroles}{
#'   Vergleich der referenzierten SubRoles.
#'   }
#'
#'   \item{direct_access_permissions}{
#'   Vergleich der Direct Access Permissions.
#'   }
#' }
#'
#' Jede Vergleichskategorie enthält:
#'
#' \describe{
#'   \item{only_in_role_1}{
#'   Objekte, die ausschließlich in Rolle 1
#'   vorhanden sind.
#'   }
#'
#'   \item{only_in_role_2}{
#'   Objekte, die ausschließlich in Rolle 2
#'   vorhanden sind.
#'   }
#'
#'   \item{common}{
#'   Objekte, die in beiden Rollen vorhanden sind.
#'   }
#' }
#'
#' @details
#' Die Funktion liest beide Rollen direkt als XML-Dateien
#' ein und extrahiert die enthaltenen Security-Referenzen.
#'
#' Der Vergleich erfolgt über Mengenoperationen mittels
#' `setdiff()` und `intersect()`.
#'
#' Es werden ausschließlich Unterschiede in den
#' referenzierten Security-Objekten betrachtet.
#'
#' Berechtigungsunterschiede innerhalb einzelner
#' Privileges oder Duties werden nicht analysiert.
#'
#' Für detaillierte Berechtigungsvergleiche sollten die
#' entsprechenden Privilege-Vergleichsfunktionen
#' verwendet werden.
#'
#' @examples
#' result <- compare_security_roles(
#'   role_file_1 = "SystemAdministrator.xml",
#'   role_file_2 = "SystemAdministrator_New.xml"
#' )
#'
#' result$duties
#'
#' result$privileges
#'
#' result$subroles
#'
#' @seealso
#' compare_all_roles()
#' compare_component_existence()
#'
#' @export
compare_security_roles_V0 <- function(
    role_file_1,
    role_file_2){

  # =========================================
  # XML LADEN
  # =========================================

  role_1 <- read_xml(role_file_1)

  role_2 <- read_xml(role_file_2)

  # =========================================
  # ROLLENNAME
  # =========================================

  role_name_1 <- xml_text(
    xml_find_first(
      role_1,
      "//Name"
    )
  )

  role_name_2 <- xml_text(
    xml_find_first(
      role_2,
      "//Name"
    )
  )

  # =========================================
  # DUTIES
  # =========================================

  duties_1 <- xml_find_all(
    role_1,
    "//Duties/AxSecurityDutyReference/Name"
  ) %>%
    xml_text()

  duties_2 <- xml_find_all(
    role_2,
    "//Duties/AxSecurityDutyReference/Name"
  ) %>%
    xml_text()

  # =========================================
  # PRIVILEGES
  # =========================================

  privileges_1 <- xml_find_all(
    role_1,
    "//Privileges/AxSecurityPrivilegeReference/Name"
  ) %>%
    xml_text()

  privileges_2 <- xml_find_all(
    role_2,
    "//Privileges/AxSecurityPrivilegeReference/Name"
  ) %>%
    xml_text()

  # =========================================
  # SUBROLES
  # =========================================

  subroles_1 <- xml_find_all(
    role_1,
    "//SubRoles/AxSecurityRoleReference/Name"
  ) %>%
    xml_text()

  subroles_2 <- xml_find_all(
    role_2,
    "//SubRoles/AxSecurityRoleReference/Name"
  ) %>%
    xml_text()

  # =========================================
  # DIRECT ACCESS PERMISSIONS
  # =========================================

  dap_1 <- xml_find_all(
    role_1,
    "//DirectAccessPermissions//*[local-name()='Name']"
  ) %>%
    xml_text()

  dap_2 <- xml_find_all(
    role_2,
    "//DirectAccessPermissions//*[local-name()='Name']"
  ) %>%
    xml_text()

  # =========================================
  # DUTY DIFF
  # =========================================

  duties_only_in_role_1 <- setdiff(
    duties_1,
    duties_2
  )

  duties_only_in_role_2 <- setdiff(
    duties_2,
    duties_1
  )

  # =========================================
  # PRIVILEGE DIFF
  # =========================================

  privileges_only_in_role_1 <- setdiff(
    privileges_1,
    privileges_2
  )

  privileges_only_in_role_2 <- setdiff(
    privileges_2,
    privileges_1
  )

  # =========================================
  # SUBROLE DIFF
  # =========================================

  subroles_only_in_role_1 <- setdiff(
    subroles_1,
    subroles_2
  )

  subroles_only_in_role_2 <- setdiff(
    subroles_2,
    subroles_1
  )

  # =========================================
  # DAP DIFF
  # =========================================

  dap_only_in_role_1 <- setdiff(
    dap_1,
    dap_2
  )

  dap_only_in_role_2 <- setdiff(
    dap_2,
    dap_1
  )

  # =========================================
  # ERGEBNIS
  # =========================================

  result <- list(

    role_1 = role_name_1,

    role_2 = role_name_2,

    duties = list(

      only_in_role_1 =
        duties_only_in_role_1,

      only_in_role_2 =
        duties_only_in_role_2,

      common =
        intersect(
          duties_1,
          duties_2
        )
    ),

    privileges = list(

      only_in_role_1 =
        privileges_only_in_role_1,

      only_in_role_2 =
        privileges_only_in_role_2,

      common =
        intersect(
          privileges_1,
          privileges_2
        )
    ),

    subroles = list(

      only_in_role_1 =
        subroles_only_in_role_1,

      only_in_role_2 =
        subroles_only_in_role_2,

      common =
        intersect(
          subroles_1,
          subroles_2
        )
    ),

    direct_access_permissions = list(

      only_in_role_1 =
        dap_only_in_role_1,

      only_in_role_2 =
        dap_only_in_role_2,

      common =
        intersect(
          dap_1,
          dap_2
        )
    )
  )

  return(result)
}
