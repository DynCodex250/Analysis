#' Get licensing requirements for D365FO privileges
#'
#' Retrieves licensing information from the
#' `LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW`.
#'
#' The function returns the relationship between
#' D365FO security privileges and their corresponding
#' license requirements.
#'
#' By default, only privileges belonging to the
#' `"Operations - Activity"` SKU are returned.
#'
#' Optionally, the result can be filtered by one or more
#' privilege identifiers.
#'
#' @param con DBI connection.
#'
#' @param privilege_identifiers Character vector of
#' privilege identifiers.
#'
#' @param sku_name License SKU name.
#'
#' @return Tibble.
#'
#' @examples
#' \dontrun{
#'
#' licenses <-
#'   get_sql_license_requirements_view(
#'     con
#'   )
#'
#' licenses <-
#'   get_sql_license_requirements_view(
#'     con,
#'     privilege_identifiers = c(
#'       "WHSLOADPLANNINGWORKBENCHVIEW",
#'       "WHSLOADPLANNINGWORKBENCHMAINTAIN"
#'     )
#'   )
#'
#' licenses <-
#'   get_sql_license_requirements_view(
#'     con,
#'     sku_name = "Operations - Task"
#'   )
#'
#' }
#'
#' @export
get_sql_license_requirements_view <- function(
    con,
    privilege_identifiers = character(),
    sku_name = "Operations - Activity"
){
  
  query <- "

SELECT

    SP.IDENTIFIER,
    LPRDV.AOTNAME,
    LPRDV.SKUNAME,
    LPRDV.ENTITLED,
    LPRDV.NOTENTITLED,
    LPRDV.ACCESSLEVEL

FROM LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW LPRDV

INNER JOIN SECURITYPRIVILEGE SP

    ON SP.RECID = LPRDV.SECURITYPRIVILEGE

WHERE 1 = 1

"
  
  # ================================
  # SKU FILTER
  # ================================
  
  if(
    
    !is.null(sku_name) &&
    length(sku_name) > 0 &&
    nzchar(sku_name)
    
  ){
    
    query <- paste0(
      
      query,
      
      "\nAND LPRDV.SKUNAME = '",
      
      gsub(
        "'",
        "''",
        sku_name
      ),
      
      "'"
      
    )
    
  }
  
  # ================================
  # PRIVILEGE FILTER
  # ================================
  
  if(length(privilege_identifiers) > 0){
    
    privilege_list <- paste0(
      
      "'",
      
      gsub(
        "'",
        "''",
        privilege_identifiers
      ),
      
      "'",
      
      collapse = ","
      
    )
    
    query <- paste0(
      
      query,
      
      "\nAND SP.IDENTIFIER IN (",
      
      privilege_list,
      
      ")"
      
    )
    
  }
  
  # ================================
  # SQL AUSFÜHREN
  # ================================
  
  result <-
    
    DBI::dbGetQuery(
      con,
      query
    ) |>
    
    tibble::as_tibble()
  
  return(result)
  
}