#' Formulardokumentation erstellen#'#' Erstellt eine technische Dokumentation#' eines analysierten D365FO Formulars.#'#' Die Funktion aggregiert die Ergebnisse#' der verschiedenen Analyse- und#' Extraktionsfunktionen in einem#' zentralen Dokumentationsobjekt.#'#' Ziel ist es, die technische Struktur#' eines Formulars sichtbar zu machen,#' ohne das Formular in Visual Studio#' manuell analysieren zu müssen.#'#' Die Dokumentation enthält unter#' anderem:#'#' * Metadaten#' * DataSources#' * Grids#' * ReferenceGroups#' * ActionPane Buttons#'#' @param form_model Ergebnis von#' analyze_form().#'#' @return Objekt der Klasse#' D365FormDocumentation.#'#' Enthält:#'#' * Metadata#' * DataSources#' * Grids#' * ReferenceGroups#' * ActionPaneButtons#'#' @details#' Die Funktion führt keine zusätzliche#' Analyse durch.#'#' Stattdessen werden bereits vorhandene#' Analyseergebnisse in einem zentralen#' Dokumentationsobjekt zusammengeführt.#'#' Die Funktion bildet die Grundlage für:#'#' * Formular-Dokumentationen#' * Release-Vergleiche#' * Extension-Vergleiche#' * Berechtigungsanalysen#' * Suchfunktionen#'#' @examples#' documentation <-#'   generate_form_documentation(#'     form_model#'   )#'#' documentation$Metadata#'#' documentation$DataSources#'#' documentation$Grids#'#' documentation$ReferenceGroups#'#' documentation$ActionPaneButtons#'#' @export

generate_form_documentation_V0 <- function(form_model){

# ================================
#   EINGABEPARAMETER VALIDIEREN
# ================================

  if(!inherits(form_model,"D365FormModel")){

    stop("form_model muss ein D365FormModel sein.")

  }

# ================================
#   DOKUMENTATION ERSTELLEN
# ================================

  result <-

    list(
      Metadata =
        form_model$Metadata,

      DataSources =
        extract_form_datasource_relations(form_model),

      Grids =
        extract_form_grid_datasources(form_model),

      ReferenceGroups =
        extract_form_reference_group_relations(form_model),

      ActionPaneButtons =
        extract_form_action_pane_buttons(form_model),

      TabStructure =
        extract_form_tab_structure(form_model),

      Groups =
        extract_form_groups(form_model),

      StaticTexts = extract_form_static_texts(form_model),

      Buttons =
        extract_form_buttons(form_model),

      Parts =
        extract_form_parts(form_model),

      Fields =
        extract_form_fields(form_model),

      MenuItems =
        extract_form_menu_items(form_model)

    )

  # ================================
  #   KLASSE SETZEN
  # ================================

    class(result) <-c("D365FormDocumentation",class(result))

    # ================================
    #   ERGEBNIS ZURÜCKGEBEN
    # ================================

      return(result)

    }
