-- =============================================================================
-- 08_licensing_privilege_requirements.sql
-- Purpose: Privilege-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 5.K of task brief / Section 7 of source document
--
-- T.SECURITYPRIVILEGE is a numeric RecId (FK into dbo.SECURITYPRIVILEGE.RECID).
-- The INNER JOIN resolves it to SECURITYPRIVILEGE.IDENTIFIER, which is the
-- internal AOT-style code (e.g. "ViewTimeline").
-- This matches USERSECGOVRELATEDOBJECTS.PRIVILEGEIDENTIFIER directly -- a
-- stable, locale-independent key. The display name (P.NAME) is kept for
-- reference only.
-- =============================================================================
SELECT
      T.SKURECID,
      T.SKUNAME,
      T.GROUPNAME,
      T.PRIORITY,
      T.RECID,
      T.SECURITYPRIVILEGE           AS SECURITYPRIVILEGERECID,   -- original numeric RecId, kept for traceability
      P.IDENTIFIER                  AS PRIVILEGEIDENTIFIER,      -- internal identifier, matches USERSECGOVRELATEDOBJECTS.PRIVILEGEIDENTIFIER
      P.NAME                        AS PRIVILEGENAME_DISPLAY,    -- localized display name (reference only, NOT used as join key)
      T.ENTITLEMENTOBJECT,
      T.ACCESSLEVEL,
      T.AOTCHILDNAME,
      T.AOTNAME,
      T.SECURABLETYPE,
      T.ENTITLED,
      T.ENTITLEDYESNO,
      T.NOTENTITLED,
      T.NOTREQUIRED,
      T.NOTREQUIREDYESNO
FROM LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYPRIVILEGE P
    ON P.RECID = T.SECURITYPRIVILEGE
WHERE (@EntitledOnly = 0 OR T.ENTITLED = 1);
