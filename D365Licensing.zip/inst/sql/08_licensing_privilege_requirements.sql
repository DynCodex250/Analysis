-- =============================================================================
-- 08_licensing_privilege_requirements.sql
-- Purpose: Privilege-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 5.K of task brief / Section 7 of source document
--
-- CONFIRMED: same RecId pattern as LICENSINGROLEREQUIREMENTSDETAILEDVIEW /
-- LICENSINGDUTYREQUIREMENTSDETAILEDVIEW. T.SECURITYPRIVILEGE is a numeric
-- RecId (foreign key into dbo.SECURITYPRIVILEGE.RECID), not the privilege
-- display-name text used in USERSECGOVRELATEDOBJECTS.PRIVILEGENAME.
-- Resolved here via dbo.SECURITYPRIVILEGE.NAME (confirmed to hold the
-- localized display text, e.g. "Zeitachse anzeigen"; IDENTIFIER holds the
-- internal AOT-style code, e.g. VIEWTIMELINE - NOT the join target).
-- Original numeric value kept as SECURITYPRIVILEGERECID for traceability.
-- =============================================================================
SELECT
      T.SKURECID,
      T.SKUNAME,
      T.GROUPNAME,
      T.PRIORITY,
      T.RECID,
      T.SECURITYPRIVILEGE            AS SECURITYPRIVILEGERECID,   -- original numeric RecId, kept for traceability
      P.NAME                          AS SECURITYPRIVILEGE,        -- resolved privilege display name (TEXT)
      T.ENTITLEMENTOBJECT,
      T.ACCESSLEVEL,
      T.AOTCHILDNAME,
      T.AOTNAME,
      T.SECURABLETYPE,
      T.ENTITLED,
      T.ENTITLEDYESNO,
      T.NOTENTITLED,
      T.NOTREQUIRED,
      T.NOTREQUIREDYESNO
FROM LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYPRIVILEGE P
    ON P.RECID = T.SECURITYPRIVILEGE
WHERE (@EntitledOnly = 0 OR T.ENTITLED = 1);
