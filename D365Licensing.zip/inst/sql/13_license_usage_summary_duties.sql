-- =============================================================================
-- 13_license_usage_summary_duties.sql
-- Purpose: Reproduces the "Duty licenses" tab of the D365FO
--          System administration > Security > Security governance >
--          Licenses usage summary view.
--
-- Param: @DutyIdentifier (varchar, nullable)
--   NULL  -> all duties (full summary)
--   value -> filter to a single duty by its IDENTIFIER
-- =============================================================================
SELECT
    D.IDENTIFIER             AS DUTYIDENTIFIER,
    D.NAME                   AS DUTYNAME_DISPLAY,
    T.SKUNAME,
    T.GROUPNAME,
    AVG(T.PRIORITY)          AS Priority,
    SUM(T.ENTITLED)          AS Entitled,
    SUM(T.ENTITLEDYESNO)     AS EntitledYesNo,
    SUM(T.NOTENTITLED)       AS NotEntitled,
    SUM(T.NOTREQUIRED)       AS NotRequired,
    SUM(T.NOTREQUIREDYESNO)  AS NotRequiredYesNo
FROM LICENSINGDUTYREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYDUTY D
    ON D.RECID = T.SECURITYDUTY
WHERE (@DutyIdentifier IS NULL OR D.IDENTIFIER = @DutyIdentifier)
GROUP BY
    D.IDENTIFIER,
    D.NAME,
    T.SKUNAME,
    T.GROUPNAME
ORDER BY
    D.IDENTIFIER ASC,
    T.SKUNAME    ASC;
