-- =============================================================================
-- 13_license_usage_summary_duties.sql
-- Purpose: Reproduces the "Duty licenses" tab of the D365FO
--          System administration > Security > Security governance >
--          Licenses usage summary view.
--
-- Groups LICENSINGDUTYREQUIREMENTSDETAILEDVIEW by Duty x SKU and sums the
-- entitlement counts. Analogous to SQL 12 for roles.
--   Duty name      = D.NAME       (localized display text)
--   Duty AOT name  = D.IDENTIFIER (internal identifier, used as join key)
--   SKU Name       = SKUNAME
--   Entitled       = SUM(ENTITLED)
--   Not entitled   = SUM(NOTENTITLED)
--   Not required   = SUM(NOTREQUIRED)
--
-- Param: @DutyIdentifier (varchar, nullable)
--   NULL  -> all duties (full summary)
--   value -> filter to a single duty by its IDENTIFIER
-- =============================================================================
SELECT
    D.IDENTIFIER             AS DUTYIDENTIFIER,
    D.NAME                   AS DUTYNAME_DISPLAY,
    T.SKUNAME,
    SUM(T.ENTITLED)          AS Entitled,
    SUM(T.ENTITLEDYESNO)     AS EntitledYesNo,
    SUM(T.NOTENTITLED)       AS NotEntitled,
    SUM(T.NOTREQUIRED)       AS NotRequired,
    SUM(T.NOTREQUIREDYESNO)  AS NotRequiredYesNo
FROM LICENSINGDUTYREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYDUTY D
    ON D.RECID = T.SECURITYDUTY
WHERE (@DutyIdentifier IS NULL OR D.IDENTIFIER = @DutyIdentifier)
GROUP BY
    D.IDENTIFIER,
    D.NAME,
    T.SKUNAME
ORDER BY
    D.IDENTIFIER ASC,
    T.SKUNAME    ASC;
