-- =============================================================================
-- 16_role_object_license_join.sql
-- Purpose: Per-Role Object-Level License Requirements.
--   Joins USERSECGOVRELATEDOBJECTS with the Consolidated Object License View
--   (SQL 15 tables) to produce one row per (Role x Object x AccessLevel x SKU).
--
--   Maps the separate access-bit columns to a unified ACCESSLEVEL:
--     1 = Read only
--     2 = Write (Update / Create / Delete / Correct / Invoke)
--
--   Objects not found in LicensingEntitlementObjects, or with no explicit
--   entitlement row for the derived AccessLevel, fall back via COALESCE to
--   SKUNAME = 'Team Members' / Priority = 20.
--
--   NOTE: USERSECGOVRELATEDOBJECTS is role-level, not user-level.
--   To get per-user requirements, join the output with SECURITYUSERROLE.
--
-- Param: @RoleIdentifier (varchar, nullable)
--   NULL  -> all roles
--   value -> single role, e.g. 'BATCHJOBMANAGER'
-- =============================================================================
WITH UsgoBase AS (
    SELECT
        ROLEIDENTIFIER,
        ROLENAME,
        RESOURCE_,
        SECURABLETYPE,
        CASE
            WHEN UPDATEACCESS  = 1 OR CREATEACCESS  = 1
              OR DELETEACCESS  = 1 OR CORRECTACCESS = 1
              OR INVOKEACCESS  = 1
            THEN 2
            WHEN READACCESS = 1
            THEN 1
        END AS ACCESSLEVEL
    FROM USERSECGOVRELATEDOBJECTS
    WHERE (@RoleIdentifier IS NULL OR ROLEIDENTIFIER = @RoleIdentifier)
      AND (  READACCESS   + UPDATEACCESS + CREATEACCESS
           + DELETEACCESS + CORRECTACCESS + INVOKEACCESS) > 0
),
ObjLic AS (
    SELECT
        obj.AOTNAME,
        laep.ACCESSLEVEL,
        lsku.Priority,
        lsku.SKUNAME,
        lsku.GROUPNAME,
        lere.ENFORCEMENTPERMISSIONS
    FROM LicensingEntitlementObjects AS obj
    LEFT JOIN LicensingElementsRequiringEntitlement AS lere
        ON lere.ENTITLEMENTOBJECT = obj.RECID
    LEFT JOIN LicensingAllEntitledPermissions AS laep
        ON laep.ENTITLEMENTOBJECT = obj.RECID
    LEFT JOIN LicensingAllSkus AS lsku
        ON lsku.RECID = laep.SKURECID
    WHERE laep.ACCESSLEVEL IS NOT NULL
)
SELECT DISTINCT
    u.ROLEIDENTIFIER,
    u.ROLENAME,
    u.RESOURCE_                          AS AOTNAME,
    u.SECURABLETYPE,
    u.ACCESSLEVEL,
    COALESCE(o.Priority, 20)             AS Priority,
    COALESCE(o.SKUNAME, 'Team Members')  AS SKUNAME,
    o.GROUPNAME,
    o.ENFORCEMENTPERMISSIONS
FROM UsgoBase AS u
LEFT JOIN ObjLic AS o
    ON  o.AOTNAME     = u.RESOURCE_
    AND o.ACCESSLEVEL = u.ACCESSLEVEL
ORDER BY
    u.ROLEIDENTIFIER ASC,
    Priority         DESC,
    u.RESOURCE_      ASC
