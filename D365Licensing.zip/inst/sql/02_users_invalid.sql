-- =============================================================================
-- 02_users_invalid.sql
-- Purpose: Users flagged as invalid / disconnected from Entra ID (READ-ONLY)
-- Source:  Section 2 ("Invalid Users")
-- =============================================================================
SELECT
      USERID,
      OBJECTID,
      INVALIDITYREASON
FROM SYSUSERINVALIDUSERS;
