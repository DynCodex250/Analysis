-- =============================================================================
-- 09_users_active_invalid_join.sql
-- Purpose: Directly answers FINDING-001 at the SQL level: active D365FO users
--          whose Entra ID identity is no longer valid (READ-ONLY)
-- Source:  Section 2, "kombinierte Auswertung"
-- NOTE:    The R layer re-derives this same result from 01_ and 02_ so that
--          the finding is testable against fixture data without a live DB;
--          this query exists for direct/ad-hoc validation against the source.
-- =============================================================================
SELECT
      ACT.ID,
      ACT.NETWORKALIAS,
      ACT.ENABLE,
      ACT.OBJECTID,
      INV.INVALIDITYREASON
FROM USERINFO ACT
INNER JOIN SYSUSERINVALIDUSERS INV
    ON ACT.ID = INV.USERID
WHERE ACT.ENABLE = 1;
