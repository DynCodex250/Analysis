-- =============================================================================
-- 01_users_active.sql
-- Purpose: All users incl. enable status and Entra ObjectID (READ-ONLY)
-- Source:  Section 2 of source document ("Aktive Benutzer & Ungültige Benutzer")
-- Params:  none (full extract; filtering happens in R for testability)
-- =============================================================================
SELECT
      ID,
      NETWORKALIAS,
      ENABLE,
      OBJECTID
FROM USERINFO;
