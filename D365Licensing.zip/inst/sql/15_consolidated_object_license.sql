-- =============================================================================
-- 15_consolidated_object_license.sql
-- Purpose: Consolidated Object License Analysis.
--   For each D365FO licensing object, returns the license SKUs that cover it
--   at each access level, together with Priority and GroupName.
--   Objects without an explicit entitlement record fall back to
--   SKUNAME = 'Team Members' and Priority = 20 via COALESCE.
--
-- Source: Microsoft webinar "Consolidated Object License Analysis" query
--         (D365FO 10.0.43+)
--
-- Access Level values:
--   1 = Read
--   2 = Write (Create / Update / Delete)
--
-- Param: @AotName (varchar, nullable)
--   NULL  -> all objects
--   value -> single object filter, e.g. 'CUSTTABLELISTPAGE'
-- =============================================================================
SELECT
    obj.RECID,
    obj.AOTNAME,
    obj.AOTCHILDNAME,
    obj.SECURABLETYPE,
    lere.ENTITLEMENTOBJECT,
    lere.ENFORCEMENTPERMISSIONS,
    laep.ACCESSLEVEL,
    COALESCE(lsku.[Priority], 20)          AS [Priority],
    COALESCE(lsku.SKUNAME, 'Team Members') AS SKUNAME,
    lsku.GROUPNAME
FROM LicensingEntitlementObjects AS obj
LEFT JOIN LicensingElementsRequiringEntitlement AS lere
    ON lere.ENTITLEMENTOBJECT = obj.RECID
LEFT JOIN LicensingAllEntitledPermissions AS laep
    ON laep.ENTITLEMENTOBJECT = obj.RECID
LEFT JOIN LicensingAllSkus AS lsku
    ON lsku.RECID = laep.SKURECID
WHERE (@AotName IS NULL OR obj.AOTNAME = @AotName)
ORDER BY
    obj.AOTNAME   ASC,
    laep.ACCESSLEVEL ASC,
    [Priority]    ASC
