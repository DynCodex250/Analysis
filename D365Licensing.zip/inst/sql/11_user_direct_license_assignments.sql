-- User Direct License Assignments
--
-- Joins LicensingUserDirectLicenseAssignments with UserInfo and LicensingAllSkus
-- to produce one row per user/SKU combination.
--
-- Key columns:
--   CANBEATTACH = 0  -> Base license  (highest-priority, most expensive)
--   CANBEATTACH = 1  -> Attach license (additional paid SKU)
--   SKUNUMBER        -> 1 = Base (most expensive), 2+ = Attach (ordered by priority)
--   COVEREDENTITLEMENTS  -> total license pool size for this SKU
--   REMAININGENTITLEMENTS -> available seats in pool (0 = pool exhausted)

SELECT
    ui.ID                           AS USERID,
    ui.NETWORKALIAS,
    ui.ENABLE                       AS USERENABLED,
    lua.SKUNUMBER,
    sku.SKUNAME,
    sku.PRIORITY                    AS SKU_PRIORITY,
    sku.GROUPNAME                   AS SKU_GROUPNAME,
    lua.COVEREDENTITLEMENTS,
    lua.REMAININGENTITLEMENTS,
    lua.CANBEATTACH
FROM LicensingUserDirectLicenseAssignments AS lua
INNER JOIN UserInfo AS ui
    ON lua.UserRecId = ui.RecId
INNER JOIN LicensingAllSkus AS sku
    ON lua.SkuRecId = sku.RecId
ORDER BY
    ui.ID       ASC,
    lua.SKUNUMBER ASC
