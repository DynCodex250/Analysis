-- =============================================================================
-- 14_license_usage_summary_privileges.sql
-- Purpose: Reproduces the "Privilege licenses" tab of the D365FO
--          System administration > Security > Security governance >
--          Licenses usage summary view.
--
-- Param: @PrivilegeIdentifier (varchar, nullable)
--   NULL  -> all privileges (full summary)
--   value -> filter to a single privilege by its IDENTIFIER
-- =============================================================================
SELECT
    P.IDENTIFIER             AS PRIVILEGEIDENTIFIER,
    P.NAME                   AS PRIVILEGENAME_DISPLAY,
    T.SKUNAME,
    T.GROUPNAME,
    AVG(T.PRIORITY)          AS Priority,
    SUM(T.ENTITLED)          AS Entitled,
    SUM(T.ENTITLEDYESNO)     AS EntitledYesNo,
    SUM(T.NOTENTITLED)       AS NotEntitled,
    SUM(T.NOTREQUIRED)       AS NotRequired,
    SUM(T.NOTREQUIREDYESNO)  AS NotRequiredYesNo
FROM LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYPRIVILEGE P
    ON P.RECID = T.SECURITYPRIVILEGE
WHERE (@PrivilegeIdentifier IS NULL OR P.IDENTIFIER = @PrivilegeIdentifier)
GROUP BY
    P.IDENTIFIER,
    P.NAME,
    T.SKUNAME,
    T.GROUPNAME
ORDER BY
    P.IDENTIFIER ASC,
    T.SKUNAME    ASC;
