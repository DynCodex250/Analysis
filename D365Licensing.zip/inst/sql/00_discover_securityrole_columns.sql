-- =============================================================================
-- 00_discover_securityrole_columns.sql
-- One-off discovery helper (READ-ONLY) - NOT called by any R function.
--
-- RESOLVED for this environment: dbo.SECURITYROLE.NAME holds the localized
-- role display-name text (matches USERSECGOVRELATEDOBJECTS.ROLENAME format,
-- e.g. "Wirtschaftsprüfer", "Warehouse worker"), while AOTNAME holds the
-- internal PascalCase code name (e.g. WMSWAREHOUSEWORKER) and is NOT the
-- right join target. sql/06_licensing_role_requirements.sql already uses
-- S.NAME accordingly. Kept here for reference / re-validation in other
-- environments where the mapping may differ.
-- =============================================================================
SELECT TOP 5 * FROM SECURITYROLE ORDER BY NAME DESC;

-- Cross-check: confirm NAME actually matches ROLENAME for the same RecIds
-- seen in LICENSINGROLEREQUIREMENTSDETAILEDVIEW.SECURITYROLE, e.g.:
-- SELECT S.RECID, S.NAME, S.AOTNAME
-- FROM SECURITYROLE S
-- WHERE S.RECID IN (99, 412, 418, 444, 496);
