-- =============================================================================
-- 05_user_security_governance_objects.sql
-- Purpose: Role -> Duty -> Privilege -> Entry Point -> License linkage,
--          the core join backbone for the whole analysis (READ-ONLY)
-- Source:  Section 6 ("USERSECGOVRELATEDOBJECTS")
-- Params:  @RoleNameFilter (optional, NULL = all roles). Parameterized instead
--          of the hard-coded 'LIKE '_WIBU QM Mitarbeiter'' in the source doc,
--          so this query is reusable across environments/tenants.
-- =============================================================================
SELECT
      *
FROM USERSECGOVRELATEDOBJECTS
WHERE (@RoleNameFilter IS NULL OR ROLENAME LIKE @RoleNameFilter);
