-- =============================================================================
-- 06_licensing_role_requirements.sql
-- Purpose: Role-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 7 ("LICENSINGROLEREQUIREMENTSDETAILEDVIEW")
-- Params:  @EntitledOnly (bit, default 1) - if 1, restrict to ENTITLED = 1
--          rows; pass 0 to also inspect non-entitled rows for data-quality.
--
-- T.SECURITYROLE is a numeric RecId (FK into dbo.SECURITYROLE.RECID).
-- The INNER JOIN resolves it to SECURITYROLE.AOTNAME, which is the internal
-- PascalCase identifier (e.g. "SystemUser", "WMSWarehouseWorker").
-- This matches USERSECGOVRELATEDOBJECTS.ROLEIDENTIFIER directly -- a stable,
-- locale-independent key. The display name (S.NAME) is kept for reference only.
-- =============================================================================
SELECT
      T.SKURECID,
      T.SKUNAME,
      T.GROUPNAME,
      T.PRIORITY,
      T.RECID,
      T.SECURITYROLE                AS SECURITYROLERECID,   -- original numeric RecId, kept for traceability
      S.AOTNAME                     AS ROLEIDENTIFIER,      -- internal identifier, matches USERSECGOVRELATEDOBJECTS.ROLEIDENTIFIER
      S.NAME                        AS ROLENAME_DISPLAY,    -- localized display name (reference only, NOT used as join key)
      T.ENTITLEMENTOBJECT,
      T.ACCESSLEVEL,
      T.AOTCHILDNAME,
      T.AOTNAME,
      T.SECURABLETYPE,
      T.ENTITLED,
      T.ENTITLEDYESNO,
      T.NOTENTITLED,
      T.NOTREQUIRED,
      T.NOTREQUIREDYESNO
FROM LICENSINGROLEREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYROLE S
    ON S.RECID = T.SECURITYROLE
WHERE (@EntitledOnly = 0 OR T.ENTITLED = 1);
