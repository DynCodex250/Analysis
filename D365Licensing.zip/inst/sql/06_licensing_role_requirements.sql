-- =============================================================================
-- 06_licensing_role_requirements.sql
-- Purpose: Role-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 7 ("LICENSINGROLEREQUIREMENTSDETAILEDVIEW")
-- Params:  @EntitledOnly (bit, default 1) - if 1, restrict to ENTITLED = 1
--          rows as in the source doc example; pass 0 to also inspect
--          non-entitled rows for data-quality checks.
--
-- IMPORTANT (confirmed against the live view definition of
-- LICENSINGROLEREQUIREMENTSDETAILEDVIEW): T.SECURITYROLE in this view is a
-- numeric RecId (foreign key into dbo.SECURITYROLE.RECID), NOT the role
-- display-name text used in USERSECGOVRELATEDOBJECTS.ROLENAME. A direct
-- text join between the two would (and did) match nothing.
--
-- This query therefore resolves the RecId to the display name itself, so
-- that the resulting "SECURITYROLE" column already contains role-name TEXT
-- and stays a drop-in match for R/data_roles_licensing.R's default
-- (name-based) join - no config override needed.
--
-- Confirmed via `SELECT TOP 5 * FROM SECURITYROLE`: dbo.SECURITYROLE.NAME
-- holds the localized display text (e.g. "Wirtschaftsprüfer", "Warehouse
-- worker") matching USERSECGOVRELATEDOBJECTS.ROLENAME's format, while
-- AOTNAME holds the internal PascalCase code name (e.g. WMSWAREHOUSEWORKER)
-- - NAME is the correct join target.
-- =============================================================================
SELECT
      T.SKURECID,
      T.SKUNAME,
      T.GROUPNAME,
      T.PRIORITY,
      T.RECID,
      T.SECURITYROLE                AS SECURITYROLERECID,   -- original numeric RecId, kept for traceability
      S.NAME                        AS SECURITYROLE,        -- resolved role display name (TEXT)
      T.ENTITLEMENTOBJECT,
      T.ACCESSLEVEL,
      T.AOTCHILDNAME,
      T.AOTNAME,
      T.SECURABLETYPE,
      T.ENTITLED,
      T.ENTITLEDYESNO,
      T.NOTENTITLED,
      T.NOTREQUIRED,
      T.NOTREQUIREDYESNO
FROM LICENSINGROLEREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYROLE S
    ON S.RECID = T.SECURITYROLE
WHERE (@EntitledOnly = 0 OR T.ENTITLED = 1);
