-- =============================================================================
-- 07_licensing_duty_requirements.sql
-- Purpose: Duty-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 5.K of task brief / Section 7 of source document
--
-- CONFIRMED: same RecId pattern as LICENSINGROLEREQUIREMENTSDETAILEDVIEW.
-- T.SECURITYDUTY is a numeric RecId (foreign key into dbo.SECURITYDUTY.RECID),
-- not the duty display-name text used in USERSECGOVRELATEDOBJECTS.DUTYNAME.
-- Resolved here via dbo.SECURITYDUTY.NAME (confirmed to hold the localized
-- display text, e.g. "Prozess für Aktivitäten aktivieren"; IDENTIFIER holds
-- the internal AOT-style code, e.g. SMMACTIVITYPROCESSENABLE - NOT the join
-- target). Original numeric value kept as SECURITYDUTYRECID for traceability.
-- =============================================================================
SELECT
      T.SKURECID,
      T.SKUNAME,
      T.GROUPNAME,
      T.PRIORITY,
      T.RECID,
      T.SECURITYDUTY                 AS SECURITYDUTYRECID,   -- original numeric RecId, kept for traceability
      D.NAME                          AS SECURITYDUTY,        -- resolved duty display name (TEXT)
      T.ENTITLEMENTOBJECT,
      T.ACCESSLEVEL,
      T.AOTCHILDNAME,
      T.AOTNAME,
      T.SECURABLETYPE,
      T.ENTITLED,
      T.ENTITLEDYESNO,
      T.NOTENTITLED,
      T.NOTREQUIRED,
      T.NOTREQUIREDYESNO
FROM LICENSINGDUTYREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYDUTY D
    ON D.RECID = T.SECURITYDUTY
WHERE (@EntitledOnly = 0 OR T.ENTITLED = 1);
