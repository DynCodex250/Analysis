-- =============================================================================
-- 07_licensing_duty_requirements.sql
-- Purpose: Duty-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 5.K of task brief / Section 7 of source document
--
-- T.SECURITYDUTY is a numeric RecId (FK into dbo.SECURITYDUTY.RECID).
-- The INNER JOIN resolves it to SECURITYDUTY.IDENTIFIER, which is the internal
-- AOT-style code (e.g. "SMMActivityProcessEnable").
-- This matches USERSECGOVRELATEDOBJECTS.DUTYIDENTIFIER directly -- a stable,
-- locale-independent key. The display name (D.NAME) is kept for reference only.
-- =============================================================================
SELECT
      T.SKURECID,
      T.SKUNAME,
      T.GROUPNAME,
      T.PRIORITY,
      T.RECID,
      T.SECURITYDUTY                AS SECURITYDUTYRECID,   -- original numeric RecId, kept for traceability
      D.IDENTIFIER                  AS DUTYIDENTIFIER,      -- internal identifier, matches USERSECGOVRELATEDOBJECTS.DUTYIDENTIFIER
      D.NAME                        AS DUTYNAME_DISPLAY,    -- localized display name (reference only, NOT used as join key)
      T.ENTITLEMENTOBJECT,
      T.ACCESSLEVEL,
      T.AOTCHILDNAME,
      T.AOTNAME,
      T.SECURABLETYPE,
      T.ENTITLED,
      T.ENTITLEDYESNO,
      T.NOTENTITLED,
      T.NOTREQUIRED,
      T.NOTREQUIREDYESNO
FROM LICENSINGDUTYREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYDUTY D
    ON D.RECID = T.SECURITYDUTY
WHERE (@EntitledOnly = 0 OR T.ENTITLED = 1);
