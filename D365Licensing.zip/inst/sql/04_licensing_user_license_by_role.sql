-- =============================================================================
-- 04_licensing_user_license_by_role.sql
-- Purpose: Microsoft's own per-user license computation by role (READ-ONLY)
--
-- LICENSINGUSERLICENSESBYROLE already contains all key columns directly:
--   USERID, SKUNAME, SKUGROUP, REQUIREDUSERLICENSE, USERREQUIREDLICENSEQTY
-- No USERINFO join needed.
--
-- The only added join is SECURITYROLE to expose ROLEIDENTIFIER (AOTNAME),
-- because the table stores only the display name, not the stable AOT name
-- required for joining with other analysis functions.
--
-- REQUIREDUSERLICENSE values:
--   'Base'   -> highest-cost license for this user x role combination
--   'Attach' -> additional license required alongside the Base
--   ''       -> no paid license required (Team Member / None sufficient)
--
-- NOTE: F&O-side calculation, not PPAC / M365 admin center record.
--       Treat as MEDIUM/HIGH evidence, not as final license assignment.
--
-- Param: @UserId (varchar, nullable)
--   NULL  -> all users
--   value -> single user filter (e.g. 'jsmith@contoso.com')
-- =============================================================================
SELECT
    L.*,
    R.AOTNAME AS ROLEIDENTIFIER
FROM LICENSINGUSERLICENSESBYROLE L
INNER JOIN SECURITYROLE R
    ON L.SECURITYROLERECID = R.RECID
WHERE (@UserId IS NULL OR L.USERID = @UserId)
ORDER BY
    L.USERID ASC,
    R.AOTNAME ASC
