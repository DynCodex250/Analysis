-- =============================================================================
-- 04_licensing_user_license_by_role.sql
-- Purpose: Microsoft's own per-user license computation by role (READ-ONLY)
-- Source:  Section 6 ("User License by Role")
-- NOTE:    This is the closest thing to ground truth available inside the
--          database, but it is still an F&O-side calculation, not the PPAC/
--          Microsoft 365 admin center licensing record. Treat as MEDIUM/HIGH
--          evidence, not as final license assignment.
-- =============================================================================
SELECT *
FROM LICENSINGUSERLICENSESBYROLE;
