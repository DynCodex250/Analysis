-- =============================================================================
-- 12_license_usage_summary_roles.sql
-- Purpose: Reproduces the "Role licenses" tab of the D365FO
--          System administration > Security > Security governance >
--          Licenses usage summary view.
--
-- Groups LICENSINGROLEREQUIREMENTSDETAILEDVIEW by Role x SKU and sums the
-- entitlement counts. Matches the on-screen columns:
--   Role name      = S.NAME  (localized display text)
--   Role AOT name  = S.AOTNAME  (internal identifier, used as join key)
--   SKU Name       = SKUNAME
--   Entitled       = SUM(ENTITLED)
--   Not entitled   = SUM(NOTENTITLED)
--   Not required   = SUM(NOTREQUIRED)
--
-- Param: @RoleIdentifier (varchar, nullable)
--   NULL  -> all roles (full summary)
--   value -> filter to a single role by its AOTNAME  (e.g. 'BATCHJOBMANAGER')
-- =============================================================================
SELECT
    S.AOTNAME                AS ROLEIDENTIFIER,
    S.NAME                   AS ROLENAME_DISPLAY,
    T.SKUNAME,
    SUM(T.ENTITLED)          AS Entitled,
    SUM(T.ENTITLEDYESNO)     AS EntitledYesNo,
    SUM(T.NOTENTITLED)       AS NotEntitled,
    SUM(T.NOTREQUIRED)       AS NotRequired,
    SUM(T.NOTREQUIREDYESNO)  AS NotRequiredYesNo
FROM LICENSINGROLEREQUIREMENTSDETAILEDVIEW T
INNER JOIN SECURITYROLE S
    ON S.RECID = T.SECURITYROLE
WHERE (@RoleIdentifier IS NULL OR S.AOTNAME = @RoleIdentifier)
GROUP BY
    S.AOTNAME,
    S.NAME,
    T.SKUNAME
ORDER BY
    S.AOTNAME ASC,
    T.SKUNAME ASC;
