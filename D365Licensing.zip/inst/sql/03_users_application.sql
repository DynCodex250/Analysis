-- =============================================================================
-- 03_users_application.sql
-- Purpose: Application users / technical & integration accounts (READ-ONLY)
-- Source:  Section 3 ("Application Users")
-- =============================================================================
SELECT
      AADCLIENTID,
      USERID,
      NAME
FROM SYSAADCLIENTTABLE;
