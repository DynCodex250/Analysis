test_cfg <- list(
  licensing = list(
    service_roles = c("System user", "Warehouse mobile device user"),
    admin_role_exceptions = c("System administrator")
  )
)

test_that("service-only role combination is classified per the documented rule", {
  ur <- data.frame(user_id = c("U1", "U1"), role = c("System user", "Warehouse mobile device user"), stringsAsFactors = FALSE)
  out <- classify_service_vs_business_roles(ur, test_cfg)
  expect_equal(out$role_combination_class, "SERVICE_ROLES_ONLY_PER_DOC_NO_LICENSE_REQUIRES_VALIDATION")
})

test_that("business + service role combination is flagged as license-likely", {
  ur <- data.frame(user_id = c("U2", "U2"), role = c("System user", "Accounts Payable Clerk"), stringsAsFactors = FALSE)
  out <- classify_service_vs_business_roles(ur, test_cfg)
  expect_equal(out$role_combination_class, "BUSINESS_PLUS_SERVICE_ROLE_LICENSE_LIKELY_REQUIRES_VALIDATION")
})

test_that("System Administrator is always treated as a special case regardless of other roles", {
  ur <- data.frame(user_id = c("U3", "U3"), role = c("System administrator", "System user"), stringsAsFactors = FALSE)
  out <- classify_service_vs_business_roles(ur, test_cfg)
  expect_equal(out$role_combination_class, "SYSTEM_ADMINISTRATOR_SPECIAL_CASE")
})

test_that("business-only roles are classified without a REQUIRES_VALIDATION disclaimer", {
  ur <- data.frame(user_id = "U4", role = "Accounts Payable Clerk", stringsAsFactors = FALSE)
  out <- classify_service_vs_business_roles(ur, test_cfg)
  expect_equal(out$role_combination_class, "BUSINESS_ROLES_ONLY")
})
