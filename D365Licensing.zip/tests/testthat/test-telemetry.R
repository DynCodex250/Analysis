test_cfg_telemetry <- list(
  telemetry = list(
    enabled = TRUE,
    telemetry_days = 90,
    min_recommended_days = 14,
    app_insights_env_var = "TEST_APPINSIGHTS_APP_ID",
    api_key_env_var = "TEST_APPINSIGHTS_API_KEY"
  )
)

test_that("run_kql_query prefers the host project's run_appinsights_query() when available", {
  called_with <- NULL
  run_appinsights_query <<- function(environment, query) {
    called_with <<- list(environment = environment, query = query)
    data.frame(user_Id = "U1", name = "EP1", last_seen = "2026-01-01T00:00:00Z",
               duration_seconds = "10", touches = "3", stringsAsFactors = FALSE)
  }
  on.exit(rm(run_appinsights_query, envir = .GlobalEnv))

  out <- run_kql_query("pageViews | take 5", test_cfg_telemetry, environment = "PRJ")

  expect_equal(called_with$environment, "PRJ")
  expect_equal(attr(out, "status"), "OK")
  expect_equal(nrow(out), 1)
})

test_that("run_kql_query returns UNKNOWN (not an error) if the host helper throws", {
  run_appinsights_query <<- function(environment, query) stop("credentials not found for environment")
  on.exit(rm(run_appinsights_query, envir = .GlobalEnv))

  out <- run_kql_query("pageViews | take 5", test_cfg_telemetry, environment = "PRJ")
  expect_equal(attr(out, "status"), "UNKNOWN")
  expect_equal(nrow(out), 0)
})

test_that("run_kql_query returns UNKNOWN when telemetry is disabled in config, without calling anything", {
  called <- FALSE
  run_appinsights_query <<- function(environment, query) { called <<- TRUE; data.frame() }
  on.exit(rm(run_appinsights_query, envir = .GlobalEnv))

  disabled_cfg <- test_cfg_telemetry
  disabled_cfg$telemetry$enabled <- FALSE

  out <- run_kql_query("pageViews | take 5", disabled_cfg, environment = "PRJ")
  expect_equal(attr(out, "status"), "UNKNOWN")
  expect_false(called)
})

test_that("load_telemetry_touches coerces numeric-looking columns and preserves status", {
  run_appinsights_query <<- function(environment, query) {
    data.frame(user_Id = c("U1", "U2"), name = c("EP1", "EP2"),
               last_seen = c("2026-01-01T00:00:00Z", "2026-01-02T00:00:00Z"),
               duration_seconds = c("10", "20"), touches = c("3", "5"),
               stringsAsFactors = FALSE)
  }
  on.exit(rm(run_appinsights_query, envir = .GlobalEnv))

  out <- load_telemetry_touches(test_cfg_telemetry, environment = "PRJ")

  expect_equal(attr(out, "status"), "OK")
  expect_true(is.numeric(out$touches))
  expect_true(is.numeric(out$duration_seconds))
  expect_equal(out$touches, c(3, 5))
})

test_that("load_telemetry_touches rejects a non-positive telemetry_days without contacting Application Insights", {
  bad_cfg <- test_cfg_telemetry
  bad_cfg$telemetry$telemetry_days <- 0
  expect_error(load_telemetry_touches(bad_cfg, environment = "PRJ"),
               "telemetry_days must be a positive number")
})
