test_cfg_telemetry <- list(
  telemetry = list(
    enabled = TRUE,
    telemetry_days = 90,
    min_recommended_days = 14,
    app_insights_env_var = "TEST_APPINSIGHTS_APP_ID",
    api_key_env_var = "TEST_APPINSIGHTS_API_KEY"
  )
)

# Hilfsfunktion: erzeugt einen minimalen Telemetrie-data.frame
.mock_touches <- function() {
  data.frame(
    user_Id          = "U1",
    name             = "EP1",
    last_seen        = "2026-01-01T00:00:00Z",
    duration_seconds = "10",
    touches          = "3",
    stringsAsFactors = FALSE
  )
}

test_that("run_kql_query leitet die KQL-Abfrage korrekt weiter", {
  received_query <- NULL

  local_mocked_bindings(
    run_appinsights_query = function(kql_query, cfg = NULL) {
      received_query <<- kql_query
      df <- .mock_touches()
      attr(df, "status") <- "OK"
      df
    }
  )

  out <- run_kql_query("pageViews | take 5", test_cfg_telemetry)

  expect_equal(received_query, "pageViews | take 5")
  expect_equal(attr(out, "status"), "OK")
  expect_equal(nrow(out), 1)
})

test_that("run_kql_query gibt UNKNOWN zurueck wenn run_appinsights_query() einen Fehler wirft", {
  local_mocked_bindings(
    run_appinsights_query = function(kql_query, cfg = NULL) {
      stop("credentials not found")
    }
  )

  out <- run_kql_query("pageViews | take 5", test_cfg_telemetry)

  expect_equal(attr(out, "status"), "UNKNOWN")
  expect_equal(nrow(out), 0)
})

test_that("run_kql_query gibt UNKNOWN zurueck wenn Telemetrie deaktiviert ist, ohne AppInsights aufzurufen", {
  called <- FALSE

  local_mocked_bindings(
    run_appinsights_query = function(kql_query, cfg = NULL) {
      called <<- TRUE
      .mock_touches()
    }
  )

  disabled_cfg <- test_cfg_telemetry
  disabled_cfg$telemetry$enabled <- FALSE

  out <- run_kql_query("pageViews | take 5", disabled_cfg)

  expect_equal(attr(out, "status"), "UNKNOWN")
  expect_false(called)
})

test_that("load_telemetry_touches konvertiert numerische Spalten und erhaelt den Status", {
  local_mocked_bindings(
    run_appinsights_query = function(kql_query, cfg = NULL) {
      df <- data.frame(
        user_Id          = c("U1", "U2"),
        name             = c("EP1", "EP2"),
        last_seen        = c("2026-01-01T00:00:00Z", "2026-01-02T00:00:00Z"),
        duration_seconds = c("10", "20"),
        touches          = c("3", "5"),
        stringsAsFactors = FALSE
      )
      attr(df, "status") <- "OK"
      df
    }
  )

  out <- load_telemetry_touches(test_cfg_telemetry)

  expect_equal(attr(out, "status"), "OK")
  expect_true(is.numeric(out$touches))
  expect_true(is.numeric(out$duration_seconds))
  expect_equal(out$touches, c(3, 5))
})

test_that("load_telemetry_touches bricht ab wenn telemetry_days nicht positiv ist", {
  bad_cfg <- test_cfg_telemetry
  bad_cfg$telemetry$telemetry_days <- 0

  expect_error(
    load_telemetry_touches(bad_cfg),
    "telemetry_days"
  )
})
