# In package context, devtools::load_all() (called by devtools::test() and
# devtools::check()) makes all exported and internal functions available
# automatically. No source() calls needed here.
#
# Tests call analyze_*() / rule_*() functions directly against fixture
# data.frames and never call load_*() (which would require a live DB).
