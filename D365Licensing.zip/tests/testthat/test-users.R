test_that("analyze_users flags active users without a valid Entra link", {
  users <- data.frame(
    ID = c("U1", "U2", "U3"),
    NETWORKALIAS = c("a", "b", "c"),
    ENABLE = c(1, 1, 0),
    OBJECTID = c("00000000-0000-0000-0000-000000000000", "11111111-1111-1111-1111-111111111111", NA),
    stringsAsFactors = FALSE
  )
  invalid_users <- data.frame(USERID = character(), INVALIDITYREASON = character())
  app_users <- data.frame(USERID = character())

  out <- analyze_users(users, invalid_users, app_users)

  expect_equal(out$user_status_flag[out$ID == "U1"], "ACTIVE_NO_ENTRA_LINK_REQUIRES_VALIDATION")
  expect_equal(out$user_status_flag[out$ID == "U2"], "ACTIVE_OK")
  expect_equal(out$user_status_flag[out$ID == "U3"], "DISABLED")
})

test_that("analyze_users flags active + invalid-user combination distinctly", {
  users <- data.frame(ID = "U1", NETWORKALIAS = "a", ENABLE = 1,
                       OBJECTID = "11111111-1111-1111-1111-111111111111", stringsAsFactors = FALSE)
  invalid_users <- data.frame(USERID = "U1", INVALIDITYREASON = "Entra ID account deleted", stringsAsFactors = FALSE)
  app_users <- data.frame(USERID = character())

  out <- analyze_users(users, invalid_users, app_users)
  expect_equal(out$user_status_flag, "ACTIVE_BUT_INVALID")
  expect_true(out$is_invalid_user)
})

test_that("analyze_invalid_users join only returns ENABLE=1 users present in both tables", {
  users <- data.frame(
    ID = c("U1", "U2", "U3"), NETWORKALIAS = c("a", "b", "c"),
    ENABLE = c(1, 1, 0), OBJECTID = c("x", "y", "z"), stringsAsFactors = FALSE
  )
  invalid_users <- data.frame(
    USERID = c("U1", "U3"), OBJECTID = c("x", "z"),
    INVALIDITYREASON = c("deleted", "deleted"), stringsAsFactors = FALSE
  )
  out <- analyze_invalid_users(users, invalid_users)

  # U3 is disabled -> must be excluded even though it's in the invalid list
  expect_equal(nrow(out), 1)
  expect_equal(out$ID, "U1")
})

test_that("analyze_application_users never auto-classifies as license-free", {
  app_users <- data.frame(AADCLIENTID = "c1", USERID = "SVC1", NAME = "Integration", stringsAsFactors = FALSE)
  out <- analyze_application_users(app_users)
  expect_equal(out$licensing_classification, "REQUIRES_VALIDATION")
})
