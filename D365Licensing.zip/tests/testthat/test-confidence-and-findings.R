test_that("compute_confidence follows the documented HIGH/MEDIUM/LOW/UNKNOWN policy", {
  expect_equal(compute_confidence(FALSE, FALSE, FALSE), "UNKNOWN")
  expect_equal(compute_confidence(TRUE, FALSE, FALSE), "MEDIUM")
  expect_equal(compute_confidence(TRUE, TRUE, TRUE), "HIGH")
  expect_equal(compute_confidence(TRUE, FALSE, FALSE, is_heuristic_only = TRUE), "LOW")
})

test_that("downgrade_confidence steps down one level and stops at UNKNOWN", {
  expect_equal(downgrade_confidence("HIGH"), "MEDIUM")
  expect_equal(downgrade_confidence("MEDIUM"), "LOW")
  expect_equal(downgrade_confidence("LOW"), "UNKNOWN")
  expect_equal(downgrade_confidence("UNKNOWN"), "UNKNOWN")
})

test_that("rule_active_invalid_user produces one finding per affected user with HIGH confidence", {
  ctx <- list(
    invalid_users_analysis = data.frame(
      ID = c("U1", "U2"), NETWORKALIAS = c("a", "b"), ENABLE = c(1, 1),
      OBJECTID = c("x", "y"), INVALIDITYREASON = c("deleted", "deleted"),
      stringsAsFactors = FALSE
    )
  )
  out <- rule_active_invalid_user(ctx)
  expect_equal(nrow(out), 2)
  expect_true(all(out$finding_id == "FINDING-001"))
  expect_true(all(out$confidence == "HIGH"))
})

test_that("rule_active_invalid_user returns NULL when there is nothing to report", {
  ctx <- list(invalid_users_analysis = data.frame(ID = character(), NETWORKALIAS = character(),
                                                     ENABLE = numeric(), OBJECTID = character(),
                                                     INVALIDITYREASON = character()))
  expect_null(rule_active_invalid_user(ctx))
})

test_that("rule_role_multiple_license_types only fires for roles with >1 distinct SKU", {
  ctx <- list(role_metrics = data.frame(
    role = c("RoleA", "RoleB"),
    distinct_license_types = c(1, 2),
    license_skus = c("Finance", "Finance; Commerce"),
    stringsAsFactors = FALSE
  ))
  out <- rule_role_multiple_license_types(ctx)
  expect_equal(nrow(out), 1)
  expect_equal(out$role, "RoleB")
})
