test_that("analyze_security_structure joins role requirements onto secgov rows correctly", {
  secgov <- data.frame(
    ROLEIDENTIFIER  = c("RoleA", "RoleA", "RoleB"),
    DUTYNAME        = c("DutyA1", "DutyA1", "DutyB1"),
    PRIVILEGENAME   = c("PrivA1", "PrivA2", "PrivB1"),
    ENTRYPOINTNAME  = c("EPA1", "EPA2", "EPB1"),
    stringsAsFactors = FALSE
  )
  role_req <- data.frame(
    ROLEIDENTIFIER = c("RoleA", "RoleB"),
    ENTITLED       = c(1, 0),
    ACCESSLEVEL    = c("CREATE", "READ"),
    SKUNAME        = c("Finance", NA),
    stringsAsFactors = FALSE
  )

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))

  expect_equal(nrow(out), 3)
  expect_true(all(out$ENTITLED[out$ROLEIDENTIFIER == "RoleA"] == 1))
  expect_true(all(out$has_license_requirement_record))
})

test_that("analyze_security_structure marks rows without a matching role requirement", {
  secgov   <- data.frame(ROLEIDENTIFIER = "RoleZ", DUTYNAME = "D1", PRIVILEGENAME = "P1", ENTRYPOINTNAME = "E1", stringsAsFactors = FALSE)
  role_req <- data.frame(ROLEIDENTIFIER = "RoleA", ENTITLED = 1, ACCESSLEVEL = "READ", SKUNAME = "Finance", stringsAsFactors = FALSE)

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))
  expect_false(out$has_license_requirement_record[out$ROLEIDENTIFIER == "RoleZ"])
})

test_that("analyze_role_metrics computes duty/privilege/entry-point counts and write ratio correctly", {
  sec <- data.frame(
    ROLENAME       = c("RoleA", "RoleA", "RoleA", "RoleB"),
    DUTYNAME       = c("D1", "D1", "D2", "D3"),
    PRIVILEGENAME  = c("P1", "P2", "P3", "P4"),
    ENTRYPOINTNAME = c("EP1", "EP2", "EP3", "EP4"),
    ENTITLED       = c(1, 1, 0, 1),
    ACCESSLEVEL    = c("CREATE", "READ", "READ", "UPDATE"),
    SKUNAME        = c("Finance", "Finance", NA, "Commerce"),
    stringsAsFactors = FALSE
  )

  out    <- analyze_role_metrics(sec)
  role_a <- out[out$role == "RoleA", ]

  expect_equal(role_a$duty_count, 2)
  expect_equal(role_a$privilege_count, 3)
  expect_equal(role_a$entry_point_count, 3)
  expect_equal(role_a$license_relevant_entry_points, 2)  # only ENTITLED=1 rows
  expect_equal(role_a$write_entry_points, 1)   # EP1 (CREATE)
  # EP2 (READ, ENTITLED=1) and EP3 (READ, ENTITLED=0) are BOTH classified as
  # READ - classify_access_level() looks only at ACCESSLEVEL, not ENTITLED.
  expect_equal(role_a$read_entry_points, 2)    # EP2, EP3
  expect_equal(role_a$distinct_license_types, 1)  # only 'Finance', NA excluded
})

test_that("write_ratio is computed only over classified (read+write) entry points", {
  sec <- data.frame(
    ROLENAME       = c("RoleA", "RoleA", "RoleA"),
    DUTYNAME       = c("D1", "D1", "D1"),
    PRIVILEGENAME  = c("P1", "P2", "P3"),
    ENTRYPOINTNAME = c("EP1", "EP2", "EP3"),
    ENTITLED       = c(1, 1, 0),
    ACCESSLEVEL    = c("CREATE", "READ", "READ"),
    SKUNAME        = c("Finance", "Finance", NA),
    stringsAsFactors = FALSE
  )
  out <- analyze_role_metrics(sec)
  # 1 write / (1 write + 2 read) = 1/3
  expect_equal(out$write_ratio[out$role == "RoleA"], 1 / 3)
})

test_that("analyze_security_structure returns UNKNOWN when ROLEIDENTIFIER not present in either data frame", {
  # Mirrors the pre-fix world: secgov has ROLENAME, role_req has numeric SECURITYROLE.
  # Auto-detection finds no ROLEIDENTIFIER column -> role join columns not identified.
  secgov   <- data.frame(ROLENAME = c("Test-Administrator", "Guide-Manager"), stringsAsFactors = FALSE)
  role_req <- data.frame(SECURITYROLE = c(99L, 412L), ENTITLED = c(1, 1),
                          ACCESSLEVEL = c("READ", "READ"), SKUNAME = c("Finance", "Commerce"),
                          stringsAsFactors = FALSE)

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))

  expect_true(all(out$ENTITLED == "UNKNOWN"))
})

test_that("analyze_security_structure joins correctly when an explicit numeric RecId column pair is provided", {
  secgov <- data.frame(
    ROLEIDENTIFIER = c("SystemUser", "TaxManager"),
    ROLERECID      = c(99L, 412L),
    stringsAsFactors = FALSE
  )
  role_req <- data.frame(SECURITYROLE = c(99L, 412L), ENTITLED = c(1, 0),
                          ACCESSLEVEL = c("READ", "READ"), SKUNAME = c("Finance", NA),
                          stringsAsFactors = FALSE)

  out <- analyze_security_structure(
    secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()),
    role_join_column_secgov = "ROLERECID", role_join_column_req = "SECURITYROLE"
  )

  expect_equal(out$ENTITLED[out$ROLEIDENTIFIER == "SystemUser"], 1)
  expect_equal(out$ENTITLED[out$ROLEIDENTIFIER == "TaxManager"], 0)
})

test_that("analyze_security_structure works with ROLEIDENTIFIER (AOTNAME) as the join key", {
  # Production path: SQL 06 resolves T.SECURITYROLE (RecId) via INNER JOIN SECURITYROLE
  # and outputs S.AOTNAME as ROLEIDENTIFIER. USERSECGOVRELATEDOBJECTS.ROLEIDENTIFIER
  # holds the same AOTNAME value -- auto-detection matches without any config override.
  secgov <- data.frame(ROLEIDENTIFIER = c("SystemUser", "TaxManager"), stringsAsFactors = FALSE)
  role_req <- data.frame(
    SECURITYROLERECID = c(99L, 412L),
    ROLEIDENTIFIER    = c("SystemUser", "TaxManager"),
    ENTITLED    = c(1, 1), ACCESSLEVEL = c("READ", "CREATE"), SKUNAME = c("Finance", "Commerce"),
    stringsAsFactors = FALSE
  )

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))

  expect_true(all(out$ENTITLED == 1))
  expect_equal(out$SKUNAME[out$ROLEIDENTIFIER == "TaxManager"], "Commerce")
})

test_that("analyze_security_structure joins on Role + Entry Point (composite key), not Role alone", {
  # Same role, multiple entry points on each side. A Role-only join would
  # cartesian-explode (2 secgov rows x 2 requirement rows = 4, instead of
  # the correct 1-to-1 match per entry point).
  secgov <- data.frame(
    ROLEIDENTIFIER = c("RoleA", "RoleA"),
    RESOURCE       = c("EP1", "EP2"),
    stringsAsFactors = FALSE
  )
  role_req <- data.frame(
    ROLEIDENTIFIER = c("RoleA", "RoleA"),
    AOTNAME        = c("EP1", "EP2"),
    ENTITLED       = c(1, 0),
    ACCESSLEVEL    = c("READ", "CREATE"),
    SKUNAME        = c("Finance", NA),
    stringsAsFactors = FALSE
  )

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))

  expect_equal(nrow(out), 2)  # NOT 4
  expect_equal(out$ENTITLED[out$RESOURCE == "EP1"], 1)
  expect_equal(out$ENTITLED[out$RESOURCE == "EP2"], 0)
})

test_that("analyze_security_structure refuses a many-to-many role-only join instead of crashing", {
  n      <- 500
  secgov   <- data.frame(ROLEIDENTIFIER = rep("RoleA", n), DUTYNAME = paste0("D", seq_len(n)), stringsAsFactors = FALSE)
  role_req <- data.frame(ROLEIDENTIFIER = rep("RoleA", n), ENTITLED = rep(1, n),
                          ACCESSLEVEL = rep("READ", n), SKUNAME = rep("Finance", n),
                          stringsAsFactors = FALSE)

  expect_no_error({
    out <- analyze_security_structure(
      secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()),
      max_merge_rows = 1000   # n*n = 250,000 > cap -> must refuse, not crash
    )
  })
  expect_true(all(out$ENTITLED == "UNKNOWN"))
})

test_that("analyze_role_metrics flags multiple distinct license SKUs on one role", {
  sec <- data.frame(
    ROLENAME       = c("RoleMulti", "RoleMulti"),
    DUTYNAME       = c("D1", "D2"), PRIVILEGENAME = c("P1", "P2"),
    ENTRYPOINTNAME = c("EP1", "EP2"),
    ENTITLED       = c(1, 1), ACCESSLEVEL = c("READ", "READ"),
    SKUNAME        = c("Finance", "Commerce"), stringsAsFactors = FALSE
  )
  out <- analyze_role_metrics(sec)
  expect_equal(out$distinct_license_types[out$role == "RoleMulti"], 2)
})

test_that("classify_access_level maps write operations correctly", {
  expect_equal(classify_access_level("CREATE"), "WRITE")
  expect_equal(classify_access_level("Update"), "WRITE")
  expect_equal(classify_access_level("READ"), "READ")
  expect_equal(classify_access_level(NA), "UNKNOWN")
})
