library(testthat)
library(D365Licensing)

test_check("D365Licensing")
