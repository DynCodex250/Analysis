# =============================================================================
# R/utils_logging.R
# Minimal dependency-free structured logger + a safe-execution wrapper so a
# failure in one analysis module doesn't abort the whole pipeline
# (brief section 18).
# =============================================================================

.log_env <- new.env(parent = emptyenv())
.log_env$entries <- list()

#' @keywords internal
log_event <- function(level, module, message, ...) {
  entry <- list(
    time = format(Sys.time(), "%Y-%m-%d %H:%M:%OS3"),
    level = level,
    module = module,
    message = sprintf(message, ...)
  )
  .log_env$entries[[length(.log_env$entries) + 1]] <- entry
  cat(sprintf("[%s] %-7s [%s] %s\n", entry$time, entry$level, entry$module, entry$message))
  invisible(entry)
}

#' Append an INFO entry to the in-memory log buffer and print it.
#' @param module Short module label shown in the log line.
#' @param message \code{sprintf()}-style format string.
#' @param ... Arguments passed to \code{sprintf()}.
#' @export
log_info  <- function(module, message, ...) log_event("INFO",  module, message, ...)

#' Append a WARN entry to the in-memory log buffer and print it.
#' @inheritParams log_info
#' @export
log_warn  <- function(module, message, ...) log_event("WARN",  module, message, ...)

#' Append an ERROR entry to the in-memory log buffer and print it.
#' @inheritParams log_info
#' @export
log_error <- function(module, message, ...) log_event("ERROR", module, message, ...)

#' Run an analysis step defensively: log timing, catch errors, never abort
#' the overall pipeline for a single non-critical module.
#'
#' @param module short name used in log lines / final log export
#' @param expr_fn a zero-arg function performing the actual work
#' @param critical if TRUE, re-throws the error after logging (use sparingly)
#' @return list(ok = TRUE/FALSE, result = ..., error = ..., elapsed_seconds = ...)
#' @export
run_safely <- function(module, expr_fn, critical = FALSE) {
  start <- Sys.time()
  log_info(module, "started")
  out <- tryCatch({
    result <- expr_fn()
    list(ok = TRUE, result = result, error = NULL)
  }, error = function(e) {
    log_error(module, "failed: %s", conditionMessage(e))
    list(ok = FALSE, result = NULL, error = conditionMessage(e))
  })
  elapsed <- as.numeric(difftime(Sys.time(), start, units = "secs"))
  log_info(module, "finished in %.2fs (ok=%s)", elapsed, out$ok)
  if (!out$ok && critical) stop(out$error)
  out$elapsed_seconds <- elapsed
  out
}

#' Write the accumulated log buffer to disk as CSV.
#'
#' @param log_dir Directory to write into (created if absent).
#' @param environment Environment name used in the filename.
#' @return Path to the written CSV file.
#' @export
write_log <- function(log_dir, environment) {
  if (!dir.exists(log_dir)) dir.create(log_dir, recursive = TRUE)
  df <- do.call(rbind, lapply(.log_env$entries, as.data.frame, stringsAsFactors = FALSE))
  path <- file.path(log_dir, sprintf("run_log_%s_%s.csv", environment, format(Sys.Date(), "%Y%m%d")))
  utils::write.csv(df, path, row.names = FALSE)
  log_info("logging", "log written to %s (%d entries)", path, nrow(df))
  path
}

#' Clear the in-memory log buffer.
#' @export
reset_log <- function() {
  .log_env$entries <- list()
}
