#' Load USERSECGOVRELATEDOBJECTS -- the Role/Duty/Privilege/EntryPoint backbone.
#'
#' @param cnn DBI connection from \code{\link{get_readonly_connection}}.
#' @param role_filter Optional SQL LIKE pattern to restrict results to matching
#'   role names (e.g. \code{"_WIBU\%"}). \code{NULL} returns all roles.
#' @return A \code{data.frame} with one row per
#'   (role, duty, privilege, entry point) path.
#' @export
load_security_governance_objects <- function(cnn, role_filter = NULL) {
  run_readonly_query(
    cnn,
    system.file("sql", "05_user_security_governance_objects.sql", package = "D365Licensing"),
    params = list(RoleNameFilter = role_filter)
  )
}

#' Load LICENSINGUSERLICENSESBYROLE.
#'
#' @param cnn DBI connection.
#' @return A \code{data.frame} of user-level license assignments by role.
#' @export
load_licensing_user_license_by_role <- function(cnn) {
  run_readonly_query(
    cnn,
    system.file("sql", "04_licensing_user_license_by_role.sql", package = "D365Licensing")
  )
}

#' Load the three licensing *_DETAILEDVIEW tables (role, duty, privilege level).
#'
#' @param cnn DBI connection.
#' @param entitled_only If \code{TRUE} (default), filters to ENTITLED rows only.
#' @return A named list with elements \code{role}, \code{duty}, \code{privilege}.
#' @export
load_licensing_requirements <- function(cnn, entitled_only = TRUE) {
  sql <- function(f) system.file("sql", f, package = "D365Licensing")
  p <- list(EntitledOnly = entitled_only)
  list(
    role      = run_readonly_query(cnn, sql("06_licensing_role_requirements.sql"),      params = p),
    duty      = run_readonly_query(cnn, sql("07_licensing_duty_requirements.sql"),      params = p),
    privilege = run_readonly_query(cnn, sql("08_licensing_privilege_requirements.sql"), params = p)
  )
}

# Normalize column names defensively -- detailed views can vary slightly by
# D365FO version.
.normalize_licensing_columns <- function(df, expected = c("ENTITLED", "ACCESSLEVEL", "SKUNAME", "ROLEIDENTIFIER")) {
  for (col in expected) {
    if (!col %in% names(df)) {
      match_idx <- which(toupper(names(df)) == col)
      if (length(match_idx) == 1) names(df)[match_idx] <- col
    }
  }
  missing <- setdiff(expected, names(df))
  if (length(missing) > 0) {
    log_warn("data_roles_licensing",
             "expected column(s) missing, will be UNKNOWN: %s",
             paste(missing, collapse = ", "))
    for (m in missing) df[[m]] <- NA
  }
  df
}

#' Build the Role -> Duty -> Privilege -> EntryPoint -> License backbone.
#'
#' Joins \code{USERSECGOVRELATEDOBJECTS} with the licensing requirement views
#' on a composite key (role + entry point) to avoid cartesian-product crashes.
#' Falls back to a role-only key if no entry-point columns can be identified,
#' but aborts if the estimated result size would exceed \code{max_merge_rows}.
#'
#' @param secgov data.frame from \code{\link{load_security_governance_objects}}.
#' @param licensing_req List from \code{\link{load_licensing_requirements}}.
#' @param role_join_column_secgov Optional explicit role-name column in \code{secgov}.
#' @param role_join_column_req Optional explicit role-name column in \code{licensing_req$role}.
#' @param entry_point_join_column_secgov Optional explicit entry-point column in \code{secgov}.
#' @param entry_point_join_column_req Optional explicit entry-point column in \code{licensing_req$role}.
#' @param max_merge_rows Safety cap on estimated merge size (default 20 million).
#' @return A \code{data.frame} with license columns attached where resolvable.
#' @export
analyze_security_structure <- function(secgov, licensing_req,
                                       role_join_column_secgov = NULL,
                                       role_join_column_req = NULL,
                                       entry_point_join_column_secgov = NULL,
                                       entry_point_join_column_req = NULL,
                                       max_merge_rows = 20e6) {
  role_req <- .normalize_licensing_columns(licensing_req$role)

  role_col_secgov <- role_join_column_secgov %||%
    names(secgov)[toupper(names(secgov)) == "ROLEIDENTIFIER"][1]
  role_col_req <- role_join_column_req %||%
    names(role_req)[toupper(names(role_req)) == "ROLEIDENTIFIER"][1]

  ep_col_secgov <- entry_point_join_column_secgov %||%
    c(names(secgov)[toupper(names(secgov)) == "RESOURCE"],
      names(secgov)[toupper(names(secgov)) == "ENTRYPOINTNAME"])[1]
  ep_col_req <- entry_point_join_column_req %||%
    names(role_req)[toupper(names(role_req)) == "AOTNAME"][1]

  if (is.na(role_col_secgov) || is.na(role_col_req) ||
      is.null(role_col_secgov) || is.null(role_col_req)) {
    log_warn("data_roles_licensing",
             "role join columns not identified; returning secgov unjoined (license = UNKNOWN)")
    secgov$ENTITLED    <- "UNKNOWN"
    secgov$ACCESSLEVEL <- "UNKNOWN"
    secgov$SKUNAME     <- "UNKNOWN"
    return(secgov)
  }

  use_composite_key <- !is.na(ep_col_secgov) && !is.na(ep_col_req) &&
    !is.null(ep_col_secgov) && !is.null(ep_col_req)

  req_is_num   <- is.numeric(role_req[[role_col_req]])   || inherits(role_req[[role_col_req]],   "integer64")
  secgov_is_num <- is.numeric(secgov[[role_col_secgov]]) || inherits(secgov[[role_col_secgov]], "integer64")
  if (req_is_num != secgov_is_num) {
    log_error("data_roles_licensing",
              "JOIN TYPE MISMATCH: secgov$%s is %s but requirements$%s is %s -- returning UNKNOWN",
              role_col_secgov, class(secgov[[role_col_secgov]])[1],
              role_col_req, class(role_req[[role_col_req]])[1])
    secgov$ENTITLED    <- "UNKNOWN"
    secgov$ACCESSLEVEL <- "UNKNOWN"
    secgov$SKUNAME     <- "UNKNOWN"
    return(secgov)
  }

  .norm_key <- function(x) {
    if (is.numeric(x) || inherits(x, "integer64")) as.character(x)
    else trimws(toupper(as.character(x)))
  }

  if (use_composite_key) {
    secgov$.JOINKEY   <- paste(.norm_key(secgov[[role_col_secgov]]),
                               .norm_key(secgov[[ep_col_secgov]]), sep = "")
    role_req$.JOINKEY <- paste(.norm_key(role_req[[role_col_req]]),
                               .norm_key(role_req[[ep_col_req]]), sep = "")
  } else {
    secgov$.JOINKEY   <- .norm_key(secgov[[role_col_secgov]])
    role_req$.JOINKEY <- .norm_key(role_req[[role_col_req]])
  }

  secgov_counts <- table(secgov$.JOINKEY)
  req_counts    <- table(role_req$.JOINKEY)
  common_keys   <- intersect(names(secgov_counts), names(req_counts))
  estimated_rows <- if (length(common_keys) > 0)
    sum(as.numeric(secgov_counts[common_keys]) * as.numeric(req_counts[common_keys]))
  else 0
  estimated_rows <- estimated_rows + sum(!(secgov$.JOINKEY %in% common_keys))

  if (estimated_rows > max_merge_rows) {
    log_error("data_roles_licensing",
              "REFUSING TO MERGE: estimated ~%.0f M rows > cap %.0f M -- returning UNKNOWN",
              estimated_rows / 1e6, max_merge_rows / 1e6)
    secgov$ENTITLED    <- "UNKNOWN"
    secgov$ACCESSLEVEL <- "UNKNOWN"
    secgov$SKUNAME     <- "UNKNOWN"
    return(secgov)
  }

  merged <- merge(secgov, role_req, by = ".JOINKEY", all.x = TRUE, suffixes = c("", "_LICREQ"))
  merged$.JOINKEY <- NULL
  for (dup_col in c(role_col_req, ep_col_req)) {
    if (is.na(dup_col)) next
    dup_nm <- paste0(dup_col, "_LICREQ")
    if (dup_nm %in% names(merged)) merged[[dup_nm]] <- NULL
  }
  merged$has_license_requirement_record <- !is.na(merged$ENTITLED)
  merged
}


#' Direkte Lizenzzuweisungen pro Benutzer laden.
#'
#' Verknuepft \code{LicensingUserDirectLicenseAssignments} mit \code{UserInfo}
#' und \code{LicensingAllSkus} zu einer flachen User/SKU-Tabelle.
#'
#' Schluesselspalten:
#' \itemize{
#'   \item \code{CANBEATTACH = 0} -- Base-Lizenz (teuerste, hoehere Prioritaet)
#'   \item \code{CANBEATTACH = 1} -- Attach-Lizenz (Zusatz-SKU)
#'   \item \code{SKUNUMBER = 1}   -- Base (hoehere Prioritaet zuerst)
#'   \item \code{COVEREDENTITLEMENTS}  -- Gesamtpool des SKU im Tenant
#'   \item \code{REMAININGENTITLEMENTS} -- Noch verfuegbare Sitze (0 = Pool erschoepft)
#' }
#'
#' @param cnn DBI connection aus \code{\link{get_readonly_connection}}.
#' @return \code{data.frame} mit einer Zeile pro Benutzer/SKU-Kombination.
#' @export
load_user_direct_licenses <- function(cnn) {
  run_readonly_query(
    cnn,
    system.file("sql", "11_user_direct_license_assignments.sql", package = "D365Licensing")
  )
}


#' Rollen-Lizenz-Zusammenfassung laden (Tab "Role licenses").
#'
#' Reproduziert den Tab "Role licenses" der D365FO-Ansicht
#' \emph{System administration > Security > Security governance >
#' Licenses usage summary}. Gibt eine Zeile pro Rolle x SKU zurueck.
#'
#' @param cnn DBI connection aus \code{\link{get_readonly_connection}}.
#' @param role_identifier Optionaler Filter auf eine einzelne Rolle (AOTNAME,
#'   z.B. \code{"BATCHJOBMANAGER"}). \code{NULL} gibt alle Rollen zurueck.
#' @return \code{data.frame} mit Spalten \code{ROLEIDENTIFIER},
#'   \code{ROLENAME_DISPLAY}, \code{SKUNAME}, \code{Entitled},
#'   \code{NotEntitled}, \code{NotRequired} (und YesNo-Varianten).
#' @export
load_role_license_summary <- function(cnn, role_identifier = NULL) {
  run_readonly_query(
    cnn,
    system.file("sql", "12_license_usage_summary_roles.sql", package = "D365Licensing"),
    params = list(RoleIdentifier = role_identifier)
  )
}


#' Duty-Lizenz-Zusammenfassung laden (Tab "Duty licenses").
#'
#' Reproduziert den Tab "Duty licenses" der D365FO-Ansicht
#' \emph{Licenses usage summary}. Gibt eine Zeile pro Duty x SKU zurueck.
#'
#' @param cnn DBI connection aus \code{\link{get_readonly_connection}}.
#' @param duty_identifier Optionaler Filter auf eine einzelne Duty (IDENTIFIER,
#'   z.B. \code{"SMMACTIVITYPROCESSENABLE"}). \code{NULL} gibt alle Duties zurueck.
#' @return \code{data.frame} mit Spalten \code{DUTYIDENTIFIER},
#'   \code{DUTYNAME_DISPLAY}, \code{SKUNAME}, \code{Entitled},
#'   \code{NotEntitled}, \code{NotRequired} (und YesNo-Varianten).
#' @export
load_duty_license_summary <- function(cnn, duty_identifier = NULL) {
  run_readonly_query(
    cnn,
    system.file("sql", "13_license_usage_summary_duties.sql", package = "D365Licensing"),
    params = list(DutyIdentifier = duty_identifier)
  )
}


#' Privilege-Lizenz-Zusammenfassung laden (Tab "Privilege licenses").
#'
#' Reproduziert den Tab "Privilege licenses" der D365FO-Ansicht
#' \emph{Licenses usage summary}. Gibt eine Zeile pro Privilege x SKU zurueck.
#'
#' @param cnn DBI connection aus \code{\link{get_readonly_connection}}.
#' @param privilege_identifier Optionaler Filter auf ein einzelnes Privilege
#'   (IDENTIFIER, z.B. \code{"VIEWTIMELINE"}). \code{NULL} gibt alle Privileges zurueck.
#' @return \code{data.frame} mit Spalten \code{PRIVILEGEIDENTIFIER},
#'   \code{PRIVILEGENAME_DISPLAY}, \code{SKUNAME}, \code{Entitled},
#'   \code{NotEntitled}, \code{NotRequired} (und YesNo-Varianten).
#' @export
load_privilege_license_summary <- function(cnn, privilege_identifier = NULL) {
  run_readonly_query(
    cnn,
    system.file("sql", "14_license_usage_summary_privileges.sql", package = "D365Licensing"),
    params = list(PrivilegeIdentifier = privilege_identifier)
  )
}
