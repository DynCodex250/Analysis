# =============================================================================
# R/reporting_excel.R
# Brief section 16.1: Excel report for operative analysis.
# Reuses writexl (already used by the source project per its library() calls)
# rather than introducing a new Excel dependency.
# =============================================================================

#' Write the four required report tables (User/Role/License Driver/Findings)
#' plus a run-metadata sheet into a single .xlsx workbook.
#'
#' @param user_report data.frame
#' @param role_report data.frame
#' @param license_driver_report data.frame
#' @param findings_report data.frame
#' @param meta data.frame (single row of run metadata: environment, date, etc.)
#' @param output_path full path to the .xlsx file to create
#' @return \code{output_path} invisibly.
#' @export
write_excel_report <- function(user_report, role_report, license_driver_report,
                                 findings_report, meta, output_path) {
  sheets <- list(
    "Run Info" = meta,
    "User Report" = user_report,
    "Role Report" = role_report,
    "License Driver Report" = license_driver_report,
    "Findings" = findings_report
  )
  writexl::write_xlsx(sheets, path = output_path)
  log_info("reporting_excel", "Excel report written to %s", output_path)
  output_path
}

# Aggregiert LICENSINGUSERLICENSESBYROLE pro Benutzer zu Base- und Attach-Spalten.
# REQUIREDUSERLICENSE = "Attach" → Attach-Lizenz; qty > 0 und nicht Attach → Base-Lizenz.
.aggregate_license_by_role <- function(df) {
  if (is.null(df) || nrow(df) == 0) return(NULL)

  uid <- names(df)[toupper(names(df)) == "USERID"][1]
  sku <- names(df)[toupper(names(df)) == "SKUNAME"][1]
  req <- names(df)[toupper(names(df)) == "REQUIREDUSERLICENSE"][1]
  qty <- names(df)[toupper(names(df)) == "USERREQUIREDLICENSEQTY"][1]

  if (anyNA(c(uid, sku, req, qty))) return(NULL)

  qty_n <- suppressWarnings(as.numeric(df[[qty]]))
  paid  <- df[!is.na(qty_n) & qty_n > 0 & toupper(trimws(df[[sku]])) != "NONE", ]
  if (nrow(paid) == 0) return(NULL)

  is_attach <- toupper(trimws(paid[[req]])) == "ATTACH"

  agg_sku <- function(sub) {
    if (nrow(sub) == 0) return(data.frame(user_id = character(), val = character(), stringsAsFactors = FALSE))
    r <- stats::aggregate(sub[[sku]], by = list(sub[[uid]]),
                           FUN = function(x) paste(unique(x), collapse = " | "))
    data.frame(user_id = r[[1]], val = r[[2]], stringsAsFactors = FALSE)
  }

  base_agg   <- agg_sku(paid[!is_attach, ])
  attach_agg <- agg_sku(paid[is_attach,  ])

  users <- data.frame(user_id = unique(paid[[uid]]), stringsAsFactors = FALSE)
  out <- merge(users, stats::setNames(base_agg,   c("user_id", "base_license")),   by = "user_id", all.x = TRUE)
  out <- merge(out,   stats::setNames(attach_agg, c("user_id", "attach_license")), by = "user_id", all.x = TRUE)
  out
}


#' Reshape \code{user_profiles} into the column set from brief section 15.
#'
#' Base/Attach license columns come from LICENSINGUSERLICENSESBYROLE when
#' available; otherwise reported as \code{UNKNOWN}.
#'
#' @param user_profiles data.frame from \code{\link{build_user_profiles}}.
#' @param license_by_role data.frame from \code{\link{load_licensing_user_license_by_role}}.
#' @param findings data.frame from \code{\link{generate_findings}}.
#' @return A \code{data.frame} ready for the Excel User Report sheet.
#' @export
format_user_report <- function(user_profiles, license_by_role, findings) {
  base_lic <- .aggregate_license_by_role(license_by_role)
  if (is.null(base_lic)) {
    base_lic <- data.frame(user_id = character(), base_license = character(), attach_license = character())
  }

  findings_per_user <- if (nrow(findings) > 0) {
    agg <- stats::aggregate(finding ~ user, data = findings[!is.na(findings$user), ],
                             FUN = function(x) paste(unique(x), collapse = " | "))
    conf <- stats::aggregate(confidence ~ user, data = findings[!is.na(findings$user), ],
                              FUN = function(x) paste(unique(x), collapse = "; "))
    merge(agg, conf, by = "user", all = TRUE)
  } else data.frame(user = character(), finding = character(), confidence = character())

  out <- merge(user_profiles, base_lic, by.x = "ID", by.y = "user_id", all.x = TRUE)
  out <- merge(out, findings_per_user, by.x = "ID", by.y = "user", all.x = TRUE)

  data.frame(
    user_id = out$ID,
    alias = out$NETWORKALIAS,
    status = ifelse(out$is_active, "ACTIVE", "DISABLED"),
    invalid_user = out$is_invalid_user,
    application_user = out$is_application_user,
    roles = paste(ifelse(is.na(out$business_roles), "", out$business_roles),
                   ifelse(is.na(out$service_roles), "", out$service_roles)),
    service_roles = out$service_roles,
    business_roles = out$business_roles,
    license_requirement = out$role_combination_class,
    base_license = ifelse(is.na(out$base_license), "UNKNOWN", out$base_license),
    attach_license = ifelse(is.na(out$attach_license), "UNKNOWN", out$attach_license),
    last_activity = out$last_telemetry_activity,
    telemetry_touches = out$telemetry_touches_total,
    transaction_activity = out$has_transaction_activity,
    findings = ifelse(is.na(out$finding), "", out$finding),
    confidence = ifelse(is.na(out$confidence), "UNKNOWN", out$confidence),
    stringsAsFactors = FALSE
  )
}

#' Build the License Driver Report (License -> Role -> Duty -> Privilege -> Entry Point -> Users).
#'
#' @param sec_structure data.frame from \code{\link{analyze_security_structure}}.
#' @param user_roles data.frame from \code{\link{analyze_user_roles}}.
#' @return A \code{data.frame} with one row per licensed entry-point path.
#' @export
build_license_driver_report <- function(sec_structure, user_roles) {
  role_col <- names(sec_structure)[toupper(names(sec_structure)) == "ROLENAME"][1]
  duty_col <- names(sec_structure)[toupper(names(sec_structure)) == "DUTYNAME"][1]
  priv_col <- names(sec_structure)[toupper(names(sec_structure)) == "PRIVILEGENAME"][1]
  ep_col   <- names(sec_structure)[toupper(names(sec_structure)) == "ENTRYPOINTNAME"][1]

  licensed <- sec_structure[!is.na(sec_structure$ENTITLED) & sec_structure$ENTITLED %in% c(1, "1", TRUE), ]
  if (nrow(licensed) == 0) {
    return(data.frame(license = character(), role = character(), duty = character(),
                       privilege = character(), entry_point = character(),
                       access_level = character(), users = character()))
  }

  users_per_role <- if (nrow(user_roles) > 0) {
    stats::aggregate(user_id ~ role, data = user_roles, FUN = function(x) paste(unique(x), collapse = "; "))
  } else {
    data.frame(role = character(), user_id = character())
  }

  out <- data.frame(
    license = licensed$SKUNAME,
    role = if (!is.na(role_col)) licensed[[role_col]] else NA,
    duty = if (!is.na(duty_col)) licensed[[duty_col]] else NA,
    privilege = if (!is.na(priv_col)) licensed[[priv_col]] else NA,
    entry_point = if (!is.na(ep_col)) licensed[[ep_col]] else NA,
    access_level = licensed$ACCESSLEVEL,
    stringsAsFactors = FALSE
  )
  out <- merge(out, users_per_role, by.x = "role", by.y = "role", all.x = TRUE)
  names(out)[names(out) == "user_id"] <- "users"
  out$users[is.na(out$users)] <- "REQUIRES_VALIDATION_NO_USER_LINK"
  out[, c("license", "role", "duty", "privilege", "entry_point", "access_level", "users")]
}
