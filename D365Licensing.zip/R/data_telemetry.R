# =============================================================================
# Application Insights Telemetrie-Verbindung
#
# Zwei Verbindungswege werden unterstützt:
#
#   1. Host-Helper (bevorzugt):
#      Wenn `run_appinsights_query(environment, query)` bereits in der
#      R-Session geladen ist (z.B. aus D365Security), wird diese Funktion
#      direkt aufgerufen. Sie übernimmt Credential-Verwaltung und
#      Environment-Routing.
#
#   2. Eingebauter httr2-Fallback:
#      Wenn kein Host-Helper vorhanden ist, baut das Paket den REST-Call
#      selbst. Credentials kommen aus Umgebungsvariablen, deren Namen in
#      cfg$telemetry$app_insights_env_var / api_key_env_var stehen.
#      Endpoint: https://api.applicationinsights.io/v1/apps/{app_id}/query
#      Methode: POST mit JSON-Body (robuster als GET bei langen KQL-Queries).
#
# Alle Funktionen geben einen leeren data.frame mit attr(status) = "UNKNOWN"
# zurueck, wenn die Verbindung nicht hergestellt werden kann -- kein Absturz.
# =============================================================================


# Laedt eine .kql-Datei aus inst/kql/ und ersetzt {{Platzhalter}} durch Werte.
.render_kql <- function(kql_filename, vars = list()) {
  path <- system.file("kql", kql_filename, package = "D365Licensing")
  if (!nzchar(path)) stop("KQL-Datei nicht im Paket gefunden: kql/", kql_filename)
  text <- paste(readLines(path, warn = FALSE), collapse = "\n")
  for (nm in names(vars)) {
    text <- gsub(paste0("\\{\\{", nm, "\\}\\}"), vars[[nm]], text, fixed = FALSE)
  }
  # Nicht ersetzte Platzhalter entfernen
  gsub("\\{\\{[a-zA-Z_]+\\}\\}", "", text)
}


# Liest App-ID und API-Key aus den konfigurierten Umgebungsvariablen.
# Gibt eine Liste mit $app_id und $api_key zurueck, oder stoppt mit einer
# klaren Fehlermeldung, wenn eine Variable fehlt.
.get_appinsights_credentials <- function(cfg) {
  app_id  <- Sys.getenv(cfg$telemetry$app_insights_env_var, unset = "")
  api_key <- Sys.getenv(cfg$telemetry$api_key_env_var,      unset = "")

  if (app_id == "") {
    stop(
      "Umgebungsvariable '", cfg$telemetry$app_insights_env_var, "' ist nicht gesetzt.\n",
      "Bitte in .Renviron eintragen: ", cfg$telemetry$app_insights_env_var, "=<App-ID>\n",
      "Dann R-Session neu starten. Siehe HOWTO Abschnitt 3.3."
    )
  }
  if (api_key == "") {
    stop(
      "Umgebungsvariable '", cfg$telemetry$api_key_env_var, "' ist nicht gesetzt.\n",
      "Bitte in .Renviron eintragen: ", cfg$telemetry$api_key_env_var, "=<API-Key>\n",
      "Dann R-Session neu starten. Siehe HOWTO Abschnitt 3.3."
    )
  }
  list(app_id = app_id, api_key = api_key)
}


# Wandelt die JSON-Antwort der Application Insights REST-API in einen
# data.frame um. Die API gibt zurueck:
#   { "tables": [{ "columns": [{"name":...}], "rows": [[wert1, wert2, ...]] }] }
#
# Wichtig: resp_body_json() liefert jede Zeile als Liste von R-Objekten.
# do.call(rbind, ...) wuerde List-Columns erzeugen, die as.POSIXct nicht
# verarbeiten kann. Stattdessen wird jede Spalte einzeln als character-Vektor
# extrahiert -- das ist der einzige robuste Weg fuer gemischte Spaltentypen.
.parse_appinsights_response <- function(resp) {
  body  <- httr2::resp_body_json(resp)
  tbl   <- body$tables[[1]]
  cols  <- vapply(tbl$columns, function(col) col$name, character(1))
  rows  <- tbl$rows

  if (length(rows) == 0) {
    res <- as.data.frame(
      matrix(nrow = 0, ncol = length(cols)),
      stringsAsFactors = FALSE
    )
    names(res) <- cols
    attr(res, "status") <- "OK_EMPTY"
    return(res)
  }

  # Jede Spalte separat als character-Vektor extrahieren.
  # Das vermeidet List-Columns, die entstehen wenn rbind() auf Listen angewendet wird.
  cols_data <- lapply(seq_along(cols), function(i) {
    vapply(rows, function(row) {
      v <- row[[i]]
      if (is.null(v) || length(v) == 0) NA_character_ else as.character(v[[1]])
    }, character(1))
  })

  df <- as.data.frame(setNames(cols_data, cols), stringsAsFactors = FALSE)
  attr(df, "status") <- "OK"
  df
}


#' Verbindung zu Application Insights testen (Diagnose-Funktion).
#'
#' Fuehrt eine minimale KQL-Abfrage (\code{pageViews | take 1}) durch und
#' gibt den HTTP-Statuscode zurueck. Verwende diese Funktion, um zu pruefen,
#' ob Credentials und Netzwerkverbindung korrekt sind, bevor die vollstaendige
#' Analyse gestartet wird.
#'
#' Voraussetzungen (HOWTO Abschnitt 3.3):
#' \itemize{
#'   \item Umgebungsvariable fuer App-ID gesetzt
#'   \item Umgebungsvariable fuer API-Key gesetzt
#'   \item R-Session nach dem Setzen neu gestartet
#' }
#'
#' @param cfg Geladene Konfiguration aus \code{\link{load_config}}.
#' @return Unsichtbar: HTTP-Statuscode (200 = OK). Gibt eine Meldung aus.
#' @export
test_appinsights_connection <- function(cfg) {
  creds <- .get_appinsights_credentials(cfg)  # stoppt mit Fehlermeldung wenn nicht gesetzt

  url <- sprintf(
    "https://api.applicationinsights.io/v1/apps/%s/query",
    creds$app_id
  )

  # Minimale Testabfrage -- identisches Muster wie im Copilot-Beispiel (GET)
  resp <- httr2::request(url) |>
    httr2::req_headers("x-api-key" = creds$api_key) |>
    httr2::req_url_query(query = "pageViews | take 1") |>
    httr2::req_perform()

  status <- httr2::resp_status(resp)
  message("Application Insights Verbindung OK -- HTTP Status: ", status)
  invisible(status)
}


#' KQL-Abfrage gegen Application Insights ausfuehren.
#'
#' Bevorzugt den Host-Helper \code{run_appinsights_query()} wenn dieser in der
#' Session verfuegbar ist. Faellt andernfalls auf einen eingebauten httr2-Call
#' zurueck (POST-Methode, robuster als GET bei langen KQL-Abfragen).
#'
#' @param kql_query character, die KQL-Abfrage.
#' @param cfg Geladene Konfiguration (siehe \code{\link{load_config}}).
#' @param environment Logischer Umgebungsname, wird an \code{run_appinsights_query()}
#'   weitergegeben.
#' @return Ein \code{data.frame} mit \code{attr(status)} = \code{"OK"},
#'   \code{"OK_EMPTY"} oder \code{"UNKNOWN"}.
#' @export
run_kql_query <- function(kql_query, cfg, environment = NULL) {

  # --- Schritt 1: Telemetrie-Aktivierung pruefen ---
  # Wenn telemetry.enabled: false in config.local.yml, sofort UNKNOWN zurueck.
  # Keine Netzwerkanfrage wird gemacht.
  if (!isTRUE(cfg$telemetry$enabled)) {
    log_warn("data_telemetry",
             "Telemetrie deaktiviert (telemetry.enabled: false) -- UNKNOWN wird zurueckgegeben. ",
             "Zum Aktivieren: telemetry.enabled: true in config.local.yml setzen (HOWTO 3.2).")
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  # --- Schritt 2: Host-Helper bevorzugen ---
  # run_appinsights_query() wird z.B. von D365Security in die Session geladen.
  # Sie uebernimmt Credential-Verwaltung und Environment-spezifisches Routing.
  if (exists("run_appinsights_query", mode = "function")) {
    if (is.null(environment)) {
      log_warn("data_telemetry",
               "run_appinsights_query() verfuegbar, aber kein 'environment' uebergeben -- UNKNOWN.")
      res <- data.frame()
      attr(res, "status") <- "UNKNOWN"
      return(res)
    }

    res <- tryCatch(
      run_appinsights_query(environment, kql_query),
      error = function(e) {
        log_error("data_telemetry",
                  "run_appinsights_query() fehlgeschlagen: %s", conditionMessage(e))
        NULL
      }
    )

    if (is.null(res)) {
      res <- data.frame()
      attr(res, "status") <- "UNKNOWN"
      return(res)
    }

    attr(res, "status") <- if (nrow(res) == 0) "OK_EMPTY" else "OK"
    return(res)
  }

  # --- Schritt 3: Eingebauter httr2-Fallback ---
  # Wird verwendet, wenn kein Host-Helper geladen ist.
  # Credentials kommen aus Umgebungsvariablen (in .Renviron gesetzt).
  log_warn("data_telemetry",
           "run_appinsights_query() nicht gefunden -- eingebauter httr2-Fallback wird verwendet.")

  creds <- tryCatch(
    .get_appinsights_credentials(cfg),
    error = function(e) {
      log_error("data_telemetry", "%s", conditionMessage(e))
      NULL
    }
  )
  if (is.null(creds)) {
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  url <- sprintf(
    "https://api.applicationinsights.io/v1/apps/%s/query",
    creds$app_id
  )

  # POST mit JSON-Body -- robuster als GET bei langen KQL-Abfragen,
  # da URL-Laengenbeschraenkungen bei komplexen Queries relevant werden koennen.
  resp <- tryCatch(
    httr2::request(url) |>
      httr2::req_headers("x-api-key" = creds$api_key) |>
      httr2::req_body_json(list(query = kql_query)) |>
      httr2::req_perform(),
    error = function(e) {
      log_error("data_telemetry", "HTTP-Anfrage fehlgeschlagen: %s", conditionMessage(e))
      NULL
    }
  )

  if (is.null(resp)) {
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  # HTTP-Fehler (4xx/5xx) abfangen und als UNKNOWN behandeln
  http_status <- httr2::resp_status(resp)
  if (http_status != 200L) {
    log_error("data_telemetry",
              "Application Insights antwortete mit HTTP %s. Credentials pruefen (HOWTO 3.3).",
              http_status)
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  # JSON-Antwort in data.frame umwandeln
  tryCatch(
    .parse_appinsights_response(resp),
    error = function(e) {
      log_error("data_telemetry", "Antwort konnte nicht geparst werden: %s", conditionMessage(e))
      res <- data.frame()
      attr(res, "status") <- "UNKNOWN"
      res
    }
  )
}


#' Telemetrie-Beruehrungspunkte pro Benutzer und EntryPoint laden.
#'
#' Laedt die KQL-Abfrage aus \code{kql/04_user_entrypoint_touches.kql} (im
#' Paket enthalten) und fuehrt sie gegen Application Insights aus. Das
#' Analysefenster wird aus \code{cfg$telemetry$telemetry_days} gelesen.
#'
#' Gibt einen leeren data.frame mit \code{attr(status) = "UNKNOWN"} zurueck,
#' wenn die Verbindung nicht hergestellt werden kann -- kein Absturz.
#'
#' @param cfg Geladene Konfiguration (siehe \code{\link{load_config}}).
#' @param environment Logischer D365FO-Umgebungsname fuer Credential-Lookup.
#' @param entry_point_filter Optionaler EntryPoint-Name zur Einschraenkung der
#'   Abfrage auf einen einzelnen EntryPoint.
#' @return \code{data.frame} mit Spalten \code{user_Id}, \code{name},
#'   \code{last_seen}, \code{duration_seconds}, \code{touches}.
#' @export
load_telemetry_touches <- function(cfg, environment = NULL, entry_point_filter = NULL) {

  # Analysefenster validieren
  days <- cfg$telemetry$telemetry_days
  if (is.null(days) || !is.numeric(days) || days <= 0) {
    stop("telemetry_days muss eine positive Zahl sein (Wert: ", days, ")")
  }
  if (days < (cfg$telemetry$min_recommended_days %||% 14)) {
    log_warn("data_telemetry",
             "telemetry_days=%s liegt unter dem empfohlenen Minimum (%s); ",
             "saisonale Prozesse koennen fehlen.",
             days, cfg$telemetry$min_recommended_days)
  }

  # Optionalen Filter-Ausdruck fuer die KQL-Abfrage aufbauen
  filter_clause <- if (is.null(entry_point_filter)) {
    ""
  } else {
    sprintf('and name == "%s"', entry_point_filter)
  }

  # KQL-Template rendern (Platzhalter ersetzen)
  kql <- .render_kql(
    "04_user_entrypoint_touches.kql",
    vars = list(telemetry_days = days, entry_point_filter = filter_clause)
  )

  # Abfrage ausfuehren
  res    <- run_kql_query(kql, cfg, environment = environment)
  status <- attr(res, "status")

  # Spaltentypen normalisieren (Parser liefert alles als character)
  if (!is.null(status) && status %in% c("OK", "OK_EMPTY") && nrow(res) > 0) {
    if ("duration_seconds" %in% names(res))
      res$duration_seconds <- suppressWarnings(as.numeric(res$duration_seconds))
    if ("touches" %in% names(res))
      res$touches <- suppressWarnings(as.numeric(res$touches))

    # AppInsights liefert Timestamps in verschiedenen ISO-8601-Varianten:
    #   "2026-01-15T14:30:00Z"
    #   "2026-01-15T14:30:00.0000000Z"  (mit Mikrosekunden)
    #   "2026-01-15 14:30:00"           (ohne T und Z)
    # strptime mit %Y-%m-%dT%H:%M:%OSZ deckt alle Faelle ab.
    if ("last_seen" %in% names(res)) {
      parsed <- tryCatch({
        p <- as.POSIXct(res$last_seen, tz = "UTC", format = "%Y-%m-%dT%H:%M:%OSZ")
        if (all(is.na(p)))
          p <- as.POSIXct(res$last_seen, tz = "UTC")  # Fallback ohne Format
        p
      }, error = function(e) {
        log_warn("data_telemetry",
                 "last_seen konnte nicht als Datum geparst werden: %s -- bleibt character.",
                 conditionMessage(e))
        NULL
      })
      if (!is.null(parsed) && !all(is.na(parsed)))
        res$last_seen <- parsed
    }

    attr(res, "status") <- status  # nach Typ-Konvertierung wiederherstellen
  }

  res
}
