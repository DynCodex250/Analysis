# =============================================================================
# R/reporting_markdown.R
# Brief section 16.2: Markdown report - a management/technical SUMMARY, not a
# raw data dump (the raw tables live in the Excel report).
# =============================================================================

#' Build and write the Markdown summary report.
#'
#' @param environment character
#' @param user_profiles data.frame (from build_user_profiles())
#' @param role_metrics data.frame (from analyze_role_metrics())
#' @param findings data.frame (from generate_findings())
#' @param cfg loaded config
#' @param output_path full path to the .md file to create
#' @return \code{output_path} invisibly.
#' @export
write_markdown_report <- function(environment, user_profiles, role_metrics, findings, cfg, output_path) {
  n_active <- sum(user_profiles$is_active, na.rm = TRUE)
  n_invalid <- sum(user_profiles$is_invalid_user, na.rm = TRUE)
  n_app_users <- sum(user_profiles$is_application_user, na.rm = TRUE)
  n_roles <- nrow(role_metrics)
  n_roles_with_drivers <- sum(role_metrics$license_relevant_entry_points > 0, na.rm = TRUE)
  n_users_with_findings <- length(unique(findings$user[!is.na(findings$user)]))

  sev_table <- if (nrow(findings) > 0) as.data.frame(table(findings$severity)) else data.frame(Var1 = character(), Freq = integer())
  conf_table <- if (nrow(findings) > 0) as.data.frame(table(findings$confidence)) else data.frame(Var1 = character(), Freq = integer())

  license_drivers <- if (nrow(role_metrics) > 0) {
    d <- role_metrics[role_metrics$distinct_license_types > 0, c("role", "license_skus", "license_relevant_entry_points")]
    d[order(-d$license_relevant_entry_points), ]
  } else data.frame()

  complex_roles <- if (nrow(role_metrics) > 0) {
    role_metrics[order(-role_metrics$entry_point_count), c("role", "duty_count", "privilege_count", "entry_point_count", "possibly_oversized")]
  } else data.frame()

  md <- c(
    sprintf("# D365FO Licensing & Security Analysis - %s", environment),
    sprintf("_Generated: %s | telemetry_days: %s_", format(Sys.time(), "%Y-%m-%d %H:%M"), cfg$telemetry$telemetry_days),
    "",
    "## Management Summary",
    "",
    sprintf("- Active users: **%d**", n_active),
    sprintf("- Invalid users (active but Entra-disconnected): **%d**", n_invalid),
    sprintf("- Application/technical users: **%d**", n_app_users),
    sprintf("- Roles analyzed: **%d**", n_roles),
    sprintf("- Roles with at least one license driver: **%d**", n_roles_with_drivers),
    sprintf("- Users with at least one finding: **%d**", n_users_with_findings),
    sprintf("- Total findings: **%d**", nrow(findings)),
    "",
    "### Findings by Severity",
    "",
    "| Severity | Count |", "|---|---|",
    if (nrow(sev_table) > 0) sprintf("| %s | %d |", sev_table$Var1, sev_table$Freq) else "| _none_ | 0 |",
    "",
    "### Findings by Confidence",
    "",
    "| Confidence | Count |", "|---|---|",
    if (nrow(conf_table) > 0) sprintf("| %s | %d |", conf_table$Var1, conf_table$Freq) else "| _none_ | 0 |",
    "",
    "### Most Common License Drivers (by role)",
    "",
    "| Role | License SKU(s) | Licensing-relevant Entry Points |", "|---|---|---|",
    if (nrow(license_drivers) > 0) sprintf("| %s | %s | %d |", license_drivers$role, license_drivers$license_skus, license_drivers$license_relevant_entry_points) else "| _none_ | | |",
    "",
    "### Roles With Highest Structural Complexity",
    "",
    "| Role | Duties | Privileges | Entry Points | Possibly Oversized |", "|---|---|---|---|---|",
    if (nrow(complex_roles) > 0) utils::head(sprintf("| %s | %s | %s | %s | %s |",
        complex_roles$role, complex_roles$duty_count, complex_roles$privilege_count,
        complex_roles$entry_point_count, complex_roles$possibly_oversized), 15) else "| _none_ | | | | |",
    "",
    "## Data Provenance",
    "",
    "This report distinguishes four kinds of statement (see README for full definitions):",
    "",
    "1. **Observed Data** - read directly from D365FO SQL tables/views or Application Insights telemetry.",
    "2. **Calculated Result** - derived by joining Observed Data (e.g. role metrics, license driver counts).",
    "3. **Interpretation** - heuristic judgement (e.g. 'possibly oversized role') that requires human review.",
    "4. **Recommendation** - a suggested next validation step, never a final licensing decision.",
    "",
    "Individual findings below carry their own Confidence Level (HIGH/MEDIUM/LOW/UNKNOWN) reflecting how many",
    "of these evidence types support them. No statement in this report should be treated as a substitute for",
    "Microsoft's official licensing documentation or a PPAC review.",
    "",
    "## Known Limitations (carried over from the source analysis)",
    "",
    "- UI telemetry does not capture Action/Output Menu Items, certain production actions, and certain print functions.",
    "- Application Insights free-tier exports can be capped; `telemetry.kql_row_limit` in config.yml should be reviewed.",
    "- Transaction-activity evidence (CreatedBy/ModifiedBy) is only available if `transaction_activity.tables` is configured; otherwise it is UNKNOWN, never assumed absent.",
    "- Service-role licensing rules are taken from the source document, not independently re-verified against current Microsoft licensing documentation.",
    ""
  )

  writeLines(md, output_path)
  log_info("reporting_markdown", "Markdown report written to %s", output_path)
  output_path
}
