#' Load raw USERINFO (all users, active + disabled)
#'
#' @param cnn DBI connection from \code{\link{get_readonly_connection}}.
#' @return A \code{data.frame} of USERINFO rows.
#' @export
load_users <- function(cnn) {
  run_readonly_query(cnn, system.file("sql", "01_users_active.sql", package = "D365Licensing"))
}

#' Load SYSUSERINVALIDUSERS
#'
#' @param cnn DBI connection.
#' @return A \code{data.frame} of invalid-user rows.
#' @export
load_invalid_users <- function(cnn) {
  run_readonly_query(cnn, system.file("sql", "02_users_invalid.sql", package = "D365Licensing"))
}

#' Load SYSAADCLIENTTABLE (application / service accounts)
#'
#' @param cnn DBI connection.
#' @return A \code{data.frame} of application-user rows.
#' @export
load_application_users <- function(cnn) {
  run_readonly_query(cnn, system.file("sql", "03_users_application.sql", package = "D365Licensing"))
}

# The all-zeros GUID is D365FO's sentinel for "no Entra ID link".
.NULL_GUID <- "00000000-0000-0000-0000-000000000000"

.has_valid_objectid <- function(objectid) {
  !is.na(objectid) & nzchar(objectid) & objectid != .NULL_GUID
}

#' Classify and enrich raw USERINFO rows.
#'
#' Produces one row per USERINFO entry with derived flags and a
#' \code{user_status_flag} that drives downstream findings.
#' Does NOT decide license outcomes -- that happens in
#' \code{\link{build_user_profiles}}.
#'
#' @param users data.frame from \code{\link{load_users}}.
#' @param invalid_users data.frame from \code{\link{load_invalid_users}}.
#' @param application_users data.frame from \code{\link{load_application_users}}.
#' @return A \code{data.frame} with one row per user and derived columns
#'   including \code{is_active}, \code{is_invalid_user}, \code{is_app_user},
#'   and \code{user_status_flag}.
#' @export
analyze_users <- function(users, invalid_users, application_users) {
  enable_col    <- names(users)[tolower(names(users)) == "enable"][1]
  id_col        <- names(users)[tolower(names(users)) == "id"][1]
  objectid_col  <- names(users)[tolower(names(users)) == "objectid"][1]

  if (is.na(enable_col) || is.na(id_col)) {
    log_warn("data_users", "USERINFO missing expected columns (ENABLE / ID); got: %s",
             paste(names(users), collapse = ", "))
    users$is_active       <- NA
    users$is_invalid_user <- FALSE
    users$is_app_user     <- FALSE
    users$user_status_flag <- "UNKNOWN"
    return(users)
  }

  inv_id_col <- names(invalid_users)[tolower(names(invalid_users)) == "userid"][1]
  app_id_col <- names(application_users)[tolower(names(application_users)) == "userid"][1]

  invalid_ids <- if (!is.na(inv_id_col)) invalid_users[[inv_id_col]] else character()
  app_ids     <- if (!is.na(app_id_col)) application_users[[app_id_col]] else character()

  users$is_active       <- users[[enable_col]] == 1
  users$is_invalid_user <- users[[id_col]] %in% invalid_ids
  users$is_app_user     <- users[[id_col]] %in% app_ids

  has_valid_oid <- if (!is.na(objectid_col)) {
    .has_valid_objectid(users[[objectid_col]])
  } else {
    rep(NA, nrow(users))
  }

  users$user_status_flag <- ifelse(
    !users$is_active,
    "DISABLED",
    ifelse(
      users$is_invalid_user,
      "ACTIVE_BUT_INVALID",
      ifelse(
        !is.na(has_valid_oid) & !has_valid_oid,
        "ACTIVE_NO_ENTRA_LINK_REQUIRES_VALIDATION",
        "ACTIVE_OK"
      )
    )
  )

  users
}

#' Return invalid-user records that belong to currently active users.
#'
#' Joins \code{invalid_users} with \code{users} and keeps only rows where
#' the user is still active (\code{ENABLE = 1}). Disabled users are excluded
#' because they are already de-licensed -- the finding is only actionable for
#' active accounts.
#'
#' @param users data.frame from \code{\link{load_users}}.
#' @param invalid_users data.frame from \code{\link{load_invalid_users}}.
#' @return A \code{data.frame} of invalid-user rows joined with user data,
#'   filtered to active users only.
#' @export
analyze_invalid_users <- function(users, invalid_users) {
  if (nrow(invalid_users) == 0) return(data.frame())
  id_col_u    <- names(users)[tolower(names(users)) == "id"][1]
  enable_col  <- names(users)[tolower(names(users)) == "enable"][1]
  id_col_i    <- names(invalid_users)[tolower(names(invalid_users)) == "userid"][1]
  if (is.na(id_col_u) || is.na(id_col_i) || is.na(enable_col)) return(invalid_users)

  joined <- merge(invalid_users, users, by.x = id_col_i, by.y = id_col_u, all.x = TRUE)
  filtered <- joined[!is.na(joined[[enable_col]]) & joined[[enable_col]] == 1, ]
  if (!"ID" %in% names(filtered)) filtered$ID <- filtered[[id_col_i]]
  filtered
}

#' Enrich application / service-account records.
#'
#' Adds \code{licensing_classification = "REQUIRES_VALIDATION"} to every row
#' because application users require manual review before a license-free ruling
#' can be made (brief section 4).
#'
#' @param application_users data.frame from \code{\link{load_application_users}}.
#' @return The input data.frame with an additional \code{licensing_classification} column.
#' @export
analyze_application_users <- function(application_users) {
  application_users$licensing_classification <- "REQUIRES_VALIDATION"
  application_users
}
