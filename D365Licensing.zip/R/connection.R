#' @keywords internal
`%||%` <- function(a, b) if (is.null(a)) b else a

# These functions are intentionally resolved at runtime from the host project
# loaded in the same R session (e.g. devtools::load_all("path/to/D365Security")).
# They are NOT package imports -- declaring them here silences the R CMD check NOTE.
utils::globalVariables(c("get_connection", "run_appinsights_query"))

#' Load and merge configuration (default + optional local override)
#'
#' Reads \code{inst/config/config.yml} bundled with the package and merges an
#' optional \code{config.local.yml} from the same directory (git-ignored) so
#' local credentials and paths never enter version control.
#'
#' @return A named list (the merged config).
#' @export
load_config <- function() {
  base_path <- system.file("config", "config.yml", package = "D365Licensing")
  if (!nzchar(base_path)) stop("config.yml not found inside D365Licensing package (inst/config/)")
  cfg <- yaml::read_yaml(base_path)$default

  local_path <- system.file("config", "config.local.yml", package = "D365Licensing")
  if (nzchar(local_path)) {
    local_cfg <- yaml::read_yaml(local_path)$default
    cfg <- utils::modifyList(cfg, local_cfg %||% list())
  }
  cfg
}

#' Resolve a read-only DB connection using the project's existing
#' \code{get_connection()} function.
#'
#' This package does not reimplement \code{get_connection()} to avoid a second,
#' divergent connection implementation. It expects the function to already be
#' available in the session (e.g. from \code{D365Security::get_connection()}).
#'
#' @param environment Logical environment name, e.g. \code{"PRJ"}.
#' @param cfg Loaded config list (see \code{\link{load_config}}).
#' @return A DBI connection object.
#' @export
get_readonly_connection <- function(environment, cfg) {
  if (!exists("get_connection", mode = "function")) {
    stop(
      "get_connection() was not found in the current R session.\n",
      "Source or load the package that provides get_connection(environment, credentials_path),\n",
      "e.g.: devtools::load_all('path/to/D365Security')\n",
      "This package intentionally does not reimplement get_connection()."
    )
  }
  get_connection(environment, cfg$connection$credentials_path)
}

#' Guard: reject any SQL text containing write or DDL statements.
#'
#' Applied to every query before execution regardless of source.
#'
#' @param sql_text Character, the raw SQL string.
#' @return \code{invisible(TRUE)} if safe; stops execution otherwise.
#' @keywords internal
guard_readonly_sql <- function(sql_text) {
  forbidden <- c(
    "\\bINSERT\\b", "\\bUPDATE\\b", "\\bDELETE\\b", "\\bMERGE\\b",
    "\\bALTER\\b", "\\bDROP\\b", "\\bTRUNCATE\\b", "\\bCREATE\\b",
    "\\bEXEC\\b", "\\bEXECUTE\\b", "\\bGRANT\\b", "\\bREVOKE\\b",
    "\\bINTO\\s+OUTFILE\\b"
  )
  stripped <- gsub("--.*$", "", sql_text)
  stripped <- gsub("/\\*.*?\\*/", "", stripped, perl = TRUE)
  hits <- vapply(forbidden, function(p) grepl(p, stripped, ignore.case = TRUE), logical(1))
  if (any(hits)) {
    stop(
      "BLOCKED: query contains a forbidden write/DDL statement (",
      paste(forbidden[hits], collapse = ", "),
      "). This pipeline is strictly read-only. Query was NOT executed."
    )
  }
  invisible(TRUE)
}

#' Read a bundled .sql file, substitute parameters, guard, and execute.
#'
#' Use \code{system.file("sql", "file.sql", package = "D365Licensing")} to
#' obtain \code{sql_file}. Parameter substitution replaces \code{@Name} tokens
#' with literal values; remaining unfilled placeholders default to NULL.
#'
#' @param cnn DBI connection.
#' @param sql_file Full path to a \code{.sql} file (use \code{system.file()}).
#' @param params Named list of \code{@Name -> value} substitutions.
#' @return A \code{data.frame} of results.
#' @keywords internal
run_readonly_query <- function(cnn, sql_file, params = list()) {
  if (!file.exists(sql_file)) stop("SQL file not found: ", sql_file)
  sql_text <- paste(readLines(sql_file, warn = FALSE), collapse = "\n")

  for (nm in names(params)) {
    val <- params[[nm]]
    literal <- if (is.null(val)) {
      "NULL"
    } else if (is.logical(val)) {
      if (isTRUE(val)) "1" else "0"
    } else if (is.numeric(val)) {
      as.character(val)
    } else {
      paste0("'", gsub("'", "''", val), "'")
    }
    sql_text <- gsub(paste0("@", nm, "\\b"), literal, sql_text)
  }
  sql_text <- gsub("@[A-Za-z_][A-Za-z0-9_]*\\b", "NULL", sql_text)

  guard_readonly_sql(sql_text)
  DBI::dbGetQuery(cnn, sql_text)
}
