# Render a bundled .kql template, substituting {{placeholders}}.
.render_kql <- function(kql_filename, vars = list()) {
  path <- system.file("kql", kql_filename, package = "D365Licensing")
  if (!nzchar(path)) stop("KQL file not found in package: kql/", kql_filename)
  text <- paste(readLines(path, warn = FALSE), collapse = "\n")
  for (nm in names(vars)) {
    text <- gsub(paste0("\\{\\{", nm, "\\}\\}"), vars[[nm]], text, fixed = FALSE)
  }
  gsub("\\{\\{[a-zA-Z_]+\\}\\}", "", text)
}

#' Execute a KQL query against Application Insights.
#'
#' Prefers the host project's \code{run_appinsights_query()} when it is
#' available in the session, and falls back to a self-contained httr2 call
#' using environment variables named by \code{cfg$telemetry$app_insights_env_var}
#' and \code{cfg$telemetry$api_key_env_var}.
#'
#' @param kql_query character, the KQL query string.
#' @param cfg Loaded config list (see \code{\link{load_config}}).
#' @param environment Logical environment name passed to \code{run_appinsights_query()}.
#' @return A \code{data.frame} with \code{attr(status)} set to
#'   \code{"OK"}, \code{"OK_EMPTY"}, or \code{"UNKNOWN"}.
#' @export
run_kql_query <- function(kql_query, cfg, environment = NULL) {
  if (!isTRUE(cfg$telemetry$enabled)) {
    log_warn("data_telemetry", "telemetry disabled in config; returning UNKNOWN")
    res <- data.frame(); attr(res, "status") <- "UNKNOWN"; return(res)
  }

  if (exists("run_appinsights_query", mode = "function")) {
    if (is.null(environment)) {
      log_warn("data_telemetry",
               "run_appinsights_query() available but no environment passed -- returning UNKNOWN")
      res <- data.frame(); attr(res, "status") <- "UNKNOWN"; return(res)
    }
    res <- tryCatch(
      run_appinsights_query(environment, kql_query),
      error = function(e) { log_error("data_telemetry", "run_appinsights_query() failed: %s", conditionMessage(e)); NULL }
    )
    if (is.null(res)) { res <- data.frame(); attr(res, "status") <- "UNKNOWN"; return(res) }
    attr(res, "status") <- if (nrow(res) == 0) "OK_EMPTY" else "OK"
    return(res)
  }

  # httr2 fallback (used when host project helpers are not loaded)
  log_warn("data_telemetry",
           "run_appinsights_query() not found; using built-in httr2 fallback")
  app_id  <- Sys.getenv(cfg$telemetry$app_insights_env_var, unset = "")
  api_key <- Sys.getenv(cfg$telemetry$api_key_env_var, unset = "")
  if (app_id == "" || api_key == "") {
    log_warn("data_telemetry", "Application Insights credentials not set -- returning UNKNOWN")
    res <- data.frame(); attr(res, "status") <- "UNKNOWN"; return(res)
  }
  url <- sprintf("https://api.applicationinsights.io/v1/apps/%s/query", app_id)
  resp <- tryCatch(
    httr2::request(url) |>
      httr2::req_headers("x-api-key" = api_key) |>
      httr2::req_url_query(query = kql_query) |>
      httr2::req_perform(),
    error = function(e) { log_error("data_telemetry", "REST call failed: %s", conditionMessage(e)); NULL }
  )
  if (is.null(resp)) { res <- data.frame(); attr(res, "status") <- "UNKNOWN"; return(res) }
  body  <- httr2::resp_body_json(resp)
  table <- body$tables[[1]]
  cols  <- vapply(table$columns, function(c) c$name, character(1))
  rows  <- table$rows
  if (length(rows) == 0) {
    res <- as.data.frame(matrix(nrow = 0, ncol = length(cols))); names(res) <- cols
    attr(res, "status") <- "OK_EMPTY"; return(res)
  }
  df <- as.data.frame(do.call(rbind, lapply(rows, unlist)), stringsAsFactors = FALSE)
  names(df) <- cols; attr(df, "status") <- "OK"; df
}

#' Load per-user, per-entry-point telemetry touches from Application Insights.
#'
#' Uses \code{kql/04_user_entrypoint_touches.kql} bundled with the package.
#' The analysis window is always read from \code{cfg$telemetry$telemetry_days}.
#'
#' @param cfg Loaded config list (see \code{\link{load_config}}).
#' @param environment Logical D365FO environment name passed to
#'   \code{run_appinsights_query()} for credential lookup.
#' @param entry_point_filter Optional entry-point name to restrict the query.
#' @return A \code{data.frame}(user_Id, name, last_seen, duration_seconds,
#'   touches), or an empty frame with \code{attr(status) = "UNKNOWN"}.
#' @export
load_telemetry_touches <- function(cfg, environment = NULL, entry_point_filter = NULL) {
  days <- cfg$telemetry$telemetry_days
  if (is.null(days) || !is.numeric(days) || days <= 0) {
    stop("telemetry_days must be a positive number in config.yml (got: ", days, ")")
  }
  if (days < (cfg$telemetry$min_recommended_days %||% 14)) {
    log_warn("data_telemetry",
             "telemetry_days=%s below recommended minimum (%s); seasonal processes may be missed",
             days, cfg$telemetry$min_recommended_days)
  }
  filter_clause <- if (is.null(entry_point_filter)) "" else
    sprintf('and name == "%s"', entry_point_filter)

  kql <- .render_kql("04_user_entrypoint_touches.kql",
                     vars = list(telemetry_days = days, entry_point_filter = filter_clause))
  res <- run_kql_query(kql, cfg, environment = environment)

  status <- attr(res, "status")
  if (!is.null(status) && status %in% c("OK", "OK_EMPTY") && nrow(res) > 0) {
    if ("duration_seconds" %in% names(res))
      res$duration_seconds <- suppressWarnings(as.numeric(res$duration_seconds))
    if ("touches" %in% names(res))
      res$touches <- suppressWarnings(as.numeric(res$touches))
    if ("last_seen" %in% names(res)) {
      parsed <- suppressWarnings(as.POSIXct(res$last_seen, tz = "UTC"))
      if (!all(is.na(parsed))) res$last_seen <- parsed
    }
    attr(res, "status") <- status
  }
  res
}
