#' Lizenzanforderungen einer Rolle berechnen
#'
#' Berechnet die Lizenz-SKUs, die eine Rolle erfordert —
#' in zwei Stufen, analog zur Microsoft-UI
#' (System administration > Security > Security governance >
#' Licenses usage summary > Role licenses).
#'
#' @details
#'
#' **Stufe 1 — Einzellizenz**
#'
#' Aus \code{LICENSINGROLEREQUIREMENTSSUMMARYVIEW} wird geprüft,
#' ob mindestens ein SKU alle Privileges der Rolle abdeckt
#' (\code{NOTENTITLED = 0}).
#'
#' Wenn ja: die SKU mit der niedrigsten PRIORITY (günstigste)
#' wird zurückgegeben. \code{algorithm_step = "single_license"}.
#'
#' **Stufe 2 — Collapse-Algorithmus**
#'
#' Wenn keine einzelne SKU ausreicht (\code{NOTENTITLED > 0}
#' für alle SKUs), wird für jedes Privilege im Rollengraph
#' (\code{SECURITYROLEPRIVILEGEEXPLODEDGRAPH}) die günstigste
#' deckende SKU ermittelt (MIN PRIORITY aus
#' \code{LICENSINGPRIVILEGESREQUIREMENTSSUMMARYVIEW} mit
#' \code{ENTITLED = 1}).
#'
#' Collapse-Regel: Sobald mindestens eine Base-App-Lizenz
#' (PRIORITY >= 40, z.B. Commerce, Finance, Supply Chain Management)
#' benötigt wird, entfallen Light-Lizenzen (PRIORITY <= 30:
#' None, Team Members, Operations - Activity), da Base-App-Lizenzen
#' diese implizit einschließen.
#'
#' \code{algorithm_step = "collapse"}.
#'
#' @param con
#' Datenbankverbindung. Ergebnis von \code{get_connection()}.
#'
#' @param role_identifiers
#' Character-Vektor mit Rollen-AOTNAMEs.
#' Wenn leer, werden alle Rollen ausgewertet
#' (kann bei vielen Rollen langsam sein).
#'
#' @return
#'
#' Tibble mit einer Zeile pro Rollen-SKU-Kombination.
#'
#' \describe{
#'   \item{ROLEIDENTIFIER}{AOT-Name der Rolle.}
#'   \item{SECURITYROLENAME}{Anzeigename der Rolle.}
#'   \item{SKUNAME}{Name der benötigten Lizenz.}
#'   \item{PRIORITY}{Lizenz-Priorität (niedrig = günstiger).}
#'   \item{privilege_count}{
#'     Stufe 1: Gesamtanzahl Privileges in der Rolle.
#'     Stufe 2: Anzahl Privileges für die diese SKU Minimum ist.
#'   }
#'   \item{algorithm_step}{\code{"single_license"} oder \code{"collapse"}.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' cnn <- get_connection("PRJ", "db_credentials.xlsx")
#'
#' # Eine Rolle
#' get_role_license_requirements(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER")
#'
#' # Mehrere Rollen vergleichen
#' get_role_license_requirements(cnn, c("_WIBU_VERKAUF_KEYACCOUNT", "_WIBU_EINKAUF_MITARBEITER"))
#'
#' }
#'
#' @seealso
#' \code{\link{get_role_license_assignments}}
#' \code{\link{get_user_licenses_by_role}}
#' \code{\link{sec_check_license_impact}}
#'
#' @export
get_role_license_requirements <- function(
  con,
  role_identifiers = character()
) {

  sql_in <- function(values) {
    paste0("'", gsub("'", "''", values), "'", collapse = ", ")
  }

  empty_result <- function() {
    tibble::tibble(
      ROLEIDENTIFIER   = character(),
      SECURITYROLENAME = character(),
      SKUNAME          = character(),
      PRIORITY         = integer(),
      privilege_count  = integer(),
      algorithm_step   = character()
    )
  }

  role_where <- if (length(role_identifiers) > 0L) {
    paste0("AND sr.AOTNAME IN (", sql_in(role_identifiers), ")")
  } else {
    ""
  }

  #====================================================
  # STUFE 1: Einzellizenz (NOTENTITLED = 0)
  #====================================================

  stage1_raw <- DBI::dbGetQuery(con, paste0("
    SELECT
      sr.AOTNAME   AS ROLEIDENTIFIER,
      sr.NAME      AS SECURITYROLENAME,
      lask.SKUNAME,
      lrrs.PRIORITY,
      lrrs.ENTITLED
    FROM LICENSINGROLEREQUIREMENTSSUMMARYVIEW lrrs
    LEFT JOIN SECURITYROLE     sr   ON sr.RECID   = lrrs.SECURITYROLE
    LEFT JOIN LICENSINGALLSKUS lask ON lask.RECID = lrrs.SKURECID
    WHERE lrrs.NOTENTITLED = 0
    ", role_where
  )) |> tibble::as_tibble()

  roles_covered_stage1 <- unique(stage1_raw$ROLEIDENTIFIER)

  result_stage1 <- if (nrow(stage1_raw) > 0L) {
    stage1_raw |>
      dplyr::group_by(ROLEIDENTIFIER, SECURITYROLENAME) |>
      dplyr::slice_min(PRIORITY, n = 1L, with_ties = FALSE) |>
      dplyr::ungroup() |>
      dplyr::mutate(
        privilege_count = as.integer(ENTITLED),
        algorithm_step  = "single_license"
      ) |>
      dplyr::select(ROLEIDENTIFIER, SECURITYROLENAME, SKUNAME, PRIORITY,
                    privilege_count, algorithm_step)
  } else {
    empty_result()
  }

  #====================================================
  # STUFE 2: Collapse-Algorithmus
  #====================================================

  roles_for_stage2 <- if (length(role_identifiers) > 0L) {
    setdiff(role_identifiers, roles_covered_stage1)
  } else {
    all_roles <- DBI::dbGetQuery(con, "
      SELECT DISTINCT sr.AOTNAME AS ROLEIDENTIFIER
      FROM SECURITYROLE sr
      JOIN LICENSINGROLEREQUIREMENTSSUMMARYVIEW lrrs ON lrrs.SECURITYROLE = sr.RECID
    ") |> dplyr::pull(ROLEIDENTIFIER)
    setdiff(all_roles, roles_covered_stage1)
  }

  if (length(roles_for_stage2) == 0L) {
    return(
      dplyr::bind_rows(result_stage1, empty_result()) |>
        dplyr::arrange(ROLEIDENTIFIER, PRIORITY)
    )
  }

  role_names <- DBI::dbGetQuery(con, paste0(
    "SELECT AOTNAME AS ROLEIDENTIFIER, NAME AS SECURITYROLENAME
     FROM SECURITYROLE WHERE AOTNAME IN (", sql_in(roles_for_stage2), ")"
  )) |> tibble::as_tibble()

  result_stage2 <- purrr::map_dfr(roles_for_stage2, function(role_id) {

    quoted <- paste0("'", gsub("'", "''", role_id), "'")

    role_name <- role_names |>
      dplyr::filter(ROLEIDENTIFIER == role_id) |>
      dplyr::pull(SECURITYROLENAME)
    role_name <- if (length(role_name) == 0L) NA_character_ else role_name[[1L]]

    raw <- DBI::dbGetQuery(con, paste0("
      SELECT
        lask.SKUNAME,
        min_prio.PRIORITY,
        COUNT(*) AS privilege_count
      FROM (
        SELECT
          lprs.SECURITYPRIVILEGE,
          MIN(lprs.PRIORITY) AS PRIORITY
        FROM LICENSINGPRIVILEGESREQUIREMENTSSUMMARYVIEW lprs
        WHERE lprs.ENTITLED = 1
          AND lprs.SECURITYPRIVILEGE IN (
            SELECT rpe.SECURITYPRIVILEGE
            FROM SECURITYROLE sr
            JOIN SECURITYROLEPRIVILEGEEXPLODEDGRAPH rpe
              ON rpe.SECURITYROLE = sr.RECID
            WHERE sr.AOTNAME = ", quoted, "
          )
        GROUP BY lprs.SECURITYPRIVILEGE
      ) min_prio
      JOIN LICENSINGPRIVILEGESREQUIREMENTSSUMMARYVIEW min_sku
        ON  min_sku.SECURITYPRIVILEGE = min_prio.SECURITYPRIVILEGE
        AND min_sku.PRIORITY          = min_prio.PRIORITY
        AND min_sku.ENTITLED          = 1
      JOIN LICENSINGALLSKUS lask ON lask.RECID = min_sku.SKURECID
      GROUP BY lask.SKUNAME, lask.RECID, min_prio.PRIORITY
      ORDER BY min_prio.PRIORITY ASC
    ")) |> tibble::as_tibble()

    if (nrow(raw) == 0L) {
      return(tibble::tibble(
        ROLEIDENTIFIER   = role_id,
        SECURITYROLENAME = role_name,
        SKUNAME          = NA_character_,
        PRIORITY         = NA_integer_,
        privilege_count  = 0L,
        algorithm_step   = "collapse"
      ))
    }

    if (any(raw$PRIORITY >= 40L)) {
      raw <- dplyr::filter(raw, PRIORITY >= 40L)
    }

    raw |>
      dplyr::mutate(
        ROLEIDENTIFIER   = role_id,
        SECURITYROLENAME = role_name,
        privilege_count  = as.integer(privilege_count),
        algorithm_step   = "collapse"
      ) |>
      dplyr::select(ROLEIDENTIFIER, SECURITYROLENAME, SKUNAME, PRIORITY,
                    privilege_count, algorithm_step)
  })

  dplyr::bind_rows(result_stage1, result_stage2) |>
    dplyr::arrange(ROLEIDENTIFIER, PRIORITY)
}
