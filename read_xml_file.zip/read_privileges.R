#' Privileges einer AxSecurityRole-XML-Datei lesen
#'
#' Gibt die Namen aller Privileges zurück, die in einer AxSecurityRole-XML-Datei
#' referenziert sind.
#'
#' @param doc
#' Geladenes XML-Dokument. Ergebnis von \code{xml2::read_xml()}.
#'
#' @return
#' Character-Vektor mit den AOT-Namen der referenzierten Privileges.
#' Länge 0 wenn keine Privileges vorhanden.
#'
#' @examples
#' \dontrun{
#'
#' doc <- xml2::read_xml("_WIBU_FIBU_FINANZBUCHHALTUNG.xml")
#' read_privileges(doc)
#'
#' }
#'
#' @seealso
#' \code{\link{read_duties}}
#' \code{\link{read_entrypoints}}
#' \code{\link{read_role_metadata}}
#'
#' @export
read_privileges <- function(doc) {
  xml2::xml_find_all(doc, "//Privileges/AxSecurityPrivilegeReference/Name") |>
    xml2::xml_text()
}
