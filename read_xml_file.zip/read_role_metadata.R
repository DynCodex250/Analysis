#' Metadaten einer AxSecurityRole-XML-Datei lesen
#'
#' Liest Name und Label aus einem geladenen AxSecurityRole-Dokument
#' und erkennt automatisch, ob der Rollenname eine GUID ist.
#'
#' @param doc
#' Geladenes XML-Dokument. Ergebnis von \code{xml2::read_xml()}.
#'
#' @return
#'
#' Tibble mit einer Zeile und drei Spalten:
#'
#' \describe{
#'   \item{RoleName}{AOT-Name der Rolle.}
#'   \item{RoleLabel}{Anzeigename der Rolle.}
#'   \item{IsGUID}{\code{TRUE} wenn \code{RoleName} eine GUID ist (Config-Rolle).}
#' }
#'
#' @examples
#' \dontrun{
#'
#' doc <- xml2::read_xml("_WIBU_FIBU_FINANZBUCHHALTUNG.xml")
#' read_role_metadata(doc)
#'
#' }
#'
#' @seealso
#' \code{\link{is_guid_name}}
#' \code{\link{compare_security_roles}}
#'
#' @export
read_role_metadata <- function(doc) {

  tibble::tibble(

    RoleName = xml2::xml_text(
      xml2::xml_find_first(doc, "//Name")
    ),

    RoleLabel = xml2::xml_text(
      xml2::xml_find_first(doc, "//Label")
    )

  ) |>
    dplyr::mutate(
      IsGUID = is_guid_name(RoleName)
    )
}
