#' Entry Points einer AxSecurityRole-XML-Datei lesen
#'
#' Gibt die Namen aller Entry Points zurück, die direkt in einer
#' AxSecurityRole-XML-Datei definiert sind.
#'
#' @param doc
#' Geladenes XML-Dokument. Ergebnis von \code{xml2::read_xml()}.
#'
#' @return
#' Character-Vektor mit den Namen der Entry Points.
#' Länge 0 wenn keine Entry Points vorhanden.
#'
#' @examples
#' \dontrun{
#'
#' doc <- xml2::read_xml("_WIBU_FIBU_FINANZBUCHHALTUNG.xml")
#' read_entrypoints(doc)
#'
#' }
#'
#' @seealso
#' \code{\link{read_duties}}
#' \code{\link{read_privileges}}
#' \code{\link{read_role_metadata}}
#'
#' @export
read_entrypoints <- function(doc) {
  xml2::xml_find_all(doc, "//EntryPoints/*/Name") |>
    xml2::xml_text()
}
