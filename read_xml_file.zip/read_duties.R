#' Duties einer AxSecurityRole-XML-Datei lesen
#'
#' Gibt die Namen aller Duties zurück, die in einer AxSecurityRole-XML-Datei
#' referenziert sind.
#'
#' @param doc
#' Geladenes XML-Dokument. Ergebnis von \code{xml2::read_xml()}.
#'
#' @return
#' Character-Vektor mit den AOT-Namen der referenzierten Duties.
#' Länge 0 wenn keine Duties vorhanden.
#'
#' @examples
#' \dontrun{
#'
#' doc <- xml2::read_xml("_WIBU_FIBU_FINANZBUCHHALTUNG.xml")
#' read_duties(doc)
#'
#' }
#'
#' @seealso
#' \code{\link{read_privileges}}
#' \code{\link{read_entrypoints}}
#' \code{\link{read_role_metadata}}
#'
#' @export
read_duties <- function(doc) {
  xml2::xml_find_all(doc, "//Duties/AxSecurityDutyReference/Name") |>
    xml2::xml_text()
}
