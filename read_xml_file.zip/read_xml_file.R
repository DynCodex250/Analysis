#' Eine AxSecurity-XML-Datei laden
#'
#' Dünner Wrapper um \code{xml2::read_xml()} für den Einsatz in Pipelines.
#'
#' @param file_path
#' Absoluter oder relativer Pfad zur XML-Datei.
#'
#' @return
#' Geparster XML-Dokumentbaum (\code{xml_document}).
#'
#' @examples
#' \dontrun{
#'
#' doc <- read_xml_file("_WIBU_FIBU_FINANZBUCHHALTUNG.xml")
#' read_role_metadata(doc)
#'
#' }
#'
#' @seealso
#' \code{\link{read_role_metadata}}
#' \code{\link{read_duties}}
#' \code{\link{read_privileges}}
#' \code{\link{read_entrypoints}}
#'
#' @export
read_xml_file <- function(file_path) {
  xml2::read_xml(file_path)
}
