#' Lizenz-Impact einer neuen Rollenzuweisung prüfen
#'
#' Prüft für eine Liste von Benutzern, ob das Hinzufügen einer neuen Rolle
#' deren Lizenzanforderung verändert.
#'
#' @details
#'
#' Die Funktion liest die aktuellen Lizenzen der Benutzer aus der
#' D365FO-Standardsicht \code{LICENSINGUSERLICENSESBYROLE} und
#' vergleicht sie mit den Lizenzen, die die neue Rolle erfordert.
#'
#' Mögliche Ergebnisse je Benutzer:
#'
#' \describe{
#'
#' \item{upgrade}{
#' Die neue Rolle erfordert eine höhere Lizenz als der Benutzer
#' aktuell benötigt.
#' Beispiel: Benutzer hat Team Members → neue Rolle erfordert Finance.
#' }
#'
#' \item{additional}{
#' Die neue Rolle fügt einen Lizenztyp hinzu, den der Benutzer
#' noch nicht hat — aber die bestehende Hauptlizenz steigt nicht.
#' Beispiel: Benutzer hat Finance, neue Rolle fügt Human Resources hinzu.
#' }
#'
#' \item{none}{
#' Alle Lizenzen der neuen Rolle sind durch bestehende Zuweisungen
#' bereits abgedeckt. Keine Lizenzänderung.
#' }
#'
#' }
#'
#' Die Rangordnung der Lizenzen (Priority) wird direkt aus
#' \code{LicensingAllSKUs} gelesen.
#'
#' @param connection
#' Datenbankverbindung. Ergebnis von \code{get_connection()}.
#'
#' @param user_ids
#' Character-Vektor mit den Benutzer-IDs, für die der Impact geprüft
#' werden soll.
#'
#' @param new_role_identifier
#' AOTNAME der Rolle, die hinzugefügt werden soll.
#'
#' @return
#'
#' Tibble mit einer Zeile pro Benutzer.
#'
#' \describe{
#'   \item{USERID}{Benutzerkennung.}
#'   \item{current_license}{Aktuelle Hauptlizenz (höchste Priority).}
#'   \item{current_priority}{Priority der aktuellen Hauptlizenz.}
#'   \item{new_license}{Hauptlizenz nach Zuweisung der neuen Rolle.}
#'   \item{new_priority}{Priority der neuen Hauptlizenz.}
#'   \item{license_change}{\code{"upgrade"}, \code{"additional"} oder \code{"none"}.}
#'   \item{additional_skus}{
#'     Neue Lizenztypen, die durch die Rolle hinzukommen
#'     (leer wenn keine).
#'   }
#' }
#'
#' @examples
#' \dontrun{
#'
#' cnn <- get_connection("PRJ", "db_credentials.xlsx")
#'
#' result <- sec_check_license_impact(
#'   connection          = cnn,
#'   user_ids            = c("wibule01", "wibule02", "wibule03"),
#'   new_role_identifier = "_WIBU_VERKAUF_KEYACCOUNT"
#' )
#'
#' result
#'
#' # Nur Benutzer mit Lizenzänderung
#' dplyr::filter(result, license_change != "none")
#'
#' }
#'
#' @seealso
#' \code{\link{get_user_licenses_by_role}}
#' \code{\link{get_role_license_assignments}}
#' \code{\link{sec_generate_role_alignment}}
#'
#' @export
sec_check_license_impact <- function(
    connection,
    user_ids,
    new_role_identifier) {

  #====================================================
  # SKU-Prioritäten laden (Rangordnung der Lizenzen)
  #====================================================

  sku_prio <- DBI::dbGetQuery(connection, "
    SELECT
      RECID                          AS SKURECID,
      COALESCE([Priority], 10)       AS Priority,
      COALESCE(SKUNAME, 'Team Members') AS SKUNAME
    FROM LicensingAllSKUs
  ") |>
    tibble::as_tibble()

  #====================================================
  # Aktuelle Lizenzen der Benutzer
  #====================================================

  current_raw <- get_user_licenses_by_role(
    connection,
    user_ids = user_ids
  )

  current_with_prio <- current_raw |>
    dplyr::left_join(
      dplyr::select(sku_prio, SKURECID, Priority),
      by = "SKURECID"
    )

  current_max <- current_with_prio |>
    dplyr::group_by(USERID) |>
    dplyr::slice_max(Priority, n = 1L, with_ties = FALSE) |>
    dplyr::ungroup() |>
    dplyr::select(USERID, current_license = SKUNAME, current_priority = Priority)

  current_skus <- current_raw |>
    dplyr::distinct(USERID, SKURECID)

  #====================================================
  # Lizenzen der neuen Rolle (rollenspezifisch)
  #====================================================

  role_sql <- paste0("
    SELECT DISTINCT
      lulr.SKURECID,
      lulr.SKUNAME
    FROM  LICENSINGUSERLICENSESBYROLE lulr
    LEFT JOIN SECURITYROLE sr ON sr.RECID = lulr.SECURITYROLERECID
    WHERE sr.AOTNAME = '", new_role_identifier, "'
  ")

  new_role_skus <- DBI::dbGetQuery(connection, role_sql) |>
    tibble::as_tibble()

  # Fallback: Rolle nicht in LICENSINGUSERLICENSESBYROLE →
  # get_role_license_assignments prüft LICENSINGROLELICENSEASSIGNMENTS
  # und gibt 0 Zeilen zurück wenn keine Lizenzinformation vorhanden ist
  if (nrow(new_role_skus) == 0L) {
    new_role_skus <- get_role_license_assignments(
      connection,
      role_identifiers = new_role_identifier
    )
  }

  # Keine Lizenzinformation gefunden → Rolle ist lizenzfrei
  if (nrow(new_role_skus) == 0L) {
    return(
      current_max |>
        dplyr::mutate(
          new_license     = current_license,
          new_priority    = current_priority,
          license_change  = "none",
          additional_skus = ""
        ) |>
        dplyr::select(
          USERID, current_license, current_priority,
          new_license, new_priority, license_change, additional_skus
        )
    )
  }

  new_role_with_prio <- new_role_skus |>
    dplyr::left_join(
      dplyr::select(sku_prio, SKURECID, Priority),
      by = "SKURECID"
    )

  new_role_max_prio <- max(new_role_with_prio$Priority, na.rm = TRUE)
  new_role_max_sku  <- new_role_with_prio |>
    dplyr::slice_max(Priority, n = 1L, with_ties = FALSE) |>
    dplyr::pull(SKUNAME)

  #====================================================
  # Impact je Benutzer berechnen
  #====================================================

  impact <- current_max |>
    dplyr::mutate(
      new_priority   = pmax(current_priority, new_role_max_prio),
      new_license    = dplyr::if_else(
        new_role_max_prio > current_priority,
        new_role_max_sku,
        current_license
      )
    )

  #====================================================
  # Neue Lizenztypen die noch nicht vorhanden sind
  #====================================================

  new_role_sku_ids <- new_role_skus$SKURECID

  additional_per_user <- purrr::map_dfr(user_ids, function(uid) {
    existing <- dplyr::filter(current_skus, USERID == uid)$SKURECID
    added    <- setdiff(new_role_sku_ids, existing)
    added_names <- new_role_skus |>
      dplyr::filter(SKURECID %in% added) |>
      dplyr::pull(SKUNAME)
    tibble::tibble(
      USERID          = uid,
      additional_skus = paste(added_names, collapse = ", ")
    )
  })

  #====================================================
  # license_change klassifizieren
  #====================================================

  impact |>
    dplyr::left_join(additional_per_user, by = "USERID") |>
    dplyr::mutate(
      license_change = dplyr::case_when(
        new_priority > current_priority           ~ "upgrade",
        additional_skus != ""                     ~ "additional",
        TRUE                                      ~ "none"
      )
    ) |>
    dplyr::select(
      USERID,
      current_license,
      current_priority,
      new_license,
      new_priority,
      license_change,
      additional_skus
    )
}
