#' Fehlende Organisationszuordnungen identifizieren
#'
#' Prüft für jede Benutzer-Rollen-Kombination, ob alle
#' geforderten Legal Entities als Organisationszuordnung
#' vorhanden sind, und gibt die fehlenden Datensätze
#' im D365-Importformat zurück.
#'
#' @details
#'
#' Die Funktion arbeitet ausschließlich auf expliziten
#' Organisationszuordnungen aus
#' \code{SystemSecurityUserRoleOrganizationEntity}.
#' Globale Zuordnungen (ORGANIZATIONID = "All") werden
#' nicht berücksichtigt, da global zugewiesene Rollen
#' bereits alle Legal Entities abdecken.
#'
#' Für jede (USERID, SECURITYROLEIDENTIFIER)-Kombination
#' wird geprüft, welche der \code{required_org_ids} fehlen.
#' Die fehlenden Zeilen werden im Format der D365-Entität
#' \emph{System security user role organization assignment}
#' zurückgegeben und können direkt importiert werden.
#'
#' @param con Datenbankverbindung.
#' @param required_org_ids
#'   Vektor der Legal-Entity-IDs, die für jede
#'   Benutzer-Rollen-Kombination vorhanden sein müssen.
#'   Beispiel: \code{c("0360", "0800")} oder
#'   \code{c("DE01", "AT01", "CH01")}.
#' @param user_ids
#'   Optionaler Vektor von Benutzerkennungen.
#'   Wenn angegeben, werden nur diese Benutzer geprüft.
#' @param role_names
#'   Optionaler Vektor von Rollennamen
#'   (\code{SECURITYROLENAME}).
#'   Wenn angegeben, werden nur diese Rollen geprüft.
#'
#' @return
#' Tibble mit fehlenden Organisationszuordnungen.
#'
#' Spalten:
#' \itemize{
#'   \item \code{USERID}
#'   \item \code{SECURITYROLEIDENTIFIER}
#'   \item \code{SECURITYROLENAME}
#'   \item \code{ORGANIZATIONTYPE} — immer \code{"LegalEntity"}
#'   \item \code{ORGANIZATIONID} — die fehlende Legal Entity
#' }
#'
#' Ein leeres Tibble bedeutet: alle geforderten
#' Organisationszuordnungen sind vorhanden.
#'
#' @examples
#' \dontrun{
#'
#' # Alle Benutzer prüfen
#' missing <- sec_find_missing_org_assignments(
#'   con              = cnn,
#'   required_org_ids = c("0360", "0800")
#' )
#'
#' # Nur bestimmte Benutzer
#' missing <- sec_find_missing_org_assignments(
#'   con              = cnn,
#'   required_org_ids = c("0360", "0800"),
#'   user_ids         = c("wibule01", "wibule02")
#' )
#'
#' # Nur bestimmte Rollen
#' missing <- sec_find_missing_org_assignments(
#'   con              = cnn,
#'   required_org_ids = c("0360", "0800"),
#'   role_names       = c("_WIBU Lagermitarbeiter")
#' )
#'
#' # Ergebnis direkt als Excel exportieren
#' writexl::write_xlsx(
#'   list(assignments = missing),
#'   "System security user role organization assignment_FIXED.xlsx"
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{sec_generate_role_alignment}}
#' \code{\link{get_sql_user_role_assignments}}
#'
#' @export
sec_find_missing_org_assignments <- function(
  con,
  required_org_ids,
  user_ids   = character(),
  role_names = character()
) {

  #====================================================
  # VALIDIERUNG
  #====================================================

  if (length(required_org_ids) == 0L) {
    stop("required_org_ids darf nicht leer sein.")
  }

  #====================================================
  # SQL: explizite Organisationszuordnungen laden
  #====================================================

  query <- "
SELECT
  org.USERID,
  org.SECURITYROLEIDENTIFIER,
  role.SECURITYROLENAME,
  org.ORGANIZATIONID
FROM
  SystemSecurityUserRoleOrganizationEntity org
LEFT JOIN
  SystemSecurityUserRoleEntity role
  ON  org.USERID                  = role.USERID
  AND org.SECURITYROLEIDENTIFIER  = role.SECURITYROLEIDENTIFIER
WHERE
  1 = 1
"

  add_in_filter <- function(query, column, values) {
    if (length(values) == 0L) return(query)
    quoted <- paste0("'", gsub("'", "''", values), "'", collapse = ", ")
    paste0(query, "\nAND ", column, " IN (", quoted, ")")
  }

  query <- add_in_filter(query, "org.USERID",            tolower(user_ids))
  query <- add_in_filter(query, "role.SECURITYROLENAME", role_names)

  current <- DBI::dbGetQuery(con, query) |>
    tibble::as_tibble() |>
    dplyr::mutate(USERID = tolower(USERID))

  if (nrow(current) == 0L) {
    return(
      tibble::tibble(
        USERID                  = character(),
        SECURITYROLEIDENTIFIER  = character(),
        SECURITYROLENAME        = character(),
        ORGANIZATIONTYPE        = character(),
        ORGANIZATIONID          = character()
      )
    )
  }

  #====================================================
  # FEHLENDE ZUORDNUNGEN ERMITTELN
  #====================================================

  # Alle vorhandenen Kombinationen (ohne ORGANIZATIONID)
  combinations <- current |>
    dplyr::distinct(USERID, SECURITYROLEIDENTIFIER, SECURITYROLENAME)

  # Kreuzprodukt: jede Kombination x jede geforderte Org
  required <- tidyr::crossing(
    combinations,
    ORGANIZATIONID = required_org_ids
  )

  # Anti-Join: geforderte Zeilen, die nicht in current sind
  missing_assignments <- dplyr::anti_join(
    required,
    current,
    by = c("USERID", "SECURITYROLEIDENTIFIER", "ORGANIZATIONID")
  ) |>
    dplyr::mutate(ORGANIZATIONTYPE = "LegalEntity") |>
    dplyr::select(
      USERID,
      SECURITYROLEIDENTIFIER,
      SECURITYROLENAME,
      ORGANIZATIONTYPE,
      ORGANIZATIONID
    ) |>
    dplyr::arrange(USERID, SECURITYROLENAME, ORGANIZATIONID)

  missing_assignments
}
