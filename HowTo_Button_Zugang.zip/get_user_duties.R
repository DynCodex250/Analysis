#' Duties eines Benutzers auslesen
#'
#' Gibt alle Duties zurück, die einem Benutzer in D365FO zugewiesen sind —
#' direkt aus \code{USERSECGOVRELATEDOBJECTUSERDUTYVIEW}.
#'
#' @details
#'
#' Die View liefert die effektiven Duties, die ein Benutzer
#' (über seine Rollenzuweisungen) erhält. Es gibt keine direkte
#' Verbindung zu Lizenzinformationen; für Lizenzanalysen
#' siehe \code{get_user_licenses_by_role()}.
#'
#' @param con
#' Datenbankverbindung. Ergebnis von \code{get_connection()}.
#'
#' @param user_ids
#' Optionaler Character-Vektor mit Benutzer-IDs.
#' \code{NULL} = alle Benutzer.
#'
#' @param duty_identifiers
#' Optionaler Character-Vektor mit Duty-AOTNAMEs (\code{DUTYIDENTIFIER}).
#' \code{NULL} = alle Duties.
#'
#' @return
#'
#' Tibble mit einer Zeile pro Benutzer-Duty-Kombination.
#'
#' \describe{
#'   \item{USER_}{Benutzerkennung.}
#'   \item{DUTYIDENTIFIER}{AOT-Name der Duty.}
#'   \item{DUTYNAME}{Anzeigename der Duty.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' cnn <- get_connection("PRJ", "db_credentials.xlsx")
#'
#' # Alle Duties aller Benutzer
#' get_user_duties(cnn)
#'
#' # Duties eines bestimmten Benutzers
#' get_user_duties(cnn, user_ids = "wibule01")
#'
#' # Mehrere Benutzer vergleichen
#' get_user_duties(cnn, user_ids = c("wibule01", "wibule02"))
#'
#' # Nur bestimmte Duties (alle Benutzer)
#' get_user_duties(cnn, duty_identifiers = "SysServerAXBasicMaintain")
#'
#' # Kombination: welche Benutzer haben diese Duty?
#' get_user_duties(cnn, duty_identifiers = c("SysServerAXBasicMaintain", "FlowViewFlowsDuty"))
#'
#' }
#'
#' @seealso
#' \code{\link{get_user_privileges}}
#' \code{\link{get_user_licenses_by_role}}
#'
#' @export
get_user_duties <- function(
  con,
  user_ids         = NULL,
  duty_identifiers = NULL
) {

  clauses <- character(0)

  if (!is.null(user_ids) && length(user_ids) > 0L) {
    quoted   <- paste0("'", gsub("'", "''", user_ids), "'", collapse = ", ")
    clauses  <- c(clauses, paste0("USER_ IN (", quoted, ")"))
  }

  if (!is.null(duty_identifiers) && length(duty_identifiers) > 0L) {
    quoted   <- paste0("'", gsub("'", "''", duty_identifiers), "'", collapse = ", ")
    clauses  <- c(clauses, paste0("DUTYIDENTIFIER IN (", quoted, ")"))
  }

  where_sql <- if (length(clauses) > 0L) {
    paste("WHERE", paste(clauses, collapse = " AND "))
  } else {
    ""
  }

  DBI::dbGetQuery(con, paste0("
    SELECT
      USER_,
      DUTYIDENTIFIER,
      DUTYNAME
    FROM USERSECGOVRELATEDOBJECTUSERDUTYVIEW
    ", where_sql, "
    ORDER BY USER_, DUTYIDENTIFIER
  ")) |>
    tibble::as_tibble()
}
