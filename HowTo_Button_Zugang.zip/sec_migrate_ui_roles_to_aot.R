#' Benutzer-Rollenzuweisungen von UI-Rollen auf AOT-Rollen umstellen
#'
#' Liest alle aktuellen Benutzer-Rollenzuweisungen aus der Datenbank,
#' ersetzt UI-Rollen-IDs (GUIDs) durch die entsprechenden AOT-Rollen-Identifier
#' anhand eines vorhandenen Mappings und gibt das Ergebnis im D365-Importformat
#' zurück — optional als Excel-Datei.
#'
#' @details
#'
#' **Hintergrund**
#'
#' In D365FO entstehen Sicherheitsrollen auf zwei Wegen:
#'
#' \itemize{
#'   \item \strong{AOT-Rollen}: Technisch im Anwendungsmodell definiert,
#'         mit lesbarem AOTNAME als Identifier.
#'   \item \strong{UI-Rollen}: Über die Benutzeroberfläche erstellt oder
#'         kopiert; ihr technischer Identifier ist eine GUID.
#' }
#'
#' Bei Migrationen zwischen Umgebungen kann es vorkommen, dass Benutzer
#' einer UI-Rolle zugeordnet sind, während in der Zielumgebung die
#' entsprechende AOT-Rolle verwendet werden soll. Die fachlichen
#' Berechtigungen bleiben dabei unverändert — nur die technischen
#' Rollenreferenzen werden umgestellt.
#'
#' **Ablauf**
#'
#' \enumerate{
#'   \item Aktuelle Benutzer-Rollenzuweisungen aus der Datenbank lesen
#'         (\code{get_sql_user_role_assignments()}).
#'   \item Zuweisungen mit dem Mapping verknüpfen:
#'         \code{SECURITYROLEIDENTIFIER} (GUID) = \code{CONFIDENT}.
#'   \item UI-Rollen-GUID durch \code{DEVIDENT} (AOT-AOTNAME) ersetzen.
#'   \item Organisatorische Zuordnungen unverändert übernehmen.
#'   \item Nicht zuordenbare Zuweisungen separat ausweisen.
#' }
#'
#' **Mapping-Tabelle**
#'
#' Das \code{mapping}-Argument wird typischerweise wie folgt erzeugt:
#'
#' \preformatted{
#' mapping_full <- load_role_mapping(con)
#' mapping <- dplyr::filter(
#'   mapping_full,
#'   !is.na(CONFIDENT),
#'   !is.na(DEVIDENT)
#' )
#' }
#'
#' Erwartete Spalten: \code{CONFIDENT} (UI-GUID), \code{CONFROLE},
#' \code{DEVIDENT} (AOT-AOTNAME), \code{DEVROLE}.
#'
#' @param con
#' Datenbankverbindung. Ergebnis von \code{get_connection()}.
#'
#' @param mapping
#' Tibble mit dem Mapping UI-Rolle → AOT-Rolle.
#' Typischerweise gefiltertes Ergebnis von \code{load_role_mapping()}.
#' Muss die Spalten \code{CONFIDENT}, \code{DEVIDENT} und \code{DEVROLE}
#' enthalten.
#'
#' @param user_ids
#' Optionaler Character-Vektor mit Benutzer-IDs.
#' \code{NULL} = alle Benutzer.
#'
#' @param output_file
#' Optionaler Dateipfad (\code{.xlsx}) für den Excel-Export.
#' \code{NULL} = kein Export.
#'
#' @return
#'
#' Benannte Liste mit zwei Tibbles:
#'
#' \describe{
#'   \item{\code{$export}}{
#'     Zuweisungen mit AOT-Rollen — bereit für den D365-Import.
#'
#'     Spalten: \code{USERID}, \code{SECURITYROLEIDENTIFIER} (AOT-AOTNAME),
#'     \code{SECURITYROLENAME}, \code{ORGANIZATIONID}.
#'   }
#'   \item{\code{$unmatched}}{
#'     Zuweisungen, für die kein Mapping gefunden wurde.
#'     Diese müssen manuell geprüft werden.
#'
#'     Spalten: wie \code{get_sql_user_role_assignments()}.
#'   }
#' }
#'
#' Wenn \code{output_file} angegeben ist, wird eine Excel-Datei mit
#' zwei Blättern erzeugt:
#' \code{"D365 Import"} und \code{"Unmatched (pruefen)"}.
#'
#' @examples
#' \dontrun{
#'
#' cnn <- get_connection("PRJ", "db_credentials.xlsx")
#'
#' # Mapping laden
#' mapping <- load_role_mapping(cnn) |>
#'   dplyr::filter(!is.na(CONFIDENT), !is.na(DEVIDENT))
#'
#' # Migration aller Benutzer
#' ergebnis <- sec_migrate_ui_roles_to_aot(cnn, mapping)
#' ergebnis$export     # bereit für D365-Import
#' ergebnis$unmatched  # nicht zuordenbar → manuelle Prüfung
#'
#' # Nur bestimmte Benutzer, direkt als Excel exportieren
#' sec_migrate_ui_roles_to_aot(
#'   con         = cnn,
#'   mapping     = mapping,
#'   user_ids    = c("wibule01", "wibule02"),
#'   output_file = "C:/Output/migration_export.xlsx"
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{load_role_mapping}}
#' \code{\link{get_sql_user_role_assignments}}
#'
#' @export
sec_migrate_ui_roles_to_aot <- function(
  con,
  mapping,
  user_ids    = NULL,
  output_file = NULL
) {

  #====================================================
  # Aktuelle Zuweisungen aus DB
  #====================================================
  assignments <- get_sql_user_role_assignments(con, user_ids = user_ids)

  #====================================================
  # Zuordnung UI → AOT per Mapping
  #====================================================
  mapping_slim <- mapping |>
    dplyr::select(CONFIDENT, DEVIDENT, DEVROLE) |>
    dplyr::distinct()

  export <- assignments |>
    dplyr::inner_join(
      mapping_slim,
      by = c("SECURITYROLEIDENTIFIER" = "CONFIDENT")
    ) |>
    dplyr::transmute(
      USERID,
      SECURITYROLEIDENTIFIER = DEVIDENT,
      SECURITYROLENAME       = DEVROLE,
      ORGANIZATIONID
    ) |>
    dplyr::distinct() |>
    dplyr::arrange(USERID, SECURITYROLEIDENTIFIER, ORGANIZATIONID)

  #====================================================
  # Nicht zuordenbare Zuweisungen
  #====================================================
  unmatched <- assignments |>
    dplyr::anti_join(
      mapping_slim,
      by = c("SECURITYROLEIDENTIFIER" = "CONFIDENT")
    ) |>
    dplyr::arrange(USERID, SECURITYROLEIDENTIFIER)

  #====================================================
  # Optional: Excel-Export
  #====================================================
  if (!is.null(output_file)) {
    writexl::write_xlsx(
      list(
        `D365 Import`             = export,
        `Unmatched (pruefen)`     = unmatched
      ),
      output_file
    )
    message(
      "Export gespeichert: ", output_file, "\n",
      "  Zeilen Export:     ", nrow(export), "\n",
      "  Zeilen Unmatched:  ", nrow(unmatched)
    )
  }

  list(
    export    = export,
    unmatched = unmatched
  )
}
