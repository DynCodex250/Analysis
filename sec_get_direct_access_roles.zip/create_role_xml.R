#' Neue D365FO-Rollen-XML von Grund auf erstellen
#'
#' Erstellt eine valide \code{AxSecurityRole}-XML-Datei für den AOT-Import —
#' ohne Vorlage, ausschließlich aus den angegebenen Parametern.
#'
#' @details
#'
#' **Gegenstück zu \code{clone_role_without()}}**
#'
#' \describe{
#'   \item{\code{clone_role_without()}}{Startet von einer bestehenden XML,
#'     entfernt Duties/Privileges.}
#'   \item{\code{create_role_xml()}}{Startet von null, fügt Duties/Privileges
#'     gezielt hinzu.}
#' }
#'
#' **Typischer Anwendungsfall: Rollenteilung**
#'
#' Nach dem Ausführen von \code{get_duty_license_breakdown()} sind die Duties
#' nach Lizenzkategorie klassifiziert. \code{create_role_xml()} erzeugt für
#' jede Lizenzkategorie eine eigene Rolle:
#'
#' \preformatted{
#' breakdown <- get_duty_license_breakdown(cnn, "WIBU_VERKAUF_INNENDIENST")
#'
#' create_role_xml(
#'   new_name  = "_WIBU_Verkauf_Innendienst_Mitarbeiter_Activity",
#'   new_label = "_WIBU Verkauf Innendienst Mitarbeiter Activity",
#'   duties    = breakdown |>
#'     dplyr::filter(LICENSE_CATEGORY == "Activity") |>
#'     dplyr::pull(DUTYIDENTIFIER),
#'   output_dir = "output/SecurityRole"
#' )
#' }
#'
#' **Erzeugte XML-Struktur**
#'
#' \preformatted{
#' <AxSecurityRole>
#'   <Name>_WIBU_Verkauf_Innendienst_Mitarbeiter_Activity</Name>
#'   <Label>_WIBU Verkauf Innendienst Mitarbeiter Activity</Label>
#'   <Description>...</Description>
#'   <Duties>
#'     <AxSecurityDutyReference><Name>SalesDuty</Name></AxSecurityDutyReference>
#'   </Duties>
#'   <Privileges>
#'     <AxSecurityPrivilegeReference><Name>DirectPriv</Name>...</AxSecurityPrivilegeReference>
#'   </Privileges>
#'   <SubRoles>
#'     <AxSecurityRoleReference><Name>SubRole</Name></AxSecurityRoleReference>
#'   </SubRoles>
#' </AxSecurityRole>
#' }
#'
#' @param new_name
#' AOT-Name der neuen Rolle. Darf keine Leerzeichen enthalten (wird als
#' Dateiname und als \code{<Name>}-Element verwendet).
#'
#' @param new_label
#' Anzeigename der Rolle (\code{<Label>}-Element). Wird von
#' \code{sec_swap_role_assignments()} und der D365-UI als Rollenname angezeigt.
#'
#' @param description
#' Optionale Beschreibung (\code{<Description>}-Element). Standard: \code{""}.
#'
#' @param duties
#' Character-Vektor mit AOT-Namen der Duties, die in die Rolle aufgenommen
#' werden sollen. Leerer Vektor = keine Duty.
#'
#' @param privileges
#' Character-Vektor mit AOT-Namen der Privileges, die der Rolle **direkt**
#' (ohne Duty-Umweg) zugewiesen werden. Leerer Vektor = kein direktes Privilege.
#'
#' @param subroles
#' Character-Vektor mit AOT-Namen der Subrollen. Leerer Vektor = keine Subrolle.
#'
#' @param output_dir
#' Ausgabeverzeichnis. Wird angelegt, falls nicht vorhanden.
#'
#' @return
#' Unsichtbar: vollständiger Pfad der geschriebenen XML-Datei.
#'
#' @examples
#' \dontrun{
#'
#' cnn <- get_connection("PRJ", "db_credentials.xlsx")
#'
#' # Schritt 1: Lizenz-Breakdown der bestehenden Rolle
#' breakdown <- get_duty_license_breakdown(
#'   cnn,
#'   "_WIBU_VERKAUF_INNENDIENST_MITARBEITER"
#' )
#'
#' out <- "_WIBU Verkauf Innendienst Mitarbeiter/SecurityRole"
#'
#' # Schritt 2: Drei neue Rollen erzeugen
#' create_role_xml(
#'   new_name   = "_WIBU_Verkauf_Innendienst_Mitarbeiter_Activity",
#'   new_label  = "_WIBU Verkauf Innendienst Mitarbeiter Activity",
#'   duties     = breakdown |>
#'     dplyr::filter(LICENSE_CATEGORY == "Activity") |>
#'     dplyr::pull(DUTYIDENTIFIER),
#'   output_dir = out
#' )
#'
#' create_role_xml(
#'   new_name   = "_WIBU_Verkauf_Innendienst_Mitarbeiter_SCM",
#'   new_label  = "_WIBU Verkauf Innendienst Mitarbeiter SCM",
#'   duties     = breakdown |>
#'     dplyr::filter(LICENSE_CATEGORY == "Finance/SCM") |>
#'     dplyr::pull(DUTYIDENTIFIER),
#'   output_dir = out
#' )
#'
#' create_role_xml(
#'   new_name   = "_WIBU_Verkauf_Innendienst_Mitarbeiter_Commerce",
#'   new_label  = "_WIBU Verkauf Innendienst Mitarbeiter Commerce",
#'   duties     = breakdown |>
#'     dplyr::filter(LICENSE_CATEGORY == "Commerce") |>
#'     dplyr::pull(DUTYIDENTIFIER),
#'   output_dir = out
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{clone_role_without}}
#' \code{\link{get_duty_license_breakdown}}
#' \code{\link{write_duties}}
#' \code{\link{write_subroles}}
#'
#' @export
create_role_xml <- function(
  new_name,
  new_label,
  description = "",
  duties      = character(),
  privileges  = character(),
  subroles    = character(),
  output_dir
) {

  #====================================================
  # Validierung
  #====================================================
  if (grepl("[[:space:]]", new_name)) {
    stop(
      "'new_name' darf keine Leerzeichen enthalten (AOT-Name): '", new_name, "'\n",
      "Tipp: gsub(\"[[:space:]]+\", \"_\", new_label) als new_name verwenden."
    )
  }

  #====================================================
  # XML-Wurzel anlegen
  #====================================================
  doc  <- xml2::xml_new_root("AxSecurityRole")
  root <- xml2::xml_root(doc)

  xml2::xml_add_child(root, "Name",        new_name)
  xml2::xml_add_child(root, "Label",       new_label)
  xml2::xml_add_child(root, "Description", description)

  #====================================================
  # Duties, Privileges, Subroles hinzufügen
  #====================================================
  write_duties(root, duties)
  .write_privileges(root, privileges)
  write_subroles(root, subroles)

  #====================================================
  # XML schreiben
  #====================================================
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }

  output_path <- file.path(output_dir, paste0(new_name, ".xml"))
  xml2::write_xml(doc, output_path, options = "format")

  message(
    "Rolle erstellt: ", output_path, "\n",
    "  AOT-Name:    ", new_name,       "\n",
    "  Anzeigename: ", new_label,      "\n",
    "  Duties:      ", length(duties),     "\n",
    "  Privileges:  ", length(privileges), "\n",
    "  SubRoles:    ", length(subroles)
  )

  invisible(output_path)
}

# Interner Helper — analog zu write_duties() / write_subroles()
.write_privileges <- function(parent_node, privileges) {
  priv_node <- xml2::xml_add_child(parent_node, "Privileges")
  if (length(privileges) == 0L) return(invisible(priv_node))
  for (p in privileges) {
    ref <- xml2::xml_add_child(priv_node, "AxSecurityPrivilegeReference")
    xml2::xml_add_child(ref, "Name", p)
  }
  invisible(priv_node)
}
