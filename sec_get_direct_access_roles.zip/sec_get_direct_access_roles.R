#' Direkte und indirekte Zugangsrollen aus einer Sicherheitshierarchie
#'
#' Teilt das Ergebnis von \code{get_sql_security_hierarchy()} in zwei
#' Listen auf:
#'
#' \itemize{
#'   \item \strong{direkt}: Rollen (oder Subrollen), die den Zugang zu einer
#'         Ressource ohne einen weiteren Subrollen-Umweg gewähren.
#'   \item \strong{via_subrole}: Rollen, die den Zugang ausschließlich über
#'         eine Subrolle erben.
#' }
#'
#' @details
#'
#' Die Funktion wertet die Spalte \code{SUBROLEIDENTIFIER} aus:
#'
#' \strong{Direkt (\code{$direkt})}
#'
#' Eine Zeile gilt als direkter Zugang, wenn \code{SUBROLEIDENTIFIER} leer
#' ist (\code{NA}). In diesem Fall ist der \code{ROLEIDENTIFIER} der
#' unmittelbare Träger des Zugangs — unabhängig davon, ob der Zugang über
#' eine Duty oder direkt über ein Privilege kommt.
#'
#' Ist \code{SUBROLEIDENTIFIER} belegt, wird die Subrolle selbst als
#' direkter Träger gewertet und unter ihrem eigenen \code{ROLEIDENTIFIER}
#' aufgeführt. Die übergeordnete Rolle erscheint in diesem Fall
#' \emph{nicht} in \code{$direkt}.
#'
#' Mögliche Pfade im \code{$direkt}-Ergebnis:
#'
#' \preformatted{
#' Rolle → Duty → Privilege → Resource   (DUTYIDENTIFIER belegt)
#' Rolle → Privilege → Resource           (DUTYIDENTIFIER = NA)
#' Subrolle → Duty → Privilege → Resource (aus Zeilen mit Subrole)
#' }
#'
#' \strong{Indirekt (\code{$via_subrole})}
#'
#' Enthält alle Zeilen, bei denen \code{SUBROLEIDENTIFIER} belegt ist.
#' Zeigt den vollständigen Pfad:
#'
#' \preformatted{
#' Rolle → Subrolle → Duty → Privilege → Resource
#' }
#'
#' Diese Liste dient zur Information: sie zeigt, welche übergeordneten
#' Rollen den Zugang nur indirekt — über eine Subrolle — erhalten.
#' Für eine Rollenzuweisung an Kollegen sind diese Rollen in der Regel
#' nicht geeignet, da die Subrolle der engere und direktere Zugang ist.
#'
#' @param hierarchie
#' Tibble. Ergebnis von \code{get_sql_security_hierarchy()}.
#'
#' Erwartete Spalten:
#' \code{ROLEIDENTIFIER}, \code{ROLENAME},
#' \code{SUBROLEIDENTIFIER}, \code{SUBROLENAME},
#' \code{DUTYIDENTIFIER}, \code{PRIVILEGEIDENTIFIER}, \code{RESOURCE_}.
#'
#' @return
#'
#' Benannte Liste mit zwei Tibbles:
#'
#' \describe{
#'   \item{\code{$direkt}}{
#'     Direkter Zugang — eine Zeile pro eindeutiger Kombination aus
#'     Rolle, Duty (optional), Privilege und Ressource.
#'
#'     Spalten:
#'     \code{ROLEIDENTIFIER}, \code{ROLENAME},
#'     \code{DUTYIDENTIFIER}, \code{PRIVILEGEIDENTIFIER}, \code{RESOURCE_}.
#'   }
#'   \item{\code{$via_subrole}}{
#'     Indirekter Zugang über Subrolle — eine Zeile pro eindeutiger
#'     Kombination aus Rolle, Subrolle, Duty, Privilege und Ressource.
#'
#'     Spalten:
#'     \code{ROLEIDENTIFIER}, \code{ROLENAME},
#'     \code{SUBROLEIDENTIFIER}, \code{SUBROLENAME},
#'     \code{DUTYIDENTIFIER}, \code{PRIVILEGEIDENTIFIER}, \code{RESOURCE_}.
#'   }
#' }
#'
#' @examples
#' \dontrun{
#'
#' cnn <- get_connection("PRJ", "db_credentials.xlsx")
#'
#' # --- Anwendungsfall 1: Zugang zu einem Button/Menüpunkt analysieren -------
#' button     <- "VendEditInvoiceArrangeDropDialog"
#' hierarchie <- get_sql_security_hierarchy(cnn, resources = button)
#'
#' zugang <- sec_get_direct_access_roles(hierarchie)
#'
#' # Rollen/Subrollen mit direktem Zugang
#' zugang$direkt
#'
#' # Rollen die den Zugang nur über eine Subrolle erben
#' zugang$via_subrole
#'
#' # Nur die Rollennamen der direkten Träger
#' zugang$direkt |> dplyr::distinct(ROLEIDENTIFIER, ROLENAME)
#'
#' # --- Anwendungsfall 2: Duty-Zentralisierung --------------------------------
#' # Alle Rollen ermitteln, die eine bestimmte Duty enthalten
#' duty_aot   <- "CustCustomersMaintain"
#' hierarchie <- get_sql_security_hierarchy(cnn, duty_identifiers = duty_aot)
#'
#' zugang <- sec_get_direct_access_roles(hierarchie)
#'
#' # Standardrollen, die die Duty direkt tragen → müssen geklont werden
#' zugang$direkt |>
#'   dplyr::filter(!grepl("wibu", ROLENAME, ignore.case = TRUE)) |>
#'   dplyr::distinct(ROLEIDENTIFIER, ROLENAME)
#'
#' # WIBU-Rollen, die die Duty über eine Standardrolle-Subrolle erben
#' zugang$via_subrole |>
#'   dplyr::filter(grepl("wibu", ROLENAME, ignore.case = TRUE)) |>
#'   dplyr::distinct(ROLEIDENTIFIER, ROLENAME, SUBROLEIDENTIFIER, SUBROLENAME)
#'
#' }
#'
#' @seealso
#' \code{\link{get_sql_security_hierarchy}}
#' \code{\link{get_role_license_assignments_compact}}
#' \code{\link{get_duty_mapping_template}}
#' \code{\link{clone_role_without}}
#'
#' @export
sec_get_direct_access_roles <- function(hierarchie) {

  direkt <- dplyr::bind_rows(
    hierarchie |>
      dplyr::filter(is.na(SUBROLEIDENTIFIER)) |>
      dplyr::transmute(
        ROLEIDENTIFIER,
        ROLENAME,
        DUTYIDENTIFIER,
        PRIVILEGEIDENTIFIER,
        RESOURCE_
      ),
    hierarchie |>
      dplyr::filter(!is.na(SUBROLEIDENTIFIER)) |>
      dplyr::transmute(
        ROLEIDENTIFIER      = SUBROLEIDENTIFIER,
        ROLENAME            = SUBROLENAME,
        DUTYIDENTIFIER,
        PRIVILEGEIDENTIFIER,
        RESOURCE_
      )
  ) |>
    dplyr::distinct() |>
    dplyr::arrange(ROLEIDENTIFIER, DUTYIDENTIFIER, PRIVILEGEIDENTIFIER)

  via_subrole <- hierarchie |>
    dplyr::filter(!(is.na(SUBROLEIDENTIFIER) | SUBROLEIDENTIFIER == "")) |>
    dplyr::distinct(
      ROLEIDENTIFIER,
      ROLENAME,
      SUBROLEIDENTIFIER,
      SUBROLENAME,
      DUTYIDENTIFIER,
      PRIVILEGEIDENTIFIER,
      RESOURCE_
    ) |>
    dplyr::arrange(ROLEIDENTIFIER, SUBROLEIDENTIFIER, DUTYIDENTIFIER)

  list(
    direkt      = direkt,
    via_subrole = via_subrole
  )
}
