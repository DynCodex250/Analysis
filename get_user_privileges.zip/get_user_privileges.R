#' Privileges eines Benutzers auslesen
#'
#' Gibt alle Privileges zurück, die einem Benutzer in D365FO zugewiesen sind —
#' direkt aus \code{USERSECGOVRELATEDOBJECTUSERPRIVILEGEVIEW}.
#'
#' @details
#'
#' Die View liefert die effektiven Privileges, die ein Benutzer
#' (über seine Rollenzuweisungen) erhält. Es gibt keine direkte
#' Verbindung zu Lizenzinformationen; für Lizenzanalysen
#' siehe \code{get_privilege_license_map()}.
#'
#' @param con
#' Datenbankverbindung. Ergebnis von \code{get_connection()}.
#'
#' @param user_ids
#' Optionaler Character-Vektor mit Benutzer-IDs.
#' \code{NULL} = alle Benutzer.
#'
#' @param privilege_identifiers
#' Optionaler Character-Vektor mit Privilege-AOTNAMEs (\code{PRIVILEGEIDENTIFIER}).
#' \code{NULL} = alle Privileges.
#'
#' @return
#'
#' Tibble mit einer Zeile pro Benutzer-Privilege-Kombination.
#'
#' \describe{
#'   \item{USERNAME}{Benutzerkennung.}
#'   \item{PRIVILEGEIDENTIFIER}{AOT-Name des Privilege.}
#'   \item{PRIVILEGENAME}{Anzeigename des Privilege.}
#' }
#'
#' @examples
#' \dontrun{
#'
#' cnn <- get_connection("PRJ", "db_credentials.xlsx")
#'
#' # Alle Privileges aller Benutzer
#' get_user_privileges(cnn)
#'
#' # Privileges eines bestimmten Benutzers
#' get_user_privileges(cnn, user_ids = "wibule01")
#'
#' # Privileges zweier Benutzer vergleichen
#' get_user_privileges(cnn, user_ids = c("wibule01", "wibule02"))
#'
#' # Nur bestimmte Privileges (alle Benutzer)
#' get_user_privileges(cnn, privilege_identifiers = "VENDEDITINVOICE")
#'
#' # Kombination: hat dieser Benutzer dieses Privilege?
#' get_user_privileges(cnn, user_ids = "wibule01", privilege_identifiers = "VENDEDITINVOICE")
#'
#' }
#'
#' @seealso
#' \code{\link{get_user_duties}}
#' \code{\link{get_privilege_license_map}}
#' \code{\link{get_user_licenses_by_role}}
#'
#' @export
get_user_privileges <- function(
  con,
  user_ids              = NULL,
  privilege_identifiers = NULL
) {

  clauses <- character(0)

  if (!is.null(user_ids) && length(user_ids) > 0L) {
    quoted  <- paste0("'", gsub("'", "''", user_ids), "'", collapse = ", ")
    clauses <- c(clauses, paste0("USERNAME IN (", quoted, ")"))
  }

  if (!is.null(privilege_identifiers) && length(privilege_identifiers) > 0L) {
    quoted  <- paste0("'", gsub("'", "''", privilege_identifiers), "'", collapse = ", ")
    clauses <- c(clauses, paste0("PRIVILEGEIDENTIFIER IN (", quoted, ")"))
  }

  where_sql <- if (length(clauses) > 0L) {
    paste("WHERE", paste(clauses, collapse = " AND "))
  } else {
    ""
  }

  DBI::dbGetQuery(con, paste0("
    SELECT
      USERNAME,
      PRIVILEGEIDENTIFIER,
      PRIVILEGENAME
    FROM USERSECGOVRELATEDOBJECTUSERPRIVILEGEVIEW
    ", where_sql, "
    ORDER BY USERNAME, PRIVILEGEIDENTIFIER
  ")) |>
    tibble::as_tibble()
}
