#' Lizenzen je Rolle auslesen
#'
#' Liest die Lizenz-SKU-Zuordnungen je Rolle direkt aus
#' \code{LICENSINGROLELICENSEASSIGNMENTS} — unabhängig davon,
#' ob die Rolle aktuell einem Benutzer zugewiesen ist.
#'
#' @details
#'
#' Im Unterschied zu \code{get_user_licenses_by_role()}, das auf der
#' benutzerspezifischen Sicht \code{LICENSINGUSERLICENSESBYROLE} basiert,
#' arbeitet diese Funktion direkt auf der Rollentabelle.
#' Sie liefert auch für Rollen Ergebnisse, die noch keinem Benutzer
#' zugewiesen wurden.
#'
#' @param con
#' Datenbankverbindung. Ergebnis von \code{get_connection()}.
#'
#' @param role_identifiers
#' Optionaler Character-Vektor mit Rollen-AOTNAMEs (\code{AOTNAME}).
#' Wenn leer, werden alle Rollen zurückgegeben.
#'
#' @return
#'
#' Tibble mit einer Zeile pro Rollen-SKU-Kombination.
#'
#' \describe{
#'   \item{ROLEIDENTIFIER}{AOT-Name der Rolle (\code{AOTNAME}).}
#'   \item{SECURITYROLENAME}{Anzeigename der Rolle.}
#'   \item{SKURECID}{Interne Lizenz-ID.}
#'   \item{SKUNAME}{Name der Lizenz (z.B. \code{"Finance"}, \code{"Team Members"}).}
#'   \item{SKUGROUP}{Lizenzgruppe.}
#' }
#'
#' Ein leeres Tibble (0 Zeilen) bedeutet, dass für die Rolle keine
#' Lizenzinformation hinterlegt ist — die Rolle gilt als lizenzfrei.
#' \code{sec_check_license_impact()} wertet diesen Fall als
#' \code{license_change = "none"}.
#'
#' @examples
#' \dontrun{
#'
#' cnn <- get_connection("PRJ", "db_credentials.xlsx")
#'
#' # Alle Rollen mit ihren Lizenzen
#' get_role_license_assignments(cnn)
#'
#' # Nur eine bestimmte Rolle
#' get_role_license_assignments(cnn, role_identifiers = "_WIBU_VERKAUF_KEYACCOUNT")
#'
#' # Mehrere Rollen vergleichen
#' get_role_license_assignments(
#'   cnn,
#'   role_identifiers = c("_WIBU_VERKAUF_KEYACCOUNT", "_WIBU_EINKAUF_MITARBEITER")
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{get_user_licenses_by_role}}
#' \code{\link{sec_check_license_impact}}
#'
#' @export
get_role_license_assignments <- function(
  con,
  role_identifiers = character()
) {

  query <- "
SELECT DISTINCT
  sr.AOTNAME        AS ROLEIDENTIFIER,
  sr.NAME           AS SECURITYROLENAME,
  lrla.SKURECID,
  lask.SKUNAME,
  lask.SKUGROUP
FROM  LICENSINGROLELICENSEASSIGNMENTS lrla
LEFT JOIN SECURITYROLE     sr   ON sr.RECID   = lrla.SECURITYROLE
LEFT JOIN LicensingAllSkus lask ON lask.RECID = lrla.SKURECID
WHERE 1 = 1
"

  if (length(role_identifiers) > 0L) {
    quoted <- paste0("'", gsub("'", "''", role_identifiers), "'", collapse = ", ")
    query  <- paste0(query, "\nAND sr.AOTNAME IN (", quoted, ")")
  }

  query <- paste0(query, "\nORDER BY sr.AOTNAME, lask.SKUNAME")

  result <- DBI::dbGetQuery(con, query) |>
    tibble::as_tibble()

  if (nrow(result) == 0L) {
    return(tibble::tibble(
      ROLEIDENTIFIER   = character(),
      SECURITYROLENAME = character(),
      SKURECID         = integer(),
      SKUNAME          = character(),
      SKUGROUP         = character()
    ))
  }

  result
}
