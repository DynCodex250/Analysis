# =============================================================================
# R/analyze_users_consolidated.R
# Brief sections G, H, 7: user<->role assignment, service-role logic, and the
# final consolidated per-user profile (User Report).
# =============================================================================

#' Extract a User -> Role assignment table from the security governance
#' backbone (USERSECGOVRELATEDOBJECTS). If no USERID-equivalent column can be
#' identified, returns an empty frame with status UNKNOWN rather than
#' guessing - user/role assignment is typically also available via the
#' "Security User Role Association" data entity as a fallback source; wiring
#' that entity up is left as a documented extension point (see README).
analyze_user_roles <- function(sec_structure) {
  user_col <- names(sec_structure)[toupper(names(sec_structure)) %in% c("USERID", "USER", "SID")][1]
  role_col <- names(sec_structure)[toupper(names(sec_structure)) == "ROLENAME"][1]

  if (is.na(user_col) || is.na(role_col)) {
    log_warn("analyze_users_consolidated", paste0(
              "no user-role linkage column found in USERSECGOVRELATEDOBJECTS; ",
              "fall back to the 'Security User Role Association' data entity (REQUIRES_VALIDATION)"))
    res <- data.frame(user_id = character(), role = character())
    attr(res, "status") <- "UNKNOWN_NO_USER_ROLE_LINK"
    return(res)
  }

  out <- unique(sec_structure[, c(user_col, role_col)])
  names(out) <- c("user_id", "role")
  attr(out, "status") <- "OK"
  out
}

#' Classify a user's roles into service vs business roles, per config.
#' Implements the rule from the source document (section 5):
#'   - Service roles only            -> no license required (per doc, NOT
#'                                       verified against Microsoft licensing
#'                                       documentation - flagged accordingly)
#'   - Business role + Service role  -> license required
#'   - System Administrator          -> special case, always license-relevant
#'
#' @return data.frame(user_id, service_roles, business_roles,
#'   role_combination_class, is_system_administrator)
classify_service_vs_business_roles <- function(user_roles, cfg) {
  service_roles <- cfg$licensing$service_roles
  admin_roles <- cfg$licensing$admin_role_exceptions

  users <- unique(user_roles$user_id)
  rows <- lapply(users, function(u) {
    roles <- user_roles$role[user_roles$user_id == u]
    is_service <- roles %in% service_roles
    is_admin <- roles %in% admin_roles

    n_service <- sum(is_service)
    n_business <- sum(!is_service & !is_admin)

    role_class <- if (any(is_admin)) {
      "SYSTEM_ADMINISTRATOR_SPECIAL_CASE"
    } else if (n_service > 0 && n_business == 0) {
      "SERVICE_ROLES_ONLY_PER_DOC_NO_LICENSE_REQUIRES_VALIDATION"
    } else if (n_service > 0 && n_business > 0) {
      "BUSINESS_PLUS_SERVICE_ROLE_LICENSE_LIKELY_REQUIRES_VALIDATION"
    } else if (n_business > 0) {
      "BUSINESS_ROLES_ONLY"
    } else {
      "NO_ROLES"
    }

    data.frame(
      user_id = u,
      service_roles = paste(roles[is_service], collapse = "; "),
      business_roles = paste(roles[!is_service & !is_admin], collapse = "; "),
      role_combination_class = role_class,
      is_system_administrator = any(is_admin),
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

#' build_user_profiles(): the single consolidated per-user view (brief
#' section 7). This function only ASSEMBLES data already produced by other
#' analyze_*() functions - it must not introduce new business rules; those
#' belong in R/findings_engine.R.
#'
#' @return data.frame, one row per user (User Report base, before findings
#'   text/confidence are attached by the findings engine)
build_user_profiles <- function(user_base, user_role_class, telemetry_touches,
                                  transaction_activity, cfg) {
  out <- user_base

  out <- merge(out, user_role_class, by.x = "ID", by.y = "user_id", all.x = TRUE)

  telem_status <- attr(telemetry_touches, "status")
  if (is.null(telem_status)) telem_status <- "OK"

  if (telem_status %in% c("OK", "OK_EMPTY") && nrow(telemetry_touches) > 0 &&
      "user_Id" %in% names(telemetry_touches)) {
    agg <- stats::aggregate(
      touches ~ user_Id, data = telemetry_touches,
      FUN = function(x) sum(as.numeric(x))
    )
    names(agg) <- c("user_id", "telemetry_touches_total")
    last_seen_agg <- stats::aggregate(
      last_seen ~ user_Id, data = telemetry_touches, FUN = max
    )
    names(last_seen_agg) <- c("user_id", "last_telemetry_activity")

    out <- merge(out, agg, by.x = "ID", by.y = "user_id", all.x = TRUE)
    out <- merge(out, last_seen_agg, by.x = "ID", by.y = "user_id", all.x = TRUE)
  } else {
    out$telemetry_touches_total <- NA
    out$last_telemetry_activity <- NA
  }
  out$telemetry_status <- telem_status

  out$has_transaction_activity <- vapply(
    out$ID, has_transaction_activity, character(1),
    transaction_df = transaction_activity
  )

  # Activity classification NEVER collapses "no telemetry" into "inactive"
  # (brief section 11). Three explicit states instead of a boolean.
  out$activity_evidence_status <- mapply(function(touches, tx_status) {
    has_telemetry <- !is.na(touches) && touches > 0
    if (has_telemetry) return("ACTIVITY_OBSERVED_TELEMETRY")
    if (identical(tx_status, "TRUE") || isTRUE(tx_status)) return("ACTIVITY_OBSERVED_TRANSACTIONS")
    if (identical(tx_status, "UNKNOWN")) return("NO_TELEMETRY_TRANSACTIONS_UNKNOWN_NOT_CONFIRMED_INACTIVE")
    "NO_ACTIVITY_EVIDENCE_FOUND_NOT_CONFIRMED_INACTIVE"
  }, out$telemetry_touches_total, out$has_transaction_activity)

  out
}
