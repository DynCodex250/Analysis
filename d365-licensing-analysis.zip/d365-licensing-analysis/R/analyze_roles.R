# =============================================================================
# R/analyze_roles.R
# Brief section 6: per-role analysis (Role Report).
# Input: the joined security-structure data.frame from
# analyze_security_structure() (R/data_roles_licensing.R).
# =============================================================================

#' Identify the write/read classification of an access level string.
#' Source doc section 7 ("AccessLevel Logik"): Write = Create/Update/Delete/
#' Correct/other writing ops; everything else defaults to Read.
classify_access_level <- function(access_level) {
  if (is.na(access_level) || access_level %in% c("UNKNOWN", "")) return("UNKNOWN")
  write_values <- c("CREATE", "UPDATE", "DELETE", "CORRECT", "WRITE", "FULLCONTROL", "MODIFY")
  if (toupper(access_level) %in% write_values) "WRITE" else "READ"
}

#' analyze_role_metrics(): one row per role with structural + licensing metrics.
#'
#' @param sec_structure data.frame from analyze_security_structure()
#' @return data.frame, one row per role
analyze_role_metrics <- function(sec_structure) {
  role_col <- names(sec_structure)[toupper(names(sec_structure)) == "ROLENAME"][1]
  duty_col <- names(sec_structure)[toupper(names(sec_structure)) == "DUTYNAME"][1]
  priv_col <- names(sec_structure)[toupper(names(sec_structure)) == "PRIVILEGENAME"][1]
  ep_col   <- names(sec_structure)[toupper(names(sec_structure)) == "ENTRYPOINTNAME"][1]

  if (is.na(role_col)) stop("analyze_role_metrics: could not identify role name column")

  sec_structure$.ACCESS_CLASS <- vapply(
    sec_structure$ACCESSLEVEL %||% NA_character_, classify_access_level, character(1)
  )

  roles <- unique(sec_structure[[role_col]])

  rows <- lapply(roles, function(r) {
    sub <- sec_structure[sec_structure[[role_col]] == r, ]

    n_duties  <- if (!is.na(duty_col)) length(unique(sub[[duty_col]])) else NA_integer_
    n_privs   <- if (!is.na(priv_col)) length(unique(sub[[priv_col]])) else NA_integer_
    n_eps     <- if (!is.na(ep_col))   length(unique(sub[[ep_col]]))   else NA_integer_

    licensed_rows <- sub[!is.na(sub$ENTITLED) & sub$ENTITLED %in% c(1, "1", TRUE), ]
    sku_values <- unique(licensed_rows$SKUNAME)
    sku_values <- sku_values[!is.na(sku_values)]

    n_write <- sum(sub$.ACCESS_CLASS == "WRITE", na.rm = TRUE)
    n_read  <- sum(sub$.ACCESS_CLASS == "READ", na.rm = TRUE)
    n_unknown_access <- sum(sub$.ACCESS_CLASS == "UNKNOWN", na.rm = TRUE)

    data.frame(
      role = r,
      duty_count = n_duties,
      privilege_count = n_privs,
      entry_point_count = n_eps,
      license_relevant_entry_points = nrow(licensed_rows),
      write_entry_points = n_write,
      read_entry_points = n_read,
      unknown_access_entry_points = n_unknown_access,
      write_ratio = ifelse((n_write + n_read) > 0, n_write / (n_write + n_read), NA_real_),
      distinct_license_types = length(sku_values),
      license_skus = paste(sku_values, collapse = "; "),
      # "most expensive" cannot be derived without an authoritative SKU price
      # order, which is not present in the source data. We report the SKU
      # SET and flag it for manual ranking rather than inventing a price.
      most_expensive_license = if (length(sku_values) == 0) "NONE_FOUND"
                                 else if (length(sku_values) == 1) sku_values[1]
                                 else "REQUIRES_VALIDATION_MULTIPLE_SKUS",
      stringsAsFactors = FALSE
    )
  })

  out <- do.call(rbind, rows)

  # Oversized-role heuristic (percentile-based, used by FINDING-008).
  # Explicitly a heuristic/interpretation - never phrased as a Microsoft
  # licensing verdict (brief section 6).
  p90_duty  <- stats::quantile(out$duty_count, 0.90, na.rm = TRUE)
  p90_priv  <- stats::quantile(out$privilege_count, 0.90, na.rm = TRUE)
  p90_ep    <- stats::quantile(out$entry_point_count, 0.90, na.rm = TRUE)

  out$possibly_oversized <- with(out,
    !is.na(duty_count) & !is.na(privilege_count) & !is.na(entry_point_count) &
      duty_count >= p90_duty & privilege_count >= p90_priv & entry_point_count >= p90_ep
  )

  out
}
