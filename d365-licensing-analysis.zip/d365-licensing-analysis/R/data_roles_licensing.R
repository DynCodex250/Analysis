# =============================================================================
# R/data_roles_licensing.R
# Sections G, I, J, K of the brief: security structure (Role -> Duty ->
# Privilege -> Entry Point) and the licensing requirement / by-role views.
# =============================================================================

#' Load USERSECGOVRELATEDOBJECTS (the Role/Duty/Privilege/Entry Point/License
#' backbone). role_filter is an optional SQL LIKE pattern (NULL = all roles).
load_security_governance_objects <- function(cnn, sql_dir, role_filter = NULL) {
  run_readonly_query(
    cnn, file.path(sql_dir, "05_user_security_governance_objects.sql"),
    params = list(RoleNameFilter = role_filter)
  )
}

#' Load LICENSINGUSERLICENSESBYROLE
load_licensing_user_license_by_role <- function(cnn, sql_dir) {
  run_readonly_query(cnn, file.path(sql_dir, "04_licensing_user_license_by_role.sql"))
}

#' Load the three *_DETAILEDVIEW licensing tables
load_licensing_requirements <- function(cnn, sql_dir, entitled_only = TRUE) {
  list(
    role      = run_readonly_query(cnn, file.path(sql_dir, "06_licensing_role_requirements.sql"),
                                    params = list(EntitledOnly = entitled_only)),
    duty      = run_readonly_query(cnn, file.path(sql_dir, "07_licensing_duty_requirements.sql"),
                                    params = list(EntitledOnly = entitled_only)),
    privilege = run_readonly_query(cnn, file.path(sql_dir, "08_licensing_privilege_requirements.sql"),
                                    params = list(EntitledOnly = entitled_only))
  )
}

#' Normalize column names defensively: detailed views can vary slightly by
#' D365FO version. This helper only renames if the expected column is absent
#' and an unambiguous case-insensitive match exists; otherwise it leaves the
#' column missing and downstream code must handle NA / "UNKNOWN".
.normalize_licensing_columns <- function(df, expected = c("ENTITLED", "ACCESSLEVEL", "SKUNAME", "SECURITYROLE")) {
  for (col in expected) {
    if (!col %in% names(df)) {
      match_idx <- which(toupper(names(df)) == col)
      if (length(match_idx) == 1) names(df)[match_idx] <- col
    }
  }
  missing <- setdiff(expected, names(df))
  if (length(missing) > 0) {
    log_warn("data_roles_licensing", "expected column(s) missing, will be treated as UNKNOWN: %s",
              paste(missing, collapse = ", "))
    for (m in missing) df[[m]] <- NA
  }
  df
}

#' analyze_security_structure(): build the Role -> Duty -> Privilege ->
#' Entry Point -> Access Level -> License Requirement backbone used by all
#' downstream role/user analyses.
#'
#' Join keys are normalized (trimmed + uppercased) before matching, because
#' fixed-length CHAR columns in SQL Server frequently carry trailing padding
#' spaces on one side of the join but not the other (secgov vs. the
#' *_DETAILEDVIEW views), which silently produces zero matches with a naive
#' merge(). The ORIGINAL (non-normalized) ROLENAME from secgov is always kept
#' for display/reporting.
#'
#' IMPORTANT (environment-specific): in some D365FO versions/extracts,
#' *_DETAILEDVIEW.SECURITYROLE is a numeric RecId (foreign key), NOT the
#' role's display name - a text-to-text join then legitimately matches
#' nothing. This function detects that case and refuses to silently produce
#' all-NA license columns; instead it logs a clear diagnostic and returns the
#' unjoined structure with license columns = "UNKNOWN", so the mismatch is
#' visible in the run log rather than hidden inside NA values (brief section
#' 3: never fabricate a result when it cannot be determined).
#'
#' If your environment needs a specific join column pair, set it explicitly
#' via role_join_column_secgov / role_join_column_req (or the equivalent
#' config.yml keys under security_structure.*) instead of relying on
#' auto-detection.
#'
#' @param secgov data.frame from load_security_governance_objects()
#' @param licensing_req list(role=, duty=, privilege=) from load_licensing_requirements()
#' @param role_join_column_secgov optional explicit column name in secgov to join on
#' @param role_join_column_req optional explicit column name in licensing_req$role to join on
#' @return data.frame, one row per (role, duty, privilege, entry point) tuple
#'         with license columns attached where resolvable, else UNKNOWN.
analyze_security_structure <- function(secgov, licensing_req,
                                         role_join_column_secgov = NULL,
                                         role_join_column_req = NULL) {
  role_req <- .normalize_licensing_columns(licensing_req$role)

  # --- Determine join columns --------------------------------------------
  role_col_secgov <- role_join_column_secgov %||%
    names(secgov)[toupper(names(secgov)) == "ROLENAME"][1]
  role_col_req <- role_join_column_req %||%
    names(role_req)[toupper(names(role_req)) == "SECURITYROLE"][1]

  if (is.na(role_col_secgov) || is.na(role_col_req) ||
      is.null(role_col_secgov) || is.null(role_col_req)) {
    log_warn("data_roles_licensing",
              "could not unambiguously identify role-name join columns; returning secgov unjoined (license columns = UNKNOWN)")
    secgov$ENTITLED   <- "UNKNOWN"
    secgov$ACCESSLEVEL <- "UNKNOWN"
    secgov$SKUNAME     <- "UNKNOWN"
    return(secgov)
  }

  # --- Type-mismatch guard: a numeric RecId cannot be text-joined against a
  # display name. Auto-detect a character-typed alternative column on the
  # numeric side that looks like a role/name field, but only USE it if
  # explicit confirmation isn't required - otherwise stop with a clear error
  # rather than silently guessing at licensing-relevant joins.
  req_col_is_numeric <- is.numeric(role_req[[role_col_req]]) || inherits(role_req[[role_col_req]], "integer64")
  secgov_col_is_numeric <- is.numeric(secgov[[role_col_secgov]]) || inherits(secgov[[role_col_secgov]], "integer64")

  if (req_col_is_numeric != secgov_col_is_numeric) {
    log_error("data_roles_licensing",
               "JOIN TYPE MISMATCH: secgov$%s is %s but %s$%s is %s. A text-to-ID join can never match.",
               role_col_secgov, class(secgov[[role_col_secgov]])[1],
               "licensing_req$role", role_col_req, class(role_req[[role_col_req]])[1])

    candidate_text_cols <- names(role_req)[vapply(role_req, is.character, logical(1))]
    candidate_text_cols <- candidate_text_cols[grepl("ROLE|NAME", toupper(candidate_text_cols))]
    candidate_id_cols <- names(secgov)[vapply(secgov, function(x) is.numeric(x) || inherits(x, "integer64"), logical(1))]
    candidate_id_cols <- candidate_id_cols[grepl("ROLE|ID|RECID", toupper(candidate_id_cols))]

    log_error("data_roles_licensing",
               "Candidate text columns in requirements view that might hold the role NAME: %s",
               if (length(candidate_text_cols) > 0) paste(candidate_text_cols, collapse = ", ") else "(none found)")
    log_error("data_roles_licensing",
               "Candidate numeric ID columns in secgov that might hold a role RecId: %s",
               if (length(candidate_id_cols) > 0) paste(candidate_id_cols, collapse = ", ") else "(none found)")
    log_error("data_roles_licensing",
               "Set the correct pair explicitly, e.g. analyze_security_structure(secgov, licensing_req, ",
               "role_join_column_secgov = 'ROLERECID', role_join_column_req = 'SECURITYROLE') or in config.yml ",
               "under security_structure.role_join_column_secgov / role_join_column_req.")

    secgov$ENTITLED   <- "UNKNOWN"
    secgov$ACCESSLEVEL <- "UNKNOWN"
    secgov$SKUNAME     <- "UNKNOWN"
    return(secgov)
  }

  # Normalized join keys (trim + uppercase for text; identity for numeric).
  # Kept as hidden helper columns so the merge is robust to CHAR-padding /
  # casing differences, without altering the original display values.
  .norm_key <- function(x) {
    if (is.numeric(x) || inherits(x, "integer64")) as.character(x) else trimws(toupper(as.character(x)))
  }
  secgov$.JOINKEY   <- .norm_key(secgov[[role_col_secgov]])
  role_req$.JOINKEY <- .norm_key(role_req[[role_col_req]])

  n_secgov_keys <- length(unique(secgov$.JOINKEY))
  n_overlap <- length(intersect(unique(secgov$.JOINKEY), unique(role_req$.JOINKEY)))

  if (n_overlap == 0 && n_secgov_keys > 0) {
    log_warn("data_roles_licensing",
              "0 of %d distinct join keys in secgov matched any key in the licensing requirements view, ",
              n_secgov_keys)
    log_warn("data_roles_licensing",
              "even after normalization. Sample secgov key: '%s' | sample requirements key: '%s'. ",
              utils::head(secgov[[role_col_secgov]], 1), utils::head(role_req[[role_col_req]], 1))
    log_warn("data_roles_licensing",
              "Check whether load_licensing_requirements() was called with entitled_only=TRUE and simply ",
              "returned 0 relevant rows, or whether the join column choice itself is wrong for this environment.")
  } else if (n_overlap < n_secgov_keys) {
    log_warn("data_roles_licensing",
              "only %d of %d distinct secgov join keys matched a licensing requirement record; ",
              n_overlap, n_secgov_keys)
    log_warn("data_roles_licensing", "the remainder will show has_license_requirement_record = FALSE (see DQ-003).")
  }

  merged <- merge(
    secgov, role_req,
    by = ".JOINKEY",
    all.x = TRUE, suffixes = c("", "_LICREQ")
  )
  merged$.JOINKEY <- NULL
  if (paste0(role_col_req, "_LICREQ") %in% names(merged)) {
    merged[[paste0(role_col_req, "_LICREQ")]] <- NULL
  } else if (role_col_req %in% names(merged) && role_col_req != role_col_secgov) {
    merged[[role_col_req]] <- NULL
  }

  # Rows with no matching licensing requirement genuinely mean "not
  # licensing-relevant per this view", NOT "unknown" - but we still flag rows
  # where ENTITLED is NA (no requirement record at all) distinctly for the
  # data-quality checks (DQ-003 / DQ-004).
  merged$has_license_requirement_record <- !is.na(merged$ENTITLED)
  merged
}
