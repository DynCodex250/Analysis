# =============================================================================
# R/connection.R
# Config loading, read-only connection handling, and the SQL safety guard.
#
# IMPORTANT: This project assumes an existing `get_connection(environment,
# credentials_path)` function is already provided elsewhere in the host
# project (the source RMarkdown document calls it directly:
#   cnn <- get_connection("PRJ", "C:/.../db_credentials.xlsx")
# ). This file does NOT reimplement it. If no such function exists in the
# target project, `get_connection()` below throws a clear error rather than
# silently faking a connection - see REQUIRES_VALIDATION note in the function.
# =============================================================================

library(yaml)
library(DBI)

#' Load and merge configuration (default + optional local override)
#'
#' @param config_dir path to the config directory
#' @return a named list (the merged config)
load_config <- function(config_dir = "config") {
  base_path <- file.path(config_dir, "config.yml")
  if (!file.exists(base_path)) {
    stop("Configuration file not found: ", base_path)
  }
  cfg <- yaml::read_yaml(base_path)$default

  local_path <- file.path(config_dir, "config.local.yml")
  if (file.exists(local_path)) {
    local_cfg <- yaml::read_yaml(local_path)$default
    cfg <- modifyList(cfg, local_cfg %||% list())
  }
  cfg
}

`%||%` <- function(a, b) if (is.null(a)) b else a

#' Resolve a read-only DB connection using the project's existing
#' get_connection() function.
#'
#' @param environment logical environment name, e.g. "PRJ"
#' @param cfg the loaded config list (see load_config())
#' @return a DBI connection object
get_readonly_connection <- function(environment, cfg) {
  if (!exists("get_connection", mode = "function")) {
    stop(
      "get_connection() was not found in the current R session.\n",
      "REQUIRES_VALIDATION: this pipeline expects the host project's existing ",
      "get_connection(environment, credentials_path) function (as used in the ",
      "source RMarkdown: get_connection(\"PRJ\", \".../db_credentials.xlsx\")).\n",
      "Source it before calling run_analysis(), e.g.:\n",
      "  source(\"path/to/existing/connection_helpers.R\")\n",
      "This project intentionally does NOT reimplement get_connection() to ",
      "avoid a second, divergent connection implementation (brief section 14)."
    )
  }
  cnn <- get_connection(environment, cfg$connection$credentials_path)

  # Defensive, environment-level guard: try to open the connection read-only
  # where the driver honours it. This is a best-effort hardening layer -
  # the authoritative protection is guard_readonly_sql() below, which is
  # applied to every query text before execution regardless of driver support.
  tryCatch({
    if (methods::existsMethod("dbSendQuery", class(cnn))) {
      # no-op probe; presence check only, some drivers expose read-only pragmas
      invisible(NULL)
    }
  }, error = function(e) invisible(NULL))

  cnn
}

#' Guard: reject any SQL text containing write/DDL statements.
#' This is applied to EVERY query before it is sent to the database,
#' regardless of source (inline string or .sql file).
#'
#' @param sql_text character, the raw SQL
#' @return invisible(TRUE) if safe; stops execution otherwise
guard_readonly_sql <- function(sql_text) {
  forbidden <- c(
    "\\bINSERT\\b", "\\bUPDATE\\b", "\\bDELETE\\b", "\\bMERGE\\b",
    "\\bALTER\\b", "\\bDROP\\b", "\\bTRUNCATE\\b", "\\bCREATE\\b",
    "\\bEXEC\\b", "\\bEXECUTE\\b", "\\bGRANT\\b", "\\bREVOKE\\b",
    "\\bINTO\\s+OUTFILE\\b"
  )
  # Strip comments so keywords inside comments don't cause false positives,
  # and so keywords hidden AFTER a comment marker can't sneak past a naive
  # check either.
  stripped <- gsub("--.*$", "", sql_text)
  stripped <- gsub("/\\*.*?\\*/", "", stripped, perl = TRUE)

  hits <- vapply(forbidden, function(p) grepl(p, stripped, ignore.case = TRUE), logical(1))
  if (any(hits)) {
    stop(
      "BLOCKED: query contains a forbidden write/DDL statement (",
      paste(forbidden[hits], collapse = ", "),
      "). This pipeline is strictly read-only. Query was NOT executed."
    )
  }
  invisible(TRUE)
}

#' Read a .sql file, apply named parameter substitution, guard, and execute.
#'
#' Parameter substitution here is a simple, explicit `@Name` -> literal
#' replacement (no ORM). Callers are responsible for passing safely-formed
#' literals (e.g. quoted strings). All values used by this pipeline's own
#' functions are either NULL, config-derived, or SQL-LIKE-escaped role names -
#' never raw, unsanitized user input.
#'
#' @param cnn DBI connection (or any object with a compatible dbGetQuery)
#' @param sql_file path to a .sql file under sql/
#' @param params named list of @Name -> value substitutions (character/logical)
#' @return data.frame of results
run_readonly_query <- function(cnn, sql_file, params = list()) {
  if (!file.exists(sql_file)) stop("SQL file not found: ", sql_file)
  sql_text <- paste(readLines(sql_file, warn = FALSE), collapse = "\n")

  for (nm in names(params)) {
    val <- params[[nm]]
    literal <- if (is.null(val)) {
      "NULL"
    } else if (is.logical(val)) {
      if (isTRUE(val)) "1" else "0"
    } else if (is.numeric(val)) {
      as.character(val)
    } else {
      paste0("'", gsub("'", "''", val), "'")
    }
    sql_text <- gsub(paste0("@", nm, "\\b"), literal, sql_text)
  }

  # Any remaining @Param placeholders default to NULL (i.e. "no filter"),
  # so a query written with optional params still runs when the caller
  # omits them.
  sql_text <- gsub("@[A-Za-z_][A-Za-z0-9_]*\\b", "NULL", sql_text)

  guard_readonly_sql(sql_text)
  DBI::dbGetQuery(cnn, sql_text)
}
