# =============================================================================
# R/confidence.R
# Brief section 10: every finding gets a Confidence Level.
#   HIGH    - SQL data + Security Analysis + Telemetry all agree
#   MEDIUM  - only Security/SQL structural data supports it (no telemetry)
#   LOW     - only an assumption/heuristic supports it
#   UNKNOWN - required data is missing entirely
# =============================================================================

#' Compute a confidence level from the evidence sources actually present.
#'
#' @param has_sql_evidence logical - a direct SQL/table fact supports the claim
#' @param has_security_structure_evidence logical - Role/Duty/Privilege/EntryPoint
#'   structure supports the claim
#' @param has_telemetry_evidence logical - telemetry/KQL corroborates the claim
#' @param is_heuristic_only logical - claim rests solely on a heuristic/assumption
#' @return one of "HIGH", "MEDIUM", "LOW", "UNKNOWN"
compute_confidence <- function(has_sql_evidence = FALSE,
                                has_security_structure_evidence = FALSE,
                                has_telemetry_evidence = FALSE,
                                is_heuristic_only = FALSE) {
  if (!has_sql_evidence && !has_security_structure_evidence && !has_telemetry_evidence) {
    return("UNKNOWN")
  }
  if (is_heuristic_only) return("LOW")

  supporting <- sum(has_sql_evidence, has_security_structure_evidence, has_telemetry_evidence)
  if (supporting >= 2 && has_telemetry_evidence) return("HIGH")
  if (has_sql_evidence || has_security_structure_evidence) return("MEDIUM")
  "LOW"
}

#' Downgrade a confidence level by one step (used when telemetry coverage is
#' below the recommended window, or when a data-quality issue affects the
#' underlying join).
downgrade_confidence <- function(level) {
  order <- c("HIGH", "MEDIUM", "LOW", "UNKNOWN")
  idx <- match(level, order)
  if (is.na(idx) || idx == length(order)) return(level)
  order[idx + 1]
}
