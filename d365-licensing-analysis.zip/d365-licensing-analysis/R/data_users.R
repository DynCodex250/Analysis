# =============================================================================
# R/data_users.R
# Section A/B/C of the brief: USERINFO, SYSUSERINVALIDUSERS, SYSAADCLIENTTABLE
# All functions here only READ and RESHAPE data - no interpretation/finding
# generation happens here (that's R/findings_engine.R).
# =============================================================================

#' Load raw USERINFO (all users, active + disabled)
load_users <- function(cnn, sql_dir) {
  run_readonly_query(cnn, file.path(sql_dir, "01_users_active.sql"))
}

#' Load SYSUSERINVALIDUSERS
load_invalid_users <- function(cnn, sql_dir) {
  run_readonly_query(cnn, file.path(sql_dir, "02_users_invalid.sql"))
}

#' Load SYSAADCLIENTTABLE
load_application_users <- function(cnn, sql_dir) {
  run_readonly_query(cnn, file.path(sql_dir, "03_users_application.sql"))
}

#' analyze_users(): base user classification.
#' Produces one row per USERINFO entry with derived flags. Does NOT decide
#' license outcomes - that happens once role/telemetry data is joined in
#' R/analyze_users_consolidated.R.
#'
#' @param users data.frame from load_users()
#' @param invalid_users data.frame from load_invalid_users()
#' @param application_users data.frame from load_application_users()
#' @return data.frame with one row per USERINFO.ID
analyze_users <- function(users, invalid_users, application_users) {
  stopifnot(all(c("ID", "NETWORKALIAS", "ENABLE", "OBJECTID") %in% names(users)))

  empty_guid <- "00000000-0000-0000-0000-000000000000"

  out <- users
  out$is_active <- out$ENABLE == 1
  out$has_entra_link <- !(is.na(out$OBJECTID) | out$OBJECTID == empty_guid)
  out$is_invalid_user <- out$ID %in% invalid_users$USERID
  out$is_application_user <- out$ID %in% application_users$USERID

  # Never-logged-in heuristic per the source doc ("wenn sämtliche
  # Login-bezogenen Werte auf 0 stehen ..."): USERINFO as queried here does
  # not carry a last-login column, so this is explicitly UNKNOWN unless a
  # richer login-tracking source is wired in later - do not fabricate it.
  out$last_login_status <- "UNKNOWN"

  out$user_status_flag <- ifelse(
    out$is_active & !out$has_entra_link & !out$is_invalid_user,
    "ACTIVE_NO_ENTRA_LINK_REQUIRES_VALIDATION",
    ifelse(out$is_active & out$is_invalid_user, "ACTIVE_BUT_INVALID",
      ifelse(!out$is_active, "DISABLED", "ACTIVE_OK"))
  )

  out
}

#' analyze_invalid_users(): active users with a simultaneous invalid-user
#' entry - the direct SQL-observable equivalent of FINDING-001's evidence.
#' @return data.frame, one row per affected user
analyze_invalid_users <- function(users, invalid_users) {
  merge(
    users[users$ENABLE == 1, c("ID", "NETWORKALIAS", "ENABLE", "OBJECTID")],
    invalid_users[, c("USERID", "INVALIDITYREASON")],
    by.x = "ID", by.y = "USERID"
  )
}

#' analyze_application_users(): technical/integration accounts, WITHOUT
#' assuming they are license-free (brief section 5.C explicitly forbids that).
#' Classification of whether they behave like technical accounts is deferred
#' to the findings engine, which combines this with telemetry/transaction data.
#' @return data.frame with a placeholder classification column
analyze_application_users <- function(application_users) {
  out <- application_users
  out$classification <- "TECHNICAL_ACCOUNT_CANDIDATE"
  out$licensing_classification <- "REQUIRES_VALIDATION"  # never auto-set to license-free
  out
}
