# =============================================================================
# R/run_analysis.R
# Single entry point, per brief section 17:
#   run_analysis(environment = "PRJ")
# or from the shell:
#   Rscript run_analysis.R PRJ
# =============================================================================

.pkg_root <- function() {
  # allow sourcing this file directly regardless of working directory
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg) == 1) dirname(dirname(sub("^--file=", "", file_arg))) else getwd()
}

source_all_R <- function(root) {
  r_dir <- file.path(root, "R")
  files <- c(
    "utils_logging.R", "connection.R", "data_users.R", "data_roles_licensing.R",
    "data_telemetry.R", "data_transaction_activity.R", "analyze_roles.R",
    "analyze_users_consolidated.R", "confidence.R", "findings_engine.R",
    "reporting_excel.R", "reporting_markdown.R"
  )
  for (f in files) source(file.path(r_dir, f))
}

#' run_analysis(): full pipeline, read-only, reproducible.
#'
#' @param environment logical D365FO environment name, e.g. "PRJ"
#' @param root project root (defaults to auto-detected location of this file)
#' @return invisible list with all intermediate + final artifacts, for
#'   interactive inspection / unit testing
run_analysis <- function(environment = "PRJ", root = .pkg_root()) {
  source_all_R(root)
  reset_log()
  t0 <- Sys.time()
  log_info("run_analysis", "=== Starting D365FO Licensing & Security Analysis for %s ===", environment)

  cfg <- load_config(file.path(root, "config"))
  cfg$environment <- environment
  rules_cfg <- yaml::read_yaml(file.path(root, cfg$findings$rules_file))$rules

  sql_dir <- file.path(root, cfg$paths$sql_dir)
  kql_dir <- file.path(root, cfg$paths$kql_dir)
  reports_dir <- file.path(root, cfg$paths$reports_dir)
  if (!dir.exists(reports_dir)) dir.create(reports_dir, recursive = TRUE)

  cnn <- get_readonly_connection(environment, cfg)
  on.exit(try(DBI::dbDisconnect(cnn), silent = TRUE), add = TRUE)

  # --- Load -------------------------------------------------------------
  users_step <- run_safely("load_users", function() load_users(cnn, sql_dir))
  invalid_step <- run_safely("load_invalid_users", function() load_invalid_users(cnn, sql_dir))
  appuser_step <- run_safely("load_application_users", function() load_application_users(cnn, sql_dir))
  secgov_step <- run_safely("load_security_governance_objects", function() load_security_governance_objects(cnn, sql_dir))
  licreq_step <- run_safely("load_licensing_requirements", function() load_licensing_requirements(cnn, sql_dir))
  telemetry_step <- run_safely("load_telemetry_touches", function() load_telemetry_touches(cfg, kql_dir, environment = environment))
  txn_step <- run_safely("load_transaction_activity", function() load_transaction_activity(cnn, cfg, sql_dir))

  for (s in list(users_step, secgov_step)) {
    if (!s$ok) stop("A critical data source failed to load; aborting. See log for details.")
  }

  users <- users_step$result
  invalid_users <- if (invalid_step$ok) invalid_step$result else data.frame(USERID = character(), OBJECTID = character(), INVALIDITYREASON = character())
  application_users <- if (appuser_step$ok) appuser_step$result else data.frame(AADCLIENTID = character(), USERID = character(), NAME = character())
  secgov <- secgov_step$result
  licensing_req <- if (licreq_step$ok) licreq_step$result else list(role = data.frame(), duty = data.frame(), privilege = data.frame())
  telemetry_touches <- if (telemetry_step$ok) telemetry_step$result else { r <- data.frame(); attr(r, "status") <- "UNKNOWN"; r }
  transaction_activity <- if (txn_step$ok) txn_step$result else { r <- data.frame(); attr(r, "status") <- "UNKNOWN"; r }

  log_info("run_analysis", "loaded: users=%d, invalid=%d, app_users=%d, secgov_rows=%d",
           nrow(users), nrow(invalid_users), nrow(application_users), nrow(secgov))

  # --- Analyze ------------------------------------------------------------
  user_base <- run_safely("analyze_users", function() analyze_users(users, invalid_users, application_users))$result
  invalid_analysis <- run_safely("analyze_invalid_users", function() analyze_invalid_users(users, invalid_users))$result
  app_user_analysis <- run_safely("analyze_application_users", function() analyze_application_users(application_users))$result

  sec_structure <- run_safely("analyze_security_structure", function() {
    analyze_security_structure(
      secgov, licensing_req,
      role_join_column_secgov = cfg$security_structure$role_join_column_secgov,
      role_join_column_req = cfg$security_structure$role_join_column_req,
      entry_point_join_column_secgov = cfg$security_structure$entry_point_join_column_secgov,
      entry_point_join_column_req = cfg$security_structure$entry_point_join_column_req
    )
  })$result
  role_metrics <- run_safely("analyze_role_metrics", function() analyze_role_metrics(sec_structure))$result

  user_roles_res <- run_safely("analyze_user_roles", function() analyze_user_roles(sec_structure))
  user_roles <- if (user_roles_res$ok) user_roles_res$result else { r <- data.frame(user_id = character(), role = character()); attr(r, "status") <- "UNKNOWN"; r }
  user_role_class <- run_safely("classify_service_vs_business_roles", function() classify_service_vs_business_roles(user_roles, cfg))$result
  if (is.null(user_role_class)) user_role_class <- data.frame(user_id = character(), service_roles = character(), business_roles = character(), role_combination_class = character(), is_system_administrator = logical())

  user_profiles <- run_safely("build_user_profiles", function() {
    build_user_profiles(user_base, user_role_class, telemetry_touches, transaction_activity, cfg)
  })$result

  # --- Findings -------------------------------------------------------------
  ctx <- list(
    users = users, invalid_users_analysis = invalid_analysis, app_users_analysis = app_user_analysis,
    user_roles = user_roles, user_role_class = user_role_class, sec_structure = sec_structure,
    role_metrics = role_metrics, telemetry_touches = telemetry_touches, user_profiles = user_profiles,
    cfg = cfg
  )
  findings <- run_safely("generate_findings", function() generate_findings(ctx, rules_cfg))$result

  # --- Report -----------------------------------------------------------
  license_by_role_raw <- run_safely("load_licensing_user_license_by_role", function() load_licensing_user_license_by_role(cnn, sql_dir))
  license_by_role_df <- if (license_by_role_raw$ok) license_by_role_raw$result else data.frame()

  license_driver_report <- run_safely("build_license_driver_report", function() build_license_driver_report(sec_structure, user_roles))$result
  user_report <- run_safely("format_user_report", function() format_user_report(user_profiles, license_by_role_df, findings))$result
  if (is.null(user_report)) user_report <- user_profiles

  meta <- data.frame(
    environment = environment,
    run_timestamp = format(Sys.time()),
    telemetry_days = cfg$telemetry$telemetry_days,
    telemetry_status = attr(telemetry_touches, "status") %||% "OK",
    transaction_activity_status = attr(transaction_activity, "status") %||% "OK",
    stringsAsFactors = FALSE
  )

  date_tag <- format(Sys.Date(), "%Y%m%d")
  excel_path <- file.path(reports_dir, gsub("\\{environment\\}", environment,
                    gsub("\\{date\\}", date_tag, cfg$output$excel_filename)))
  md_path <- file.path(reports_dir, gsub("\\{environment\\}", environment,
                    gsub("\\{date\\}", date_tag, cfg$output$markdown_filename)))

  run_safely("write_excel_report", function() {
    write_excel_report(user_report, role_metrics, license_driver_report, findings, meta, excel_path)
  })
  run_safely("write_markdown_report", function() {
    write_markdown_report(environment, user_profiles, role_metrics, findings, cfg, md_path)
  })

  write_log(file.path(root, cfg$paths$log_dir), environment)

  log_info("run_analysis", "=== Completed in %.1fs ===", as.numeric(difftime(Sys.time(), t0, units = "secs")))

  invisible(list(
    config = cfg, users = user_base, user_profiles = user_profiles,
    role_metrics = role_metrics, sec_structure = sec_structure,
    findings = findings, license_driver_report = license_driver_report,
    excel_path = excel_path, markdown_path = md_path
  ))
}

# Allow `Rscript run_analysis.R PRJ`
if (sys.nframe() == 0 && !interactive()) {
  cli_args <- commandArgs(trailingOnly = TRUE)
  env_arg <- if (length(cli_args) >= 1) cli_args[1] else "PRJ"
  run_analysis(environment = env_arg)
}
