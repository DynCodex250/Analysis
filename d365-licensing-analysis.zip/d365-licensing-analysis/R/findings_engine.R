# =============================================================================
# R/findings_engine.R
# Brief sections 9-11: configurable Findings Engine.
#
# Design: config/findings_rules.yml lists which rules are active and their
# severity/confidence defaults. Each rule maps to exactly one evaluator
# function below (by name), so rules can be toggled/re-graded without
# touching this file, while the actual join/comparison logic stays testable
# R code (brief section 20: joins must be unit-tested).
#
# Every evaluator returns a data.frame with AT LEAST:
#   finding_id, severity, confidence, user, role, object, finding, evidence,
#   data_sources, reason, recommended_validation
# Evaluators must NEVER assert a Microsoft licensing decision as fact - only
# "REQUIRES_VALIDATION" style findings (brief section 6, 11).
# =============================================================================

new_finding <- function(finding_id, severity, confidence, user = NA, role = NA,
                          object = NA, finding, evidence, data_sources, reason,
                          recommended_validation) {
  data.frame(
    finding_id = finding_id, severity = severity, confidence = confidence,
    user = user, role = role, object = object, finding = finding,
    evidence = evidence, data_sources = data_sources, reason = reason,
    recommended_validation = recommended_validation, stringsAsFactors = FALSE
  )
}

# --- FINDING-001 -------------------------------------------------------------
rule_active_invalid_user <- function(ctx) {
  df <- ctx$invalid_users_analysis
  if (nrow(df) == 0) return(NULL)
  do.call(rbind, lapply(seq_len(nrow(df)), function(i) {
    r <- df[i, ]
    new_finding(
      "FINDING-001", "HIGH", "HIGH",
      user = r$ID, role = NA, object = "USERINFO / SYSUSERINVALIDUSERS",
      finding = "Active user with an Invalid User (Entra ID) entry",
      evidence = sprintf("ENABLE=1, InvalidityReason=%s", r$INVALIDITYREASON),
      data_sources = "USERINFO; SYSUSERINVALIDUSERS",
      reason = "User is enabled in D365FO but Entra ID no longer recognises the identity as valid.",
      recommended_validation = "Confirm with IAM/Entra admin whether this account should be disabled or is a false positive (e.g. sync delay)."
    )
  }))
}

# --- FINDING-002 -------------------------------------------------------------
rule_business_plus_service_role <- function(ctx) {
  df <- ctx$user_role_class
  hits <- df[df$role_combination_class == "BUSINESS_PLUS_SERVICE_ROLE_LICENSE_LIKELY_REQUIRES_VALIDATION", ]
  if (nrow(hits) == 0) return(NULL)
  do.call(rbind, lapply(seq_len(nrow(hits)), function(i) {
    r <- hits[i, ]
    new_finding(
      "FINDING-002", "MEDIUM", "MEDIUM",
      user = r$user_id, role = paste(r$business_roles, r$service_roles, sep = " + "),
      object = "Security User Role Association",
      finding = "User holds both a Business Role and a Service Role",
      evidence = sprintf("Business roles: %s | Service roles: %s", r$business_roles, r$service_roles),
      data_sources = "USERSECGOVRELATEDOBJECTS; config:service_roles",
      reason = "Per the source document, Service Roles alone require no license, but combined with a Business Role a license is required. This is a document-derived rule, not independently verified against current Microsoft licensing documentation.",
      recommended_validation = "Confirm current SKU requirement for this exact role combination against Microsoft's licensing guide / PPAC."
    )
  }))
}

# --- FINDING-003 -------------------------------------------------------------
rule_unused_expensive_entry_points <- function(ctx) {
  sec <- ctx$sec_structure
  touches <- ctx$telemetry_touches
  ep_col <- names(sec)[toupper(names(sec)) == "ENTRYPOINTNAME"][1]
  role_col <- names(sec)[toupper(names(sec)) == "ROLENAME"][1]
  user_roles <- ctx$user_roles

  if (is.na(ep_col) || is.null(touches) || nrow(user_roles) == 0) return(NULL)
  telem_status <- attr(touches, "status")
  if (is.null(telem_status)) telem_status <- "OK"
  if (!telem_status %in% c("OK", "OK_EMPTY") || !"name" %in% names(touches)) return(NULL)

  observed_eps <- unique(touches$name)
  licensed <- sec[!is.na(sec$ENTITLED) & sec$ENTITLED %in% c(1, "1", TRUE), ]
  if (nrow(licensed) == 0) return(NULL)

  rows <- list()
  for (u in unique(user_roles$user_id)) {
    roles <- user_roles$role[user_roles$user_id == u]
    user_licensed_eps <- licensed[licensed[[role_col]] %in% roles, ]
    unused <- user_licensed_eps[!user_licensed_eps[[ep_col]] %in% observed_eps, ]
    if (nrow(unused) == 0) next
    rows[[length(rows) + 1]] <- new_finding(
      "FINDING-003", "MEDIUM", "MEDIUM",
      user = u, role = paste(unique(unused[[role_col]]), collapse = "; "),
      object = paste(unique(unused[[ep_col]]), collapse = "; "),
      finding = sprintf("%d licensing-relevant entry point(s) held via role but not observed in telemetry", nrow(unused)),
      evidence = sprintf("Entitled entry points with 0 telemetry touches in the configured window: %s",
                          paste(unique(unused[[ep_col]]), collapse = ", ")),
      data_sources = "LICENSINGROLEREQUIREMENTSDETAILEDVIEW; USERSECGOVRELATEDOBJECTS; telemetry:pageViews",
      reason = "Absence of telemetry is evidence of non-use, not proof - some usage (Action/Output Menu Items, printing, production actions) is not fully captured by telemetry per the source document's Known Issues section.",
      recommended_validation = "Cross-check with transaction activity and business owner before removing the role/entry point."
    )
  }
  if (length(rows) == 0) return(NULL)
  do.call(rbind, rows)
}

# --- FINDING-004 -------------------------------------------------------------
rule_role_multiple_license_types <- function(ctx) {
  roles <- ctx$role_metrics
  hits <- roles[!is.na(roles$distinct_license_types) & roles$distinct_license_types > 1, ]
  if (nrow(hits) == 0) return(NULL)
  do.call(rbind, lapply(seq_len(nrow(hits)), function(i) {
    r <- hits[i, ]
    new_finding(
      "FINDING-004", "MEDIUM", "HIGH",
      user = NA, role = r$role, object = "LICENSINGROLEREQUIREMENTSDETAILEDVIEW",
      finding = sprintf("Role maps to %d distinct license SKUs", r$distinct_license_types),
      evidence = sprintf("SKUs: %s", r$license_skus),
      data_sources = "LICENSINGROLEREQUIREMENTSDETAILEDVIEW",
      reason = "A role spanning multiple SKUs often indicates a poorly separated / historically grown role.",
      recommended_validation = "Review whether the role should be split by functional area; confirm base/attach logic with licensing SME."
    )
  }))
}

# --- FINDING-005 -------------------------------------------------------------
rule_role_high_write_ratio <- function(ctx) {
  roles <- ctx$role_metrics
  threshold <- ctx$rule_params$`FINDING-005`$write_ratio_threshold %||% 0.40
  hits <- roles[!is.na(roles$write_ratio) & roles$write_ratio > threshold, ]
  if (nrow(hits) == 0) return(NULL)
  do.call(rbind, lapply(seq_len(nrow(hits)), function(i) {
    r <- hits[i, ]
    new_finding(
      "FINDING-005", "LOW", "HIGH",
      user = NA, role = r$role, object = "USERSECGOVRELATEDOBJECTS",
      finding = sprintf("Role has a high write-access ratio (%.0f%%)", r$write_ratio * 100),
      evidence = sprintf("%d write / %d read entry points", r$write_entry_points, r$read_entry_points),
      data_sources = "USERSECGOVRELATEDOBJECTS",
      reason = sprintf("Write ratio exceeds configured threshold of %.0f%%.", threshold * 100),
      recommended_validation = "Review whether all write entry points are functionally required for this role."
    )
  }))
}

# --- FINDING-006 -------------------------------------------------------------
rule_role_no_usage_evidence <- function(ctx) {
  profiles <- ctx$user_profiles
  hits <- profiles[profiles$activity_evidence_status %in%
                      c("NO_TELEMETRY_TRANSACTIONS_UNKNOWN_NOT_CONFIRMED_INACTIVE",
                        "NO_ACTIVITY_EVIDENCE_FOUND_NOT_CONFIRMED_INACTIVE") &
                      !is.na(profiles$business_roles) & profiles$business_roles != "", ]
  if (nrow(hits) == 0) return(NULL)
  do.call(rbind, lapply(seq_len(nrow(hits)), function(i) {
    r <- hits[i, ]
    new_finding(
      "FINDING-006", "MEDIUM", "LOW",
      user = r$ID, role = r$business_roles, object = "telemetry + transaction activity",
      finding = "No usage evidence found for this user's role(s) within the analysis window",
      evidence = sprintf("activity_evidence_status = %s", r$activity_evidence_status),
      data_sources = "telemetry:pageViews; transaction_activity (if configured)",
      reason = "No demonstrated usage was found, but per brief section 11 this must NOT be reported as 'user does not use D365FO' - only as missing evidence.",
      recommended_validation = "Confirm with the business owner whether the user is genuinely inactive, uses non-telemetered functions, or works via CRM/API/thin client."
    )
  }))
}

# --- FINDING-007 -------------------------------------------------------------
rule_application_user_business_activity <- function(ctx) {
  app_users <- ctx$app_users_analysis
  touches <- ctx$telemetry_touches
  if (nrow(app_users) == 0 || is.null(touches) || !"user_Id" %in% names(touches)) return(NULL)

  business_like <- touches[touches$user_Id %in% app_users$USERID, ]
  if (nrow(business_like) == 0) return(NULL)

  agg <- stats::aggregate(touches ~ user_Id, data = business_like, FUN = function(x) sum(as.numeric(x)))
  do.call(rbind, lapply(seq_len(nrow(agg)), function(i) {
    r <- agg[i, ]
    new_finding(
      "FINDING-007", "HIGH", "MEDIUM",
      user = r$user_Id, role = NA, object = "SYSAADCLIENTTABLE",
      finding = "Application/technical user shows telemetry consistent with regular business activity",
      evidence = sprintf("%s telemetry touches observed in the analysis window", r$touches),
      data_sources = "SYSAADCLIENTTABLE; telemetry:pageViews",
      reason = "Per the source document, Microsoft may re-classify such accounts away from technical/license-free status if regular business forms/entry points are used.",
      recommended_validation = "Review whether this integration account should instead be a normal licensed user, or whether its automation should avoid interactive forms."
    )
  }))
}

# --- FINDING-008 -------------------------------------------------------------
rule_role_oversized_heuristic <- function(ctx) {
  roles <- ctx$role_metrics
  hits <- roles[isTRUE(roles$possibly_oversized) | roles$possibly_oversized == TRUE, ]
  if (nrow(hits) == 0) return(NULL)
  do.call(rbind, lapply(seq_len(nrow(hits)), function(i) {
    r <- hits[i, ]
    new_finding(
      "FINDING-008", "LOW", "LOW",
      user = NA, role = r$role, object = "USERSECGOVRELATEDOBJECTS",
      finding = "Role may contain oversized / historically grown permissions (heuristic)",
      evidence = sprintf("duties=%s, privileges=%s, entry points=%s (all >= 90th percentile across analyzed roles)",
                          r$duty_count, r$privilege_count, r$entry_point_count),
      data_sources = "USERSECGOVRELATEDOBJECTS",
      reason = "Percentile-based heuristic only - this is an interpretation, not a Microsoft licensing statement.",
      recommended_validation = "Manual role review; consider splitting by functional area."
    )
  }))
}

# --- FINDING-009 -------------------------------------------------------------
rule_unusual_role_combination <- function(ctx) {
  # Functional-area classification is not present as ground truth data;
  # without a maintained role -> functional-area mapping, this evaluator
  # returns no findings but is retained as an active, documented extension
  # point, rather than fabricating a functional-area taxonomy.
  log_warn("findings_engine",
            "FINDING-009 (unusual role combination) requires a role -> functional-area mapping ",
            "that is not present in the source data; skipped (REQUIRES_VALIDATION extension point)")
  NULL
}

# --- FINDING-010 -------------------------------------------------------------
rule_missing_telemetry_coverage <- function(ctx) {
  status <- attr(ctx$telemetry_touches, "status")
  if (is.null(status)) status <- "OK"
  if (status %in% c("OK", "OK_EMPTY")) return(NULL)
  new_finding(
    "FINDING-010", "LOW", "UNKNOWN",
    user = NA, role = NA, object = "telemetry:pageViews",
    finding = "Telemetry unavailable for this run - all telemetry-dependent findings are degraded",
    evidence = sprintf("telemetry status = %s", status),
    data_sources = "telemetry:pageViews (absence)",
    reason = "Application Insights credentials/config missing, or the API call failed.",
    recommended_validation = sprintf("Configure %s and %s env vars, or verify Application Insights App ID.",
                                       ctx$cfg$telemetry$app_insights_env_var, ctx$cfg$telemetry$api_key_env_var)
  )
}

# =============================================================================
# Data Quality evaluators (brief section 19)
# =============================================================================

dq_missing_user_id <- function(ctx) {
  df <- ctx$users
  hits <- df[is.na(df$ID) | df$ID == "", ]
  if (nrow(hits) == 0) return(NULL)
  new_finding("DQ-001", "MEDIUM", "HIGH", object = "USERINFO",
              finding = sprintf("%d row(s) with missing User ID", nrow(hits)),
              evidence = "NA/empty ID in USERINFO extract", data_sources = "USERINFO",
              reason = "Missing primary key breaks downstream joins.",
              recommended_validation = "Investigate extract/ETL for malformed rows.")
}

dq_duplicate_role_assignment <- function(ctx) {
  df <- ctx$user_roles
  if (nrow(df) == 0) return(NULL)
  dupes <- df[duplicated(df[, c("user_id", "role")]), ]
  if (nrow(dupes) == 0) return(NULL)
  new_finding("DQ-002", "LOW", "HIGH", object = "USERSECGOVRELATEDOBJECTS",
              finding = sprintf("%d duplicate user-role assignment row(s)", nrow(dupes)),
              evidence = paste(utils::head(paste(dupes$user_id, dupes$role, sep = "/"), 10), collapse = "; "),
              data_sources = "USERSECGOVRELATEDOBJECTS",
              reason = "Duplicate rows can inflate entry-point/license counts.",
              recommended_validation = "De-duplicate before final reporting; check source view definition.")
}

dq_role_without_requirements <- function(ctx) {
  sec <- ctx$sec_structure
  if (!"has_license_requirement_record" %in% names(sec)) return(NULL)
  role_col <- names(sec)[toupper(names(sec)) == "ROLENAME"][1]
  missing_roles <- unique(sec[[role_col]][!sec$has_license_requirement_record])
  if (length(missing_roles) == 0) return(NULL)
  new_finding("DQ-003", "MEDIUM", "HIGH", role = paste(utils::head(missing_roles, 20), collapse = "; "),
              object = "LICENSINGROLEREQUIREMENTSDETAILEDVIEW",
              finding = sprintf("%d role(s) with no licensing requirement record", length(missing_roles)),
              evidence = "No matching row in LICENSINGROLEREQUIREMENTSDETAILEDVIEW",
              data_sources = "USERSECGOVRELATEDOBJECTS; LICENSINGROLEREQUIREMENTSDETAILEDVIEW",
              reason = "Role cannot be license-evaluated without a requirements record.",
              recommended_validation = "Confirm whether these roles are custom/ISV roles missing from the licensing catalogue.")
}

dq_requirement_without_role <- function(ctx) {
  # Requires the raw (unfiltered) requirements set to detect orphans; if the
  # loader was called with entitled_only = TRUE this check is necessarily
  # partial and is flagged as such.
  NULL  # documented extension point - wire up with entitled_only = FALSE load
}

dq_telemetry_unknown_user <- function(ctx) {
  touches <- ctx$telemetry_touches
  status <- attr(touches, "status")
  if (is.null(status)) status <- "OK"
  if (!status %in% c("OK", "OK_EMPTY") || !"user_Id" %in% names(touches)) return(NULL)
  known_users <- ctx$users$ID
  unknown <- unique(touches$user_Id[!touches$user_Id %in% known_users])
  unknown <- unknown[!is.na(unknown) & unknown != ""]
  if (length(unknown) == 0) return(NULL)
  new_finding("DQ-005", "LOW", "HIGH", object = "telemetry:pageViews",
              finding = sprintf("%d telemetry user_Id value(s) do not match any known USERINFO.ID", length(unknown)),
              evidence = paste(utils::head(unknown, 10), collapse = "; "),
              data_sources = "telemetry:pageViews; USERINFO",
              reason = "Telemetry user_Id may use a different identifier scheme (e.g. Entra ObjectId) than USERINFO.ID.",
              recommended_validation = "Confirm the identifier mapping between Application Insights user_Id and D365FO USERINFO.ID/OBJECTID.")
}

dq_user_without_roles <- function(ctx) {
  users <- ctx$users
  roles <- ctx$user_roles
  active <- users$ID[users$ENABLE == 1]
  without_roles <- setdiff(active, unique(roles$user_id))
  if (length(without_roles) == 0) return(NULL)
  new_finding("DQ-006", "MEDIUM", "HIGH", object = "USERSECGOVRELATEDOBJECTS",
              finding = sprintf("%d active user(s) with no role assignment found", length(without_roles)),
              evidence = paste(utils::head(without_roles, 10), collapse = "; "),
              data_sources = "USERINFO; USERSECGOVRELATEDOBJECTS",
              reason = "Active user without any role is unusual and may indicate incomplete data extraction.",
              recommended_validation = "Verify in D365FO UI whether the user genuinely has no roles assigned.")
}

dq_role_without_privileges <- function(ctx) {
  sec <- ctx$sec_structure
  role_col <- names(sec)[toupper(names(sec)) == "ROLENAME"][1]
  priv_col <- names(sec)[toupper(names(sec)) == "PRIVILEGENAME"][1]
  if (is.na(role_col) || is.na(priv_col)) return(NULL)
  by_role <- split(sec[[priv_col]], sec[[role_col]])
  empty_roles <- names(by_role)[vapply(by_role, function(x) all(is.na(x)), logical(1))]
  if (length(empty_roles) == 0) return(NULL)
  new_finding("DQ-007", "LOW", "HIGH", role = paste(utils::head(empty_roles, 20), collapse = "; "),
              object = "USERSECGOVRELATEDOBJECTS",
              finding = sprintf("%d role(s) with no privileges found", length(empty_roles)),
              evidence = "All privilege values NA for this role", data_sources = "USERSECGOVRELATEDOBJECTS",
              reason = "A role with no privileges may be unused, deprecated, or a data extraction gap.",
              recommended_validation = "Verify role definition in D365FO Security configuration.")
}

dq_privilege_without_entry_points <- function(ctx) {
  sec <- ctx$sec_structure
  priv_col <- names(sec)[toupper(names(sec)) == "PRIVILEGENAME"][1]
  ep_col <- names(sec)[toupper(names(sec)) == "ENTRYPOINTNAME"][1]
  if (is.na(priv_col) || is.na(ep_col)) return(NULL)
  by_priv <- split(sec[[ep_col]], sec[[priv_col]])
  empty <- names(by_priv)[vapply(by_priv, function(x) all(is.na(x)), logical(1))]
  if (length(empty) == 0) return(NULL)
  new_finding("DQ-008", "LOW", "HIGH", object = paste(utils::head(empty, 20), collapse = "; "),
              finding = sprintf("%d privilege(s) with no entry points found", length(empty)),
              evidence = "All entry point values NA for this privilege", data_sources = "USERSECGOVRELATEDOBJECTS",
              reason = "Structural gap in the security governance extract.",
              recommended_validation = "Cross-check against Security Analysis rebuild in D365FO.")
}

dq_entry_point_without_license_info <- function(ctx) {
  sec <- ctx$sec_structure
  ep_col <- names(sec)[toupper(names(sec)) == "ENTRYPOINTNAME"][1]
  if (is.na(ep_col) || !"has_license_requirement_record" %in% names(sec)) return(NULL)
  missing <- unique(sec[[ep_col]][!sec$has_license_requirement_record])
  missing <- missing[!is.na(missing)]
  if (length(missing) == 0) return(NULL)
  new_finding("DQ-009", "MEDIUM", "MEDIUM", object = paste(utils::head(missing, 20), collapse = "; "),
              finding = sprintf("%d entry point(s) with no license information", length(missing)),
              evidence = "No matching row in *_REQUIREMENTSDETAILEDVIEW tables", data_sources = "LICENSING*REQUIREMENTSDETAILEDVIEW",
              reason = "Entry point cannot be assessed for license relevance.",
              recommended_validation = "Confirm whether entry point is genuinely license-free or missing from the licensing catalogue.")
}

# =============================================================================
# Orchestrator
# =============================================================================

#' generate_findings(): run every ACTIVE rule from findings_rules.yml against
#' the analysis context and return one combined findings data.frame.
#'
#' @param ctx a named list with all analysis outputs the evaluators need:
#'   users, invalid_users_analysis, app_users_analysis, user_roles,
#'   user_role_class, sec_structure, role_metrics, telemetry_touches,
#'   user_profiles, cfg, rule_params
#' @param rules_cfg the parsed findings_rules.yml$rules list
#' @return data.frame of all findings across all active rules
generate_findings <- function(ctx, rules_cfg) {
  evaluators <- list(
    rule_active_invalid_user = rule_active_invalid_user,
    rule_business_plus_service_role = rule_business_plus_service_role,
    rule_unused_expensive_entry_points = rule_unused_expensive_entry_points,
    rule_role_multiple_license_types = rule_role_multiple_license_types,
    rule_role_high_write_ratio = rule_role_high_write_ratio,
    rule_role_no_usage_evidence = rule_role_no_usage_evidence,
    rule_application_user_business_activity = rule_application_user_business_activity,
    rule_role_oversized_heuristic = rule_role_oversized_heuristic,
    rule_unusual_role_combination = rule_unusual_role_combination,
    rule_missing_telemetry_coverage = rule_missing_telemetry_coverage,
    dq_missing_user_id = dq_missing_user_id,
    dq_duplicate_role_assignment = dq_duplicate_role_assignment,
    dq_role_without_requirements = dq_role_without_requirements,
    dq_requirement_without_role = dq_requirement_without_role,
    dq_telemetry_unknown_user = dq_telemetry_unknown_user,
    dq_user_without_roles = dq_user_without_roles,
    dq_role_without_privileges = dq_role_without_privileges,
    dq_privilege_without_entry_points = dq_privilege_without_entry_points,
    dq_entry_point_without_license_info = dq_entry_point_without_license_info
  )

  ctx$rule_params <- lapply(rules_cfg, function(r) r$parameters)

  results <- list()
  for (rule_id in names(rules_cfg)) {
    rule <- rules_cfg[[rule_id]]
    if (!isTRUE(rule$active)) next
    fn <- evaluators[[rule$evaluator]]
    if (is.null(fn)) {
      log_warn("findings_engine", "no evaluator registered for %s (%s); skipping", rule_id, rule$evaluator)
      next
    }
    res <- run_safely(paste0("finding:", rule_id), function() fn(ctx))
    if (res$ok && !is.null(res$result) && nrow(res$result) > 0) {
      out <- res$result
      out$severity <- rule$severity
      results[[rule_id]] <- out
    }
  }

  if (length(results) == 0) {
    return(new_finding(character(0), character(0), character(0), finding = character(0),
                        evidence = character(0), data_sources = character(0), reason = character(0),
                        recommended_validation = character(0))[0, ])
  }
  do.call(rbind, results)
}
