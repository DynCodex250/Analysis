# =============================================================================
# R/data_transaction_activity.R
# Section 8 of the brief: transaction activity (CreatedBy/ModifiedBy) as a
# second activity signal, independent of UI telemetry.
#
# The brief is explicit: "Wenn konkrete Tabellen dafür notwendig sind,
# identifiziere diese zunächst und dokumentiere die Abhängigkeit. Erfinde
# keine Tabellen." No concrete transaction table was named in the source
# document, so this module returns REQUIRES_VALIDATION / UNKNOWN by design
# until an environment-specific table list is supplied via config.
# =============================================================================

#' Load transaction activity evidence, IF a table list has been configured.
#'
#' To enable this, add to config.yml:
#'   transaction_activity:
#'     tables:
#'       - "CUSTINVOICEJOUR"
#'       - "PURCHTABLE"
#' and populate sql/10_transaction_activity_TEMPLATE.sql (or one file per
#' table) with read-only SELECTs over CREATEDBY/CREATEDDATETIME/MODIFIEDBY/
#' MODIFIEDDATETIME (or module-specific equivalents).
#'
#' @return data.frame(user_id, table_name, created_count, last_created,
#'   last_modified) if configured, otherwise an empty data.frame with
#'   attr(status) = "UNKNOWN_NO_TABLE_CONFIGURED"
load_transaction_activity <- function(cnn, cfg, sql_dir) {
  tables <- cfg$transaction_activity$tables
  if (is.null(tables) || length(tables) == 0) {
    log_warn("data_transaction_activity", paste0(
              "no transaction tables configured (cfg$transaction_activity$tables); ",
              "transaction-based activity evidence is UNKNOWN for this run"))
    res <- data.frame(user_id = character(), table_name = character(),
                       created_count = integer(), last_created = as.Date(character()),
                       last_modified = as.Date(character()))
    attr(res, "status") <- "UNKNOWN_NO_TABLE_CONFIGURED"
    return(res)
  }

  # Left as an explicit per-table loop so a failure on one module table
  # doesn't block others; each SELECT must be added by the analyst per
  # brief section 8 (no invented table/column names).
  results <- list()
  for (tbl in tables) {
    sql_path <- file.path(sql_dir, paste0("transaction_", tolower(tbl), ".sql"))
    if (!file.exists(sql_path)) {
      log_warn("data_transaction_activity", "no SQL file found for configured table %s (%s); skipping", tbl, sql_path)
      next
    }
    res <- run_safely(paste0("transaction_activity:", tbl), function() {
      run_readonly_query(cnn, sql_path)
    })
    if (res$ok) results[[tbl]] <- res$result
  }

  if (length(results) == 0) {
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN_NO_TABLE_CONFIGURED"
    return(res)
  }

  out <- do.call(rbind, results)
  attr(out, "status") <- "OK"
  out
}

#' Determine whether a user has demonstrated transaction activity.
#' Returns "UNKNOWN" (never "INACTIVE") when the underlying data source is
#' not configured, consistent with brief section 11 ("keine Telemetrie" must
#' never silently become "Benutzer verwendet D365FO nicht").
has_transaction_activity <- function(user_id, transaction_df) {
  status <- attr(transaction_df, "status")
  if (!is.null(status) && startsWith(status, "UNKNOWN")) return("UNKNOWN")
  if (nrow(transaction_df) == 0) return("UNKNOWN")
  any(transaction_df$user_id == user_id)
}
