# =============================================================================
# R/data_telemetry.R
# Section E/F of the brief: Application Insights / KQL telemetry.
# telemetry_days is ALWAYS read from config - never hard-coded here (brief
# explicitly forbids hard-coding e.g. 14 or 700 days in code).
#
# REUSE NOTE (brief section 14): the host project already provides
#   get_appinsights_connection(environment)
#   run_appinsights_query(environment, query)
# (Excel-based credentials on the "Insights" sheet of the same credentials
# file used by get_connection(), app_id + api_key auth against
# https://api.applicationinsights.io/v1/apps/{app_id}/query). This pipeline
# calls THOSE functions directly instead of re-implementing REST/auth logic -
# no second implementation is maintained here.
#
# A small, self-contained httr2-based fallback is kept ONLY for host projects
# that do not already provide run_appinsights_query() (e.g. this pipeline
# used standalone, without the host project's existing helpers sourced). It
# is never used when the host function is available.
# =============================================================================

#' Render a .kql template file, substituting {{placeholders}}.
#' @param kql_file path to a .kql file under kql/
#' @param vars named list of placeholder -> value (values are inserted as-is;
#'   numeric/day-count values only - do not pass untrusted free text here)
render_kql <- function(kql_file, vars = list()) {
  if (!file.exists(kql_file)) stop("KQL file not found: ", kql_file)
  text <- paste(readLines(kql_file, warn = FALSE), collapse = "\n")
  for (nm in names(vars)) {
    text <- gsub(paste0("\\{\\{", nm, "\\}\\}"), vars[[nm]], text, fixed = FALSE)
  }
  # Any still-unfilled optional placeholder (e.g. {{entry_point_filter}}) is
  # removed, meaning "no extra filter".
  text <- gsub("\\{\\{[a-zA-Z_]+\\}\\}", "", text)
  text
}

#' Execute a KQL query against Application Insights.
#'
#' Prefers the host project's existing run_appinsights_query(environment,
#' query) if it is available in the session (see REUSE NOTE above). Falls
#' back to a self-contained httr2 call using config-named environment
#' variables only if that function is not found.
#'
#' @param kql_query rendered KQL string
#' @param cfg loaded config (see load_config())
#' @param environment logical D365FO/Insights environment name, e.g. "PRJ" -
#'   required when using the host project's run_appinsights_query(), which
#'   looks up Application Insights credentials by environment (Excel
#'   "Insights" sheet), the same way get_connection() looks up DB credentials.
#' @return data.frame of results, or an empty data.frame with an
#'   attr(., "status") = "UNKNOWN" if telemetry is disabled/unavailable
run_kql_query <- function(kql_query, cfg, environment = NULL) {
  if (!isTRUE(cfg$telemetry$enabled)) {
    log_warn("data_telemetry", "telemetry disabled in config; returning empty result (UNKNOWN)")
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  # --- Preferred path: reuse the host project's existing helper -----------
  if (exists("run_appinsights_query", mode = "function")) {
    if (is.null(environment)) {
      log_warn("data_telemetry", paste0(
        "run_appinsights_query() is available but no `environment` was passed to run_kql_query(); ",
        "cannot look up Insights credentials by environment. Returning UNKNOWN."))
      res <- data.frame()
      attr(res, "status") <- "UNKNOWN"
      return(res)
    }
    res <- tryCatch(
      run_appinsights_query(environment, kql_query),
      error = function(e) {
        log_error("data_telemetry", "run_appinsights_query() failed for environment %s: %s",
                   environment, conditionMessage(e))
        NULL
      }
    )
    if (is.null(res)) {
      res <- data.frame()
      attr(res, "status") <- "UNKNOWN"
      return(res)
    }
    attr(res, "status") <- if (nrow(res) == 0) "OK_EMPTY" else "OK"
    return(res)
  }

  # --- Fallback: self-contained REST call (host project doesn't provide the
  # helper above). Requires the httr2 package and config-named env vars. ---
  log_warn("data_telemetry", paste0(
    "run_appinsights_query() was not found in the session; using the built-in httr2 fallback. ",
    "Prefer sourcing the host project's existing Application Insights helpers if available."))

  if (!requireNamespace("httr2", quietly = TRUE)) {
    log_error("data_telemetry", "httr2 package not available and no run_appinsights_query() helper found; returning UNKNOWN")
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  app_id  <- Sys.getenv(cfg$telemetry$app_insights_env_var, unset = "")
  api_key <- Sys.getenv(cfg$telemetry$api_key_env_var, unset = "")

  if (app_id == "" || api_key == "") {
    log_warn("data_telemetry",
              "Application Insights credentials not found in env vars (%s / %s); returning UNKNOWN",
              cfg$telemetry$app_insights_env_var, cfg$telemetry$api_key_env_var)
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  url <- sprintf("https://api.applicationinsights.io/v1/apps/%s/query", app_id)

  resp <- tryCatch({
    httr2::request(url) |>
      httr2::req_headers("x-api-key" = api_key) |>
      httr2::req_url_query(query = kql_query) |>
      httr2::req_perform()
  }, error = function(e) {
    log_error("data_telemetry", "Application Insights request failed: %s", conditionMessage(e))
    NULL
  })

  if (is.null(resp)) {
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  body <- httr2::resp_body_json(resp)
  table <- body$tables[[1]]
  cols <- vapply(table$columns, function(c) c$name, character(1))
  rows <- table$rows
  if (length(rows) == 0) {
    res <- as.data.frame(matrix(nrow = 0, ncol = length(cols)))
    names(res) <- cols
    attr(res, "status") <- "OK_EMPTY"
    return(res)
  }
  df <- as.data.frame(do.call(rbind, lapply(rows, function(r) unlist(r))), stringsAsFactors = FALSE)
  names(df) <- cols
  attr(df, "status") <- "OK"
  df
}

#' Load per-user, per-entry-point telemetry touches for the configured
#' analysis window (kql/04_user_entrypoint_touches.kql).
#'
#' @param cfg loaded config
#' @param kql_dir path to the kql/ directory
#' @param environment logical environment name (e.g. "PRJ") - passed through
#'   to run_appinsights_query() for Insights-credential lookup
#' @param entry_point_filter optional single entry point name to filter to
#' @return data.frame(user_Id, name, last_seen, duration_seconds, touches).
#'   Numeric-looking columns (duration_seconds, touches) are coerced to
#'   numeric, since the host project's run_appinsights_query() may return all
#'   columns as character (unlisted JSON rows). last_seen is coerced to
#'   POSIXct where parseable, left as character (ISO8601 still sorts
#'   correctly) otherwise. Returns an empty data.frame with
#'   attr(status) = "UNKNOWN" if unavailable - never fabricated.
load_telemetry_touches <- function(cfg, kql_dir, environment = NULL, entry_point_filter = NULL) {
  days <- cfg$telemetry$telemetry_days
  if (is.null(days) || !is.numeric(days) || days <= 0) {
    stop("telemetry_days must be a positive number set in config.yml (got: ", days, ")")
  }
  if (days < (cfg$telemetry$min_recommended_days %||% 14)) {
    log_warn("data_telemetry",
              "telemetry_days=%s is below the recommended minimum (%s); seasonal/rare processes may be missed",
              days, cfg$telemetry$min_recommended_days)
  }

  filter_clause <- if (is.null(entry_point_filter)) "" else sprintf('and name == "%s"', entry_point_filter)

  kql <- render_kql(
    file.path(kql_dir, "04_user_entrypoint_touches.kql"),
    vars = list(telemetry_days = days, entry_point_filter = filter_clause)
  )
  res <- run_kql_query(kql, cfg, environment = environment)

  status <- attr(res, "status")
  if (!is.null(status) && status %in% c("OK", "OK_EMPTY") && nrow(res) > 0) {
    if ("duration_seconds" %in% names(res)) res$duration_seconds <- suppressWarnings(as.numeric(res$duration_seconds))
    if ("touches" %in% names(res)) res$touches <- suppressWarnings(as.numeric(res$touches))
    if ("last_seen" %in% names(res)) {
      parsed <- suppressWarnings(as.POSIXct(res$last_seen, tz = "UTC"))
      if (!all(is.na(parsed))) res$last_seen <- parsed
    }
    attr(res, "status") <- status  # coercion above can drop attributes; restore
  }
  res
}
