# =============================================================================
# R/data_telemetry.R
# Section E/F of the brief: Application Insights / KQL telemetry.
# telemetry_days is ALWAYS read from config - never hard-coded here (brief
# explicitly forbids hard-coding e.g. 14 or 700 days in code).
# =============================================================================

library(httr2)

#' Render a .kql template file, substituting {{placeholders}}.
#' @param kql_file path to a .kql file under kql/
#' @param vars named list of placeholder -> value (values are inserted as-is;
#'   numeric/day-count values only - do not pass untrusted free text here)
render_kql <- function(kql_file, vars = list()) {
  if (!file.exists(kql_file)) stop("KQL file not found: ", kql_file)
  text <- paste(readLines(kql_file, warn = FALSE), collapse = "\n")
  for (nm in names(vars)) {
    text <- gsub(paste0("\\{\\{", nm, "\\}\\}"), vars[[nm]], text, fixed = FALSE)
  }
  # Any still-unfilled optional placeholder (e.g. {{entry_point_filter}}) is
  # removed, meaning "no extra filter".
  text <- gsub("\\{\\{[a-zA-Z_]+\\}\\}", "", text)
  text
}

#' Execute a KQL query against Application Insights via the REST API.
#' Credentials/app id come strictly from environment variables named in
#' config (never hard-coded, never stored in this repo).
#'
#' @param kql_query rendered KQL string
#' @param cfg loaded config (see load_config())
#' @return data.frame of results, or an empty data.frame with an
#'   attr(., "status") = "UNKNOWN" if telemetry is disabled/unavailable
run_kql_query <- function(kql_query, cfg) {
  if (!isTRUE(cfg$telemetry$enabled)) {
    log_warn("data_telemetry", "telemetry disabled in config; returning empty result (UNKNOWN)")
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  app_id  <- Sys.getenv(cfg$telemetry$app_insights_env_var, unset = "")
  api_key <- Sys.getenv(cfg$telemetry$api_key_env_var, unset = "")

  if (app_id == "" || api_key == "") {
    log_warn("data_telemetry",
              "Application Insights credentials not found in env vars (%s / %s); returning UNKNOWN",
              cfg$telemetry$app_insights_env_var, cfg$telemetry$api_key_env_var)
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  url <- sprintf("https://api.applicationinsights.io/v1/apps/%s/query", app_id)

  resp <- tryCatch({
    httr2::request(url) |>
      httr2::req_headers("x-api-key" = api_key) |>
      httr2::req_url_query(query = kql_query) |>
      httr2::req_perform()
  }, error = function(e) {
    log_error("data_telemetry", "Application Insights request failed: %s", conditionMessage(e))
    NULL
  })

  if (is.null(resp)) {
    res <- data.frame()
    attr(res, "status") <- "UNKNOWN"
    return(res)
  }

  body <- httr2::resp_body_json(resp)
  table <- body$tables[[1]]
  cols <- vapply(table$columns, function(c) c$name, character(1))
  rows <- table$rows
  if (length(rows) == 0) {
    res <- as.data.frame(matrix(nrow = 0, ncol = length(cols)))
    names(res) <- cols
    attr(res, "status") <- "OK_EMPTY"
    return(res)
  }
  df <- as.data.frame(do.call(rbind, lapply(rows, function(r) unlist(r))), stringsAsFactors = FALSE)
  names(df) <- cols
  attr(df, "status") <- "OK"
  df
}

#' Load per-user, per-entry-point telemetry touches for the configured
#' analysis window (kql/04_user_entrypoint_touches.kql).
#'
#' @return data.frame(user_Id, name, last_seen, duration_seconds, touches)
#'   or empty data.frame with attr(status) = "UNKNOWN" if unavailable.
load_telemetry_touches <- function(cfg, kql_dir, entry_point_filter = NULL) {
  days <- cfg$telemetry$telemetry_days
  if (is.null(days) || !is.numeric(days) || days <= 0) {
    stop("telemetry_days must be a positive number set in config.yml (got: ", days, ")")
  }
  if (days < (cfg$telemetry$min_recommended_days %||% 14)) {
    log_warn("data_telemetry",
              "telemetry_days=%s is below the recommended minimum (%s); seasonal/rare processes may be missed",
              days, cfg$telemetry$min_recommended_days)
  }

  filter_clause <- if (is.null(entry_point_filter)) "" else sprintf('and name == "%s"', entry_point_filter)

  kql <- render_kql(
    file.path(kql_dir, "04_user_entrypoint_touches.kql"),
    vars = list(telemetry_days = days, entry_point_filter = filter_clause)
  )
  run_kql_query(kql, cfg)
}
