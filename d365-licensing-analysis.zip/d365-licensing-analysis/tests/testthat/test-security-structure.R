test_that("analyze_security_structure joins role requirements onto secgov rows correctly", {
  secgov <- data.frame(
    ROLENAME = c("RoleA", "RoleA", "RoleB"),
    DUTYNAME = c("DutyA1", "DutyA1", "DutyB1"),
    PRIVILEGENAME = c("PrivA1", "PrivA2", "PrivB1"),
    ENTRYPOINTNAME = c("EPA1", "EPA2", "EPB1"),
    stringsAsFactors = FALSE
  )
  role_req <- data.frame(
    SECURITYROLE = c("RoleA", "RoleB"),
    ENTITLED = c(1, 0),
    ACCESSLEVEL = c("CREATE", "READ"),
    SKUNAME = c("Finance", NA),
    stringsAsFactors = FALSE
  )

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))

  expect_equal(nrow(out), 3)
  expect_true(all(out$ENTITLED[out$ROLENAME == "RoleA"] == 1))
  expect_true(all(out$has_license_requirement_record))
})

test_that("analyze_security_structure marks rows without a matching role requirement", {
  secgov <- data.frame(ROLENAME = "RoleZ", DUTYNAME = "D1", PRIVILEGENAME = "P1", ENTRYPOINTNAME = "E1", stringsAsFactors = FALSE)
  role_req <- data.frame(SECURITYROLE = "RoleA", ENTITLED = 1, ACCESSLEVEL = "READ", SKUNAME = "Finance", stringsAsFactors = FALSE)

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))
  expect_false(out$has_license_requirement_record[out$ROLENAME == "RoleZ"])
})

test_that("analyze_role_metrics computes duty/privilege/entry-point counts and write ratio correctly", {
  sec <- data.frame(
    ROLENAME = c("RoleA", "RoleA", "RoleA", "RoleB"),
    DUTYNAME = c("D1", "D1", "D2", "D3"),
    PRIVILEGENAME = c("P1", "P2", "P3", "P4"),
    ENTRYPOINTNAME = c("EP1", "EP2", "EP3", "EP4"),
    ENTITLED = c(1, 1, 0, 1),
    ACCESSLEVEL = c("CREATE", "READ", "READ", "UPDATE"),
    SKUNAME = c("Finance", "Finance", NA, "Commerce"),
    stringsAsFactors = FALSE
  )

  out <- analyze_role_metrics(sec)
  role_a <- out[out$role == "RoleA", ]

  expect_equal(role_a$duty_count, 2)
  expect_equal(role_a$privilege_count, 3)
  expect_equal(role_a$entry_point_count, 3)
  expect_equal(role_a$license_relevant_entry_points, 2)  # only ENTITLED=1 rows
  expect_equal(role_a$write_entry_points, 1)   # EP1 (CREATE)
  # EP2 (READ, ENTITLED=1) and EP3 (READ, ENTITLED=0) are BOTH classified as
  # READ - classify_access_level() looks only at ACCESSLEVEL, not ENTITLED,
  # because "read/write entry points" describes the role's structure, not
  # its licensing relevance (that's covered separately by
  # license_relevant_entry_points above).
  expect_equal(role_a$read_entry_points, 2)    # EP2, EP3
  expect_equal(role_a$distinct_license_types, 1)  # only 'Finance', NA excluded
})

test_that("write_ratio is computed only over classified (read+write) entry points", {
  sec <- data.frame(
    ROLENAME = c("RoleA", "RoleA", "RoleA"),
    DUTYNAME = c("D1", "D1", "D1"),
    PRIVILEGENAME = c("P1", "P2", "P3"),
    ENTRYPOINTNAME = c("EP1", "EP2", "EP3"),
    ENTITLED = c(1, 1, 0),
    ACCESSLEVEL = c("CREATE", "READ", "READ"),
    SKUNAME = c("Finance", "Finance", NA),
    stringsAsFactors = FALSE
  )
  out <- analyze_role_metrics(sec)
  # 1 write / (1 write + 2 read) = 1/3
  expect_equal(out$write_ratio[out$role == "RoleA"], 1 / 3)
})

test_that("analyze_security_structure detects a text-vs-numeric join type mismatch and refuses to guess", {
  secgov <- data.frame(ROLENAME = c("Test-Administrator", "Guide-Manager"), stringsAsFactors = FALSE)
  # SECURITYROLE here mirrors the real-world case from the screenshot: a
  # numeric RecId, not a role display name.
  role_req <- data.frame(SECURITYROLE = c(99L, 412L), ENTITLED = c(1, 1),
                           ACCESSLEVEL = c("READ", "READ"), SKUNAME = c("Finance", "Commerce"),
                           stringsAsFactors = FALSE)

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))

  # Must NOT silently produce all-NA ENTITLED values - falls back to the
  # explicit UNKNOWN sentinel instead, per brief section 3.
  expect_true(all(out$ENTITLED == "UNKNOWN"))
})

test_that("analyze_security_structure joins correctly when an explicit numeric RecId column pair is provided", {
  secgov <- data.frame(
    ROLENAME = c("Test-Administrator", "Guide-Manager"),
    ROLERECID = c(99L, 412L),
    stringsAsFactors = FALSE
  )
  role_req <- data.frame(SECURITYROLE = c(99L, 412L), ENTITLED = c(1, 0),
                           ACCESSLEVEL = c("READ", "READ"), SKUNAME = c("Finance", NA),
                           stringsAsFactors = FALSE)

  out <- analyze_security_structure(
    secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()),
    role_join_column_secgov = "ROLERECID", role_join_column_req = "SECURITYROLE"
  )

  expect_equal(out$ENTITLED[out$ROLENAME == "Test-Administrator"], 1)
  expect_equal(out$ENTITLED[out$ROLENAME == "Guide-Manager"], 0)
})

test_that("analyze_security_structure works out of the box once SQL resolves SECURITYROLE to text (the production fix)", {
  # Mirrors sql/06_licensing_role_requirements.sql after adding the
  # INNER JOIN SECURITYROLE resolution: SECURITYROLE now arrives as TEXT,
  # matching USERSECGOVRELATEDOBJECTS.ROLENAME directly - no config override
  # needed, auto-detection should just work.
  secgov <- data.frame(ROLENAME = c("Test-Administrator", "Guide-Manager"), stringsAsFactors = FALSE)
  role_req <- data.frame(
    SECURITYROLERECID = c(99L, 412L),
    SECURITYROLE = c("Test-Administrator", "Guide-Manager"),   # resolved TEXT, not RecId
    ENTITLED = c(1, 1), ACCESSLEVEL = c("READ", "CREATE"), SKUNAME = c("Finance", "Commerce"),
    stringsAsFactors = FALSE
  )

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))

  expect_true(all(out$ENTITLED == 1))
  expect_equal(out$SKUNAME[out$ROLENAME == "Guide-Manager"], "Commerce")
})

test_that("analyze_role_metrics flags multiple distinct license SKUs on one role", {
  sec <- data.frame(
    ROLENAME = c("RoleMulti", "RoleMulti"),
    DUTYNAME = c("D1", "D2"), PRIVILEGENAME = c("P1", "P2"),
    ENTRYPOINTNAME = c("EP1", "EP2"),
    ENTITLED = c(1, 1), ACCESSLEVEL = c("READ", "READ"),
    SKUNAME = c("Finance", "Commerce"), stringsAsFactors = FALSE
  )
  out <- analyze_role_metrics(sec)
  expect_equal(out$distinct_license_types[out$role == "RoleMulti"], 2)
})

test_that("classify_access_level maps write operations correctly", {
  expect_equal(classify_access_level("CREATE"), "WRITE")
  expect_equal(classify_access_level("Update"), "WRITE")
  expect_equal(classify_access_level("READ"), "READ")
  expect_equal(classify_access_level(NA), "UNKNOWN")
})
