# Sources all pipeline R files once for the whole test suite.
# Avoids requiring a live DB connection: tests call the analyze_*()/rule_*()
# functions directly against fixture data.frames, never load_*() (which need cnn).

.root <- normalizePath(file.path(dirname(dirname(dirname(getwd())))), mustWork = FALSE)

.candidate_roots <- c(
  ".", "..", "../..",
  Sys.getenv("D365_PIPELINE_ROOT", unset = NA)
)

.find_root <- function() {
  for (candidate in c("../..", "..", ".")) {
    if (file.exists(file.path(candidate, "R", "connection.R"))) return(normalizePath(candidate))
  }
  stop("Could not locate project root containing R/connection.R from ", getwd())
}

root <- .find_root()

for (f in c("utils_logging.R", "connection.R", "data_users.R", "data_roles_licensing.R",
            "analyze_roles.R", "analyze_users_consolidated.R", "confidence.R",
            "findings_engine.R")) {
  source(file.path(root, "R", f))
}
