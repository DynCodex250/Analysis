-- =============================================================================
-- 08_licensing_privilege_requirements.sql
-- Purpose: Privilege-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 5.K of task brief / Section 7 of source document
--
-- NOTE: same RecId-vs-text caveat as 07_licensing_duty_requirements.sql -
-- verify column semantics against the view's own CREATE VIEW definition
-- before relying on any role/duty/privilege identifier column for joins.
-- =============================================================================
SELECT *
FROM LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW
WHERE (@EntitledOnly = 0 OR ENTITLED = 1);
