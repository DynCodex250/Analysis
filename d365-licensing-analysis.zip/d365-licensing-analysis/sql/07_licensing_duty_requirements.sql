-- =============================================================================
-- 07_licensing_duty_requirements.sql
-- Purpose: Duty-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 5.K of task brief / Section 7 of source document
--
-- NOTE: LICENSINGROLEREQUIREMENTSDETAILEDVIEW.SECURITYROLE turned out to be
-- a numeric RecId, not the display name (see 06_licensing_role_requirements.sql).
-- LICENSINGDUTYREQUIREMENTSDETAILEDVIEW likely carries the same pattern for
-- any role/duty identifier columns it exposes - inspect its column list and
-- underlying view definition (SSMS: right-click view > Script View as >
-- CREATE To, same as done for the role view) before trusting a text join on
-- it. Currently left as SELECT * pending that check (REQUIRES_VALIDATION).
-- =============================================================================
SELECT *
FROM LICENSINGDUTYREQUIREMENTSDETAILEDVIEW
WHERE (@EntitledOnly = 0 OR ENTITLED = 1);
