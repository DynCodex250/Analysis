# =========================================================================
# Production Test Runner for SQL-First Recursive Security Customizer
# =========================================================================

library(xml2)
library(dplyr)

# Setup directories
mock_aot_dir <- "C:/Users/Cedric/.gemini/antigravity-ide/scratch/security_harden/mock_aot"
output_dir <- "C:/Users/Cedric/.gemini/antigravity-ide/scratch/security_harden/output_wibu"

# Clean and recreate
unlink(mock_aot_dir, recursive = TRUE)
unlink(output_dir, recursive = TRUE)

dir.create(file.path(mock_aot_dir, "SecurityPrivilege"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(mock_aot_dir, "SecurityDuty"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(mock_aot_dir, "SecurityRole"), recursive = TRUE, showWarnings = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

# -------------------------------------------------------------------------
# 1. Create Mock Deep Nested AOT XMLs (Role -> SubRole -> Duty -> Privilege)
# -------------------------------------------------------------------------
message("Creating mock standard XML files for deep recursion...")

# Privilege E: Contains target item + keep item -> Replace
priv_e_xml <- '<?xml version="1.0" encoding="utf-8"?>
<AxSecurityPrivilege xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Name>PrivilegeE</Name>
  <Label>Privilege E</Label>
  <EntryPoints>
    <AxSecurityEntryPointReference>
      <ObjectName>ProdMultiUserDefaultProcess</ObjectName>
      <ObjectType>MenuItemAction</ObjectType>
    </AxSecurityEntryPointReference>
    <AxSecurityEntryPointReference>
      <ObjectName>KeepThisItem</ObjectName>
      <ObjectType>MenuItemDisplay</ObjectType>
    </AxSecurityEntryPointReference>
  </EntryPoints>
</AxSecurityPrivilege>'
writeLines(priv_e_xml, file.path(mock_aot_dir, "SecurityPrivilege", "PrivilegeE.xml"))

# Duty C: Contains Privilege E + standard -> Replace
duty_c_xml <- '<?xml version="1.0" encoding="utf-8"?>
<AxSecurityDuty xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Name>DutyC</Name>
  <Label>Duty C</Label>
  <Privileges>
    <AxSecurityPrivilegeReference>
      <Name>PrivilegeE</Name>
    </AxSecurityPrivilegeReference>
    <AxSecurityPrivilegeReference>
      <Name>SomeOtherStandardPrivilege</Name>
    </AxSecurityPrivilegeReference>
  </Privileges>
</AxSecurityDuty>'
writeLines(duty_c_xml, file.path(mock_aot_dir, "SecurityDuty", "DutyC.xml"))

# SubRole B: Contains Duty C + standard -> Replace
subrole_b_xml <- '<AxSecurityRole xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Name>SubRoleB</Name>
  <Label>SubRole B</Label>
  <Duties>
    <AxSecurityDutyReference>
      <Name>DutyC</Name>
    </AxSecurityDutyReference>
    <AxSecurityDutyReference>
      <Name>SomeOtherStandardDuty</Name>
    </AxSecurityDutyReference>
  </Duties>
</AxSecurityRole>'
writeLines(subrole_b_xml, file.path(mock_aot_dir, "SecurityRole", "SubRoleB.xml"))

# Role A: Contains SubRole B + standard -> Replace
role_a_xml <- '<?xml version="1.0" encoding="utf-8"?>
<AxSecurityRole xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Name>RoleA</Name>
  <Label>Role A</Label>
  <SubRoles>
    <AxSecurityRoleReference>
      <Name>SubRoleB</Name>
    </AxSecurityRoleReference>
    <AxSecurityRoleReference>
      <Name>SomeOtherStandardSubRole</Name>
    </AxSecurityRoleReference>
  </SubRoles>
</AxSecurityRole>'
writeLines(role_a_xml, file.path(mock_aot_dir, "SecurityRole", "RoleA.xml"))

# Role G1: GUID-named custom Role (translates label) -> Replace
role_g1_xml <- '<?xml version="1.0" encoding="utf-8"?>
<AxSecurityRole xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Name>90A9AA17-E474-40E4-A44D-8F8EEDD6AC30</Name>
  <Label>Logistik Mitarbeiter</Label>
  <Duties>
    <AxSecurityDutyReference>
      <Name>DutyC</Name>
    </AxSecurityDutyReference>
  </Duties>
</AxSecurityRole>'
writeLines(role_g1_xml, file.path(mock_aot_dir, "SecurityRole", "90A9AA17-E474-40E4-A44D-8F8EEDD6AC30.xml"))

# Role G2: GUID-named custom Role (non-sensible label -> falls back to original name) -> Replace
role_g2_xml <- '<?xml version="1.0" encoding="utf-8"?>
<AxSecurityRole xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Name>8F9D7E2B-1234-5678-ABCD-EF0123456789</Name>
  <Label>@SYS12345</Label>
  <Duties>
    <AxSecurityDutyReference>
      <Name>DutyC</Name>
    </AxSecurityDutyReference>
  </Duties>
</AxSecurityRole>'
writeLines(role_g2_xml, file.path(mock_aot_dir, "SecurityRole", "8F9D7E2B-1234-5678-ABCD-EF0123456789.xml"))

# Role Admin: Special Role flagged as System Administrator -> MUST remain Keep (untouched)
role_admin_xml <- '<?xml version="1.0" encoding="utf-8"?>
<AxSecurityRole xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Name>SysAdminRole</Name>
  <Label>System Administrator Role</Label>
  <IsSystemAdministrator>Yes</IsSystemAdministrator>
  <Duties>
    <AxSecurityDutyReference>
      <Name>DutyC</Name>
    </AxSecurityDutyReference>
  </Duties>
</AxSecurityRole>'
writeLines(role_admin_xml, file.path(mock_aot_dir, "SecurityRole", "SysAdminRole.xml"))

# -------------------------------------------------------------------------
# 2. Create Mock Database Data
# -------------------------------------------------------------------------
message("Creating mock database data...")
mock_db_data <- tibble::tribble(
  ~ROLEIDENTIFIER, ~SUBROLEIDENTIFIER, ~DUTYIDENTIFIER, ~PRIVILEGEIDENTIFIER, ~RESOURCE_, ~RESOURCETYPE,
  "RoleA", "SubRoleB", "DutyC", "PrivilegeE", "ProdMultiUserDefaultProcess", "MenuItemAction",
  "90A9AA17-E474-40E4-A44D-8F8EEDD6AC30", "", "DutyC", "PrivilegeE", "ProdMultiUserDefaultProcess", "MenuItemAction",
  "8F9D7E2B-1234-5678-ABCD-EF0123456789", "", "DutyC", "PrivilegeE", "ProdMultiUserDefaultProcess", "MenuItemAction",
  "SysAdminRole", "", "DutyC", "PrivilegeE", "ProdMultiUserDefaultProcess", "MenuItemAction"
)

# -------------------------------------------------------------------------
# 3. Run Customizer Pipeline
# -------------------------------------------------------------------------
mock_mode        <- TRUE
basePath         <- "C:/Users/Cedric"
target_menu_item <- "ProdMultiUserDefaultProcess"
aot_root         <- mock_aot_dir
output_dir       <- output_dir
mock_db_data     <- mock_db_data

source("C:/Users/Cedric/.gemini/antigravity-ide/scratch/security_harden/security_customizer.R")

# -------------------------------------------------------------------------
# 4. Verify generated files and assertions
# -------------------------------------------------------------------------
message("\n=== Verifying Test Results ===")

# A. Privilege E check
p_file <- file.path(output_dir, "_WIBU_PrivilegeE.xml")
stopifnot(file.exists(p_file))
p_doc <- read_xml(p_file)
stopifnot(xml_text(xml_find_first(p_doc, "/AxSecurityPrivilege/Name")) == "_WIBU_PrivilegeE")
stopifnot(length(xml_find_all(p_doc, "//EntryPoints/AxSecurityEntryPointReference")) == 1)
message("[SUCCESS] Privilege E subtracted and renamed correctly.")

# B. Duty C check
c_file <- file.path(output_dir, "_WIBU_DutyC.xml")
stopifnot(file.exists(c_file))
c_doc <- read_xml(c_file)
stopifnot(xml_text(xml_find_first(c_doc, "/AxSecurityDuty/Name")) == "_WIBU_DutyC")
stopifnot(xml_text(xml_find_first(c_doc, "//Privileges/AxSecurityPrivilegeReference[Name='_WIBU_PrivilegeE']")) == "_WIBU_PrivilegeE")
message("[SUCCESS] Duty C nested Privilege reference updated correctly.")

# C. SubRole B check
sb_file <- file.path(output_dir, "_WIBU_SubRoleB.xml")
stopifnot(file.exists(sb_file))
sb_doc <- read_xml(sb_file)
stopifnot(xml_text(xml_find_first(sb_doc, "//Duties/AxSecurityDutyReference[Name='_WIBU_DutyC']")) == "_WIBU_DutyC")
message("[SUCCESS] SubRole B nested Duty reference updated correctly.")

# D. Role A check
ra_file <- file.path(output_dir, "_WIBU_RoleA.xml")
stopifnot(file.exists(ra_file))
ra_doc <- read_xml(ra_file)
stopifnot(xml_text(xml_find_first(ra_doc, "//SubRoles/AxSecurityRoleReference[Name='_WIBU_SubRoleB']")) == "_WIBU_SubRoleB")
message("[SUCCESS] Role A nested SubRole reference updated correctly.")

# E. Naming verification for G1 (Sensible Label: Logistik Mitarbeiter -> _WIBU_Logistik_Mitarbeiter)
stopifnot(file.exists(file.path(output_dir, "_WIBU_Logistik_Mitarbeiter.xml")))
message("[SUCCESS] Custom GUID Role renamed using translated Label successfully.")

# F. Naming verification for G2 (Non-sensible Label: @SYS12345 -> falls back to original name)
fallback_file <- file.path(output_dir, "_WIBU_8F9D7E2B_1234_5678_ABCD_EF0123456789.xml")
stopifnot(file.exists(fallback_file))
message("[SUCCESS] Custom GUID Role fell back to original name successfully due to non-sensible Label.")

# G. Verify System Administrator Role safety check
sysadmin_key <- get_node_key("SysAdminRole", "Role")
stopifnot(exists(sysadmin_key, envir = nodes))
stopifnot(nodes[[sysadmin_key]]$decision == "Keep")
stopifnot(!file.exists(file.path(output_dir, "SysAdminRole.xml")))
stopifnot(!file.exists(file.path(output_dir, "_WIBU_SysAdminRole.xml")))
message("[SUCCESS] System Administrator Role bypassed modification and was successfully kept intact.")

# H. Verify XML Caching: Unique files read matches unique paths in cache env
cache_keys <- ls(xml_cache)
stopifnot(length(cache_keys) == 7) # PrivilegeE, DutyC, SubRoleB, RoleA, G1, G2, SysAdminRole
# Verify that get_xml_doc successfully reused parsed documents in memory instead of doing double disk reads
stopifnot(xml_read_counts[[cache_keys[1]]] >= 1)
message("[SUCCESS] XML Caching verified. All files read exactly once from disk.")

# I. Verify Deterministic Generation Order
# Check ordered_nodes list inside security_customizer execution environment
types_ordered <- map_chr(ordered_nodes, "type")
stopifnot(all(diff(match(types_ordered, c("Privilege", "Duty", "Role"))) >= 0))
message("[SUCCESS] Deterministic Generation Order verified (Privileges -> Duties -> Roles).")

# -------------------------------------------------------------------------
# 5. Verify Cycle Detection
# -------------------------------------------------------------------------
message("\n=== Testing Cycle Detection Engine ===")

# Reset nodes and states
rm(list = ls(nodes), envir = nodes)
rm(list = ls(node_states), envir = node_states)

# Create a manual cycle: Role1 -> Role2 -> Role1
p_key <- get_or_create_node("Role1", "Role")
c_key <- get_or_create_node("Role2", "Role")

nodes[[p_key]]$children <- c_key
nodes[[c_key]]$children <- p_key

# We set mock XML paths to avoid file missing errors during evaluation
nodes[[p_key]]$xml_path <- file.path(mock_aot_dir, "SecurityRole", "RoleA.xml")
nodes[[c_key]]$xml_path <- file.path(mock_aot_dir, "SecurityRole", "RoleA.xml")

# Run evaluate_node on p_key; it must detect the circular cycle and stop
cycle_passed <- tryCatch({
  evaluate_node(p_key)
  FALSE
}, error = function(e) {
  message(sprintf("[SUCCESS] Cycle detection successfully caught circular loop: %s", e$message))
  TRUE
})

stopifnot(cycle_passed)
message("\n=== ALL RECURSIVE TESTS PASSED SUCCESSFULLY! ===")
