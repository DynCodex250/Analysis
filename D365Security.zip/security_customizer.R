# =========================================================================
# D365FO Security Customizer & Hardening Script (Production-Grade Graph Engine)
# =========================================================================
# This script automates the identification and subtraction of security privileges
# for a given MenuItem/Resource using the D365Security library and SQL database.
# It implements a true graph-based recursive bottom-up decision engine
# (Replace vs. NoReplace) by building the graph directly from SQL relationships,
# caching XML documents, evaluating reference sets, and executing validations.
#
# All mutable state (graph, XML cache, report) lives inside a
# new_security_engine() instance instead of the global environment, so a
# single engine can process multiple target menu items in one run while
# keeping the XML/AOT-index cache warm across them, and so the decision
# logic can be unit tested without depending on script execution order.
# =========================================================================

library(DBI)
library(xml2)
library(dplyr)
library(purrr)

# Set security_customizer_autorun <- FALSE before source()-ing this file to
# get new_security_engine() and its helpers defined without loading the
# D365Security DB/AOT-lookup bootstrap below or running the real pipeline
# at the bottom of the file - this is how tests/testthat sources it (see
# test-security_customizer_engine.R). Only Pipeline Execution actually
# needs get_connection()/get_sql_security_hierarchy()/basePath to resolve
# to a real installation; the engine itself does not.
if (!exists("security_customizer_autorun")) security_customizer_autorun <- TRUE

if (security_customizer_autorun) {
  if (!exists("basePath")) basePath <- "c:/Users/CKAM"

  if (requireNamespace("D365Security", quietly = TRUE)) {
    #library(D365Security)
    devtools::load_all(paste0(basePath, "/Documents/RProjects/D365Security"))
  } else {
    message("Package 'D365Security' not installed. Sourcing source files locally...")
    source(paste0(basePath, "/Documents/RProjects/D365Security/R/find_security_object_file.R"))
    source(paste0(basePath, "/Documents/RProjects/D365Security/R/get_sql_security_hierarchy.R"))
    source(paste0(basePath, "/Documents/RProjects/D365Security/R/get_connection.R"))
  }
}

# -------------------------------------------------------------------------
# Configuration
# -------------------------------------------------------------------------
# target_menu_item/aot_root/output_dir/db_environment only matter to
# Pipeline Execution below (new_security_engine() itself takes aot_root/
# output_dir as explicit constructor arguments from the caller) - skipped
# together with the rest of autorun so a test source doesn't need basePath
# to resolve to anything real.
if (security_customizer_autorun) {
  if (!exists("mock_mode")) mock_mode <- FALSE

  # Every setting below can be overridden by defining the variable before
  # sourcing this script (same pattern as basePath/mock_mode above), instead
  # of editing these hardcoded defaults directly.
  if (!mock_mode) {
    if (!exists("target_menu_item")) target_menu_item <- "ProdMultiUserDefault"
    if (!exists("aot_root"))         aot_root         <- paste0(basePath, "/AppData/Local/Microsoft/Dynamics365/10.0.2645.90/PackagesLocalDirectory")
    if (!exists("output_dir"))       output_dir       <- paste0(basePath, "/Documents/RProjects/WIBU_Security/")
    if (!exists("db_environment"))   db_environment   <- "TST"
  }
}

# -------------------------------------------------------------------------
# Pure Helper Functions (no engine state - naming, labels, XML parsing)
# -------------------------------------------------------------------------
is_guid <- function(name) {
  grepl("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", name)
}

is_custom_object <- function(name, prefix = "_WIBU_") {
  prefix_bare <- sub("_+$", "", prefix)
  is_guid(name) || startsWith(toupper(name), toupper(prefix_bare))
}

is_sensible_label <- function(label) {
  if (is.null(label) || is.na(label) || !nzchar(label)) {
    return(FALSE)
  }
  # A label is not sensible if it is a system label ID starting with '@'
  if (grepl("^@", label)) return(FALSE)
  # A label is not sensible if it consists only of digits/spaces/special chars
  if (grepl("^[0-9_\\-\\s\\(\\)]+$", label)) return(FALSE)
  if (trimws(label) == "") return(FALSE)
  return(TRUE)
}

get_custom_name <- function(original_name, label = NULL, is_custom = FALSE, prefix = "_WIBU_") {
  if (is_custom && is_sensible_label(label)) {
    # Clean label
    clean_label <- gsub("^@", "", label)
    clean_label <- gsub("^[a-zA-Z0-9]+:", "", clean_label)
    clean_label <- gsub("[^a-zA-Z0-9_]+", "_", clean_label)
    clean_label <- gsub("[[:space:]]+", "_", clean_label)
    base_name <- clean_label
  } else {
    clean_name <- gsub("[^a-zA-Z0-9_]+", "_", original_name)
    clean_name <- gsub("[[:space:]]+", "_", clean_name)
    base_name <- clean_name
  }

  # Strip a pre-existing occurrence of the prefix (re-customizing an
  # already-prefixed object must not double it up), then apply it exactly
  # once. Substring-based, not regex, so an arbitrary prefix never needs
  # escaping here.
  prefix_bare <- sub("_+$", "", prefix)
  if (startsWith(toupper(base_name), toupper(prefix_bare))) {
    base_name <- substring(base_name, nchar(prefix_bare) + 1)
    base_name <- sub("^_+", "", base_name)
  }
  new_name <- paste0(prefix, base_name)

  new_name <- gsub("_+", "_", new_name)
  new_name <- gsub("_$", "", new_name)
  return(new_name)
}

get_xml_label <- function(xml_doc) {
  label_node <- xml_find_first(xml_doc, "/*[self::AxSecurityRole or self::AxSecurityDuty or self::AxSecurityPrivilege]/Label")
  if (!is.na(label_node)) {
    return(xml_text(label_node))
  }
  return(NULL)
}

get_node_key <- function(name, type) {
  # EntryPoints come from two sources that may differ in casing: SQL RESOURCE_
  # (collation-dependent) and XML <Name>/<ObjectName> (AOT-defined casing).
  # Normalise to lowercase so the exists() lookup is always case-insensitive.
  # All other types (Role, Duty, Privilege) are consistently cased in D365FO.
  key_name <- trimws(if (type == "EntryPoint") tolower(name) else name)
  paste(type, key_name, sep = "::")
}

# Deterministic dependency-first order within a single type group (e.g. all
# Replace Duties), using each node's own replaced_refs as the edge set - a
# Duty that Replace-references another Duty as subduty must be written
# after that subduty, or an AOT import of the generated files would hit a
# forward reference within the same object type. The whole-graph cycle
# check in evaluate_node() already guarantees this is acyclic by the time
# generation runs, so a plain post-order DFS suffices (visited-guard only
# for safety, not because a cycle is expected here).
topological_sort_by_type <- function(nodes_of_type) {
  if (length(nodes_of_type) == 0) return(list())
  by_key <- set_names(nodes_of_type, map_chr(nodes_of_type, ~ get_node_key(.x$name, .x$type)))
  visited <- character()
  ordered <- list()
  visit <- function(key) {
    if (key %in% visited || !key %in% names(by_key)) return(invisible(NULL))
    visited <<- c(visited, key)
    n <- by_key[[key]]
    dep_keys <- map_chr(n$replaced_refs, ~ get_node_key(.x$name, .x$type))
    for (d in dep_keys) visit(d)
    ordered[[length(ordered) + 1]] <<- n
  }
  for (key in names(by_key)) visit(key)
  ordered
}

parse_xml_references <- function(doc, type) {
  refs <- list()
  if (type == "Privilege") {
    eps <- xml_find_all(doc, "/AxSecurityPrivilege/EntryPoints/AxSecurityEntryPointReference")
    for (ep in eps) {
      obj_name <- trimws(xml_text(xml_find_first(ep, "ObjectName")))
      if (is.na(obj_name) || !nzchar(obj_name)) {
        obj_name <- trimws(xml_text(xml_find_first(ep, "Name")))
      }
      if (!is.na(obj_name) && nzchar(obj_name)) {
        refs[[length(refs) + 1]] <- list(name = obj_name, type = "EntryPoint")
      }
    }
    # A Privilege can also grant access via an embedded DirectAccessPermissions
    # collection (table/service/menu-item permissions declared inline, e.g.
    # <AxSecurityTablePermission>/<AxSecurityMenuItemPermission>), independent
    # of the EntryPoints collection above. Any entry whose Name matches an
    # in-scope EntryPoint (i.e. the target menu item) must be classified the
    # same way as a normal EntryPoint reference - otherwise a direct-access
    # grant to the target would silently bypass this engine entirely.
    dap <- xml_find_all(doc, "/AxSecurityPrivilege/DirectAccessPermissions/*")
    for (perm in dap) {
      obj_name <- xml_text(xml_find_first(perm, "Name"))
      if (!is.na(obj_name) && nzchar(obj_name)) {
        refs[[length(refs) + 1]] <- list(name = obj_name, type = "EntryPoint")
      }
    }
  } else if (type == "Duty") {
    subduties <- xml_find_all(doc, "/AxSecurityDuty/SubDuties/AxSecurityDutyReference/Name") |> xml_text()
    privs <- xml_find_all(doc, "/AxSecurityDuty/Privileges/AxSecurityPrivilegeReference/Name") |> xml_text()
    for (sd in subduties) {
      if (!is.na(sd) && nzchar(sd)) refs[[length(refs) + 1]] <- list(name = sd, type = "Duty")
    }
    for (p in privs) {
      if (!is.na(p) && nzchar(p)) refs[[length(refs) + 1]] <- list(name = p, type = "Privilege")
    }
  } else if (type == "Role") {
    subroles <- xml_find_all(doc, "/AxSecurityRole/SubRoles/AxSecurityRoleReference/Name") |> xml_text()
    duties <- xml_find_all(doc, "/AxSecurityRole/Duties/AxSecurityDutyReference/Name") |> xml_text()
    privs <- xml_find_all(doc, "/AxSecurityRole/Privileges/AxSecurityPrivilegeReference/Name") |> xml_text()
    for (sr in subroles) {
      if (!is.na(sr) && nzchar(sr)) refs[[length(refs) + 1]] <- list(name = sr, type = "Role")
    }
    for (d in duties) {
      if (!is.na(d) && nzchar(d)) refs[[length(refs) + 1]] <- list(name = d, type = "Duty")
    }
    for (p in privs) {
      if (!is.na(p) && nzchar(p)) refs[[length(refs) + 1]] <- list(name = p, type = "Privilege")
    }
  }
  return(refs)
}

# -------------------------------------------------------------------------
# AOT Index Builder (pure: filesystem in, index + scope-limitation
# warnings out - no engine/report state touched here)
# -------------------------------------------------------------------------
build_aot_index <- function(aot_root) {
  message("Building AOT index for fast security object lookup...")
  aot_index <- list()
  warnings_out <- character()

  if (dir.exists(aot_root)) {
    packages <- list.dirs(aot_root, recursive = FALSE, full.names = TRUE)
    models <- list.dirs(packages, recursive = FALSE, full.names = TRUE)
    all_subdirs <- list.dirs(models, recursive = FALSE, full.names = TRUE)

    categories <- c("Role", "Duty", "Privilege", "DirectAccess", "Policy")
    for (cat in categories) {
      category_pattern <- switch(
        cat,
        "Role"         = "SecurityRole",
        "Duty"         = "SecurityDuty",
        "Privilege"    = "SecurityPrivilege",
        "DirectAccess" = "DirectAccessPermission",
        "Policy"       = "AxSecurityPolicy"
      )
      target_dirs <- all_subdirs[grepl(category_pattern, basename(all_subdirs), ignore.case = TRUE)]

      # Fallback for flat directories (like mock tests)
      if (length(target_dirs) == 0) {
        all_dirs <- list.dirs(aot_root, recursive = TRUE, full.names = TRUE)
        target_dirs <- all_dirs[grepl(category_pattern, basename(all_dirs), ignore.case = TRUE)]
      }

      files <- list.files(path = target_dirs, pattern = "\\.xml$", full.names = TRUE)
      aot_index[[cat]] <- list(
        names = tolower(basename(files)),
        paths = files
      )
    }

    # "DirectAccess" and "Policy" are indexed for lookup completeness, but are
    # deliberately NOT part of the decision graph:
    #  - DirectAccess here means standalone AxSecurityDirectAccessPermission
    #    AOT objects (their own files under a DirectAccessPermission folder) -
    #    distinct from the <DirectAccessPermissions> collection embedded
    #    inside a Privilege's own XML, which IS handled (see
    #    parse_xml_references / process_replace_xml). Their reference schema
    #    and whether they can ever grant a menu item entry point has not been
    #    verified against real AOT data, so no decision logic is applied here
    #    rather than risk a false sense of coverage.
    #  - AxSecurityPolicy objects are row-level (XDS) filters, a separate
    #    security dimension from menu-item access grants; they cannot make an
    #    EntryPoint reachable or unreachable and therefore have no Keep /
    #    Replace / NoReplace meaning in this graph.
    # If either category actually contains files in this AOT, that's a known
    # scope limitation for every run of this engine, not a per-target fact -
    # returned here so the engine can seed every fresh report with it.
    unresolved_categories <- Filter(function(cat) length(aot_index[[cat]]$paths) > 0, c("DirectAccess", "Policy"))
    for (cat in unresolved_categories) {
      warnings_out <- c(
        warnings_out,
        sprintf(
          "%d %s object(s) found in this AOT are indexed but not evaluated by this engine (out of scope by design - see build_aot_index()). Access granted exclusively through such an object would not be detected.",
          length(aot_index[[cat]]$paths), cat
        )
      )
    }
  }

  list(index = aot_index, warnings = warnings_out)
}

# =========================================================================
# Security Engine Factory
# =========================================================================
# Persistent across run() calls: aot_index and the XML cache (that's the
# whole point of caching in a batch-of-menu-items scenario). Reset at the
# start of every run(): the graph and report, since Keep/Replace/NoReplace
# decisions are specific to one target menu item and must never leak into
# the evaluation of another.
new_security_engine <- function(aot_root, output_dir, custom_prefix = "_WIBU_") {

  aot_built <- build_aot_index(aot_root)
  aot_index <- aot_built$index
  aot_level_warnings <- aot_built$warnings

  xml_cache <- new.env(parent = emptyenv())
  xml_read_counts <- new.env(parent = emptyenv())

  nodes <- NULL
  node_states <- NULL
  call_stack <- NULL
  target_menu_item <- NULL
  report_data <- NULL

  reset_run_state <- function(menu_item) {
    nodes <<- new.env(parent = emptyenv())
    node_states <<- new.env(parent = emptyenv())
    call_stack <<- character()
    target_menu_item <<- menu_item
    report_data <<- list(
      target_menu_item = menu_item,
      resource_type = "Unknown",
      found_privileges = character(),
      found_duties = character(),
      found_roles = character(),
      direct_roles = character(),
      generated_duties = character(),
      generated_roles = character(),
      generated_xml_files = character(),
      warnings = aot_level_warnings,
      errors = character(),
      cycles = list(),
      sysadmin_roles = list()
    )
  }

  # -----------------------------------------------------------------------
  # 1. Fast AOT object lookup
  # -----------------------------------------------------------------------
  find_security_object_file_fast <- function(object_name, category) {
    idx <- aot_index[[category]]
    if (is.null(idx)) return(NULL)

    target_name <- tolower(paste0(object_name, ".xml"))
    match_pos <- which(idx$names == target_name)
    if (length(match_pos) > 0) {
      return(idx$paths[match_pos[1]])
    }
    return(NULL)
  }

  # -----------------------------------------------------------------------
  # 2. XML Caching Architecture
  # -----------------------------------------------------------------------
  get_xml_doc <- function(path) {
    if (is.null(path) || is.na(path) || !nzchar(path)) return(NULL)
    path_key <- tolower(path)
    if (!exists(path_key, envir = xml_cache, inherits = FALSE)) {
      doc <- tryCatch(read_xml(path), error = function(e) NULL)
      if (is.null(doc)) return(NULL)
      xml_cache[[path_key]] <- doc
      xml_read_counts[[path_key]] <- 1
    } else {
      xml_read_counts[[path_key]] <- xml_read_counts[[path_key]] + 1
    }
    return(xml_cache[[path_key]])
  }

  # -----------------------------------------------------------------------
  # Graph Nodes
  # -----------------------------------------------------------------------
  get_or_create_node <- function(name, type) {
    key <- get_node_key(name, type)
    if (!exists(key, envir = nodes, inherits = FALSE)) {
      nodes[[key]] <- list(
        name = name,
        type = type,
        label = NULL,
        children = character(),
        parents = character(),
        decision = "Unchanged",
        custom_name = NULL,
        xml_path = NULL,
        is_custom = FALSE,
        kept_refs = list(),
        replaced_refs = list(),
        removed_refs = list()
      )
      node_states[[key]] <- "unvisited"
    }
    return(key)
  }

  # SQL only carries a flat Role/SubRole -> Duty -> Privilege -> EntryPoint
  # chain and has no column for nested Duty -> Duty (subduty) references. SQL
  # still decides which objects are in scope (node$children); XML fills in the
  # edges between already-in-scope nodes that SQL cannot express, so bottom-up
  # recursion visits e.g. a referenced subduty before the duty that refers to it.
  resolve_structural_children <- function(node, xml_refs) {
    xml_child_keys <- xml_refs |>
      map_chr(~ get_node_key(.x$name, .x$type)) |>
      keep(~ exists(.x, envir = nodes, inherits = FALSE))
    union(node$children, xml_child_keys)
  }

  # -----------------------------------------------------------------------
  # Recursive Bottom-Up Decision Engine (Object-Based References)
  # -----------------------------------------------------------------------
  evaluate_node <- function(key) {
    if (!exists(key, envir = node_states, inherits = FALSE)) {
      node_states[[key]] <- "unvisited"
    }

    # Cycle Detection Check. Report and continue instead of stop() so one
    # cyclic branch doesn't abort evaluation of the rest of the hierarchy, and
    # so every cycle - not just the first one hit - ends up in the report.
    # The re-entrant call returns a conservative "Keep" placeholder without
    # touching nodes[[key]] or node_states[[key]] - the original, still-running
    # call for this node is left to finish and compute the real decision.
    if (node_states[[key]] == "processing") {
      cycle_start <- match(key, call_stack)
      cycle_path <- c(call_stack[cycle_start:length(call_stack)], key)
      report_data$cycles <<- c(report_data$cycles, list(cycle_path))
      warning(sprintf("[CIRCULAR REFERENCE] %s", paste(cycle_path, collapse = " -> ")))
      return("Keep")
    }

    node <- nodes[[key]]
    if (node$decision != "Unchanged") {
      return(node$decision)
    }

    call_stack <<- c(call_stack, key)
    on.exit(call_stack <<- call_stack[-length(call_stack)], add = TRUE)

    if (node$type == "EntryPoint") {
      node_states[[key]] <- "processing"
      if (trimws(tolower(node$name)) == trimws(tolower(target_menu_item))) {
        nodes[[key]]$decision <- "NoReplace"
      } else {
        nodes[[key]]$decision <- "Keep"
      }
      node_states[[key]] <- "visited"
      return(nodes[[key]]$decision)
    }

    node_states[[key]] <- "processing"

    # 1. Resolve this node's own XML source before recursing into children.
    #    Structural children must include XML-derived references (e.g. Duty ->
    #    Duty subduties) that the flat SQL hierarchy cannot express - recursing
    #    on SQL-only children would visit siblings out of order and read a
    #    still-"Unchanged" decision as an implicit Keep.
    path <- find_security_object_file_fast(node$name, node$type)
    if (is.null(path)) {
      # Missing AOT source is a data problem (wrong aot_root, deleted object,
      # stale model), not a security decision - surface it instead of letting
      # it masquerade as an ordinary NoReplace.
      report_data$warnings <<- c(
        report_data$warnings,
        sprintf("AOT source file not found for %s '%s' (key: %s) - treated as NoReplace without verification.",
                node$type, node$name, key)
      )
      # Still resolve its SQL children so they remain reachable even though
      # this node itself becomes NoReplace.
      invisible(map_chr(node$children, evaluate_node))
      nodes[[key]]$decision <- "NoReplace"
      node_states[[key]] <- "visited"
      return("NoReplace")
    }

    nodes[[key]]$xml_path <- path
    doc <- get_xml_doc(path)

    nodes[[key]]$label <- get_xml_label(doc)
    nodes[[key]]$is_custom <- is_custom_object(node$name, custom_prefix)

    # 2. Object-based Reference Decisions
    xml_refs <- parse_xml_references(doc, node$type)

    # 3. Recurse into the true structural children (SQL scope + XML structure)
    #    before classifying references, so every in-graph referenced node has
    #    already been resolved.
    invisible(map_chr(resolve_structural_children(node, xml_refs), evaluate_node))

    kept_refs <- list()
    replaced_refs <- list()
    removed_refs <- list()

    for (ref in xml_refs) {
      ref_key <- get_node_key(ref$name, ref$type)
      if (exists(ref_key, envir = nodes, inherits = FALSE)) {
        ref_decision <- nodes[[ref_key]]$decision
        if (ref_decision == "NoReplace") {
          removed_refs[[length(removed_refs) + 1]] <- ref
        } else if (ref_decision == "Replace") {
          replaced_refs[[length(replaced_refs) + 1]] <- ref
        } else {
          kept_refs[[length(kept_refs) + 1]] <- ref
        }
      } else {
        # Children not in the SQL graph default to Keep
        kept_refs[[length(kept_refs) + 1]] <- ref
      }
    }

    # System Administrator Bypass Verification
    is_sysadmin_node <- FALSE
    if (node$type == "Role") {
      sysadmin_val <- xml_text(xml_find_first(doc, "/AxSecurityRole/IsSystemAdministrator"))
      if (!is.na(sysadmin_val) && tolower(sysadmin_val) == "yes") {
        is_sysadmin_node <- TRUE
      }
    }

    # Final reference-based decision logic
    if (length(replaced_refs) == 0 && length(kept_refs) == 0) {
      decision <- "NoReplace"
      custom_name <- NULL
    } else if (length(removed_refs) > 0 || length(replaced_refs) > 0) {
      decision <- "Replace"
      custom_name <- get_custom_name(node$name, nodes[[key]]$label, nodes[[key]]$is_custom, custom_prefix)
    } else {
      decision <- "Keep"
      custom_name <- NULL
    }

    # Force System Administrator roles to remain unchanged. Record what was
    # actually found and done here - the technical report states only this,
    # not an unverifiable claim about the whole system (see write_technical_report).
    if (is_sysadmin_node) {
      forced <- decision != "Keep"
      report_data$sysadmin_roles <<- c(report_data$sysadmin_roles, list(list(
        key = key, name = node$name, forced = forced
      )))
      if (forced) {
        warning(sprintf("[SECURITY SYSTEM ADMIN] Role '%s' bypasses security and must remain untouched. Forcing decision to 'Keep'.", node$name))
        decision <- "Keep"
        custom_name <- NULL
      }
    }

    nodes[[key]]$decision <- decision
    nodes[[key]]$custom_name <- custom_name
    nodes[[key]]$kept_refs <- kept_refs
    nodes[[key]]$replaced_refs <- replaced_refs
    nodes[[key]]$removed_refs <- removed_refs

    node_states[[key]] <- "visited"
    return(decision)
  }

  # -----------------------------------------------------------------------
  # XML Writer & Mutator (Memory Caching & Order-Based)
  # -----------------------------------------------------------------------
  process_replace_xml <- function(key) {
    node <- nodes[[key]]
    if (is.null(node$xml_path)) return(NULL)

    # xml2 documents are external pointers with reference semantics - mutating
    # the cached instance directly would corrupt it for any other consumer
    # (multi-target batch runs, re-processing, future callers reusing the same
    # cache). xml2 has no public xml_clone(); round-tripping through
    # as.character()/read_xml() is the portable way to get an independent copy
    # so the cache stays a read-only source.
    doc <- read_xml(as.character(get_xml_doc(node$xml_path)))

    # 1. Update Name
    name_node <- xml_find_first(doc, "/*[self::AxSecurityRole or self::AxSecurityDuty or self::AxSecurityPrivilege]/Name")
    if (!is.na(name_node)) {
      xml_set_text(name_node, node$custom_name)
    }

    # 2. Update Label
    label_node <- xml_find_first(doc, "/*[self::AxSecurityRole or self::AxSecurityDuty or self::AxSecurityPrivilege]/Label")
    if (!is.na(label_node) && !is.null(node$label)) {
      xml_set_text(label_node, paste(sub("_+$", "", custom_prefix), node$label))
    }

    # 3. Update / Remove child references
    if (node$type == "Privilege") {
      eps <- xml_find_all(doc, "/AxSecurityPrivilege/EntryPoints/AxSecurityEntryPointReference")
      for (ep in eps) {
        obj_name <- xml_text(xml_find_first(ep, "ObjectName"))
        if (is.na(obj_name) || !nzchar(obj_name)) {
          obj_name <- xml_text(xml_find_first(ep, "Name"))
        }
        if (!is.na(obj_name) && tolower(obj_name) == tolower(target_menu_item)) {
          xml_remove(ep)
        }
      }
      # Mirror the same removal for embedded DirectAccessPermissions entries
      # (see parse_xml_references) so a direct-access grant to the target menu
      # item cannot survive a Replace just because it bypasses EntryPoints.
      dap <- xml_find_all(doc, "/AxSecurityPrivilege/DirectAccessPermissions/*")
      for (perm in dap) {
        obj_name <- xml_text(xml_find_first(perm, "Name"))
        if (!is.na(obj_name) && tolower(obj_name) == tolower(target_menu_item)) {
          xml_remove(perm)
        }
      }
    } else {
      ref_xpaths <- c(
        "AxSecurityRoleReference"      = "/AxSecurityRole/SubRoles/AxSecurityRoleReference",
        "AxSecurityDutyReference"      = "//*[self::AxSecurityRole or self::AxSecurityDuty]/Duties/AxSecurityDutyReference | //*[self::AxSecurityRole or self::AxSecurityDuty]/SubDuties/AxSecurityDutyReference",
        "AxSecurityPrivilegeReference" = "//*[self::AxSecurityRole or self::AxSecurityDuty]/Privileges/AxSecurityPrivilegeReference"
      )

      # Generic reference updating
      for (xpath_name in names(ref_xpaths)) {
        xpath <- ref_xpaths[[xpath_name]]
        refs <- xml_find_all(doc, xpath)
        for (ref in refs) {
          ref_name <- xml_text(xml_find_first(ref, "Name"))
          if (is.na(ref_name)) next

          child_type <- switch(
            xpath_name,
            "AxSecurityRoleReference"      = "Role",
            "AxSecurityDutyReference"      = "Duty",
            "AxSecurityPrivilegeReference" = "Privilege"
          )
          if (is.null(child_type)) next

          child_key <- get_node_key(ref_name, child_type)
          if (exists(child_key, envir = nodes, inherits = FALSE)) {
            child_dec <- nodes[[child_key]]$decision
            if (child_dec == "NoReplace") {
              xml_remove(ref)
            } else if (child_dec == "Replace") {
              xml_set_text(xml_find_first(ref, "Name"), nodes[[child_key]]$custom_name)
            }
          }
        }
      }
    }

    output_filepath <- file.path(output_dir, paste0(node$custom_name, ".xml"))
    write_xml(doc, output_filepath, options = "format")
    return(output_filepath)
  }

  # -----------------------------------------------------------------------
  # Name Collision Resolution
  # -----------------------------------------------------------------------
  # get_custom_name() derives a name from the object's label, so two
  # unrelated objects with similar labels (or the same label reused across
  # a Role/Duty/Privilege - all generated files land in the same flat
  # output_dir regardless of type) can collapse onto the same custom_name.
  # Left alone, the second file written would silently overwrite the first,
  # and anything referencing the overwritten name would point at the wrong
  # object. Run once, after all decisions are final, over the full set of
  # Replace nodes - not interleaved into evaluate_node() - so the result
  # does not depend on evaluation/traversal order: the same input hierarchy
  # always produces the same disambiguated names, which matters for
  # re-generating this menu item's customizations later without churn.
  resolve_name_collisions <- function() {
    replace_keys <- ls(nodes) |> keep(~ nodes[[.x]]$decision == "Replace")
    if (length(replace_keys) == 0) return(invisible(NULL))

    by_name <- split(replace_keys, map_chr(replace_keys, ~ nodes[[.x]]$custom_name))
    for (nm in names(by_name)) {
      colliding_keys <- by_name[[nm]]
      if (length(colliding_keys) <= 1) next

      # Sort so the assignment of _1, _2, ... is stable regardless of the
      # order evaluate_node() happened to visit these nodes in.
      colliding_keys <- sort(colliding_keys)
      for (i in seq_along(colliding_keys)) {
        key <- colliding_keys[i]
        disambiguated <- sprintf("%s_%d", nm, i)
        nodes[[key]]$custom_name <- disambiguated
      }
      report_data$warnings <<- c(
        report_data$warnings,
        sprintf(
          "Name collision: %d objects (%s) all produced custom name '%s'; disambiguated to '%s_1' .. '%s_%d'.",
          length(colliding_keys), paste(colliding_keys, collapse = ", "), nm, nm, nm, length(colliding_keys)
        )
      )
    }
  }

  # -----------------------------------------------------------------------
  # Graph Validation
  # -----------------------------------------------------------------------
  validate_graph_structure <- function() {
    all_keys <- ls(nodes)
    hard_issues <- character()

    for (key in all_keys) {
      node <- nodes[[key]]
      if (node$type == "EntryPoint") next

      # A node that was never visited exists in the graph but is unreachable
      # from any evaluated root role - not necessarily a bug in this engine,
      # but an oddity in the source data worth a human looking at it. Soft
      # signal only: goes to warnings, does not block generation.
      if (!exists(key, envir = node_states, inherits = FALSE) || node_states[[key]] != "visited") {
        report_data$warnings <<- c(
          report_data$warnings,
          sprintf("Node '%s' exists in the graph but was never evaluated (unreachable from any root role).", key)
        )
        next  # nothing else below is meaningful for an unresolved node
      }

      # "Empty after Replace" only makes sense for Replace itself: NoReplace is
      # supposed to end up with nothing left (that's why it collapsed), and
      # Keep by definition had nothing that needed replacing.
      if (node$decision == "Replace" && length(node$kept_refs) == 0 && length(node$replaced_refs) == 0) {
        hard_issues <- c(hard_issues, sprintf("Node '%s' is marked 'Replace' but has 0 remaining children.", key))
      }

      # Decision <-> source-file consistency. Only the missing-AOT-file branch
      # in evaluate_node is allowed to leave xml_path unset while deciding
      # anything other than NoReplace - this guards that invariant against
      # future changes to evaluate_node breaking it silently.
      if (node$decision != "NoReplace" && is.null(node$xml_path)) {
        hard_issues <- c(hard_issues, sprintf("Node '%s' has decision '%s' but no resolved AOT source file.", key, node$decision))
      }

      # A Replace reference must point at a node that exists AND is itself
      # Replace - unreachable by construction today (see classify loop in
      # evaluate_node), kept as a defensive guard against future changes to
      # that classification logic.
      for (ref in node$replaced_refs) {
        ref_key <- get_node_key(ref$name, ref$type)
        if (!exists(ref_key, envir = nodes, inherits = FALSE)) {
          hard_issues <- c(hard_issues, sprintf("Node '%s' references child '%s' which does not exist in graph.", key, ref_key))
        } else if (nodes[[ref_key]]$decision != "Replace") {
          hard_issues <- c(hard_issues, sprintf("Node '%s' references replaced child '%s', but child has decision '%s'.", key, ref_key, nodes[[ref_key]]$decision))
        }
      }
    }

    if (length(hard_issues) > 0) {
      stop(sprintf(
        "[GRAPH VALIDATION ERROR] %d issue(s) found - aborting before any XML is generated:\n%s",
        length(hard_issues),
        paste(sprintf("  - %s", hard_issues), collapse = "\n")
      ))
    }
    message("[GRAPH VALIDATION SUCCESS] Graph structure is consistent and free of structural errors.")
  }

  validate_generated_xmls <- function() {
    # Business rules (emptiness, dangling/orphaned references, decision
    # consistency) are the graph's job and were already enforced by
    # validate_graph_structure() BEFORE a single file was written - re-deriving
    # them here from the written XML would just be a second, independently
    # drifting implementation of the same rules. This is deliberately limited
    # to what only a written file can tell you: did it land on disk, and does
    # it parse back into what the graph decided it should be.
    generated_files <- report_data$generated_xml_files
    expected_root <- c(Role = "AxSecurityRole", Duty = "AxSecurityDuty", Privilege = "AxSecurityPrivilege")

    for (f in generated_files) {
      if (!file.exists(f)) {
        stop(sprintf("[VALIDATION ERROR] Expected generated file does not exist: %s", f))
      }

      doc <- tryCatch(read_xml(f), error = function(e) {
        stop(sprintf("[VALIDATION ERROR] XML file is not parseable: %s. Error: %s", f, e$message))
      })

      root_name <- xml_name(doc)
      written_name <- xml_text(xml_find_first(doc, "/*/Name"))
      expected_name <- tools::file_path_sans_ext(basename(f))

      node_key <- Find(function(k) identical(nodes[[k]]$custom_name, expected_name), ls(nodes))
      if (is.null(node_key)) {
        stop(sprintf("[VALIDATION ERROR] Generated file '%s' does not correspond to any node decided as Replace.", f))
      }
      node <- nodes[[node_key]]

      if (is.na(written_name) || written_name != expected_name) {
        stop(sprintf("[VALIDATION ERROR] '%s': written Name '%s' does not match the decided custom name '%s'.", f, written_name, expected_name))
      }
      if (is.na(root_name) || root_name != expected_root[[node$type]]) {
        stop(sprintf("[VALIDATION ERROR] '%s': root element '%s' does not match expected type '%s'.", f, root_name, expected_root[[node$type]]))
      }
    }
    message("[VALIDATION SUCCESS] All generated AOT XML files exist, parse, and match their graph decision.")
  }

  # -----------------------------------------------------------------------
  # Technical Report Generation
  # -----------------------------------------------------------------------
  write_technical_report <- function() {
    report_path <- file.path(output_dir, "technical_report.md")

    refraction_entries <- map_chr(ls(nodes), function(key) {
      node <- nodes[[key]]
      if (node$type == "EntryPoint") return("")
      sprintf("* `%s` \\rightarrow **%s** %s",
              node$name,
              node$decision,
              ifelse(is.null(node$custom_name), "", paste0("(Custom name: `", node$custom_name, "`)")))
    }) |> keep(~ .x != "")

    # Section 4 must state only what evaluate_node actually checked: which
    # Role nodes in THIS graph carry IsSystemAdministrator = Yes, and whether
    # forcing them back to Keep was necessary. It must not claim anything
    # about the rest of the system, because System Administrator's access
    # bypass is not represented in UserSecGovRelatedObjects and therefore
    # cannot be part of this SQL-derived graph in the first place - a role
    # with the flag set simply may never appear here to be checked.
    sysadmin_entries <- map_chr(report_data$sysadmin_roles, function(r) {
      sprintf(
        "* `%s` - IsSystemAdministrator = Yes; decision: **Keep**%s.",
        r$name,
        if (r$forced) " (forced back from a would-be Replace/NoReplace)" else " (already Keep independently)"
      )
    })
    sysadmin_section <- if (length(sysadmin_entries) > 0) {
      c(
        sprintf("%d role(s) with `IsSystemAdministrator = Yes` were found in this menu item's security graph and verified to remain `Keep`:", length(sysadmin_entries)),
        "",
        sysadmin_entries
      )
    } else {
      c("No role with `IsSystemAdministrator = Yes` appears in this menu item's SQL-derived security graph.",
        "This does not mean no System Administrator access exists - the bypass is not represented in `UserSecGovRelatedObjects` and such a role may simply never appear in this hierarchy to be checked.")
    }

    report_content <- c(
      "# Technical Security Audit & Hardening Report",
      "",
      "## 1. General Info",
      sprintf("* **Date/Time**: %s", Sys.time()),
      sprintf("* **Target Security Resource**: `%s`", report_data$target_menu_item),
      sprintf("* **Resource Type**: %s", report_data$resource_type),
      "",
      "## 2. Analysis & Refraction Decisions",
      "Below is the classification of each security object in the hierarchy (Replace vs. NoReplace):",
      refraction_entries,
      "",
      "## 3. Customizations Implemented (_WIBU)",
      "### Generated Custom Duties",
      if (length(report_data$generated_duties) > 0) {
        paste(paste0("* `", report_data$generated_duties, "`"), collapse = "\n")
      } else {
        "* None"
      },
      "",
      "### Generated Custom Roles",
      if (length(report_data$generated_roles) > 0) {
        paste(paste0("* `", report_data$generated_roles, "`"), collapse = "\n")
      } else {
        "* None"
      },
      "",
      "### Generated XML Files",
      if (length(report_data$generated_xml_files) > 0) {
        paste(paste0("* [", basename(report_data$generated_xml_files), "](file:///", report_data$generated_xml_files, ")"), collapse = "\n")
      } else {
        "* None"
      },
      "",
      "## 4. Security Verification (System Administrator Check)",
      sysadmin_section,
      "",
      "> [!NOTE]",
      "> This check covers only roles carrying `IsSystemAdministrator = Yes` that appear in this menu item's SQL-derived security graph. It is not an empirical, system-wide confirmation of who can still open this menu item after the `_WIBU` objects are deployed - that would require re-querying the security hierarchy (or the target environment) after import.",
      "",
      "## 5. Diagnostic Logs",
      "### Warnings",
      if (length(report_data$warnings) > 0) {
        paste(paste0("* [WARNING] ", report_data$warnings), collapse = "\n")
      } else {
        "* None"
      },
      "",
      "### Errors",
      if (length(report_data$errors) > 0) {
        paste(paste0("* [ERROR] ", report_data$errors), collapse = "\n")
      } else {
        "* None"
      }
    )

    writeLines(report_content, report_path)
    message("Technical report successfully written to: ", report_path)
    invisible(report_path)
  }

  # -----------------------------------------------------------------------
  # Graph construction from the SQL hierarchy (pure SQL-first mapping)
  # -----------------------------------------------------------------------
  build_graph_from_hierarchy <- function(hierarchy) {
    for (i in seq_len(nrow(hierarchy))) {
      row <- hierarchy[i, ]

      path_elements <- list()
      if ("ROLEIDENTIFIER" %in% names(row) && !is.na(row$ROLEIDENTIFIER) && trimws(row$ROLEIDENTIFIER) != "") {
        path_elements[[length(path_elements) + 1]] <- list(name = trimws(row$ROLEIDENTIFIER), type = "Role")
      }
      if ("SUBROLEIDENTIFIER" %in% names(row) && !is.na(row$SUBROLEIDENTIFIER) && trimws(row$SUBROLEIDENTIFIER) != "") {
        path_elements[[length(path_elements) + 1]] <- list(name = trimws(row$SUBROLEIDENTIFIER), type = "Role")
      }
      if ("DUTYIDENTIFIER" %in% names(row) && !is.na(row$DUTYIDENTIFIER) && trimws(row$DUTYIDENTIFIER) != "") {
        path_elements[[length(path_elements) + 1]] <- list(name = trimws(row$DUTYIDENTIFIER), type = "Duty")
      }
      if ("PRIVILEGEIDENTIFIER" %in% names(row) && !is.na(row$PRIVILEGEIDENTIFIER) && trimws(row$PRIVILEGEIDENTIFIER) != "") {
        path_elements[[length(path_elements) + 1]] <- list(name = trimws(row$PRIVILEGEIDENTIFIER), type = "Privilege")
      }
      if ("RESOURCE_" %in% names(row) && !is.na(row$RESOURCE_) && trimws(row$RESOURCE_) != "") {
        path_elements[[length(path_elements) + 1]] <- list(name = trimws(row$RESOURCE_), type = "EntryPoint")
      }

      if (length(path_elements) > 1) {
        for (j in 1:(length(path_elements) - 1)) {
          parent_el <- path_elements[[j]]
          child_el <- path_elements[[j + 1]]

          p_key <- get_or_create_node(parent_el$name, parent_el$type)
          c_key <- get_or_create_node(child_el$name, child_el$type)

          curr_parent <- nodes[[p_key]]
          curr_child <- nodes[[c_key]]

          if (!(c_key %in% curr_parent$children)) {
            nodes[[p_key]]$children <- c(curr_parent$children, c_key)
          }
          if (!(p_key %in% curr_child$parents)) {
            nodes[[c_key]]$parents <- c(curr_child$parents, p_key)
          }
        }
      }
    }
  }

  # -----------------------------------------------------------------------
  # Pipeline Orchestration
  # -----------------------------------------------------------------------
  run <- function(menu_item, hierarchy) {
    menu_item <- trimws(menu_item)
    if (nrow(hierarchy) == 0) {
      stop("No security hierarchy mappings found for menu item: ", menu_item)
    }

    reset_run_state(menu_item)
    report_data$resource_type <<- unique(hierarchy$RESOURCETYPE)[1]

    message("Building graph from SQL security hierarchy...")
    build_graph_from_hierarchy(hierarchy)

    message("\n2. Running Bottom-Up Refraction Decisions...")
    all_keys <- ls(nodes)
    root_roles <- unique(hierarchy$ROLEIDENTIFIER) |> discard(~ is.na(.x) || .x == "")
    for (r in root_roles) {
      r_key <- get_node_key(r, "Role")
      if (exists(r_key, envir = nodes, inherits = FALSE)) {
        evaluate_node(r_key)
      }
    }

    # Circular references make any decision touching the cycle unreliable
    # (see evaluate_node's cycle handling). Traversal of the rest of the
    # hierarchy was still allowed to complete so every cycle - not just the
    # first - is known; now stop before anything is written, with the full list.
    if (length(report_data$cycles) > 0) {
      cycle_report <- map_chr(report_data$cycles, ~ paste(.x, collapse = " -> "))
      stop(sprintf(
        "[CIRCULAR REFERENCE ERROR] %d circular reference(s) found - aborting before any XML is generated:\n%s",
        length(report_data$cycles),
        paste(sprintf("  - %s", cycle_report), collapse = "\n")
      ))
    }

    resolve_name_collisions()
    validate_graph_structure()

    message("\n3. Generating custom XML AOT objects...")
    replace_nodes <- keep(map(all_keys, ~ nodes[[.x]]), ~ .x$decision == "Replace")
    ordered_nodes <- c(
      topological_sort_by_type(keep(replace_nodes, ~ .x$type == "Privilege")),
      topological_sort_by_type(keep(replace_nodes, ~ .x$type == "Duty")),
      topological_sort_by_type(keep(replace_nodes, ~ .x$type == "Role"))
    )

    for (node in ordered_nodes) {
      key <- get_node_key(node$name, node$type)
      path <- process_replace_xml(key)
      if (!is.null(path)) {
        report_data$generated_xml_files <<- c(report_data$generated_xml_files, path)
        if (node$type == "Duty") {
          report_data$generated_duties <<- c(report_data$generated_duties, node$custom_name)
        } else if (node$type == "Role") {
          report_data$generated_roles <<- c(report_data$generated_roles, node$custom_name)
        }
      }
    }

    # Populate metadata lists
    node_list <- map(all_keys, ~ nodes[[.x]])
    report_data$found_privileges <<- keep(node_list, ~ .x$type == "Privilege") |> map_chr("name") |> unique()
    report_data$found_duties     <<- keep(node_list, ~ .x$type == "Duty") |> map_chr("name") |> unique()
    report_data$found_roles      <<- keep(node_list, ~ .x$type == "Role") |> map_chr("name") |> unique()

    message("\n4. Running Post-Generation Validation Phase...")
    validate_generated_xmls()

    message("\n5. Writing technical report...")
    write_technical_report()

    accessed <- ls(xml_read_counts)
    total_accesses <- sum(map_dbl(accessed, ~ xml_read_counts[[.x]]))
    message(sprintf(
      "XML cache: %d unique file(s), %d total access(es), %d cache hit(s).",
      length(accessed), total_accesses, total_accesses - length(accessed)
    ))

    invisible(report_data)
  }

  list(
    run = run,
    get_report = function() report_data,
    get_nodes = function() nodes,
    get_aot_index = function() aot_index,
    cache_size = function() length(ls(xml_cache)),
    cache_stats = function() {
      counts <- ls(xml_read_counts)
      accesses <- map_dbl(counts, ~ xml_read_counts[[.x]])
      list(
        unique_files = length(counts),
        total_accesses = sum(accesses),
        cache_hits = sum(accesses) - length(counts)
      )
    }
  )
}

# -------------------------------------------------------------------------
# Pipeline Execution
# -------------------------------------------------------------------------
if (security_customizer_autorun) {
  message("1. Querying security mappings...")
  if (!mock_mode) {
    con <- get_connection(db_environment)
    on.exit({
      if (exists("con") && DBI::dbIsValid(con)) dbDisconnect(con)
    })

    hierarchy <- get_sql_security_hierarchy(con = con, resources = target_menu_item)
  } else {
    hierarchy <- mock_db_data |> filter(tolower(RESOURCE_) == tolower(target_menu_item))
  }

  if (!exists("custom_prefix")) custom_prefix <- "_WIBU_"

  engine <- new_security_engine(aot_root = aot_root, output_dir = output_dir, custom_prefix = custom_prefix)
  report_data <- engine$run(target_menu_item, hierarchy)

  message("\n=== FERTIG! Custom-Sicherheitsdateien liegen in: ", output_dir)
}
