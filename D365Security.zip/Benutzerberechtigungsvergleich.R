# =========================================================================
# Demonstration / Berechtigungsvergleich
# =========================================================================
# In diesem Skript wird die Verwendung der sieben neuen Funktionen demonstriert:
# 1. sec_compare_to_reference_user_details()
# 2. sec_create_permission_matrix()
# 3. sec_compare_user_permissions_fingerprint()
# 4. export_permission_matrix_sheet()
# 5. sec_create_permission_groups()
# 6. compare_users_complete()
# 7. sec_create_role_matrix()
# 8. get_sql_user_role_assignments()

# Bibliotheken laden
library(dplyr)
library(purrr)
library(tibble)
library(tidyr)
library(DBI)

# Lokale Funktionsdateien sourcen
source("R/sec_compare_to_reference_user_details.R")
source("R/sec_create_permission_matrix.R")
source("R/sec_compare_user_permissions_fingerprint.R")
source("R/export_permission_matrix_sheet.R")
source("R/sec_create_permission_groups.R")
source("R/compare_users_complete.R")
source("R/sec_create_role_matrix.R")
source("R/get_sql_user_role_assignments.R")

# =========================================================================
# Mock-Daten vorbereiten (security_assignments / security_model)
# =========================================================================
security_model <- tibble::tibble(
  USERID = c(
    "s.o.", "s.o.",
    "s.t.", "s.t.", "s.t.",
    "a.b.", "a.b.", "a.b.",
    "x.y.", "x.y."
  ),
  SECURITYROLEIDENTIFIER = c(
    # s.o.
    "408D9823-E27F-417A-8888-111111111111", "C3B0DBE5-FDAE-4925-B162-21A3E0D04E2A",
    # s.t. (Reference User)
    "408D9823-E27F-417A-8888-111111111111", "C3B0DBE5-FDAE-4925-B162-21A3E0D04E2A", "E99D8F11-417A-417A-8888-222222222222",
    # a.b. (Identical to s.t.)
    "408D9823-E27F-417A-8888-111111111111", "C3B0DBE5-FDAE-4925-B162-21A3E0D04E2A", "E99D8F11-417A-417A-8888-222222222222",
    # x.y. (Different roles)
    "C3B0DBE5-FDAE-4925-B162-21A3E0D04E2A", "F88A2222-3333-4444-5555-666666666666"
  ),
  SECURITYROLENAME = c(
    # s.o.
    "_TEST Verkauf Innendienst Leitung", "_TEST Einkauf Mitarbeiter_ReadOnly",
    # s.t. (Reference User)
    "_TEST Verkauf Innendienst Leitung", "_TEST Einkauf Mitarbeiter_ReadOnly", "_TEST Projektmanagement",
    # a.b.
    "_TEST Verkauf Innendienst Leitung", "_TEST Einkauf Mitarbeiter_ReadOnly", "_TEST Projektmanagement",
    # x.y.
    "_TEST Einkauf Mitarbeiter_ReadOnly", "_TEST Systemadministrator"
  ),
  ORGANIZATIONID = c(
    "All", "All",
    "All", "All", "All",
    "All", "All", "All",
    "All", "DE10"
  )
)

# e definieren (sec_create_permission_matrix greift intern auf 'e' statt auf 'security_model' zu)
e <- security_model

# =========================================================================
# 1. Referenzvergleich ausführen (sec_compare_to_reference_user_details)
# =========================================================================
cat("\n=== 1. Referenzvergleich (Reference User: s.t.) ===\n")
details <- sec_compare_to_reference_user_details(
  security_assignments = security_model,
  reference_user = "s.t."
)
print(details)

# =========================================================================
# 2. Berechtigungsmatrix erzeugen (sec_create_permission_matrix)
# =========================================================================
cat("\n=== 2. Berechtigungsmatrix ===\n")
matrix_df <- sec_create_permission_matrix(
  security_model = security_model
)
print(matrix_df)

# =========================================================================
# 3. Fingerprint-Vergleich (sec_compare_user_permissions_fingerprint)
# =========================================================================
cat("\n=== 3. Fingerprint-Vergleich ===\n")
# Wir fügen ORGANIZATIONTYPE zu mock data hinzu, um den Fingerprint zu berechnen
security_assignments_with_type <- security_model |>
  dplyr::mutate(ORGANIZATIONTYPE = "OperatingUnit")

fingerprint_df <- sec_compare_user_permissions_fingerprint(
  security_assignments = security_assignments_with_type,
  required_columns = c("USERID", "SECURITYROLEIDENTIFIER", "ORGANIZATIONID", "ORGANIZATIONTYPE")
)
print(fingerprint_df)

# =========================================================================
# 4. Excel-Export (export_permission_matrix_sheet)
# =========================================================================
cat("\n=== 4. Excel-Export ===\n")
wb <- openxlsx::createWorkbook()
wb <- export_permission_matrix_sheet(
  wb = wb,
  sheet_name = "05_permission_matrix",
  x = matrix_df
)
# Speichern der Excel-Datei im Scratch-Verzeichnis, damit keine Reste im Workspace bleiben
excel_path <- "D365FO_Benutzerberechtigungsvergleich.xlsx"
openxlsx::saveWorkbook(wb, excel_path, overwrite = TRUE)
cat("Excel-Arbeitsmappe erfolgreich unter '", excel_path, "' gespeichert!\n", sep="")

# =========================================================================
# 5. Gruppierung nach identischen Berechtigungen (sec_create_permission_groups)
# =========================================================================
cat("\n=== 5. Gruppierung nach identischen Berechtigungen ===\n")
groups_df <- sec_create_permission_groups(
  fingerprint_analysis = fingerprint_df
)
print(groups_df)

# =========================================================================
# 6. Vollständiger Benutzervergleich (compare_users_complete)
# =========================================================================
cat("\n=== 6. Vollständiger Benutzervergleich ===\n")
comparison_df <- compare_users_complete(
  security_model = security_model
)
print(comparison_df)

# =========================================================================
# 7. Rollen-Matrix erzeugen (sec_create_role_matrix)
# =========================================================================
cat("\n=== 7. Rollen-Matrix ===\n")
role_matrix_df <- sec_create_role_matrix(
  security_assignments = security_model
)
print(role_matrix_df)

# =========================================================================
# 8. Benutzer-Rollenzuweisungen laden (get_sql_user_role_assignments)
# =========================================================================
cat("\n=== 8. SQL-Rollenzuweisungen laden ===\n")
# Mock-Verbindung definieren, da keine echte Datenbank vorhanden ist
setClass("MockConnection", contains = "DBIConnection")
setMethod("dbGetQuery", signature("MockConnection", "character"), function(conn, statement, ...) {
  cat("\n--- Generiertes SQL Query ---\n", statement, "\n-----------------------------\n")
  return(
    tibble::tibble(
      USERID = c("s.o.", "s.t."),
      SECURITYROLEIDENTIFIER = c("408D9823-E27F-417A-8888-111111111111", "C3B0DBE5-FDAE-4925-B162-21A3E0D04E2A"),
      SECURITYROLENAME = c("_TEST Verkauf Innendienst Leitung", "_TEST Einkauf Mitarbeiter_ReadOnly"),
      ORGANIZATIONID = c("All", "All")
    )
  )
})
con <- new("MockConnection")

assignments_df <- get_sql_user_role_assignments(
  con = con,
  user_ids = c("s.o.", "s.t."),
  role_names = "_TEST Verkauf Innendienst Leitung",
  organization_ids = "All"
)
print(assignments_df)






