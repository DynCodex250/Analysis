#' Formular-Buttons extrahieren
#'
#' Extrahiert alle ausführbaren
#' Button-Controls eines D365FO
#' Formulars.
#'
#' Unterstützte Typen:
#'
#' * Button
#' * MenuFunctionButton
#' * MenuButton
#' * DropDialogButton
#'
#' Die Funktion dient als Grundlage für:
#'
#' * Formular-Dokumentationen
#' * Release-Vergleiche
#' * Berechtigungsanalysen
#' * Menü-Item Analysen
#'
#' @param form_model Ergebnis von
#' analyze_form().
#'
#' @return Tibble mit:
#'
#' * ButtonType
#' * Name
#' * MenuItemName
#' * MenuItemType
#' * NeededPermission
#' * Label
#' * Parent
#' * Path
#'
#' @export
extract_form_buttons <- function(
    form_model){

  # ================================
  # EINGABEPARAMETER VALIDIEREN
  # ================================

  if(!inherits(
    form_model,
    "D365FormModel"
  )){

    stop(
      "form_model muss ein D365FormModel sein."
    )

  }

  # ================================
  # BUTTONS FILTERN
  # ================================

  buttons <-

    form_model$Controls |>

    dplyr::filter(

      Type %in% c(

        "Button",

        "MenuFunctionButton",

        "MenuButton",

        "DropDialogButton"

      )

    )

  # ================================
  # LEERES MODELL
  # ================================

  if(nrow(buttons) == 0){

    return(
      empty_form_buttons()
    )

  }

  # ================================
  # FACHMODELL ERSTELLEN
  # ================================

  result <-

    purrr::pmap_dfr(

      list(

        buttons$Name,

        buttons$Type,

        buttons$Parent,

        buttons$Path,

        buttons$Properties

      ),

      function(

        Name,

        Type,

        Parent,

        Path,

        Properties){

        tibble::tibble(

          ButtonType = Type,

          Name = Name,

          MenuItemName =
            get_property(
              Properties,
              "MenuItemName"
            ),

          MenuItemType =
            get_property(
              Properties,
              "MenuItemType"
            ),

          NeededPermission =
            get_property(
              Properties,
              "NeededPermission"
            ),

          Label =
            get_property(
              Properties,
              "Text"
            ),

          Parent = Parent,

          Path = Path

        )

      }

    )

  # ================================
  # ERGEBNIS ZURÜCKGEBEN
  # ================================

  return(result)

}
