# ================================================
# TESTDATEN
# ================================================

xml_with_controls <- xml2::read_xml('
<AxSecurityPrivilege>
  <EntryPoints>
    <AxSecurityEntryPointReference>
      <Name>SalesOrderView_MenuItemDisplay</Name>
      <Forms>
        <AxSecurityEntryPointReferenceForm>
          <Name>SalesTable</Name>
          <Controls>
            <AxSecurityEntryPointReferenceFormControl>
              <Name>SalesId</Name>
              <Grant>
                <Read>Allow</Read>
                <Invoke>Allow</Invoke>
              </Grant>
            </AxSecurityEntryPointReferenceFormControl>
            <AxSecurityEntryPointReferenceFormControl>
              <Name>CustAccount</Name>
              <Grant>
                <Read>Allow</Read>
              </Grant>
            </AxSecurityEntryPointReferenceFormControl>
          </Controls>
        </AxSecurityEntryPointReferenceForm>
      </Forms>
    </AxSecurityEntryPointReference>
  </EntryPoints>
</AxSecurityPrivilege>
')

xml_without_controls <- xml2::read_xml('
<AxSecurityPrivilege>
  <EntryPoints>
    <AxSecurityEntryPointReference>
      <Name>SalesOrderView_MenuItemDisplay</Name>
      <Forms>
        <AxSecurityEntryPointReferenceForm>
          <Name>SalesTable</Name>
          <Controls/>
        </AxSecurityEntryPointReferenceForm>
      </Forms>
    </AxSecurityEntryPointReference>
  </EntryPoints>
</AxSecurityPrivilege>
')

xml_no_entrypoints <- xml2::read_xml('
<AxSecurityPrivilege>
  <EntryPoints/>
</AxSecurityPrivilege>
')

# ================================================
# STRUKTUR
# ================================================

testthat::test_that("extract_controls gibt Tibble mit korrekten Spalten zurück", {
  result <- extract_controls(xml_with_controls)
  expect_true(tibble::is_tibble(result))
  expect_named(result, c("entrypoint", "form_name", "control_name", "grants"))
})

# ================================================
# ANZAHL
# ================================================

testthat::test_that("extract_controls liefert korrekte Anzahl Controls", {
  result <- extract_controls(xml_with_controls)
  expect_equal(nrow(result), 2)
})

# ================================================
# INHALT
# ================================================

testthat::test_that("extract_controls liest Control-Namen korrekt aus", {
  result <- extract_controls(xml_with_controls)
  expect_equal(result$control_name, c("SalesId", "CustAccount"))
})

testthat::test_that("extract_controls weist Controls korrekt dem EntryPoint und Formular zu", {
  result <- extract_controls(xml_with_controls)
  expect_true(all(result$entrypoint == "SalesOrderView_MenuItemDisplay"))
  expect_true(all(result$form_name  == "SalesTable"))
})

testthat::test_that("extract_controls sortiert Grants alphabetisch und trennt mit '|'", {
  result <- extract_controls(xml_with_controls)
  expect_equal(result$grants[[1]], "Invoke|Read")
  expect_equal(result$grants[[2]], "Read")
})

# ================================================
# LEERE ERGEBNISSE
# ================================================

testthat::test_that("extract_controls gibt leeres Tibble zurück wenn keine Controls vorhanden", {
  result <- extract_controls(xml_without_controls)
  expect_true(tibble::is_tibble(result))
  expect_equal(nrow(result), 0)
})

testthat::test_that("extract_controls gibt leeres Tibble zurück wenn keine EntryPoints vorhanden", {
  result <- extract_controls(xml_no_entrypoints)
  expect_true(tibble::is_tibble(result))
  expect_equal(nrow(result), 0)
})

# ================================================
# FEHLERBEHANDLUNG
# ================================================

testthat::test_that("extract_controls bricht bei ungültigem Input ab", {
  expect_error(extract_controls(NULL))
  expect_error(extract_controls(list()))
  expect_error(extract_controls(42L))
})
