library(testthat)

test_that("sec_compare_to_reference_user_details works correctly", {
  # Mock data
  mock_data <- tibble::tibble(
    USERID = c("ref.user", "ref.user", "user.same", "user.same", "user.diff", "user.diff"),
    SECURITYROLEIDENTIFIER = c("RoleA", "RoleB", "RoleA", "RoleB", "RoleA", "RoleC"),
    SECURITYROLENAME = c("Role A Name", "Role B Name", "Role A Name", "Role B Name", "Role A Name", "Role C Name")
  )
  
  # Run function
  res <- sec_compare_to_reference_user_details(mock_data, "ref.user")
  
  # Check output classes/columns
  expect_s3_class(res, "tbl_df")
  expect_equal(names(res), c("USERID", "Differenztyp", "SECURITYROLEIDENTIFIER", "SECURITYROLENAME"))
  
  # Check ref.user row
  ref_row <- res[res$USERID == "ref.user", ]
  expect_equal(ref_row$Differenztyp, "Referenz")
  expect_true(is.na(ref_row$SECURITYROLEIDENTIFIER))
  
  # Check user.same row (identical roles)
  same_row <- res[res$USERID == "user.same", ]
  expect_equal(same_row$Differenztyp, "Identisch")
  expect_true(is.na(same_row$SECURITYROLEIDENTIFIER))
  
  # Check user.diff row (missing and additional)
  diff_rows <- res[res$USERID == "user.diff", ]
  expect_equal(nrow(diff_rows), 2)
  
  missing_row <- diff_rows[diff_rows$Differenztyp == "Missing", ]
  expect_equal(missing_row$SECURITYROLEIDENTIFIER, "RoleB")
  
  additional_row <- diff_rows[diff_rows$Differenztyp == "Additional", ]
  expect_equal(additional_row$SECURITYROLEIDENTIFIER, "RoleC")
})

test_that("sec_compare_to_reference_user_details validation works", {
  bad_data <- tibble::tibble(
    USERID = "user1",
    BAD_COL = "RoleA"
  )
  expect_error(sec_compare_to_reference_user_details(bad_data, "user1"), "Folgende Spalten fehlen")
  
  good_data <- tibble::tibble(
    USERID = "user1",
    SECURITYROLEIDENTIFIER = "RoleA",
    SECURITYROLENAME = "Role A Name"
  )
  expect_error(sec_compare_to_reference_user_details(good_data, "non_existent"), "Referenzbenutzer nicht gefunden")
})
