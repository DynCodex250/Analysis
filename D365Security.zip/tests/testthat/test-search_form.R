# ================================================
# HILFSFUNKTION: Testdokumentation erstellen
# ================================================

make_documentation <- function() {

  result <- list(

    Metadata = list(Name = "SalesTable"),

    DataSources = tibble::tibble(
      DataSource       = c("SalesTable", "SalesLine"),
      Table            = c("SalesTable", "SalesLine"),
      ParentDataSource = c(NA_character_, "SalesTable"),
      JoinSource       = c(NA_character_, NA_character_)
    ),

    ReferenceGroups = tibble::tibble(
      Name                  = c("CustAccount_RG", "InvoiceAccount_RG"),
      DataSource            = c("SalesTable", "SalesTable"),
      ReferenceField        = c("CustAccount", "InvoiceAccount"),
      ReplacementFieldGroup = c("AccountNum", "AccountNum"),
      Label                 = c("Kundenkonto", "Rechnungskonto"),
      Parent                = c("HeaderGroup", "HeaderGroup"),
      Path                  = c(
        "HeaderGroup/CustAccount_RG",
        "HeaderGroup/InvoiceAccount_RG"
      )
    ),

    Grids = tibble::tibble(
      GridName      = c("SalesGrid", "InvoiceGrid"),
      DataSource    = c("SalesTable", "CustInvoiceJour"),
      Table         = c("SalesTable", "CustInvoiceJour"),
      DefaultAction = c(NA_character_, NA_character_),
      Parent        = c(NA_character_, NA_character_),
      Path          = c("SalesGrid", "InvoiceGrid")
    ),

    ActionPaneButtons = tibble::tibble(
      ActionPaneTab = c("ActionPaneTab0", "ActionPaneTab0"),
      ButtonGroup   = c("ButtonGroupPost", "ButtonGroupPost"),
      Button        = c("PostInvoice", "CancelInvoice"),
      MenuItemName  = c("SalesInvoice", "SalesCancelInvoice"),
      OpenMode      = c(NA_character_, NA_character_),
      Primary       = c(NA_character_, NA_character_),
      Big           = c(NA_character_, NA_character_),
      Path          = c(
        "ActionPane/PostInvoice",
        "ActionPane/CancelInvoice"
      )
    )
  )

  class(result) <- c("D365FormDocumentation", "list")
  result
}

# ================================================
# STRUKTUR
# ================================================

testthat::test_that("search_form gibt Tibble mit korrekten Spalten zurück", {

  result <- search_form(make_documentation(), "Invoice")

  expect_true(tibble::is_tibble(result))
  expect_named(result, c("ObjectType", "Name", "Path", "Source"))
})

# ================================================
# SUCHE ÜBER ALLE TYPEN
# ================================================

testthat::test_that("search_form findet Treffer in allen Objekttypen", {

  result <- search_form(make_documentation(), "Invoice")

  expect_true("ReferenceGroup" %in% result$ObjectType)
  expect_true("Grid"           %in% result$ObjectType)
  expect_true("ActionButton"   %in% result$ObjectType)
})

testthat::test_that("search_form liefert korrekte Source-Werte", {

  result <- search_form(make_documentation(), "Invoice")

  expect_true("ReferenceGroups"   %in% result$Source)
  expect_true("Grids"             %in% result$Source)
  expect_true("ActionPaneButtons" %in% result$Source)
})

# ================================================
# TYP-FILTER
# ================================================

testthat::test_that("search_form filtert korrekt nach type = 'ReferenceGroup'", {

  result <- search_form(make_documentation(), "Invoice", type = "ReferenceGroup")

  expect_true(nrow(result) > 0)
  expect_true(all(result$ObjectType == "ReferenceGroup"))
})

testthat::test_that("search_form filtert korrekt nach type = 'Grid'", {

  result <- search_form(make_documentation(), "Invoice", type = "Grid")

  expect_true(nrow(result) > 0)
  expect_true(all(result$ObjectType == "Grid"))
})

testthat::test_that("search_form filtert korrekt nach type = 'ActionButton'", {

  result <- search_form(make_documentation(), "Invoice", type = "ActionButton")

  expect_true(nrow(result) > 0)
  expect_true(all(result$ObjectType == "ActionButton"))
})

# ================================================
# CASE-INSENSITIVE
# ================================================

testthat::test_that("search_form sucht case-insensitive", {

  doc <- make_documentation()
  result_lower <- search_form(doc, "invoice")
  result_upper <- search_form(doc, "INVOICE")
  result_mixed <- search_form(doc, "Invoice")

  expect_equal(nrow(result_lower), nrow(result_upper))
  expect_equal(nrow(result_lower), nrow(result_mixed))
})

# ================================================
# DETAILANSICHT
# ================================================

testthat::test_that("search_form details = TRUE gibt ReferenceGroup-Vollstruktur zurück", {

  result <- search_form(
    make_documentation(), "Invoice",
    type    = "ReferenceGroup",
    details = TRUE
  )

  expect_true(tibble::is_tibble(result))
  expect_named(
    result,
    c("Name", "DataSource", "ReferenceField",
      "ReplacementFieldGroup", "Label", "Parent", "Path")
  )
})

testthat::test_that("search_form details = TRUE gibt Grid-Vollstruktur zurück", {

  result <- search_form(
    make_documentation(), "Invoice",
    type    = "Grid",
    details = TRUE
  )

  expect_true(tibble::is_tibble(result))
  expect_true("GridName"   %in% names(result))
  expect_true("DataSource" %in% names(result))
})

testthat::test_that("search_form details = TRUE gibt ActionButton-Vollstruktur zurück", {

  result <- search_form(
    make_documentation(), "Invoice",
    type    = "ActionButton",
    details = TRUE
  )

  expect_true(tibble::is_tibble(result))
  expect_true("Button"      %in% names(result))
  expect_true("MenuItemName" %in% names(result))
})

# ================================================
# KEINE TREFFER
# ================================================

testthat::test_that("search_form gibt leeres Tibble zurück wenn kein Treffer", {

  result <- search_form(make_documentation(), "XYZ_EXISTIERT_NICHT_99999")

  expect_true(tibble::is_tibble(result))
  expect_equal(nrow(result), 0)
  expect_named(result, c("ObjectType", "Name", "Path", "Source"))
})

# ================================================
# FEHLERBEHANDLUNG
# ================================================

testthat::test_that("search_form bricht ab wenn details = TRUE ohne type angegeben", {

  expect_error(search_form(make_documentation(), "Invoice", details = TRUE))
})

testthat::test_that("search_form bricht bei ungültigem documentation-Objekt ab", {

  expect_error(search_form(list(), "Invoice"))
  expect_error(search_form(NULL,  "Invoice"))
})
