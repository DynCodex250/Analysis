# ================================================
# TESTDATEN
# ================================================

xml_with_entities <- xml2::read_xml('
<AxSecurityPrivilege>
  <DataEntityPermissions>
    <AxSecurityDataEntityPermission>
      <Name>SalesOrderHeaderV2Entity</Name>
      <IntegrationMode>DataServices</IntegrationMode>
      <Grant>
        <Read>Allow</Read>
        <Create>Allow</Create>
      </Grant>
    </AxSecurityDataEntityPermission>
    <AxSecurityDataEntityPermission>
      <Name>SalesOrderLineV2Entity</Name>
      <IntegrationMode>DataServices</IntegrationMode>
      <Grant>
        <Read>Allow</Read>
      </Grant>
    </AxSecurityDataEntityPermission>
  </DataEntityPermissions>
</AxSecurityPrivilege>
')

xml_without_entities <- xml2::read_xml('
<AxSecurityPrivilege>
  <DataEntityPermissions/>
</AxSecurityPrivilege>
')

xml_entity_no_grant <- xml2::read_xml('
<AxSecurityPrivilege>
  <DataEntityPermissions>
    <AxSecurityDataEntityPermission>
      <Name>CustomerEntity</Name>
      <IntegrationMode>DataServices</IntegrationMode>
    </AxSecurityDataEntityPermission>
  </DataEntityPermissions>
</AxSecurityPrivilege>
')

# ================================================
# STRUKTUR
# ================================================

testthat::test_that("extract_data_entities gibt Tibble mit korrekten Spalten zurück", {
  result <- extract_data_entities(xml_with_entities)
  expect_true(tibble::is_tibble(result))
  expect_named(result, c("name", "integration_mode", "grants"))
})

# ================================================
# ANZAHL
# ================================================

testthat::test_that("extract_data_entities liefert korrekte Anzahl Entities", {
  result <- extract_data_entities(xml_with_entities)
  expect_equal(nrow(result), 2)
})

# ================================================
# INHALT
# ================================================

testthat::test_that("extract_data_entities liest Entity-Namen korrekt aus", {
  result <- extract_data_entities(xml_with_entities)
  expect_equal(
    result$name,
    c("SalesOrderHeaderV2Entity", "SalesOrderLineV2Entity")
  )
})

testthat::test_that("extract_data_entities liest IntegrationMode korrekt aus", {
  result <- extract_data_entities(xml_with_entities)
  expect_true(all(result$integration_mode == "DataServices"))
})

testthat::test_that("extract_data_entities sortiert Grants alphabetisch und trennt mit '|'", {
  result <- extract_data_entities(xml_with_entities)
  expect_equal(result$grants[[1]], "Create|Read")
  expect_equal(result$grants[[2]], "Read")
})

# ================================================
# LEERE ERGEBNISSE
# ================================================

testthat::test_that("extract_data_entities gibt leeres Tibble zurück wenn keine Entities vorhanden", {
  result <- extract_data_entities(xml_without_entities)
  expect_true(tibble::is_tibble(result))
  expect_equal(nrow(result), 0)
})

testthat::test_that("extract_data_entities verarbeitet Entity ohne Grant korrekt", {
  result <- extract_data_entities(xml_entity_no_grant)
  expect_equal(nrow(result), 1)
  expect_equal(result$name[[1]], "CustomerEntity")
  expect_equal(result$grants[[1]], "")
})

# ================================================
# FEHLERBEHANDLUNG
# ================================================

testthat::test_that("extract_data_entities bricht bei ungültigem Input ab", {
  expect_error(extract_data_entities(NULL))
  expect_error(extract_data_entities(list()))
  expect_error(extract_data_entities(42L))
})
