testthat::test_that(

  "Privilege folder contains only privileges",

  {

    xml_files <- list.files(
      testthat::test_path(
        "testdata/Privileges"
      ),
      pattern    = "\\.xml$",
      full.names = TRUE
    )

    invalid_files <- xml_files[
      !purrr::map_lgl(
        xml_files,
        ~ is_security_object_xml(
          xml_file    = .x,
          object_type = "AxSecurityPrivilege"
        )
      )
    ]

    expect_equal(
      length(invalid_files),
      0,
      info = paste(
        basename(invalid_files),
        collapse = ", "
      )
    )

  }

)
