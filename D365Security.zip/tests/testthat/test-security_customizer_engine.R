library(testthat)

# security_customizer.R lives at the project root, not in R/, so it is not
# part of the D365Security package and must be sourced explicitly here.
# security_customizer_autorun <- FALSE skips the DB connection / AOT scan /
# real pipeline run at the bottom of the file (and the D365Security
# devtools::load_all() bootstrap at the top) - only the pure helpers and
# new_security_engine() get defined. See the guard's own comment in
# security_customizer.R for details.
security_customizer_autorun <- FALSE
# local = TRUE: source() defaults to evaluating in the global environment
# regardless of caller, which would hide the autorun flag above (testthat
# runs each test file in its own environment, not globalenv) and would
# also leave new_security_engine() et al. defined somewhere this file's
# test_that() blocks cannot see them.
source(testthat::test_path("../../security_customizer.R"), local = TRUE)

# ---------------------------------------------------------------------
# Shared helpers for building a temporary, real-shaped AOT directory
# (Package/Model/AxSecurityXxx/*.xml) so new_security_engine() is always
# exercised through the real filesystem and real XML parsing - none of
# its internals are reachable for mocking/overriding from outside once
# encapsulated in the engine closure, which is the point of that design.
# ---------------------------------------------------------------------
make_aot_root <- function() {
  root <- file.path(tempdir(), paste0("aot_", as.integer(Sys.time()), "_", sample.int(1e6, 1)))
  for (cat_dir in c("AxSecurityRole", "AxSecurityDuty", "AxSecurityPrivilege", "AxSecurityPolicy")) {
    dir.create(file.path(root, "PackageFoo/ModelBar", cat_dir), recursive = TRUE)
  }
  root
}

write_aot <- function(aot_root, relpath, content) {
  writeLines(content, file.path(aot_root, "PackageFoo/ModelBar", relpath))
}

make_output_dir <- function() {
  d <- file.path(tempdir(), paste0("wibu_out_", as.integer(Sys.time()), "_", sample.int(1e6, 1)))
  dir.create(d)
  d
}

# ---------------------------------------------------------------------
# Synthetic scenario reproducing the Duty -> Duty (subduty) bug found in
# review: Duty A wraps Duty B only via an XML SubDuties reference, an edge
# SQL's flat single-DUTYIDENTIFIER schema never exposes. Before the fix,
# evaluate_node() recursed only over SQL-derived node$children, so A could
# be evaluated before B and read B's still-"Unchanged" decision as Keep.
# ---------------------------------------------------------------------
test_that("nested Duty subduty reference (XML-only) resolves correctly regardless of SQL row order", {
  aot_root <- make_aot_root()
  write_aot(aot_root, "AxSecurityRole/RoleR.xml", "<AxSecurityRole><Name>RoleR</Name><Label>@Lbl:RoleR</Label>
    <Duties>
      <AxSecurityDutyReference><Name>DutyA</Name></AxSecurityDutyReference>
      <AxSecurityDutyReference><Name>DutyB</Name></AxSecurityDutyReference>
    </Duties>
  </AxSecurityRole>")
  write_aot(aot_root, "AxSecurityDuty/DutyA.xml", "<AxSecurityDuty><Name>DutyA</Name><Label>@Lbl:DutyA</Label>
    <SubDuties><AxSecurityDutyReference><Name>DutyB</Name></AxSecurityDutyReference></SubDuties>
  </AxSecurityDuty>")
  write_aot(aot_root, "AxSecurityDuty/DutyB.xml", "<AxSecurityDuty><Name>DutyB</Name><Label>@Lbl:DutyB</Label>
    <Privileges><AxSecurityPrivilegeReference><Name>PrivP</Name></AxSecurityPrivilegeReference></Privileges>
  </AxSecurityDuty>")
  write_aot(aot_root, "AxSecurityPrivilege/PrivP.xml", "<AxSecurityPrivilege><Name>PrivP</Name><Label>@Lbl:PrivP</Label>
    <EntryPoints>
      <AxSecurityEntryPointReference><Name>TargetMenuItem</Name></AxSecurityEntryPointReference>
      <AxSecurityEntryPointReference><Name>OtherMenuItem</Name></AxSecurityEntryPointReference>
    </EntryPoints>
  </AxSecurityPrivilege>")

  hierarchy <- tibble::tibble(
    ROLEIDENTIFIER = c("RoleR", "RoleR"), ROLENAME = c("RoleR", "RoleR"),
    SUBROLEIDENTIFIER = NA_character_, SUBROLENAME = NA_character_,
    # DutyA has no privilege of its own in SQL - its row exists only so SQL
    # puts it in scope at all (SQL decides scope; XML fills in structure).
    # Its only path to the target is the XML-only subduty reference to B.
    DUTYIDENTIFIER = c("DutyB", "DutyA"), DUTYNAME = c("DutyB", "DutyA"),
    PRIVILEGEIDENTIFIER = c("PrivP", NA_character_), PRIVILEGENAME = c("PrivP", NA_character_),
    RESOURCE_ = "TargetMenuItem", RESOURCETYPE = "Menu Item Display"
  )

  engine <- new_security_engine(aot_root = aot_root, output_dir = make_output_dir())
  engine$run("TargetMenuItem", hierarchy)
  nodes <- engine$get_nodes()

  expect_equal(nodes[["Duty::DutyB"]]$decision, "Replace")
  expect_equal(nodes[["Duty::DutyA"]]$decision, "Replace",
    label = "DutyA (XML-only subduty wrapping DutyB) must also be Replace"
  )
  expect_equal(nodes[["Role::RoleR"]]$decision, "Replace")
})

test_that("engine reuses the XML cache across runs while keeping graph/report state isolated per run", {
  aot_root <- make_aot_root()
  write_aot(aot_root, "AxSecurityRole/RoleR.xml", "<AxSecurityRole><Name>RoleR</Name><Label>@Lbl:RoleR</Label>
    <Duties><AxSecurityDutyReference><Name>DutyB</Name></AxSecurityDutyReference></Duties>
  </AxSecurityRole>")
  write_aot(aot_root, "AxSecurityDuty/DutyB.xml", "<AxSecurityDuty><Name>DutyB</Name><Label>@Lbl:DutyB</Label>
    <Privileges><AxSecurityPrivilegeReference><Name>PrivP</Name></AxSecurityPrivilegeReference></Privileges>
  </AxSecurityDuty>")
  write_aot(aot_root, "AxSecurityPrivilege/PrivP.xml", "<AxSecurityPrivilege><Name>PrivP</Name><Label>@Lbl:PrivP</Label>
    <EntryPoints>
      <AxSecurityEntryPointReference><Name>TargetMenuItem</Name></AxSecurityEntryPointReference>
      <AxSecurityEntryPointReference><Name>OtherMenuItem</Name></AxSecurityEntryPointReference>
    </EntryPoints>
  </AxSecurityPrivilege>")

  hierarchy1 <- tibble::tibble(
    ROLEIDENTIFIER = "RoleR", ROLENAME = "RoleR",
    SUBROLEIDENTIFIER = NA_character_, SUBROLENAME = NA_character_,
    DUTYIDENTIFIER = "DutyB", DUTYNAME = "DutyB",
    PRIVILEGEIDENTIFIER = "PrivP", PRIVILEGENAME = "PrivP",
    RESOURCE_ = "TargetMenuItem", RESOURCETYPE = "Menu Item Display"
  )
  engine <- new_security_engine(aot_root = aot_root, output_dir = make_output_dir())
  engine$run("TargetMenuItem", hierarchy1)
  nodes1 <- engine$get_nodes()
  cache_after_run1 <- engine$cache_size()

  hierarchy2 <- hierarchy1
  hierarchy2$RESOURCE_ <- "OtherMenuItem"
  engine$run("OtherMenuItem", hierarchy2)
  nodes2 <- engine$get_nodes()

  expect_false(identical(nodes1, nodes2))
  expect_false(exists("EntryPoint::targetmenuitem", envir = nodes2, inherits = FALSE),
    label = "run 2's graph must not contain a node for run 1's target at all"
  )
  expect_equal(nodes2[["EntryPoint::othermenuitem"]]$decision, "NoReplace")
  expect_equal(engine$cache_size(), cache_after_run1,
    label = "cache must not grow for files already read in run 1"
  )
})

test_that("engine$run() aborts on a circular reference with a full path report, before writing anything", {
  aot_root <- make_aot_root()
  write_aot(aot_root, "AxSecurityRole/RoleC.xml", "<AxSecurityRole><Name>RoleC</Name><Label>@Lbl:RoleC</Label>
    <Duties><AxSecurityDutyReference><Name>DutyX</Name></AxSecurityDutyReference></Duties>
  </AxSecurityRole>")
  write_aot(aot_root, "AxSecurityDuty/DutyX.xml", "<AxSecurityDuty><Name>DutyX</Name><Label>@Lbl:DutyX</Label>
    <SubDuties><AxSecurityDutyReference><Name>DutyY</Name></AxSecurityDutyReference></SubDuties>
  </AxSecurityDuty>")
  write_aot(aot_root, "AxSecurityDuty/DutyY.xml", "<AxSecurityDuty><Name>DutyY</Name><Label>@Lbl:DutyY</Label>
    <SubDuties><AxSecurityDutyReference><Name>DutyX</Name></AxSecurityDutyReference></SubDuties>
  </AxSecurityDuty>")

  output_dir <- make_output_dir()
  hierarchy <- tibble::tibble(
    # Both DutyX and DutyY must appear as real SQL rows so both become real
    # in-scope nodes - if DutyY were only reachable via DutyX's XML subduty
    # reference (never a row of its own), it would correctly never enter
    # the graph at all and the cycle could never be hit.
    ROLEIDENTIFIER = c("RoleC", "RoleC"), ROLENAME = c("RoleC", "RoleC"),
    SUBROLEIDENTIFIER = NA_character_, SUBROLENAME = NA_character_,
    DUTYIDENTIFIER = c("DutyX", "DutyY"), DUTYNAME = c("DutyX", "DutyY"),
    PRIVILEGEIDENTIFIER = NA_character_, PRIVILEGENAME = NA_character_,
    RESOURCE_ = "TargetMenuItem", RESOURCETYPE = "Menu Item Display"
  )

  engine <- new_security_engine(aot_root = aot_root, output_dir = output_dir)
  expect_error(
    suppressWarnings(engine$run("TargetMenuItem", hierarchy)),
    regexp = "Duty::DutyX -> Duty::DutyY -> Duty::DutyX",
    fixed = TRUE
  )
  expect_length(list.files(output_dir), 0)
})

test_that("colliding custom names are deterministically disambiguated, no file overwrite, stable across re-runs", {
  aot_root <- make_aot_root()
  # get_custom_name() only derives the name from Label when the object's
  # OWN technical name already looks "custom" (GUID, or already prefixed) -
  # so to hit that path, both duties need GUID-like names; their labels are
  # what collide after sanitization.
  guid_one <- "aaaaaaaa-1111-1111-1111-111111111111"
  guid_two <- "bbbbbbbb-2222-2222-2222-222222222222"
  write_aot(aot_root, "AxSecurityRole/RoleD.xml", sprintf("<AxSecurityRole><Name>RoleD</Name><Label>@Lbl:RoleD</Label>
    <Duties>
      <AxSecurityDutyReference><Name>%s</Name></AxSecurityDutyReference>
      <AxSecurityDutyReference><Name>%s</Name></AxSecurityDutyReference>
    </Duties>
  </AxSecurityRole>", guid_one, guid_two))
  write_aot(aot_root, file.path("AxSecurityDuty", paste0(guid_one, ".xml")), sprintf(
    "<AxSecurityDuty><Name>%s</Name><Label>Sales Order</Label>
      <Privileges><AxSecurityPrivilegeReference><Name>PrivQ</Name></AxSecurityPrivilegeReference></Privileges>
    </AxSecurityDuty>", guid_one
  ))
  write_aot(aot_root, file.path("AxSecurityDuty", paste0(guid_two, ".xml")), sprintf(
    "<AxSecurityDuty><Name>%s</Name><Label>Sales-Order!!</Label>
      <Privileges><AxSecurityPrivilegeReference><Name>PrivQ</Name></AxSecurityPrivilegeReference></Privileges>
    </AxSecurityDuty>", guid_two
  ))
  write_aot(aot_root, "AxSecurityPrivilege/PrivQ.xml", "<AxSecurityPrivilege><Name>PrivQ</Name><Label>@Lbl:PrivQ</Label>
    <EntryPoints>
      <AxSecurityEntryPointReference><Name>TargetMenuItem</Name></AxSecurityEntryPointReference>
      <AxSecurityEntryPointReference><Name>OtherMenuItem</Name></AxSecurityEntryPointReference>
    </EntryPoints>
  </AxSecurityPrivilege>")

  output_dir <- make_output_dir()
  hierarchy <- tibble::tibble(
    ROLEIDENTIFIER = c("RoleD", "RoleD"), ROLENAME = c("RoleD", "RoleD"),
    SUBROLEIDENTIFIER = NA_character_, SUBROLENAME = NA_character_,
    DUTYIDENTIFIER = c(guid_one, guid_two), DUTYNAME = c(guid_one, guid_two),
    PRIVILEGEIDENTIFIER = "PrivQ", PRIVILEGENAME = "PrivQ",
    RESOURCE_ = "TargetMenuItem", RESOURCETYPE = "Menu Item Display"
  )

  engine <- new_security_engine(aot_root = aot_root, output_dir = output_dir)
  report <- engine$run("TargetMenuItem", hierarchy)
  nodes <- engine$get_nodes()

  key_one <- get_node_key(guid_one, "Duty")
  key_two <- get_node_key(guid_two, "Duty")
  name_one <- nodes[[key_one]]$custom_name
  name_two <- nodes[[key_two]]$custom_name

  expect_equal(nodes[[key_one]]$decision, "Replace")
  expect_equal(nodes[[key_two]]$decision, "Replace")
  expect_false(name_one == name_two)
  expect_match(name_one, "^_WIBU_Sales_Order_[12]$")
  expect_match(name_two, "^_WIBU_Sales_Order_[12]$")
  expect_true(file.exists(file.path(output_dir, paste0(name_one, ".xml"))))
  expect_true(file.exists(file.path(output_dir, paste0(name_two, ".xml"))))
  expect_true(any(grepl("Name collision", report$warnings, fixed = TRUE)))

  # Determinism: an independent second run on identical input must assign
  # the same disambiguated names - the resolution must not depend on
  # evaluation/traversal order.
  engine2 <- new_security_engine(aot_root = aot_root, output_dir = make_output_dir())
  engine2$run("TargetMenuItem", hierarchy)
  nodes2 <- engine2$get_nodes()
  expect_identical(nodes2[[key_one]]$custom_name, name_one)
  expect_identical(nodes2[[key_two]]$custom_name, name_two)
})

test_that("topological_sort_by_type() orders dependencies before dependents regardless of input order", {
  nodeA <- list(name = "A", type = "Duty", replaced_refs = list(list(name = "B", type = "Duty")))
  nodeB <- list(name = "B", type = "Duty", replaced_refs = list())
  nodeC <- list(name = "C", type = "Duty", replaced_refs = list(list(name = "A", type = "Duty")))

  ordered <- topological_sort_by_type(list(nodeC, nodeA, nodeB))
  ordered_names <- purrr::map_chr(ordered, "name")

  expect_setequal(ordered_names, c("A", "B", "C"))
  expect_lt(match("B", ordered_names), match("A", ordered_names))
  expect_lt(match("A", ordered_names), match("C", ordered_names))
})

test_that("custom_prefix is honored end-to-end in decisions, file names, and files on disk", {
  aot_root <- make_aot_root()
  write_aot(aot_root, "AxSecurityRole/RoleR.xml", "<AxSecurityRole><Name>RoleR</Name><Label>@Lbl:RoleR</Label>
    <Duties><AxSecurityDutyReference><Name>DutyB</Name></AxSecurityDutyReference></Duties>
  </AxSecurityRole>")
  write_aot(aot_root, "AxSecurityDuty/DutyB.xml", "<AxSecurityDuty><Name>DutyB</Name><Label>@Lbl:DutyB</Label>
    <Privileges><AxSecurityPrivilegeReference><Name>PrivP</Name></AxSecurityPrivilegeReference></Privileges>
  </AxSecurityDuty>")
  write_aot(aot_root, "AxSecurityPrivilege/PrivP.xml", "<AxSecurityPrivilege><Name>PrivP</Name><Label>@Lbl:PrivP</Label>
    <EntryPoints>
      <AxSecurityEntryPointReference><Name>TargetMenuItem</Name></AxSecurityEntryPointReference>
      <AxSecurityEntryPointReference><Name>OtherMenuItem</Name></AxSecurityEntryPointReference>
    </EntryPoints>
  </AxSecurityPrivilege>")

  output_dir <- make_output_dir()
  hierarchy <- tibble::tibble(
    ROLEIDENTIFIER = "RoleR", ROLENAME = "RoleR",
    SUBROLEIDENTIFIER = NA_character_, SUBROLENAME = NA_character_,
    DUTYIDENTIFIER = "DutyB", DUTYNAME = "DutyB",
    PRIVILEGEIDENTIFIER = "PrivP", PRIVILEGENAME = "PrivP",
    RESOURCE_ = "TargetMenuItem", RESOURCETYPE = "Menu Item Display"
  )

  engine <- new_security_engine(aot_root = aot_root, output_dir = output_dir, custom_prefix = "_ACME_")
  engine$run("TargetMenuItem", hierarchy)
  nodes <- engine$get_nodes()

  expect_match(nodes[["Duty::DutyB"]]$custom_name, "^_ACME_")
  expect_false(grepl("_WIBU_", nodes[["Duty::DutyB"]]$custom_name, fixed = TRUE))
  expect_true(file.exists(file.path(output_dir, paste0(nodes[["Duty::DutyB"]]$custom_name, ".xml"))))
})

test_that("cache_stats() reports consistent unique/total/hit counts", {
  aot_root <- make_aot_root()
  write_aot(aot_root, "AxSecurityRole/RoleR.xml", "<AxSecurityRole><Name>RoleR</Name><Label>@Lbl:RoleR</Label>
    <Duties><AxSecurityDutyReference><Name>DutyB</Name></AxSecurityDutyReference></Duties>
  </AxSecurityRole>")
  write_aot(aot_root, "AxSecurityDuty/DutyB.xml", "<AxSecurityDuty><Name>DutyB</Name><Label>@Lbl:DutyB</Label>
    <Privileges><AxSecurityPrivilegeReference><Name>PrivP</Name></AxSecurityPrivilegeReference></Privileges>
  </AxSecurityDuty>")
  write_aot(aot_root, "AxSecurityPrivilege/PrivP.xml", "<AxSecurityPrivilege><Name>PrivP</Name><Label>@Lbl:PrivP</Label>
    <EntryPoints><AxSecurityEntryPointReference><Name>TargetMenuItem</Name></AxSecurityEntryPointReference></EntryPoints>
  </AxSecurityPrivilege>")

  hierarchy <- tibble::tibble(
    ROLEIDENTIFIER = "RoleR", ROLENAME = "RoleR",
    SUBROLEIDENTIFIER = NA_character_, SUBROLENAME = NA_character_,
    DUTYIDENTIFIER = "DutyB", DUTYNAME = "DutyB",
    PRIVILEGEIDENTIFIER = "PrivP", PRIVILEGENAME = "PrivP",
    RESOURCE_ = "TargetMenuItem", RESOURCETYPE = "Menu Item Display"
  )
  engine <- new_security_engine(aot_root = aot_root, output_dir = make_output_dir())
  engine$run("TargetMenuItem", hierarchy)
  stats <- engine$cache_stats()

  expect_gt(stats$unique_files, 0)
  expect_gte(stats$total_accesses, stats$unique_files)
  expect_equal(stats$cache_hits, stats$total_accesses - stats$unique_files)
})

# ---------------------------------------------------------------------
# Real-world scenario: an unmodified Role/Duty/Privilege triple copied
# verbatim from tests/testdata (real customer security objects, not
# hand-authored fixtures) that happens to form a fully resolvable chain:
#
#   Role 028655f5-... --Duties--> Duty 7e7c192a-...
#     --Privileges--> Privilege 840a7725-...
#       --EntryPoints (ObjectName)--> SALESQUOTATIONLISTPAGE
#
# The Role also references five other duties and nine other privileges
# that are NOT part of this SQL hierarchy - they must stay untouched
# (Keep, external), exercising realistic partial processing of a role
# that is far larger than the one path relevant to this menu item. The
# Privilege also carries a real <DirectAccessPermissions> entry
# referencing a data entity (not a menu item), which must be silently
# ignored rather than mistaken for a grant to the target.
# ---------------------------------------------------------------------
test_that("real Role/Duty/Privilege objects from tests/testdata resolve and generate correctly", {
  testdata_root <- testthat::test_path("testdata")
  skip_if_not(dir.exists(testdata_root), "tests/testthat/testdata not present")

  role_guid <- "028655f5-fbf0-45d5-84b0-725fea4e5aa3"
  duty_guid <- "7e7c192a-9a81-4c58-bcee-16089cfdd054"
  priv_guid <- "840a7725-7109-4812-8480-d9cde16ef7a7"
  target <- "SALESQUOTATIONLISTPAGE"

  role_src <- file.path(testdata_root, "Roles", paste0(role_guid, ".xml"))
  duty_src <- file.path(testdata_root, "Duties", paste0(duty_guid, ".xml"))
  priv_src <- file.path(testdata_root, "Privileges", paste0(priv_guid, ".xml"))
  skip_if_not(all(file.exists(role_src, duty_src, priv_src)), "expected real testdata files not found")

  aot_root <- make_aot_root()
  file.copy(role_src, file.path(aot_root, "PackageFoo/ModelBar/AxSecurityRole", paste0(role_guid, ".xml")))
  file.copy(duty_src, file.path(aot_root, "PackageFoo/ModelBar/AxSecurityDuty", paste0(duty_guid, ".xml")))
  file.copy(priv_src, file.path(aot_root, "PackageFoo/ModelBar/AxSecurityPrivilege", paste0(priv_guid, ".xml")))

  output_dir <- make_output_dir()
  hierarchy <- tibble::tibble(
    ROLEIDENTIFIER = role_guid, ROLENAME = role_guid,
    SUBROLEIDENTIFIER = NA_character_, SUBROLENAME = NA_character_,
    DUTYIDENTIFIER = duty_guid, DUTYNAME = duty_guid,
    PRIVILEGEIDENTIFIER = priv_guid, PRIVILEGENAME = priv_guid,
    RESOURCE_ = target, RESOURCETYPE = "Menu Item Display"
  )

  engine <- new_security_engine(aot_root = aot_root, output_dir = output_dir)
  report <- engine$run(target, hierarchy)
  nodes <- engine$get_nodes()

  role_key <- get_node_key(role_guid, "Role")
  duty_key <- get_node_key(duty_guid, "Duty")
  priv_key <- get_node_key(priv_guid, "Privilege")

  expect_equal(nodes[[priv_key]]$decision, "Replace",
    label = "privilege has 1 removed entry point among ~35 kept ones"
  )
  expect_equal(nodes[[duty_key]]$decision, "Replace")
  expect_equal(nodes[[role_key]]$decision, "Replace")

  # custom_name must be derived from the real label ("_WIBU_Angebotsstatus_
  # abfragen"), not the GUID. In this real data the Duty and Privilege
  # happen to carry the EXACT SAME label - a genuine real-world instance of
  # the name collision P2 #12 exists to catch, not a hand-built fixture -
  # so both must end up disambiguated (_1/_2) rather than one silently
  # overwriting the other's output file.
  expect_false(grepl("[0-9a-f]{8}-[0-9a-f]{4}", nodes[[duty_key]]$custom_name),
    label = "generated name must not just be the GUID re-prefixed"
  )
  expect_match(nodes[[duty_key]]$custom_name, "^_WIBU_Angebotsstatus_abfragen(_[12])?$")
  expect_match(nodes[[priv_key]]$custom_name, "^_WIBU_Angebotsstatus_abfragen(_[12])?$")
  expect_false(identical(nodes[[duty_key]]$custom_name, nodes[[priv_key]]$custom_name),
    label = "Duty and Privilege share a label in the real data - must not collide on disk"
  )
  expect_true(any(grepl("Name collision", report$warnings, fixed = TRUE)))

  # Files were actually written and pass the post-generation validation
  # (already run as part of engine$run()); re-check existence directly too.
  expect_true(length(report$generated_xml_files) >= 3)
  expect_true(all(file.exists(report$generated_xml_files)))

  # The Role's other 5 duty references and 9 privilege references (not
  # part of this SQL hierarchy) must remain untouched, not swept up into
  # the customization.
  expect_false(exists(get_node_key("EcoResProductDefinitionMasterInquire", "Duty"), envir = nodes, inherits = FALSE),
    label = "duties outside the SQL scope must never become graph nodes at all"
  )
})
