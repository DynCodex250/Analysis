testthat::test_that(
  "Privilege XML roundtrip works",
  {

    # =====================================
    # XML-DATEIEN ERMITTELN
    # =====================================

    #xml_folder <- "C:\\Users\\ckam_admin\\Documents\\RProjects\\Sicherheitsobjekte\\WIBU\\AxSecurityPrivilege"
    xml_folder <-  "testdata/Privileges"

    privilege_files <- list.files(
      testthat::test_path(
        xml_folder
      ),
      pattern    = "\\.xml$",
      full.names = TRUE
    )

    # =====================================
    # NUR PRIVILEGES VERARBEITEN
    # =====================================

    privilege_files_Filtered <- privilege_files[
      purrr::map_lgl(
        privilege_files,
        ~ is_security_object_xml(
          xml_file    = .x,
          object_type = "AxSecurityPrivilege"
        )
      )
    ]

    # =====================================
    # SICHERSTELLEN, DASS DATEIEN
    # VORHANDEN SIND
    # =====================================

    expect_gt(length(privilege_files_Filtered), 0)

    # =====================================
    # ROUNDTRIP TEST
    # =====================================

    for (xml_file in privilege_files_Filtered) {

      temp_xml <- tempfile(fileext = ".xml")

      original_model <- parse_privilege(xml_file)

      generate_privilege_xml(
        privilege_model = original_model,
        output_file     = temp_xml
      )

      expect_true(
        isTRUE(
          compare_privilege_roundtrip_model(
            original_xml  = xml_file,
            generated_xml = temp_xml
          )
        ),
        info = basename(xml_file)
      )

    }

  }

)




# expect_true(
#
#   isTRUE(
#
#     compare_privilege_roundtrip_model(
#       original_xml  = xml_file,
#       generated_xml = temp_xml
#     )
#
#   ),
#
#   info = basename(
#     xml_file
#   )
#
# )
# expect_equal(
