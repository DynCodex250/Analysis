# ================================================
# TESTDATEN
# ================================================

xml_with_forms <- xml2::read_xml('
<AxSecurityPrivilege>
  <EntryPoints>
    <AxSecurityEntryPointReference>
      <Name>SalesOrderView_MenuItemDisplay</Name>
      <Forms>
        <AxSecurityEntryPointReferenceForm>
          <Name>SalesTable</Name>
        </AxSecurityEntryPointReferenceForm>
        <AxSecurityEntryPointReferenceForm>
          <Name>SalesLine</Name>
        </AxSecurityEntryPointReferenceForm>
      </Forms>
    </AxSecurityEntryPointReference>
    <AxSecurityEntryPointReference>
      <Name>SalesOrderCreate_MenuItemDisplay</Name>
      <Forms>
        <AxSecurityEntryPointReferenceForm>
          <Name>SalesCreateOrder</Name>
        </AxSecurityEntryPointReferenceForm>
      </Forms>
    </AxSecurityEntryPointReference>
  </EntryPoints>
</AxSecurityPrivilege>
')

xml_without_forms <- xml2::read_xml('
<AxSecurityPrivilege>
  <EntryPoints>
    <AxSecurityEntryPointReference>
      <Name>SalesOrderView_MenuItemDisplay</Name>
      <Forms/>
    </AxSecurityEntryPointReference>
  </EntryPoints>
</AxSecurityPrivilege>
')

xml_no_entrypoints <- xml2::read_xml('
<AxSecurityPrivilege>
  <EntryPoints/>
</AxSecurityPrivilege>
')

# ================================================
# STRUKTUR
# ================================================

testthat::test_that("extract_forms gibt Tibble mit korrekten Spalten zurück", {
  result <- extract_forms(xml_with_forms)
  expect_true(tibble::is_tibble(result))
  expect_named(result, c("entrypoint", "form_name"))
})

# ================================================
# ANZAHL
# ================================================

testthat::test_that("extract_forms liefert korrekte Anzahl Formulare", {
  result <- extract_forms(xml_with_forms)
  expect_equal(nrow(result), 3)
})

# ================================================
# INHALT
# ================================================

testthat::test_that("extract_forms liest Formularnamen korrekt aus", {
  result <- extract_forms(xml_with_forms)
  expect_equal(
    result$form_name,
    c("SalesTable", "SalesLine", "SalesCreateOrder")
  )
})

testthat::test_that("extract_forms weist Formulare korrekt den EntryPoints zu", {
  result <- extract_forms(xml_with_forms)

  expect_equal(
    result$entrypoint[result$form_name == "SalesTable"],
    "SalesOrderView_MenuItemDisplay"
  )
  expect_equal(
    result$entrypoint[result$form_name == "SalesLine"],
    "SalesOrderView_MenuItemDisplay"
  )
  expect_equal(
    result$entrypoint[result$form_name == "SalesCreateOrder"],
    "SalesOrderCreate_MenuItemDisplay"
  )
})

# ================================================
# LEERE ERGEBNISSE
# ================================================

testthat::test_that("extract_forms gibt leeres Tibble zurück wenn keine Formulare vorhanden", {
  result <- extract_forms(xml_without_forms)
  expect_true(tibble::is_tibble(result))
  expect_equal(nrow(result), 0)
})

testthat::test_that("extract_forms gibt leeres Tibble zurück wenn keine EntryPoints vorhanden", {
  result <- extract_forms(xml_no_entrypoints)
  expect_true(tibble::is_tibble(result))
  expect_equal(nrow(result), 0)
})

# ================================================
# FEHLERBEHANDLUNG
# ================================================

testthat::test_that("extract_forms bricht bei ungültigem Input ab", {
  expect_error(extract_forms(NULL))
  expect_error(extract_forms(list()))
  expect_error(extract_forms(42L))
})
