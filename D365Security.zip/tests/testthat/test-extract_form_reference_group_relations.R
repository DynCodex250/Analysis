# ================================================
# HILFSFUNKTION: Testmodell erstellen
# ================================================

make_form_model_with_reference_groups <- function() {

  controls <- tibble::tibble(
    Name = c("CustAccount_RG", "ItemId_RG"),
    Type = c("ReferenceGroup", "ReferenceGroup"),
    Parent = c("HeaderGroup", "LineGroup"),
    Path = c(
      "HeaderGroup/CustAccount_RG",
      "LineGroup/ItemId_RG"
    ),
    Properties = list(
      list(
        DataSource            = "SalesTable",
        ReferenceField        = "CustAccount",
        ReplacementFieldGroup = "AccountNum",
        Label                 = "Kundenkonto"
      ),
      list(
        DataSource            = "SalesLine",
        ReferenceField        = "ItemId",
        ReplacementFieldGroup = "ItemName",
        Label                 = "Artikel"
      )
    )
  )

  result <- list(
    Metadata    = list(Name = "SalesTable"),
    DataSources = tibble::tibble(
      Name             = c("SalesTable", "SalesLine"),
      Table            = c("SalesTable", "SalesLine"),
      JoinSource       = c(NA_character_, NA_character_),
      ParentDataSource = c(NA_character_, "SalesTable")
    ),
    Controls = controls,
    Parts    = tibble::tibble(
      Name         = character(),
      PartType     = character(),
      MenuItemName = character()
    )
  )
  class(result) <- c("D365FormModel", "list")
  result
}

make_form_model_no_reference_groups <- function() {

  controls <- tibble::tibble(
    Name       = c("SalesGrid"),
    Type       = c("Grid"),
    Parent     = c(NA_character_),
    Path       = c("SalesGrid"),
    Properties = list(list(DataSource = "SalesTable"))
  )

  result <- list(
    Metadata    = list(Name = "SalesTable"),
    DataSources = tibble::tibble(
      Name             = "SalesTable",
      Table            = "SalesTable",
      JoinSource       = NA_character_,
      ParentDataSource = NA_character_
    ),
    Controls = controls,
    Parts    = tibble::tibble(
      Name         = character(),
      PartType     = character(),
      MenuItemName = character()
    )
  )
  class(result) <- c("D365FormModel", "list")
  result
}

# ================================================
# STRUKTUR
# ================================================

testthat::test_that(
  "extract_form_reference_group_relations gibt Tibble mit korrekten Spalten zurück", {

  result <- extract_form_reference_group_relations(
    make_form_model_with_reference_groups()
  )

  expect_true(tibble::is_tibble(result))
  expect_named(
    result,
    c("Name", "DataSource", "ReferenceField",
      "ReplacementFieldGroup", "Label", "Parent", "Path")
  )
})

# ================================================
# ANZAHL
# ================================================

testthat::test_that(
  "extract_form_reference_group_relations liefert korrekte Anzahl ReferenceGroups", {

  result <- extract_form_reference_group_relations(
    make_form_model_with_reference_groups()
  )

  expect_equal(nrow(result), 2)
})

# ================================================
# INHALT
# ================================================

testthat::test_that(
  "extract_form_reference_group_relations liest Namen korrekt aus", {

  result <- extract_form_reference_group_relations(
    make_form_model_with_reference_groups()
  )

  expect_equal(result$Name, c("CustAccount_RG", "ItemId_RG"))
})

testthat::test_that(
  "extract_form_reference_group_relations liest Properties korrekt aus", {

  result <- extract_form_reference_group_relations(
    make_form_model_with_reference_groups()
  )

  expect_equal(result$DataSource,    c("SalesTable", "SalesLine"))
  expect_equal(result$ReferenceField, c("CustAccount", "ItemId"))
  expect_equal(
    result$ReplacementFieldGroup,
    c("AccountNum", "ItemName")
  )
  expect_equal(result$Label, c("Kundenkonto", "Artikel"))
})

testthat::test_that(
  "extract_form_reference_group_relations übernimmt Parent und Path korrekt", {

  result <- extract_form_reference_group_relations(
    make_form_model_with_reference_groups()
  )

  expect_equal(result$Parent, c("HeaderGroup", "LineGroup"))
  expect_equal(
    result$Path,
    c("HeaderGroup/CustAccount_RG", "LineGroup/ItemId_RG")
  )
})

# ================================================
# LEERE ERGEBNISSE
# ================================================

testthat::test_that(
  "extract_form_reference_group_relations gibt leeres Tibble zurück wenn keine ReferenceGroups vorhanden", {

  result <- extract_form_reference_group_relations(
    make_form_model_no_reference_groups()
  )

  expect_true(tibble::is_tibble(result))
  expect_equal(nrow(result), 0)
  expect_named(
    result,
    c("Name", "DataSource", "ReferenceField",
      "ReplacementFieldGroup", "Label", "Parent", "Path")
  )
})

# ================================================
# FEHLERBEHANDLUNG
# ================================================

testthat::test_that(
  "extract_form_reference_group_relations bricht bei ungültigem Input ab", {

  expect_error(extract_form_reference_group_relations(list()))
  expect_error(extract_form_reference_group_relations(NULL))
  expect_error(extract_form_reference_group_relations("kein Modell"))
})
