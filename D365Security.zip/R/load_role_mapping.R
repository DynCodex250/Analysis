#' WIBU-Rollenmapping laden
#'
#' Liest alle WIBU-Rollen aus SECURITYROLE
#' und erzeugt eine Zuordnungstabelle
#' zwischen Dev-Rollen (AOT/Visual Studio)
#' und Config-Rollen (UI-erstellt).
#'
#' Unterscheidung:
#'
#' \describe{
#'   \item{Dev-Rolle}{
#'   AOTNAME enthält "WIBU".
#'   Technischer Identifier, leicht lesbar.
#'   Rollenname enthält optional ein Suffix
#'   in Klammern (z.B. "(\_WIBU\_Fibu\_Finanzbuchhaltung)").
#'   }
#'   \item{Config-Rolle}{
#'   AOTNAME enthält kein "WIBU",
#'   aber NAME enthält "WIBU".
#'   Identifier ist ein GUID oder
#'   systemgenerierter alphanumerischer Wert.
#'   }
#' }
#'
#' Mapping-Logik:
#'
#' Der Rollenname der Dev-Rolle wird bereinigt
#' (Klammer-Suffix entfernt) und mit dem
#' unveränderten Namen der Config-Rolle verglichen.
#'
#' Nur vollständige Matches werden zurückgegeben
#' (kein NULL-DEVIDENT oder NULL-CONFIDENT).
#'
#' @param connection DBI-Verbindung zur D365FO-Datenbank.
#'
#' @return Tibble mit vier Spalten:
#'
#' \describe{
#'   \item{CONFIDENT}{AOTNAME der Config-Rolle (GUID / systemgeneriert).}
#'   \item{CONFROLE}{Anzeigename der Config-Rolle.}
#'   \item{DEVIDENT}{AOTNAME der Dev-Rolle (lesbarer Identifier).}
#'   \item{DEVROLE}{Anzeigename der Dev-Rolle (mit Klammer-Suffix).}
#' }
#'
#' @details
#' Das Ergebnis kann direkt als `roleMapping`-Argument
#' an `compare_all_roles()` übergeben werden.
#'
#' Config-Rollen ohne passende Dev-Rolle und
#' Dev-Rollen ohne passende Config-Rolle
#' werden nicht zurückgegeben.
#'
#' @examples
#' \dontrun{
#'
#' mapping <- load_role_mapping(connection)
#'
#' mapping
#'
#' compare_all_roles(
#'   roleMapping   = mapping,
#'   ConfigFolder  = "path/to/ConfigRoles",
#'   DevFolder     = "path/to/DevRoles",
#'   outputFile    = "RoleComparison.xlsx"
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{compare_all_roles}}
#' \code{\link{compare_security_roles}}
#'
#' @export

load_role_mapping <- function(connection) {

  sql <- "
WITH BaseRoles AS (
    SELECT
        SR.AOTNAME,
        SR.NAME
    FROM SECURITYROLE SR
),

ConfigRoles AS (
    SELECT
        AOTNAME AS CONFIDENT,
        NAME    AS CONFROLE,
        NAME    AS NAME2
    FROM BaseRoles
    WHERE AOTNAME NOT LIKE '%WIBU%'
      AND NAME     LIKE '%WIBU%'
),

DevRoles AS (
    SELECT
        AOTNAME AS DEVIDENT,
        NAME    AS DEVROLE,
        LTRIM(RTRIM(
            CASE
                WHEN CHARINDEX('(', NAME) > 0
                THEN LEFT(NAME, CHARINDEX('(', NAME) - 1)
                ELSE NAME
            END
        )) AS NAME2
    FROM BaseRoles
    WHERE AOTNAME LIKE '%WIBU%'
),

Mapping AS (
    SELECT
        c.CONFIDENT,
        c.CONFROLE,
        d.DEVIDENT,
        d.DEVROLE
    FROM ConfigRoles c
    LEFT JOIN DevRoles d
        ON d.NAME2 = c.NAME2
)

SELECT *
FROM Mapping
WHERE DEVIDENT IS NOT NULL
ORDER BY CONFROLE ASC
"

  result <- DBI::dbGetQuery(connection, sql)

  tibble::as_tibble(result)

}
