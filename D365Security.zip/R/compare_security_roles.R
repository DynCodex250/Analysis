#' Zwei D365FO Security-Rollen vergleichen
#'
#' Vergleicht zwei D365FO Security-Rollen anhand ihrer
#' XML-Definitionen.
#'
#' Die Funktion liest beide AxSecurityRole XML-Dateien ein
#' und analysiert Unterschiede in den enthaltenen
#' Security-Objekten.
#'
#' Verglichen werden:
#'
#' * Duties
#' * Privileges
#' * SubRoles
#' * Direct Access Permissions
#'
#' Für jede Ebene werden ermittelt:
#'
#' * Objekte nur in Rolle 1
#' * Objekte nur in Rolle 2
#' * Gemeinsame Objekte
#'
#' Die Funktion eignet sich insbesondere für:
#'
#' * Vergleich von Standard- und Kundenrollen
#' * Regressionstests
#' * Rollenmigrationen
#' * Security Reviews
#' * Analyse von Berechtigungsänderungen
#'
#' @param role_file_1
#' Pfad zur ersten AxSecurityRole XML-Datei.
#'
#' @param role_file_2
#' Pfad zur zweiten AxSecurityRole XML-Datei.
#'
#' @details
#'
#' Die Funktion liest beide XML-Dateien mittels
#' xml2::read_xml() ein.
#'
#' Anschließend werden folgende XML-Bereiche ausgewertet:
#'
#' * Duties
#' * Privileges
#' * SubRoles
#' * DirectAccessPermissions
#'
#' Der Vergleich erfolgt ausschließlich anhand der
#' Namen der referenzierten Security-Objekte.
#'
#' Die XML-Dateien müssen dem Standardformat
#' einer AxSecurityRole entsprechen.
#'
#' @return
#'
#' Liste mit folgenden Elementen:
#'
#' \describe{
#'
#' \item{role_1}{
#' Name der ersten Rolle.
#' }
#'
#' \item{role_2}{
#' Name der zweiten Rolle.
#' }
#'
#' \item{duties}{
#' Vergleich der Duties.
#' }
#'
#' \item{privileges}{
#' Vergleich der Privileges.
#' }
#'
#' \item{subroles}{
#' Vergleich der SubRoles.
#' }
#'
#' \item{direct_access_permissions}{
#' Vergleich der Direct Access Permissions.
#' }
#'
#' }
#'
#' Jede Vergleichsebene enthält:
#'
#' \preformatted{
#' only_in_role_1
#' only_in_role_2
#' common
#' }
#'
#' @examples
#' \dontrun{
#'
#' comparison <-
#'   compare_security_roles(
#'     role_file_1 =
#'       "SalesManager.xml",
#'     role_file_2 =
#'       "_WIBU SalesManager.xml"
#'   )
#'
#' comparison$duties$only_in_role_1
#'
#' comparison$privileges$common
#'
#' comparison$subroles$only_in_role_2
#'
#' comparison$direct_access_permissions$common
#'
#' }
#'
#' @seealso
#' \code{\link{compare_sql_security_hierarchies}}
#'
#' @export
#' 

compare_security_roles <- function(
    role_file_1,
    role_file_2){
  
  #====================================================
  # XML LADEN
  #====================================================
  
  role_1 <- xml2::read_xml(role_file_1)
  
  role_2 <- xml2::read_xml(role_file_2)
  
  #====================================================
  # ROLLENNAME
  #====================================================
  
  role_name_1 <- xml2::xml_text(
    xml2::xml_find_first(
      role_1,
      "//Name"
    )
  )
  
  role_name_2 <- xml2::xml_text(
    xml2::xml_find_first(
      role_2,
      "//Name"
    )
  )
  
  #====================================================
  # DUTIES
  #====================================================
  
  duties_1 <-
    xml2::xml_find_all(
      role_1,
      "//Duties/AxSecurityDutyReference/Name"
    ) %>%
    xml2::xml_text()
  
  duties_2 <-
    xml2::xml_find_all(
      role_2,
      "//Duties/AxSecurityDutyReference/Name"
    ) %>%
    xml2::xml_text()
  
  #====================================================
  # PRIVILEGES
  #====================================================
  
  privileges_1 <-
    xml2::xml_find_all(
      role_1,
      "//Privileges/AxSecurityPrivilegeReference/Name"
    ) %>%
    xml2::xml_text()
  
  privileges_2 <-
    xml2::xml_find_all(
      role_2,
      "//Privileges/AxSecurityPrivilegeReference/Name"
    ) %>%
    xml2::xml_text()
  
  #====================================================
  # SUBROLES
  #====================================================
  
  subroles_1 <-
    xml2::xml_find_all(
      role_1,
      "//SubRoles/AxSecurityRoleReference/Name"
    ) %>%
    xml2::xml_text()
  
  subroles_2 <-
    xml2::xml_find_all(
      role_2,
      "//SubRoles/AxSecurityRoleReference/Name"
    ) %>%
    xml2::xml_text()
  
  #====================================================
  # DIRECT ACCESS PERMISSIONS
  #====================================================
  
  dap_1 <-
    xml2::xml_find_all(
      role_1,
      "//DirectAccessPermissions//*[local-name()='Name']"
    ) %>%
    xml2::xml_text()
  
  dap_2 <-
    xml2::xml_find_all(
      role_2,
      "//DirectAccessPermissions//*[local-name()='Name']"
    ) %>%
    xml2::xml_text()
  
  #====================================================
  # DUTY DIFF
  #====================================================
  
  duties_only_in_role_1 <-
    setdiff(
      duties_1,
      duties_2
    )
  
  duties_only_in_role_2 <-
    setdiff(
      duties_2,
      duties_1
    )
  
  #====================================================
  # PRIVILEGE DIFF
  #====================================================
  
  privileges_only_in_role_1 <-
    setdiff(
      privileges_1,
      privileges_2
    )
  
  privileges_only_in_role_2 <-
    setdiff(
      privileges_2,
      privileges_1
    )
  
  #====================================================
  # SUBROLE DIFF
  #====================================================
  
  subroles_only_in_role_1 <-
    setdiff(
      subroles_1,
      subroles_2
    )
  
  subroles_only_in_role_2 <-
    setdiff(
      subroles_2,
      subroles_1
    )
  
  #====================================================
  # DAP DIFF
  #====================================================
  
  dap_only_in_role_1 <-
    setdiff(
      dap_1,
      dap_2
    )
  
  dap_only_in_role_2 <-
    setdiff(
      dap_2,
      dap_1
    )
  
  #====================================================
  # ERGEBNIS
  #====================================================
  
  result <- list(
    
    role_1 = role_name_1,
    
    role_2 = role_name_2,
    
    duties = list(
      
      only_in_role_1 =
        duties_only_in_role_1,
      
      only_in_role_2 =
        duties_only_in_role_2,
      
      common =
        intersect(
          duties_1,
          duties_2
        )
    ),
    
    privileges = list(
      
      only_in_role_1 =
        privileges_only_in_role_1,
      
      only_in_role_2 =
        privileges_only_in_role_2,
      
      common =
        intersect(
          privileges_1,
          privileges_2
        )
    ),
    
    subroles = list(
      
      only_in_role_1 =
        subroles_only_in_role_1,
      
      only_in_role_2 =
        subroles_only_in_role_2,
      
      common =
        intersect(
          subroles_1,
          subroles_2
        )
    ),
    
    direct_access_permissions = list(
      
      only_in_role_1 =
        dap_only_in_role_1,
      
      only_in_role_2 =
        dap_only_in_role_2,
      
      common =
        intersect(
          dap_1,
          dap_2
        )
    )
  )
  
  return(result)
}