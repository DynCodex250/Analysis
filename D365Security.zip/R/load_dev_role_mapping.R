#' Dev-Rollenmapping laden (Dev als Basis)
#'
#' Erzeugt eine Zuordnungstabelle aus Sicht der Dev-Rollen.
#'
#' Jede Dev-Rolle bleibt erhalten.
#' Eine passende Config-Rolle wird ergänzt, sofern vorhanden.
#' Fehlt eine Config-Entsprechung, bleiben CONFIDENT und CONFROLE NULL.
#'
#' Dieser View dient der Qualitätsprüfung:
#'
#' Er zeigt Dev-Rollen, für die noch keine Config-Rolle
#' in D365FO angelegt wurde.
#'
#' Für den produktiven Batchvergleich (compare_all_roles)
#' wird stattdessen load_role_mapping() verwendet,
#' das nur erfolgreiche Matches zurückgibt.
#'
#' @param connection DBI-Verbindung zur D365FO-Datenbank.
#'
#' @return Tibble mit vier Spalten:
#'
#' \describe{
#'   \item{DEVIDENT}{AOTNAME der Dev-Rolle.}
#'   \item{DEVROLE}{Anzeigename der Dev-Rolle.}
#'   \item{CONFIDENT}{AOTNAME der Config-Rolle (NULL wenn kein Match).}
#'   \item{CONFROLE}{Anzeigename der Config-Rolle (NULL wenn kein Match).}
#' }
#'
#' @examples
#' \dontrun{
#'
#' dev_mapping <- load_dev_role_mapping(connection)
#'
#' # Dev-Rollen ohne Config-Entsprechung
#' dplyr::filter(dev_mapping, is.na(CONFIDENT))
#'
#' }
#'
#' @seealso
#' \code{\link{load_role_mapping}}
#' \code{\link{load_dev_roles}}
#' \code{\link{load_config_roles}}
#'
#' @export

load_dev_role_mapping <- function(connection) {

  sql <- "
WITH BaseRoles AS (
    SELECT
        SR.AOTNAME,
        SR.NAME
    FROM SECURITYROLE SR
),

ConfigRoles AS (
    SELECT
        AOTNAME AS CONFIDENT,
        NAME    AS CONFROLE,
        NAME    AS NAME2
    FROM BaseRoles
    WHERE AOTNAME NOT LIKE '%WIBU%'
      AND NAME     LIKE '%WIBU%'
),

DevRoles AS (
    SELECT
        AOTNAME AS DEVIDENT,
        NAME    AS DEVROLE,
        LTRIM(RTRIM(
            CASE
                WHEN CHARINDEX('(', NAME) > 0
                THEN LEFT(NAME, CHARINDEX('(', NAME) - 1)
                ELSE NAME
            END
        )) AS NAME2
    FROM BaseRoles
    WHERE AOTNAME LIKE '%WIBU%'
)

SELECT
    d.DEVIDENT,
    d.DEVROLE,
    c.CONFIDENT,
    c.CONFROLE
FROM DevRoles d
LEFT JOIN ConfigRoles c
    ON d.NAME2 = c.NAME2
ORDER BY d.DEVROLE ASC
"

  result <- DBI::dbGetQuery(connection, sql)

  tibble::as_tibble(result)

}
