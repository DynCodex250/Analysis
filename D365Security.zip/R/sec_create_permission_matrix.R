#' Berechtigungsmatrix erzeugen
#'
#' Erzeugt eine benutzerfreundliche Berechtigungsmatrix
#' auf Basis eines Security-Modells.
#'
#' Jede Zeile repräsentiert eine eindeutige Kombination aus:
#'
#' * Sicherheitsrolle
#' * Organisation
#'
#' Jede Benutzerspalte zeigt mittels
#' \code{"X"} an, ob der Benutzer die
#' entsprechende Rolle in der jeweiligen
#' Organisation besitzt.
#'
#' Die Funktion eignet sich insbesondere für:
#'
#' * Berechtigungsvergleiche
#' * Audit-Analysen
#' * Fachbereichsworkshops
#' * Rollenharmonisierungen
#' * Rezertifizierungen
#'
#' @details
#' Die Funktion erstellt zunächst eine
#' eindeutige Liste aller Kombinationen aus:
#'
#' * USERID
#' * SECURITYROLEIDENTIFIER
#' * ORGANIZATIONID
#'
#' Anschließend wird eine Matrix erzeugt, bei
#' der jeder Benutzer als eigene Spalte
#' dargestellt wird.
#'
#' Die technische Rollen-ID
#' (\code{SECURITYROLEIDENTIFIER})
#' bleibt bewusst Bestandteil der Matrix,
#' damit Rollen eindeutig identifiziert werden
#' können.
#'
#' Dies ist wichtig, da in Dynamics 365
#' Finance & Operations verschiedene Rollen
#' denselben Anzeigenamen
#' (\code{SECURITYROLENAME})
#' besitzen können, jedoch technisch
#' unterschiedliche Rollen darstellen.
#'
#' Nach dem Aufbau der Matrix werden die
#' lesbaren Rollennamen ergänzt und vor der
#' technischen Rollen-ID angezeigt.
#'
#' Somit enthält das Ergebnis sowohl:
#'
#' * die technische Rollen-ID
#' * den lesbaren Rollennamen
#'
#' und unterstützt sowohl technische als auch
#' fachliche Analysen.
#'
#' @param security_model Tibble mit den
#' konsolidierten Rollenzuweisungen.
#'
#' Erwartete Spalten:
#' * USERID
#' * SECURITYROLEIDENTIFIER
#' * SECURITYROLENAME
#' * ORGANIZATIONID
#'
#' @return Tibble.
#'
#' Die ersten Spalten des Ergebnisses sind:
#'
#' * SECURITYROLENAME
#' * SECURITYROLEIDENTIFIER
#' * ORGANIZATIONID
#'
#' Danach folgt für jeden Benutzer eine eigene
#' Spalte.
#'
#' Der Wert:
#'
#' \preformatted{
#' X
#' }
#' zeigt an, dass die entsprechende Rolle
#' vorhanden ist.
#'
#' Leere Werte bedeuten, dass die Rolle für
#' den Benutzer nicht vorhanden ist.
#'
#' @examples
#' \dontrun{
#' permission_matrix <-
#'   sec_create_permission_matrix(
#'     security_model
#'   )
#' }
#'
#' Beispielausgabe:
#'
#' \preformatted{
#' SECURITYROLENAME
#' _WIBU Einkauf Mitarbeiter_ReadOnly
#'
#' SECURITYROLEIDENTIFIER
#' C3B0DBE5-FDAE-4925-B162-21A3E0D04E2A
#'
#' ORGANIZATIONID
#' All
#'
#' s.o.
#' X
#'
#' s.t.
#' }
#'
#' Typische Verwendung:
#'
#' * Excel-Blatt
#'   02_RollenMatrix
#'
#' * Benutzervergleiche
#' * Berechtigungsanalysen
#' * Rollenharmonisierung
#' * Fachbereichsberichte
#'
#' @seealso
#' compare_user_permissions_fingerprint
#'
#' @seealso
#' compare_to_reference_user
#'
#' @seealso
#' compare_to_reference_user_details
#'
#' @seealso
#' create_permission_groups
#'
#' @export
sec_create_permission_matrix <- function(
  security_model
){
  security_model |>
    dplyr::distinct(
      USERID,
      SECURITYROLEIDENTIFIER,
      ORGANIZATIONID
    ) |>
    dplyr::mutate(
      HasPermission = "x"
    ) |>
    tidyr::pivot_wider(
      id_cols = c(
        SECURITYROLEIDENTIFIER,
        ORGANIZATIONID
      ),
      names_from =
        USERID,
      values_from =
        HasPermission#,values_fill = 0
    ) |>
    dplyr::arrange(
      SECURITYROLEIDENTIFIER,
      ORGANIZATIONID
    ) |>
    left_join(
      e |>
        distinct(
          SECURITYROLEIDENTIFIER,
          SECURITYROLENAME
        ),
      by = "SECURITYROLEIDENTIFIER"
    ) |>
    relocate(
      SECURITYROLENAME,
      .before =
        SECURITYROLEIDENTIFIER
    )
}
