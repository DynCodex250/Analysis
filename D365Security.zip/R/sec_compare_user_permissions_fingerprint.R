    #' Benutzerberechtigungen per Fingerprint vergleichen
#'
#' Erzeugt für jeden Benutzer einen
#' Berechtigungs-Fingerprint auf Basis von:
#'
#' * SECURITYROLEIDENTIFIER
#' * ORGANIZATIONID
#' * ORGANIZATIONTYPE
#'
#' Benutzer mit identischem Fingerprint
#' besitzen exakt dieselben Rollenzuweisungen.
#'
#' @details
#' Die Funktion filtert die Eingangsdaten auf die in \code{required_columns}
#' angegebenen Spalten. Die erste Spalte in \code{required_columns} wird als
#' Benutzeridentifikation (z. B. \code{USERID}) interpretiert. Alle weiteren
#' Spalten werden als Berechtigungsmerkmale verwendet.
#'
#' Für jeden Benutzer wird aus den Berechtigungsmerkmalen ein eindeutiger,
#' sortierter String (Fingerprint) erzeugt. Benutzer mit exakt dem gleichen
#' Fingerprint werden in Gruppen zusammengefasst.
#'
#' @param security_assignments Tibble aus
#' System security user role organization assignment.
#'
#' @param required_columns Vektor mit Spaltennamen. Die erste Spalte wird als
#' Benutzerkennung genutzt, alle weiteren zur Berechnungs des Fingerprints.
#'
#' @return Ein Tibble mit folgenden Spalten:
#' \itemize{
#'   \item \code{USERID} (oder der Name der ersten Spalte in \code{required_columns}): Die Benutzerkennung.
#'   \item \code{PermissionFingerprint}: Der berechnete Fingerprint als sortierter, semikolon-separierter String.
#'   \item \code{NumberOfAssignments}: Die Anzahl der Berechtigungszuweisungen für diesen Benutzer.
#'   \item \code{FingerprintGroup}: Numerische ID der Gruppe mit identischem Fingerprint.
#'   \item \code{UsersInGroup}: Anzahl der Benutzer in dieser Fingerprint-Gruppe.
#' }
#'
#' @examples
#' \dontrun{
#' res <- sec_compare_user_permissions_fingerprint(
#'   security_assignments = security_model,
#'   required_columns = c("USERID", "SECURITYROLEIDENTIFIER", "ORGANIZATIONID")
#' )
#' }
#'
#' @export
sec_compare_user_permissions_fingerprint <- function(
  security_assignments,
  required_columns
){
  #=============================================
  # VALIDIERUNG
  #=============================================
  missing_columns <- setdiff(
    required_columns,
    names(security_assignments)
  )

  if(length(missing_columns) > 0){
    stop(
      paste("Folgende Spalten fehlen:",
      paste(missing_columns, collapse = ", "))
    )
  }

  #=============================================
  # RELEVANTE SPALTEN
  #=============================================
  security_assignments <-
    security_assignments |>
    dplyr::select(
      dplyr::all_of(
        required_columns
      )
    )

  user_column <- required_columns[1]
  permission_columns <- required_columns[-1]

  #=============================================
  # FINGERPRINT
  #=============================================
  result <-
    security_assignments |>
    dplyr::distinct() |>
    dplyr::arrange(
      dplyr::across(
        dplyr::all_of(
          required_columns
        )
      )
    ) |>
    dplyr::rowwise() |>
    dplyr::mutate(
      PermissionEntry = paste(
        c_across(
          dplyr::all_of(
            permission_columns
          )
        ), collapse = "|"
      )
    ) |>
    dplyr::ungroup() |>
    dplyr::group_by(
      .data[[user_column]]
    ) |>
    dplyr::summarise(
      PermissionFingerprint = paste(
        sort(PermissionEntry),
        collapse = ";"
      ),
      NumberOfAssignments = dplyr::n(),
      .groups = "drop"
    )

  #=============================================
  # IDENTISCHE GRUPPEN
  #=============================================
  result <-
    result |>
    dplyr::group_by(
      PermissionFingerprint
    ) |>
    dplyr::mutate(
      FingerprintGroup = dplyr::cur_group_id(),
      UsersInGroup = dplyr::n()
    ) |>
    dplyr::ungroup()

  return(result)
}
