# =============================================================================
# R/data_roles_licensing.R
# Sections G, I, J, K of the brief: security structure (Role -> Duty ->
# Privilege -> Entry Point) and the licensing requirement / by-role views.
# =============================================================================

#' Load USERSECGOVRELATEDOBJECTS (the Role/Duty/Privilege/Entry Point/License
#' backbone). role_filter is an optional SQL LIKE pattern (NULL = all roles).
load_security_governance_objects <- function(cnn, sql_dir, role_filter = NULL) {
  run_readonly_query(
    cnn, file.path(sql_dir, "05_user_security_governance_objects.sql"),
    params = list(RoleNameFilter = role_filter)
  )
}

#' Load LICENSINGUSERLICENSESBYROLE
load_licensing_user_license_by_role <- function(cnn, sql_dir) {
  run_readonly_query(cnn, file.path(sql_dir, "04_licensing_user_license_by_role.sql"))
}

#' Load the three *_DETAILEDVIEW licensing tables
load_licensing_requirements <- function(cnn, sql_dir, entitled_only = TRUE) {
  list(
    role      = run_readonly_query(cnn, file.path(sql_dir, "06_licensing_role_requirements.sql"),
                                    params = list(EntitledOnly = entitled_only)),
    duty      = run_readonly_query(cnn, file.path(sql_dir, "07_licensing_duty_requirements.sql"),
                                    params = list(EntitledOnly = entitled_only)),
    privilege = run_readonly_query(cnn, file.path(sql_dir, "08_licensing_privilege_requirements.sql"),
                                    params = list(EntitledOnly = entitled_only))
  )
}

#' Normalize column names defensively: detailed views can vary slightly by
#' D365FO version. This helper only renames if the expected column is absent
#' and an unambiguous case-insensitive match exists; otherwise it leaves the
#' column missing and downstream code must handle NA / "UNKNOWN".
.normalize_licensing_columns <- function(df, expected = c("ENTITLED", "ACCESSLEVEL", "SKUNAME", "SECURITYROLE")) {
  for (col in expected) {
    if (!col %in% names(df)) {
      match_idx <- which(toupper(names(df)) == col)
      if (length(match_idx) == 1) names(df)[match_idx] <- col
    }
  }
  missing <- setdiff(expected, names(df))
  if (length(missing) > 0) {
    log_warn("data_roles_licensing", "expected column(s) missing, will be treated as UNKNOWN: %s",
              paste(missing, collapse = ", "))
    for (m in missing) df[[m]] <- NA
  }
  df
}

#' analyze_security_structure(): build the Role -> Duty -> Privilege ->
#' Entry Point -> Access Level -> License Requirement backbone used by all
#' downstream role/user analyses.
#'
#' @param secgov data.frame from load_security_governance_objects()
#' @param licensing_req list(role=, duty=, privilege=) from load_licensing_requirements()
#' @return data.frame, one row per (role, duty, privilege, entry point) tuple
#'         with license columns attached where resolvable, else UNKNOWN.
analyze_security_structure <- function(secgov, licensing_req) {
  role_req <- .normalize_licensing_columns(licensing_req$role)

  # USERSECGOVRELATEDOBJECTS column names vary by version; we defensively
  # look for the role name column rather than assuming exact casing.
  role_col_secgov <- names(secgov)[toupper(names(secgov)) == "ROLENAME"]
  role_col_req    <- names(role_req)[toupper(names(role_req)) == "SECURITYROLE"]

  if (length(role_col_secgov) != 1 || length(role_col_req) != 1) {
    log_warn("data_roles_licensing",
              "could not unambiguously identify role-name join columns; returning secgov unjoined (license columns = UNKNOWN)")
    secgov$ENTITLED   <- "UNKNOWN"
    secgov$ACCESSLEVEL <- "UNKNOWN"
    secgov$SKUNAME     <- "UNKNOWN"
    return(secgov)
  }

  merged <- merge(
    secgov, role_req,
    by.x = role_col_secgov, by.y = role_col_req,
    all.x = TRUE, suffixes = c("", "_LICREQ")
  )
  # Rows with no matching licensing requirement genuinely mean "not
  # licensing-relevant per this view", NOT "unknown" - but we still flag rows
  # where ENTITLED is NA (no requirement record at all) distinctly for the
  # data-quality checks (DQ-003 / DQ-004).
  merged$has_license_requirement_record <- !is.na(merged$ENTITLED)
  merged
}
