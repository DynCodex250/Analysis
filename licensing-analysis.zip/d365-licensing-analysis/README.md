# D365FO Licensing & Security Analysis Engine

A reproducible, read-only, evidence-based pipeline that automates the manual
D365 Finance & Operations licensing/security/telemetry analysis described in
the source document (`D365 Licensing Enforcement 2026 | Security Changes,
Telemetry Deep Dive, & Cost‑Saving Strategies`).

This is **not** a one-off script. It is an analysis platform: point it at an
environment (`run_analysis(environment = "PRJ")`), and it reads data, joins
it, generates findings with evidence and confidence levels, and writes an
Excel + Markdown report — without hand-editing SQL each time.

---

## 1. Source of Truth — how statements are classified

Every fact this pipeline reports is internally tagged into exactly one of
six categories (brief section 4). This distinction is preserved end-to-end,
including in the Findings report (`data_sources`, `reason`,
`recommended_validation` columns):

| # | Category | Example in this project |
|---|---|---|
| 1 | Directly read from D365FO SQL | `USERINFO.ENABLE`, `LICENSINGUSERLICENSESBYROLE` |
| 2 | From Application Insights / KQL | `pageViews` touches, `last_seen` |
| 3 | Rule described in the source document | "Service Role alone ⇒ no license" |
| 4 | Assumption | e.g. write-ratio threshold of 40% |
| 5 | Fachliche Interpretation | "role possibly oversized" |
| 6 | Needs Microsoft Licensing Documentation to verify | any concrete SKU price/ranking claim |

**No Microsoft licensing rule is invented.** Rules copied from the source
document (e.g. service-role logic, base/attach logic) are implemented
exactly as described, but every finding derived from them is explicitly
labelled `REQUIRES_VALIDATION` and never presented as a final licensing
verdict. Where data cannot answer a question, the result is `UNKNOWN` or
`REQUIRES_VALIDATION` — never guessed.

---

## 2. Architecture

```
config/
  config.yml              # non-secret runtime configuration (env, paths, telemetry window, ...)
  findings_rules.yml       # declarative Findings Engine rule catalogue (on/off, severity, params)
R/
  connection.R             # config loader + read-only SQL guard + get_connection() wrapper
  utils_logging.R          # structured logging + run_safely() fault isolation
  data_users.R             # USERINFO / SYSUSERINVALIDUSERS / SYSAADCLIENTTABLE
  data_roles_licensing.R   # USERSECGOVRELATEDOBJECTS + LICENSING*REQUIREMENTSDETAILEDVIEW
  data_telemetry.R         # Application Insights / KQL, configurable telemetry_days
  data_transaction_activity.R  # CreatedBy/ModifiedBy evidence (gated behind config)
  analyze_roles.R          # per-role metrics (Role Report)
  analyze_users_consolidated.R  # user<->role join, service/business classification, user profile
  confidence.R             # HIGH/MEDIUM/LOW/UNKNOWN scoring
  findings_engine.R        # FINDING-001..010 + DQ-001..009 evaluators, config-driven
  reporting_excel.R        # writexl-based Excel report
  reporting_markdown.R     # Markdown management/technical summary
  run_analysis.R           # single entry point: run_analysis(environment = "PRJ")
sql/                       # one file per query, all SELECT-only, parameterized
kql/                       # one file per KQL query, {{telemetry_days}} templated
tests/testthat/            # join-logic and rule unit tests (fixture-based, no live DB needed)
data/, reports/            # generated artifacts (git-ignored except .gitkeep)
```

Each analysis area is independently callable, e.g.:

```r
source("R/run_analysis.R")   # sources everything else too
cnn <- get_connection("PRJ", "path/to/db_credentials.xlsx")
cfg <- load_config("config")
users <- load_users(cnn, "sql")
profile <- analyze_users(users, load_invalid_users(cnn, "sql"), load_application_users(cnn, "sql"))
```

or simply:

```r
run_analysis(environment = "PRJ")
# or from the shell:
# Rscript R/run_analysis.R PRJ
```

### Existing project code

This pipeline was built without a companion repository being provided to
inspect (no repo/files were attached to the automation request — only the
source Markdown). It therefore:

- **Reuses, rather than re-implements, `get_connection()`.** `R/connection.R`
  calls the host project's existing `get_connection(environment,
  credentials_path)` (as already used in the source RMarkdown) and throws a
  clear, actionable error if it isn't found in the session, instead of
  silently stubbing a second connection implementation.
- **Reuses `writexl`**, already imported in the source document, for the
  Excel report rather than adding a new Excel dependency.
- Everywhere else a genuinely new function was needed (SQL query wrappers,
  join logic, findings engine, reporting), it was written fresh because no
  prior implementation was available to inspect. **If/when this is dropped
  into the real project repository, re-run Phase 1/2 (see §7) against the
  actual codebase** and fold in any existing SQL helper functions, Excel
  export utilities, or test infrastructure that already exist there, to
  avoid duplicate implementations (brief section 14/23).

---

## 3. Read-only guarantee

- Every `.sql` file under `sql/` contains only `SELECT` statements.
- `guard_readonly_sql()` (`R/connection.R`) scans the **final, parameter-substituted**
  SQL text for `INSERT / UPDATE / DELETE / MERGE / ALTER / DROP / TRUNCATE /
  CREATE / EXEC / GRANT / REVOKE / INTO OUTFILE` (case-insensitive, comment-stripped)
  before every single query execution and aborts if any are found.
- `run_readonly_query()` is the **only** path used by all `load_*()` functions
  to reach the database — there is no other code path that sends SQL.
- Credentials are never stored in this repository; `config.yml` only stores a
  *path* to a credentials file, and Application Insights keys are read from
  environment variables named in config, never hard-coded.

---

## 4. Configuration (`config/config.yml`)

Nothing environment-specific is hard-coded in R/SQL/KQL. In particular:

| Previously hard-coded in the source doc | Now configurable via |
|---|---|
| `"PRJ"` environment name | `run_analysis(environment = ...)` |
| `db_credentials.xlsx` path | `config.connection.credentials_path` |
| `ago(14day)` / `ago(700d)` | `config.telemetry.telemetry_days` |
| App Insights App ID / API key | env vars named in `config.telemetry.app_insights_env_var` / `api_key_env_var` |
| `ROLENAME LIKE '_WIBU QM Mitarbeiter'` | `RoleNameFilter` parameter (NULL = all roles) |
| Service role name list | `config.licensing.service_roles` |
| Output file names | `config.output.excel_filename` / `markdown_filename` (templated) |

For local secrets/paths that must not be committed, create
`config/config.local.yml` with the same `default:` structure — values there
override `config.yml` at runtime (see `.gitignore`).

---

## 5. Findings Engine

Findings are declared in `config/findings_rules.yml` (id, title, severity,
default confidence, evaluator function name, data sources, optional
parameters, active flag) and *evaluated* by matching R functions in
`R/findings_engine.R`. This split means:

- Turning a rule off, or re-grading its severity, is a config change.
- The actual join/comparison logic stays in tested R code (brief section 20).
- Every finding row carries: `finding_id, severity, confidence, user, role,
  object, finding, evidence, data_sources, reason, recommended_validation`.

Implemented rules: **FINDING-001** through **FINDING-010** (see brief §9),
plus **DQ-001..DQ-009** data-quality checks (brief §19). `FINDING-009`
(unusual role combination) and `DQ-004` are implemented as *documented,
inactive-by-default extension points* rather than fabricated, because they
require a role→functional-area taxonomy / an unfiltered requirements load
that were not present in the source data — see inline comments in
`findings_engine.R`.

### Confidence policy (`R/confidence.R`)

```
HIGH    SQL data + Security Analysis structure + Telemetry all agree
MEDIUM  only SQL/Security-structure data supports the claim
LOW     only a heuristic/assumption supports the claim
UNKNOWN required data is missing entirely
```

### Never-do rules enforced in code (brief section 11)

- No telemetry ⇒ `activity_evidence_status` is one of the explicit
  "...NOT_CONFIRMED_INACTIVE" states, **never** "inactive" (`analyze_users_consolidated.R`).
- Service Role alone ⇒ labelled `..._REQUIRES_VALIDATION`, never "no license" as fact.
- Expensive license requirement present ⇒ only ever phrased as a "potential
  license driver" finding with `recommended_validation`, never "user needs
  this license".

---

## 6. Reports

- **Excel** (`reports/D365_Licensing_Security_Report_<env>_<date>.xlsx`):
  `Run Info`, `User Report`, `Role Report`, `License Driver Report`, `Findings`.
- **Markdown** (`reports/....md`): management/technical summary (counts by
  severity/confidence, top license drivers, most complex roles, known
  limitations) — not a raw data dump; raw tables live in the Excel file.
- **Log** (`reports/logs/run_log_<env>_<date>.csv`): timestamped start/finish
  per module, row counts, warnings, errors — brief section 18.

---

## 7. Implementation phases (brief section 22) — status

| Phase | Status |
|---|---|
| 1. Analyze source Markdown | Done — this README's §1/§5 and `findings_rules.yml` trace every finding back to a source-document section. |
| 2. Identify existing data sources/functions | Partially done — no companion repo was supplied; `get_connection()`/`writexl` reuse is assumed per the source doc's own code. Re-run against the real repo before production use. |
| 3. Target data model | Done — see `R/data_roles_licensing.R::analyze_security_structure()` (Role→Duty→Privilege→EntryPoint→License backbone). |
| 4. Analysis functions | Done for all data sources named in the brief; transaction-activity and unusual-role-combination are explicit `REQUIRES_VALIDATION`/extension points (no table names invented). |
| 5. Findings Engine | Done — config-driven, 19 rules implemented/registered. |
| 6. Reporting | Done — Excel + Markdown. |
| 7. Tests | Done for the highest-risk joins (security structure, role metrics, user/invalid-user join, role classification, confidence, FINDING-001/004). Extend as new evaluators are added. |
| 8. End-to-end test with test data | **Not run** — no R runtime was available in the authoring environment (see §8). Fixture-based `testthat` tests were authored and reviewed instead; run `Rscript -e "testthat::test_dir('tests/testthat')"` in an environment with R + a live/staged DB before production use. |

---

## 8. Known limitations / what still needs validation before production use

1. **No live D365FO connection was available while building this.** SQL/KQL
   was written to match the exact tables/columns/paths named in the source
   document, but column names in `USERSECGOVRELATEDOBJECTS` and the
   `*_DETAILEDVIEW` tables can vary slightly by D365FO version — the join
   code in `analyze_security_structure()` / `analyze_role_metrics()` looks up
   columns case-insensitively and degrades to `UNKNOWN` rather than failing
   silently, but this should be validated against a real extract.
2. **Transaction activity (brief §8) is gated behind explicit configuration**
   (`config.transaction_activity.tables`) because no concrete table was named
   in the source document. Until configured, users are correctly reported as
   `activity_evidence_status = UNKNOWN`, not "inactive".
3. **User↔Role linkage** is derived from `USERSECGOVRELATEDOBJECTS` if it
   carries a user identifier column; if not, `analyze_user_roles()` returns
   `UNKNOWN_NO_USER_ROLE_LINK` and documents the "Security User Role
   Association" data entity as the fallback source to wire in.
4. **"Most expensive license" per role** is intentionally *not* computed as a
   single value when a role maps to multiple SKUs — there is no authoritative
   SKU price ranking in the source data, so this is reported as
   `REQUIRES_VALIDATION_MULTIPLE_SKUS` rather than guessed.
5. **Service-role licensing rules** (service-only ⇒ no license, business+service
   ⇒ license, System Administrator special case) are implemented exactly as
   described in the source document but are explicitly flagged as unverified
   against current Microsoft licensing documentation in every related finding.
6. **Tests were authored but not executed** (no R interpreter in the authoring
   sandbox). Run the suite and fix any environment-specific column-name
   mismatches before relying on this in production.
7. **Rebuilding Security Analysis** (source doc: "15–20 minutes") is a manual
   prerequisite step in D365FO itself and is outside this pipeline's scope;
   document it as an operational runbook step before `run_analysis()`.

---

## 9. Data quality checks (brief §19)

Implemented as `DQ-001`..`DQ-009` findings (same engine, same report) —
missing User IDs, duplicate role assignments, roles without requirements,
telemetry rows with unmapped users, users without roles, roles without
privileges, privileges without entry points, entry points without license
info. `DQ-004` (requirement without matching role) is a documented extension
point requiring an *unfiltered* `ENTITLED`-inclusive load, see comment in
`findings_engine.R`.

---

## 10. Extending this pipeline

- **New finding**: add an entry to `config/findings_rules.yml`, implement a
  matching `rule_*`/`dq_*` function in `R/findings_engine.R`, register it in
  the `evaluators` list inside `generate_findings()`, and add a unit test.
- **New data source**: add a `.sql`/`.kql` file with a header comment
  documenting its source-document section, a `load_*()` wrapper, and wire it
  into `run_analysis.R`'s Load section with `run_safely()`.
- **New environment**: no code change needed — `run_analysis(environment =
  "NEW_ENV")`, provided `get_connection()` can resolve credentials for it.
