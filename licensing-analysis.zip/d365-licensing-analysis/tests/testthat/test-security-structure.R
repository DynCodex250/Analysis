test_that("analyze_security_structure joins role requirements onto secgov rows correctly", {
  secgov <- data.frame(
    ROLENAME = c("RoleA", "RoleA", "RoleB"),
    DUTYNAME = c("DutyA1", "DutyA1", "DutyB1"),
    PRIVILEGENAME = c("PrivA1", "PrivA2", "PrivB1"),
    ENTRYPOINTNAME = c("EPA1", "EPA2", "EPB1"),
    stringsAsFactors = FALSE
  )
  role_req <- data.frame(
    SECURITYROLE = c("RoleA", "RoleB"),
    ENTITLED = c(1, 0),
    ACCESSLEVEL = c("CREATE", "READ"),
    SKUNAME = c("Finance", NA),
    stringsAsFactors = FALSE
  )

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))

  expect_equal(nrow(out), 3)
  expect_true(all(out$ENTITLED[out$ROLENAME == "RoleA"] == 1))
  expect_true(all(out$has_license_requirement_record))
})

test_that("analyze_security_structure marks rows without a matching role requirement", {
  secgov <- data.frame(ROLENAME = "RoleZ", DUTYNAME = "D1", PRIVILEGENAME = "P1", ENTRYPOINTNAME = "E1", stringsAsFactors = FALSE)
  role_req <- data.frame(SECURITYROLE = "RoleA", ENTITLED = 1, ACCESSLEVEL = "READ", SKUNAME = "Finance", stringsAsFactors = FALSE)

  out <- analyze_security_structure(secgov, list(role = role_req, duty = data.frame(), privilege = data.frame()))
  expect_false(out$has_license_requirement_record[out$ROLENAME == "RoleZ"])
})

test_that("analyze_role_metrics computes duty/privilege/entry-point counts and write ratio correctly", {
  sec <- data.frame(
    ROLENAME = c("RoleA", "RoleA", "RoleA", "RoleB"),
    DUTYNAME = c("D1", "D1", "D2", "D3"),
    PRIVILEGENAME = c("P1", "P2", "P3", "P4"),
    ENTRYPOINTNAME = c("EP1", "EP2", "EP3", "EP4"),
    ENTITLED = c(1, 1, 0, 1),
    ACCESSLEVEL = c("CREATE", "READ", "READ", "UPDATE"),
    SKUNAME = c("Finance", "Finance", NA, "Commerce"),
    stringsAsFactors = FALSE
  )

  out <- analyze_role_metrics(sec)
  role_a <- out[out$role == "RoleA", ]

  expect_equal(role_a$duty_count, 2)
  expect_equal(role_a$privilege_count, 3)
  expect_equal(role_a$entry_point_count, 3)
  expect_equal(role_a$license_relevant_entry_points, 2)  # only ENTITLED=1 rows
  expect_equal(role_a$write_entry_points, 1)
  expect_equal(role_a$read_entry_points, 1)
  # unknown_access counts the ENTITLED=0 / READ row -> classify_access_level("READ") = READ actually.
  expect_equal(role_a$distinct_license_types, 1)  # only 'Finance', NA excluded
})

test_that("analyze_role_metrics flags multiple distinct license SKUs on one role", {
  sec <- data.frame(
    ROLENAME = c("RoleMulti", "RoleMulti"),
    DUTYNAME = c("D1", "D2"), PRIVILEGENAME = c("P1", "P2"),
    ENTRYPOINTNAME = c("EP1", "EP2"),
    ENTITLED = c(1, 1), ACCESSLEVEL = c("READ", "READ"),
    SKUNAME = c("Finance", "Commerce"), stringsAsFactors = FALSE
  )
  out <- analyze_role_metrics(sec)
  expect_equal(out$distinct_license_types[out$role == "RoleMulti"], 2)
})

test_that("classify_access_level maps write operations correctly", {
  expect_equal(classify_access_level("CREATE"), "WRITE")
  expect_equal(classify_access_level("Update"), "WRITE")
  expect_equal(classify_access_level("READ"), "READ")
  expect_equal(classify_access_level(NA), "UNKNOWN")
})
