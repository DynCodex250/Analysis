-- =============================================================================
-- 06_licensing_role_requirements.sql
-- Purpose: Role-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 7 ("LICENSINGROLEREQUIREMENTSDETAILEDVIEW")
-- Params:  @EntitledOnly (bit, default 1) - if 1, restrict to ENTITLED = 1
--          rows as in the source doc example; pass 0 to also inspect
--          non-entitled rows for data-quality checks.
-- =============================================================================
SELECT *
FROM LICENSINGROLEREQUIREMENTSDETAILEDVIEW
WHERE (@EntitledOnly = 0 OR ENTITLED = 1);
