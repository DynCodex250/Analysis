-- =============================================================================
-- 08_licensing_privilege_requirements.sql
-- Purpose: Privilege-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 5.K of task brief / Section 7 of source document
-- =============================================================================
SELECT *
FROM LICENSINGPRIVILEGEREQUIREMENTSDETAILEDVIEW
WHERE (@EntitledOnly = 0 OR ENTITLED = 1);
