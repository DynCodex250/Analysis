-- =============================================================================
-- 07_licensing_duty_requirements.sql
-- Purpose: Duty-level licensing entitlement detail (READ-ONLY)
-- Source:  Section 5.K of task brief / Section 7 of source document
-- =============================================================================
SELECT *
FROM LICENSINGDUTYREQUIREMENTSDETAILEDVIEW
WHERE (@EntitledOnly = 0 OR ENTITLED = 1);
